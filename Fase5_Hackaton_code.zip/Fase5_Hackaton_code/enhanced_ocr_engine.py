# enhanced_ocr_engine.py
"""
from typing import Dict, List, Optional, Tuple, Any, Union
OCR Engine com múltiplas técnicas e IA
"""

import easyocr
import pytesseract
import cv2
import numpy as np
from transformers import TrOCRProcessor, VisionEncoderDecoderModel
from PIL import Image
import torch

class MultiEngineOCR:
    """OCR com múltiplos engines e técnicas avançadas"""
    
    def __init__(self):
        # EasyOCR para múltiplos idiomas
        self.easy_reader = easyocr.Reader(['en', 'pt'], gpu=True)
        
        # TrOCR da Microsoft (Transformer OCR)
        self.trocr_processor = TrOCRProcessor.from_pretrained('microsoft/trocr-large-printed')
        self.trocr_model = VisionEncoderDecoderModel.from_pretrained('microsoft/trocr-large-printed')
        
        # PaddleOCR para texto em ângulos
        try:
            from paddleocr import PaddleOCR
            self.paddle_ocr = PaddleOCR(use_angle_cls=True, lang='en', use_gpu=True)
        except:
            self.paddle_ocr = None
            
    def extract_comprehensive_text(self, image_path: str) -> Dict:
        """Extração completa com todos os engines"""
        
        results = {
            'pytesseract': self._extract_tesseract(image_path),
            'easyocr': self._extract_easyocr(image_path),
            'trocr': self._extract_trocr(image_path),
            'paddle': self._extract_paddle(image_path) if self.paddle_ocr else [],
            'combined': [],
            'confidence_scores': {}
        }
        
        # Combinar e validar resultados
        results['combined'] = self._merge_and_validate(results)
        
        # Detectar estruturas específicas (tabelas, diagramas)
        results['structures'] = self._detect_document_structures(image_path)
        
        return results
    
    def _extract_tesseract(self, image_path: str) -> List[Dict]:
        """Extração com Tesseract usando múltiplas configurações"""
        
        image = cv2.imread(image_path)
        results = []
        
        # Configurações otimizadas para diferentes tipos de texto
        configs = [
            ('--psm 6 --oem 3', 'uniform_block'),
            ('--psm 3 --oem 3', 'auto_osd'),
            ('--psm 11 --oem 3', 'sparse_text'),
            ('--psm 13 --oem 3', 'raw_line')
        ]
        
        # Pré-processamentos específicos
        preprocessors = [
            lambda img: img,  # Original
            lambda img: cv2.cvtColor(img, cv2.COLOR_BGR2GRAY),
            lambda img: cv2.threshold(cv2.cvtColor(img, cv2.COLOR_BGR2GRAY), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)[1],
            lambda img: cv2.bilateralFilter(img, 9, 75, 75)
        ]
        
        for preprocessor in preprocessors:
            processed_img = preprocessor(image.copy())
            
            for config, config_name in configs:
                try:
                    data = pytesseract.image_to_data(processed_img, config=config, output_type=pytesseract.Output.DICT)
                    
                    for i in range(len(data['text'])):
                        text = data['text'][i].strip()
                        conf = int(data['conf'][i])
                        
                        if text and conf > 20:
                            results.append({
                                'text': text,
                                'confidence': conf,
                                'bbox': (data['left'][i], data['top'][i], 
                                       data['left'][i] + data['width'][i],
                                       data['top'][i] + data['height'][i]),
                                'method': f'tesseract_{config_name}'
                            })
                except Exception as e:
                    continue
                    
        return results
    
    def _extract_trocr(self, image_path: str) -> List[Dict]:
        """Extração usando TrOCR (Transformer OCR)"""
        
        image = Image.open(image_path).convert('RGB')
        results = []
        
        # Dividir imagem em patches para processar
        patches = self._create_image_patches(image)
        
        for patch, bbox in patches:
            inputs = self.trocr_processor(patch, return_tensors="pt").pixel_values
            
            with torch.no_grad():
                generated_ids = self.trocr_model.generate(inputs)
            
            text = self.trocr_processor.batch_decode(generated_ids, skip_special_tokens=True)[0]
            
            if text:
                results.append({
                    'text': text,
                    'confidence': 85,  # TrOCR não fornece confidence
                    'bbox': bbox,
                    'method': 'trocr'
                })
                
        return results
    
    def _create_image_patches(self, image: Image, patch_size: int = 384) -> List[Tuple[Image, Tuple]]:
        """Divide imagem em patches para processamento"""
        
        patches = []
        width, height = image.size
        
        for y in range(0, height, patch_size // 2):
            for x in range(0, width, patch_size // 2):
                # Criar patch com overlap
                x_end = min(x + patch_size, width)
                y_end = min(y + patch_size, height)
                
                patch = image.crop((x, y, x_end, y_end))
                patches.append((patch, (x, y, x_end, y_end)))
                
        return patches
    
    def _merge_and_validate(self, all_results: Dict) -> List[Dict]:
        """Merge e validação de resultados de múltiplos engines"""
        
        merged = []
        text_clusters = {}
        
        # Agrupar textos similares por localização
        for engine, results in all_results.items():
            if engine in ['combined', 'confidence_scores', 'structures']:
                continue
                
            for result in results:
                if not isinstance(result, dict):
                    continue
                    
                text = result.get('text', '')
                bbox = result.get('bbox', (0, 0, 0, 0))
                
                # Criar chave baseada em localização aproximada
                grid_x = bbox[0] // 50
                grid_y = bbox[1] // 50
                location_key = f"{grid_x}_{grid_y}"
                
                if location_key not in text_clusters:
                    text_clusters[location_key] = []
                
                text_clusters[location_key].append({
                    'text': text,
                    'confidence': result.get('confidence', 50),
                    'bbox': bbox,
                    'engine': engine,
                    'method': result.get('method', engine)
                })
        
        # Votar no melhor texto para cada cluster
        for location, cluster in text_clusters.items():
            if not cluster:
                continue
                
            # Agrupar por texto similar
            text_votes = {}
            for item in cluster:
                text_key = item['text'].lower().strip()
                if text_key not in text_votes:
                    text_votes[text_key] = []
                text_votes[text_key].append(item)
            
            # Escolher texto com mais votos e maior confiança média
            best_text = None
            best_score = 0
            
            for text_key, votes in text_votes.items():
                avg_confidence = np.mean([v['confidence'] for v in votes])
                vote_score = len(votes) * avg_confidence
                
                if vote_score > best_score:
                    best_score = vote_score
                    best_text = votes[0]  # Pegar o primeiro como representante
                    best_text['confidence'] = avg_confidence
                    best_text['vote_count'] = len(votes)
                    best_text['engines_agreed'] = list(set([v['engine'] for v in votes]))
            
            if best_text:
                merged.append(best_text)
        
        return sorted(merged, key=lambda x: x['confidence'], reverse=True)