# setup_stride_system.py
"""
Script de setup e verificação para o Sistema STRIDE
Instala dependências e verifica configuração
"""

import subprocess
import sys
import os
from pathlib import Path

def check_python_version():
    """Verifica versão do Python"""
    print("🐍 Verificando versão do Python...")
    version = sys.version_info
    if version.major == 3 and version.minor >= 8:
        print(f"✅ Python {version.major}.{version.minor}.{version.micro} - OK")
        return True
    else:
        print(f"❌ Python {version.major}.{version.minor} - Requer Python 3.8+")
        return False

def install_package(package):
    """Instala um pacote via pip"""
    try:
        subprocess.check_call([sys.executable, "-m", "pip", "install", package])
        return True
    except subprocess.CalledProcessError:
        return False

def create_requirements_file():
    """Cria arquivo requirements.txt"""
    
    # Requirements mínimos (para versão standalone)
    minimal_requirements = """# Requirements mínimos para STRIDE Analyzer Standalone
streamlit>=1.28.0
openai>=1.0.0
opencv-python>=4.8.0
numpy>=1.24.0
Pillow>=9.0.0
"""
    
    # Requirements completos (para sistema unificado)
    full_requirements = """# Requirements completos para STRIDE Unified System
# Core
streamlit>=1.28.0
numpy>=1.24.0
pandas>=2.0.0
Pillow>=9.0.0

# OpenAI e Vision
openai>=1.0.0
opencv-python>=4.8.0

# Machine Learning
scikit-learn>=1.3.0
xgboost>=1.7.0
joblib>=1.3.0

# Deep Learning (opcional)
torch>=2.0.0
torchvision>=0.15.0
transformers>=4.30.0

# Vector Database e RAG
chromadb>=0.4.0
sentence-transformers>=2.2.0
faiss-cpu>=1.7.4

# OCR (opcional)
pytesseract>=0.3.10
easyocr>=1.7.0

# YOLO (opcional)
ultralytics>=8.0.0
albumentations>=1.3.0

# Utilities
python-dotenv>=1.0.0
aiohttp>=3.8.0
"""
    
    # Criar arquivo de requirements mínimos
    with open("requirements_minimal.txt", "w") as f:
        f.write(minimal_requirements)
    print("✅ Criado: requirements_minimal.txt")
    
    # Criar arquivo de requirements completos
    with open("requirements_full.txt", "w") as f:
        f.write(full_requirements)
    print("✅ Criado: requirements_full.txt")
    
    return True

def install_minimal_requirements():
    """Instala apenas os requirements mínimos"""
    print("\n📦 Instalando dependências mínimas...")
    
    packages = [
        "streamlit",
        "openai",
        "opencv-python",
        "numpy",
        "Pillow"
    ]
    
    failed = []
    for package in packages:
        print(f"Installing {package}...")
        if not install_package(package):
            failed.append(package)
    
    if failed:
        print(f"\n⚠️ Falha ao instalar: {', '.join(failed)}")
        print("Tente instalar manualmente com:")
        print(f"pip install {' '.join(failed)}")
    else:
        print("\n✅ Todas as dependências mínimas instaladas!")
    
    return len(failed) == 0

def check_optional_dependencies():
    """Verifica dependências opcionais"""
    print("\n🔍 Verificando dependências opcionais...")
    
    optional = {
        "pytesseract": "OCR com Tesseract",
        "easyocr": "OCR com EasyOCR",
        "torch": "Deep Learning",
        "transformers": "Modelos Transformer",
        "chromadb": "Vector Database",
        "sentence_transformers": "Embeddings",
        "ultralytics": "YOLO Detection",
        "xgboost": "Machine Learning"
    }
    
    available = []
    missing = []
    
    for package, description in optional.items():
        try:
            __import__(package.replace("-", "_"))
            available.append(f"✅ {package} - {description}")
        except ImportError:
            missing.append(f"❌ {package} - {description}")
    
    print("\nDisponíveis:")
    for item in available:
        print(f"  {item}")
    
    if missing:
        print("\nNão instalados (opcional):")
        for item in missing:
            print(f"  {item}")
    
    return len(available), len(missing)

def check_api_keys():
    """Verifica configuração de API keys"""
    print("\n🔑 Verificando API Keys...")
    
    openai_key = os.getenv("OPENAI_API_KEY")
    
    if openai_key:
        print(f"✅ OPENAI_API_KEY configurada ({len(openai_key)} caracteres)")
    else:
        print("⚠️ OPENAI_API_KEY não encontrada")
        print("   Para usar OpenAI Vision, configure:")
        print("   Windows: set OPENAI_API_KEY=sua-chave-aqui")
        print("   Linux/Mac: export OPENAI_API_KEY=sua-chave-aqui")
    
    return openai_key is not None

def create_fix_imports_script():
    """Cria script para corrigir imports"""
    fix_script = '''# fix_imports.py
"""
Script para corrigir imports em todos os arquivos
"""

import os
from pathlib import Path

def fix_file_imports(filepath):
    """Corrige imports em um arquivo"""
    
    # Imports necessários para cada arquivo
    required_imports = {
        "from typing import": "from typing import Dict, List, Optional, Tuple, Any, Union",
    }
    
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Verificar e corrigir imports
        modified = False
        lines = content.split('\\n')
        new_lines = []
        
        for line in lines:
            if line.strip().startswith("from typing import"):
                # Garantir que tem todos os imports necessários
                if "Dict" not in line:
                    line = required_imports["from typing import"]
                    modified = True
            new_lines.append(line)
        
        if modified:
            with open(filepath, 'w', encoding='utf-8') as f:
                f.write('\\n'.join(new_lines))
            print(f"✅ Corrigido: {filepath}")
        
    except Exception as e:
        print(f"❌ Erro ao processar {filepath}: {e}")

def main():
    """Corrige imports em todos os arquivos Python"""
    
    python_files = [
        "enhanced_ocr_engine.py",
        "cloud_icon_trainer.py",
        "multi_cloud_security_analyzer.py",
        "openai_vision_enhanced.py",
        "vector_database_enhanced.py",
        "ml_threat_pattern_detection.py",
        "unified_stride_system.py"
    ]
    
    print("🔧 Corrigindo imports...")
    
    for file in python_files:
        if Path(file).exists():
            fix_file_imports(file)
    
    print("\\n✅ Processo concluído!")

if __name__ == "__main__":
    main()
'''
    
    with open("fix_imports.py", "w", encoding="utf-8") as f:
        f.write(fix_script)
    print("✅ Criado: fix_imports.py")
    
    return True

def main():
    """Função principal do setup"""
    print("=" * 60)
    print("🚀 STRIDE SYSTEM SETUP")
    print("=" * 60)
    
    # 1. Verificar Python
    if not check_python_version():
        print("\n❌ Versão do Python incompatível!")
        return
    
    # 2. Criar arquivos de requirements
    print("\n📝 Criando arquivos de configuração...")
    create_requirements_file()
    create_fix_imports_script()
    
    # 3. Perguntar qual versão instalar
    print("\n❓ Qual versão deseja configurar?")
    print("1. Mínima (Standalone) - Recomendada para começar")
    print("2. Completa (Unified) - Todas as funcionalidades")
    print("3. Apenas verificar dependências")
    
    choice = input("\nEscolha (1/2/3): ").strip()
    
    if choice == "1":
        print("\n📦 Instalando versão mínima...")
        if install_minimal_requirements():
            print("\n✅ Sistema pronto para uso!")
            print("\n🚀 Para executar:")
            print("   streamlit run stride_analyzer_standalone.py")
    
    elif choice == "2":
        print("\n📦 Para instalar a versão completa, execute:")
        print("   pip install -r requirements_full.txt")
        print("\n⚠️ Nota: Algumas dependências podem requerer configuração adicional")
    
    elif choice == "3":
        available, missing = check_optional_dependencies()
        print(f"\n📊 Resumo: {available} disponíveis, {missing} ausentes")
    
    else:
        print("\n❌ Opção inválida")
        return
    
    # 4. Verificar API keys
    check_api_keys()
    
    # 5. Instruções finais
    print("\n" + "=" * 60)
    print("📚 PRÓXIMOS PASSOS:")
    print("=" * 60)
    print("\n1. Para corrigir imports automaticamente:")
    print("   python fix_imports.py")
    print("\n2. Para executar a versão standalone:")
    print("   streamlit run stride_analyzer_standalone.py")
    print("\n3. Para executar a versão completa (após instalar tudo):")
    print("   streamlit run unified_stride_system.py")
    print("\n4. Para configurar OpenAI (opcional):")
    print("   set OPENAI_API_KEY=sua-chave-aqui")
    print("\n" + "=" * 60)
    print("✨ Setup concluído!")

if __name__ == "__main__":
    main()