#!/usr/bin/env python3
"""
AI Provider Manager - Sistema de Fallback e Redundância entre OpenAI e Anthropic
Integração transparente com o sistema STRIDE existente
"""

import os
import json
import time
import base64
from typing import Dict, List, Optional, Any, Tuple, Union
from dataclasses import dataclass
from enum import Enum
import hashlib
from datetime import datetime
import numpy as np

# Imports das APIs
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

try:
    import anthropic
    ANTHROPIC_AVAILABLE = True
except ImportError:
    ANTHROPIC_AVAILABLE = False

# Para Streamlit UI
import streamlit as st


class ProviderMode(Enum):
    """Modos de operação do AI Provider"""
    OPENAI_ONLY = "openai_only"
    ANTHROPIC_ONLY = "anthropic_only"
    FALLBACK = "fallback"  # OpenAI primário, Anthropic backup
    REDUNDANT = "redundant"  # Usa ambos e consolida
    AUTO = "auto"  # Decide automaticamente baseado em disponibilidade


@dataclass
class AIResponse:
    """Resposta padronizada de AI"""
    content: str
    provider: str
    model: str
    success: bool
    error: Optional[str] = None
    metadata: Dict[str, Any] = None
    processing_time: float = 0.0
    tokens_used: int = 0


class AIProviderManager:
    """
    Gerencia múltiplos providers de AI com fallback e redundância
    Mantém compatibilidade total com o sistema existente
    """
    
    def __init__(self, mode: ProviderMode = ProviderMode.AUTO):
        self.mode = mode
        self.openai_client = None
        self.anthropic_client = None
        
        # Inicializar clientes
        self._initialize_clients()
        
        # Cache de respostas para evitar chamadas duplicadas
        self.response_cache = {}
        
        # Estatísticas de uso
        self.stats = {
            'openai_calls': 0,
            'anthropic_calls': 0,
            'openai_failures': 0,
            'anthropic_failures': 0,
            'fallback_used': 0,
            'consolidations': 0
        }
    
    def _initialize_clients(self):
        """Inicializa os clientes das APIs"""
        # OpenAI
        if OPENAI_AVAILABLE and os.getenv('OPENAI_API_KEY'):
            try:
                self.openai_client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
            except Exception as e:
                st.warning(f"Erro ao inicializar OpenAI: {e}")
        
        # Anthropic
        if ANTHROPIC_AVAILABLE and os.getenv('ANTHROPIC_API_KEY'):
            try:
                self.anthropic_client = anthropic.Anthropic(api_key=os.getenv('ANTHROPIC_API_KEY'))
            except Exception as e:
                st.warning(f"Erro ao inicializar Anthropic: {e}")
        
        # Auto-ajustar modo baseado na disponibilidade
        if self.mode == ProviderMode.AUTO:
            if self.openai_client and self.anthropic_client:
                self.mode = ProviderMode.FALLBACK
            elif self.openai_client:
                self.mode = ProviderMode.OPENAI_ONLY
            elif self.anthropic_client:
                self.mode = ProviderMode.ANTHROPIC_ONLY
            else:
                st.error("Nenhum provider de AI disponível!")
    
    def get_status(self) -> Dict:
        """Retorna status dos providers"""
        return {
            'mode': self.mode.value,
            'openai_available': self.openai_client is not None,
            'anthropic_available': self.anthropic_client is not None,
            'stats': self.stats.copy()
        }
    
    def analyze_image(self, image_data: Union[bytes, str], prompt: str) -> AIResponse:
        """
        Analisa imagem usando visão AI com fallback/redundância
        Compatível com _analyze_with_openai existente
        """
        if self.mode == ProviderMode.REDUNDANT:
            return self._analyze_image_redundant(image_data, prompt)
        elif self.mode == ProviderMode.FALLBACK:
            return self._analyze_image_with_fallback(image_data, prompt)
        elif self.mode == ProviderMode.OPENAI_ONLY:
            return self._analyze_image_openai(image_data, prompt)
        elif self.mode == ProviderMode.ANTHROPIC_ONLY:
            return self._analyze_image_anthropic(image_data, prompt)
        else:
            return self._analyze_image_with_fallback(image_data, prompt)
    
    def _analyze_image_openai(self, image_data: Union[bytes, str], prompt: str) -> AIResponse:
        """Análise de imagem com OpenAI GPT-4 Vision"""
        if not self.openai_client:
            return AIResponse(
                content="",
                provider="openai",
                model="gpt-4o",
                success=False,
                error="OpenAI client not initialized"
            )
        
        try:
            start_time = time.time()
            self.stats['openai_calls'] += 1
            
            # Preparar imagem base64
            if isinstance(image_data, bytes):
                image_b64 = base64.b64encode(image_data).decode()
            else:
                image_b64 = image_data
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4o",
                messages=[{
                    "role": "user",
                    "content": [
                        {"type": "text", "text": prompt},
                        {"type": "image_url", "image_url": {"url": f"data:image/png;base64,{image_b64}"}}
                    ]
                }],
                max_tokens=500
            )
            
            content = response.choices[0].message.content
            
            return AIResponse(
                content=content,
                provider="openai",
                model="gpt-4o",
                success=True,
                processing_time=time.time() - start_time,
                tokens_used=response.usage.total_tokens if hasattr(response, 'usage') else 0
            )
            
        except Exception as e:
            self.stats['openai_failures'] += 1
            return AIResponse(
                content="",
                provider="openai",
                model="gpt-4o",
                success=False,
                error=str(e)
            )
    
    def _analyze_image_anthropic(self, image_data: Union[bytes, str], prompt: str) -> AIResponse:
        """Análise de imagem com Claude 3 Vision"""
        if not self.anthropic_client:
            return AIResponse(
                content="",
                provider="anthropic",
                model="claude-opus-4-1-20250805",
                success=False,
                error="Anthropic client not initialized"
            )
        
        try:
            start_time = time.time()
            self.stats['anthropic_calls'] += 1
            
            # Preparar imagem base64
            if isinstance(image_data, bytes):
                image_b64 = base64.b64encode(image_data).decode()
            else:
                image_b64 = image_data
            
            # Claude 3 Vision
            response = self.anthropic_client.messages.create(
                model="claude-opus-4-1-20250805",
                max_tokens=500,
                messages=[{
                    "role": "user",
                    "content": [
                        {
                            "type": "image",
                            "source": {
                                "type": "base64",
                                "media_type": "image/png",
                                "data": image_b64
                            }
                        },
                        {
                            "type": "text",
                            "text": prompt
                        }
                    ]
                }]
            )
            
            content = response.content[0].text if response.content else ""
            
            return AIResponse(
                content=content,
                provider="anthropic",
                model="claude-opus-4-1-20250805",
                success=True,
                processing_time=time.time() - start_time,
                tokens_used=response.usage.output_tokens if hasattr(response, 'usage') else 0
            )
            
        except Exception as e:
            self.stats['anthropic_failures'] += 1
            return AIResponse(
                content="",
                provider="anthropic",
                model="claude-opus-4-1",
                success=False,
                error=str(e)
            )
    
    def _analyze_image_with_fallback(self, image_data: Union[bytes, str], prompt: str) -> AIResponse:
        """Análise com fallback automático"""
        # Tentar OpenAI primeiro
        response = self._analyze_image_openai(image_data, prompt)
        
        if response.success:
            return response
        
        # Fallback para Anthropic
        st.warning("OpenAI falhou, usando Anthropic como fallback...")
        self.stats['fallback_used'] += 1
        
        response = self._analyze_image_anthropic(image_data, prompt)
        
        if response.success:
            response.metadata = {'fallback_used': True, 'primary_error': response.error}
        
        return response
    
    def _analyze_image_redundant(self, image_data: Union[bytes, str], prompt: str) -> AIResponse:
        """Análise redundante com consolidação de resultados"""
        responses = []
        
        # Executar ambas análises em paralelo
        with st.spinner("🔄 Executando análise redundante (OpenAI + Anthropic)..."):
            # OpenAI
            openai_response = self._analyze_image_openai(image_data, prompt)
            if openai_response.success:
                responses.append(openai_response)
            
            # Anthropic
            anthropic_response = self._analyze_image_anthropic(image_data, prompt)
            if anthropic_response.success:
                responses.append(anthropic_response)
        
        if not responses:
            return AIResponse(
                content="",
                provider="both",
                model="consolidated",
                success=False,
                error="Both providers failed"
            )
        
        # Consolidar respostas
        self.stats['consolidations'] += 1
        consolidated = self._consolidate_image_analysis(responses)
        
        return consolidated
    
    def _consolidate_image_analysis(self, responses: List[AIResponse]) -> AIResponse:
        """Consolida múltiplas análises de imagem"""
        if len(responses) == 1:
            return responses[0]
        
        # Extrair componentes detectados de cada resposta
        all_components = []
        all_providers = []
        all_metadata = {}
        
        for resp in responses:
            try:
                # Tentar parse JSON se possível
                data = json.loads(resp.content)
                
                # Combinar componentes
                if 'components' in data:
                    for comp in data.get('components', []):
                        if comp not in all_components:
                            all_components.append(comp)
                
                # Combinar providers detectados
                if 'provider' in data:
                    provider = data['provider']
                    if provider not in all_providers:
                        all_providers.append(provider)
                
                # Adicionar metadata específico
                all_metadata[resp.provider] = {
                    'component_count': data.get('component_count', 0),
                    'confidence': data.get('confidence', 0)
                }
                
            except json.JSONDecodeError:
                # Se não for JSON, processar como texto
                all_metadata[resp.provider] = {'raw_response': resp.content}
        
        # Criar resposta consolidada
        consolidated_data = {
            'components': all_components,
            'component_count': len(all_components),
            'providers_detected': all_providers,
            'provider': all_providers[0] if all_providers else 'unknown',
            'analysis_sources': [r.provider for r in responses],
            'consolidated': True,
            'metadata': all_metadata
        }
        
        return AIResponse(
            content=json.dumps(consolidated_data),
            provider="consolidated",
            model=f"[{', '.join([r.model for r in responses])}]",
            success=True,
            metadata={'sources': len(responses), 'details': all_metadata},
            processing_time=sum(r.processing_time for r in responses)
        )
    
    def chat_completion(self, messages: List[Dict], temperature: float = 0.7, 
                        max_tokens: int = 800) -> AIResponse:
        """
        Chat completion com fallback/redundância
        Compatível com chamadas GPT-4 existentes
        """
        if self.mode == ProviderMode.REDUNDANT:
            return self._chat_redundant(messages, temperature, max_tokens)
        elif self.mode == ProviderMode.FALLBACK:
            return self._chat_with_fallback(messages, temperature, max_tokens)
        elif self.mode == ProviderMode.OPENAI_ONLY:
            return self._chat_openai(messages, temperature, max_tokens)
        elif self.mode == ProviderMode.ANTHROPIC_ONLY:
            return self._chat_anthropic(messages, temperature, max_tokens)
        else:
            return self._chat_with_fallback(messages, temperature, max_tokens)
    
    def _chat_openai(self, messages: List[Dict], temperature: float, max_tokens: int) -> AIResponse:
        """Chat com OpenAI"""
        if not self.openai_client:
            return AIResponse("", "openai", "gpt-4", False, "Client not initialized")
        
        try:
            start_time = time.time()
            self.stats['openai_calls'] += 1
            
            response = self.openai_client.chat.completions.create(
                model="gpt-4",
                messages=messages,
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            return AIResponse(
                content=response.choices[0].message.content,
                provider="openai",
                model="gpt-4",
                success=True,
                processing_time=time.time() - start_time,
                tokens_used=response.usage.total_tokens if hasattr(response, 'usage') else 0
            )
            
        except Exception as e:
            self.stats['openai_failures'] += 1
            return AIResponse("", "openai", "gpt-4", False, str(e))
    
    def _chat_anthropic(self, messages: List[Dict], temperature: float, max_tokens: int) -> AIResponse:
        """Chat com Anthropic"""
        if not self.anthropic_client:
            return AIResponse("", "anthropic", "claude-4.1", False, "Client not initialized")
        
        try:
            start_time = time.time()
            self.stats['anthropic_calls'] += 1
            
            # Converter formato de mensagens para Anthropic
            anthropic_messages = []
            system_msg = None
            
            for msg in messages:
                if msg['role'] == 'system':
                    system_msg = msg['content']
                else:
                    anthropic_messages.append({
                        'role': msg['role'],
                        'content': msg['content']
                    })
            
            response = self.anthropic_client.messages.create(
                model="claude-opus-4-1-20250805",
                system=system_msg if system_msg else "",
                messages=anthropic_messages,
                temperature=temperature,
                max_tokens=max_tokens
            )
            
            return AIResponse(
                content=response.content[0].text if response.content else "",
                provider="anthropic",
                model="claude-opus-4-1",
                success=True,
                processing_time=time.time() - start_time,
                tokens_used=response.usage.output_tokens if hasattr(response, 'usage') else 0
            )
            
        except Exception as e:
            self.stats['anthropic_failures'] += 1
            return AIResponse("", "anthropic", "claude-4.1", False, str(e))
    
    def _chat_with_fallback(self, messages: List[Dict], temperature: float, max_tokens: int) -> AIResponse:
        """Chat com fallback automático"""
        # Tentar OpenAI primeiro
        response = self._chat_openai(messages, temperature, max_tokens)
        
        if response.success:
            return response
        
        # Fallback para Anthropic
        self.stats['fallback_used'] += 1
        response = self._chat_anthropic(messages, temperature, max_tokens)
        
        if response.success:
            response.metadata = {'fallback_used': True}
        
        return response
    
    def _chat_redundant(self, messages: List[Dict], temperature: float, max_tokens: int) -> AIResponse:
        """Chat redundante com consolidação"""
        responses = []
        
        # Executar ambos
        openai_resp = self._chat_openai(messages, temperature, max_tokens)
        if openai_resp.success:
            responses.append(openai_resp)
        
        anthropic_resp = self._chat_anthropic(messages, temperature, max_tokens)
        if anthropic_resp.success:
            responses.append(anthropic_resp)
        
        if not responses:
            return AIResponse("", "both", "consolidated", False, "All providers failed")
        
        # Consolidar
        self.stats['consolidations'] += 1
        return self._consolidate_chat_responses(responses)
    
    def _consolidate_chat_responses(self, responses: List[AIResponse]) -> AIResponse:
        """Consolida múltiplas respostas de chat"""
        if len(responses) == 1:
            return responses[0]
        
        # Estratégia de consolidação: combinar insights únicos
        consolidated_content = "### Análise Consolidada (Multiple AI Providers)\n\n"
        
        # Adicionar resposta de cada provider
        for resp in responses:
            provider_name = "OpenAI GPT-4" if resp.provider == "openai" else "Anthropic Claude 3"
            consolidated_content += f"**{provider_name}:**\n{resp.content}\n\n"
        
        # Identificar pontos comuns e divergências
        consolidated_content += "---\n### Síntese Consolidada:\n"
        
        # Análise simples de overlap (pode ser melhorada com NLP)
        contents = [r.content for r in responses]
        
        # Encontrar elementos comuns (simplificado)
        common_points = []
        unique_points = {}
        
        for i, content in enumerate(contents):
            provider = responses[i].provider
            sentences = content.split('.')
            
            for sentence in sentences:
                if len(sentence.strip()) > 20:  # Ignorar frases muito curtas
                    is_common = False
                    for other_content in contents:
                        if content != other_content and sentence.strip() in other_content:
                            is_common = True
                            if sentence.strip() not in common_points:
                                common_points.append(sentence.strip())
                            break
                    
                    if not is_common:
                        if provider not in unique_points:
                            unique_points[provider] = []
                        unique_points[provider].append(sentence.strip())
        
        if common_points:
            consolidated_content += "\n**Pontos em Comum:**\n"
            for point in common_points[:5]:  # Limitar a 5 pontos
                consolidated_content += f"• {point}\n"
        
        if unique_points:
            consolidated_content += "\n**Insights Únicos:**\n"
            for provider, points in unique_points.items():
                provider_name = "OpenAI" if provider == "openai" else "Anthropic"
                consolidated_content += f"\n_{provider_name}_:\n"
                for point in points[:3]:  # Limitar a 3 pontos por provider
                    consolidated_content += f"• {point}\n"
        
        return AIResponse(
            content=consolidated_content,
            provider="consolidated",
            model=f"[{', '.join([r.model for r in responses])}]",
            success=True,
            metadata={
                'sources': len(responses),
                'providers': [r.provider for r in responses],
                'consolidation_type': 'redundant'
            },
            processing_time=sum(r.processing_time for r in responses)
        )
    
    def create_embeddings(self, texts: List[str], model: str = "auto") -> Optional[np.ndarray]:
        """
        Cria embeddings com fallback/redundância
        Compatível com embeddings OpenAI existentes
        """
        if model == "auto":
            if self.openai_client:
                return self._create_openai_embeddings(texts)
            elif self.anthropic_client:
                # Anthropic não tem embeddings nativos, usar fallback para TF-IDF
                return None
        
        return self._create_openai_embeddings(texts)
    
    def _create_openai_embeddings(self, texts: List[str]) -> Optional[np.ndarray]:
        """Cria embeddings com OpenAI"""
        if not self.openai_client:
            return None
        
        try:
            embeddings = []
            batch_size = 100
            
            for i in range(0, len(texts), batch_size):
                batch = texts[i:i + batch_size]
                response = self.openai_client.embeddings.create(
                    model="text-embedding-ada-002",
                    input=batch
                )
                
                batch_embeddings = [data.embedding for data in response.data]
                embeddings.extend(batch_embeddings)
            
            return np.array(embeddings)
            
        except Exception as e:
            st.warning(f"Erro ao criar embeddings: {e}")
            return None


# Singleton para gerenciamento global
_ai_provider_manager = None

def get_ai_provider_manager(mode: ProviderMode = ProviderMode.AUTO) -> AIProviderManager:
    """Obtém instância singleton do AI Provider Manager"""
    global _ai_provider_manager
    
    if _ai_provider_manager is None:
        _ai_provider_manager = AIProviderManager(mode)
    
    return _ai_provider_manager


def show_ai_provider_status():
    """Mostra status dos providers na UI do Streamlit"""
    manager = get_ai_provider_manager()
    status = manager.get_status()
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if status['openai_available']:
            st.success("✅ OpenAI Ativo")
        else:
            st.error("❌ OpenAI Indisponível")
    
    with col2:
        if status['anthropic_available']:
            st.success("✅ Anthropic Ativo")
        else:
            st.error("❌ Anthropic Indisponível")
    
    with col3:
        mode_emoji = {
            'openai_only': '🔵',
            'anthropic_only': '🟣',
            'fallback': '🔄',
            'redundant': '🔀',
            'auto': '🤖'
        }
        st.info(f"{mode_emoji.get(status['mode'], '❓')} Modo: {status['mode'].replace('_', ' ').title()}")
    
    # Estatísticas expandíveis
    with st.expander("📊 Estatísticas de Uso"):
        stats = status['stats']
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.metric("OpenAI Calls", stats['openai_calls'])
            st.metric("OpenAI Failures", stats['openai_failures'])
            st.metric("Fallbacks Used", stats['fallback_used'])
        
        with col2:
            st.metric("Anthropic Calls", stats['anthropic_calls'])
            st.metric("Anthropic Failures", stats['anthropic_failures'])
            st.metric("Consolidations", stats['consolidations'])


def configure_ai_provider_mode():
    """Widget para configurar o modo do AI Provider"""
    st.markdown("### 🤖 Configuração do AI Provider")
    
    mode_options = {
        "Auto (Recomendado)": ProviderMode.AUTO,
        "OpenAI Apenas": ProviderMode.OPENAI_ONLY,
        "Anthropic Apenas": ProviderMode.ANTHROPIC_ONLY,
        "Fallback (OpenAI → Anthropic)": ProviderMode.FALLBACK,
        "Redundante (Ambos + Consolidação)": ProviderMode.REDUNDANT
    }
    
    selected_mode = st.selectbox(
        "Modo de Operação",
        options=list(mode_options.keys()),
        help="Escolha como os providers de AI devem operar"
    )
    
    manager = get_ai_provider_manager()
    manager.mode = mode_options[selected_mode]
    
    # Mostrar configuração de API Keys
    with st.expander("🔑 Configuração de API Keys"):
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**OpenAI**")
            if os.getenv('OPENAI_API_KEY'):
                st.success("✅ API Key configurada")
            else:
                st.warning("⚠️ Configure OPENAI_API_KEY")
                st.code("export OPENAI_API_KEY='sua_chave'")
        
        with col2:
            st.markdown("**Anthropic**")
            if os.getenv('ANTHROPIC_API_KEY'):
                st.success("✅ API Key configurada")
            else:
                st.warning("⚠️ Configure ANTHROPIC_API_KEY")
                st.code("export ANTHROPIC_API_KEY='sua_chave'")
    
    return manager