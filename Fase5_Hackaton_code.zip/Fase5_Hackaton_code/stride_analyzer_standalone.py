# stride_analyzer_standalone.py
"""
STRIDE Analyzer Standalone - Versão simplificada e funcional
Sem dependências complexas, pronto para executar
"""

import streamlit as st
import json
import time
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any
import base64
import hashlib
import os

# Tentar carregar variáveis do .env
try:
    from dotenv import load_dotenv
    load_dotenv()  # Carrega as variáveis do arquivo .env
    ENV_LOADED = True
except ImportError:
    ENV_LOADED = False
    st.info("python-dotenv não instalado. Para usar .env, instale com: pip install python-dotenv")

# Tentar importar OpenAI se disponível
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False
    st.warning("OpenAI não instalado. Instale com: pip install openai")

# Tentar importar CV2 se disponível
try:
    import cv2
    import numpy as np
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False
    st.warning("OpenCV não instalado. Instale com: pip install opencv-python numpy")


class SimpleSTRIDEAnalyzer:
    """Analisador STRIDE simplificado"""
    
    def __init__(self):
        self.analysis_cache = {}
        self.stride_categories = [
            'Spoofing', 'Tampering', 'Repudiation',
            'Information Disclosure', 'Denial of Service', 
            'Elevation of Privilege'
        ]
    
    def analyze_with_openai(self, image_path: str) -> Dict:
        """Análise usando OpenAI Vision API"""
        if not OPENAI_AVAILABLE:
            return {"error": "OpenAI não disponível"}
        
        try:
            client = OpenAI()
            
            # Codificar imagem em base64
            with open(image_path, "rb") as image_file:
                base64_image = base64.b64encode(image_file.read()).decode('utf-8')
            
            # Prompt otimizado
            system_prompt = """You are an expert cloud security architect specializing in STRIDE threat modeling.
            Analyze the architecture diagram and identify security threats."""
            
            user_prompt = """Analyze this cloud architecture diagram and provide a JSON response with:
            1. Components detected (name, type, provider)
            2. STRIDE threats (category, severity, description, mitigation)
            3. Risk score (0-10)
            4. Recommendations as array of objects with: priority, category, title, description, effort

            Format:
            {
                "components": [...],
                "threats": [...],
                "risk_score": 0-10,
                "recommendations": [
                    {
                        "priority": "IMMEDIATE|HIGH|MEDIUM|LOW",
                        "category": "Security|Compliance|Architecture|Cost",
                        "title": "Short title",
                        "description": "Detailed description",
                        "effort": "High|Medium|Low"
                    }
                ]
            }"""
            
            response = client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": user_prompt},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{base64_image}",
                                    "detail": "high"
                                }
                            }
                        ]
                    }
                ],
                max_tokens=2000,
                temperature=0.1,
                response_format={"type": "json_object"}
            )
            
            result = json.loads(response.choices[0].message.content)
            
            # Validar e corrigir formato das recomendações
            if 'recommendations' in result:
                valid_recs = []
                for rec in result.get('recommendations', []):
                    if isinstance(rec, dict):
                        # Garantir que tem os campos necessários
                        valid_rec = {
                            'priority': rec.get('priority', 'MEDIUM'),
                            'category': rec.get('category', 'General'),
                            'title': rec.get('title', 'Recommendation'),
                            'description': rec.get('description', ''),
                            'effort': rec.get('effort', 'Medium')
                        }
                        valid_recs.append(valid_rec)
                    elif isinstance(rec, str):
                        # Converter string em objeto
                        valid_recs.append({
                            'priority': 'MEDIUM',
                            'category': 'General',
                            'title': rec[:50] if len(rec) > 50 else rec,
                            'description': rec,
                            'effort': 'Medium'
                        })
                result['recommendations'] = valid_recs
            
            return result
            
        except Exception as e:
            return {"error": str(e)}
    
    def analyze_basic(self, image_path: str) -> Dict:
        """Análise básica sem APIs externas"""
        
        # Análise simulada baseada em heurísticas
        result = {
            "timestamp": datetime.now().isoformat(),
            "components": [],
            "threats": [],
            "risk_score": 0,
            "recommendations": []
        }
        
        # Detectar componentes básicos (simulado)
        if CV2_AVAILABLE:
            img = cv2.imread(image_path)
            if img is not None:
                height, width = img.shape[:2]
                
                # Heurísticas simples
                result["image_info"] = {
                    "width": width,
                    "height": height,
                    "size_mb": Path(image_path).stat().st_size / (1024*1024)
                }
                
                # Análise de cores para detectar providers
                result["color_analysis"] = self._analyze_colors(img)
        
        # Gerar threats STRIDE básicos
        result["threats"] = self._generate_basic_threats()
        
        # Calcular risk score
        result["risk_score"] = len(result["threats"]) * 1.5
        result["risk_score"] = min(10, result["risk_score"])
        
        # Gerar recomendações
        result["recommendations"] = self._generate_basic_recommendations()
        
        return result
    
    def _analyze_colors(self, img) -> Dict:
        """Analisa cores dominantes na imagem"""
        if not CV2_AVAILABLE:
            return {}
        
        # Converter para HSV
        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        
        # Detectar cores dominantes
        colors = {
            "orange": np.sum((hsv[:,:,0] > 10) & (hsv[:,:,0] < 25)),  # AWS
            "blue": np.sum((hsv[:,:,0] > 100) & (hsv[:,:,0] < 130)),  # Azure/GCP
            "green": np.sum((hsv[:,:,0] > 40) & (hsv[:,:,0] < 80))    # Outros
        }
        
        total_pixels = img.shape[0] * img.shape[1]
        
        # Determinar provider dominante
        dominant_color = max(colors, key=colors.get)
        confidence = colors[dominant_color] / total_pixels
        
        provider_map = {
            "orange": "AWS",
            "blue": "Azure/GCP",
            "green": "Generic"
        }
        
        return {
            "dominant_provider": provider_map[dominant_color],
            "confidence": round(confidence, 2),
            "color_distribution": {k: v/total_pixels for k, v in colors.items()}
        }
    
    def _generate_basic_threats(self) -> List[Dict]:
        """Gera threats STRIDE básicos"""
        threats = [
            {
                "category": "Spoofing",
                "severity": "high",
                "description": "Potential identity spoofing vulnerability in authentication components",
                "mitigation": "Implement Multi-Factor Authentication (MFA)",
                "impact": "Unauthorized access to resources"
            },
            {
                "category": "Tampering",
                "severity": "medium",
                "description": "Data integrity risks in data storage components",
                "mitigation": "Enable encryption at rest and in transit",
                "impact": "Data corruption or unauthorized modification"
            },
            {
                "category": "Information Disclosure",
                "severity": "high",
                "description": "Potential data exposure through misconfigured services",
                "mitigation": "Review and restrict access policies",
                "impact": "Sensitive data leakage"
            },
            {
                "category": "Denial of Service",
                "severity": "medium",
                "description": "Resource exhaustion vulnerability",
                "mitigation": "Implement rate limiting and auto-scaling",
                "impact": "Service unavailability"
            },
            {
                "category": "Elevation of Privilege",
                "severity": "critical",
                "description": "Excessive permissions in IAM roles",
                "mitigation": "Apply principle of least privilege",
                "impact": "Unauthorized access to critical resources"
            }
        ]
        
        return threats
    
    def _generate_basic_recommendations(self) -> List[Dict]:
        """Gera recomendações básicas"""
        return [
            {
                "priority": "IMMEDIATE",
                "category": "Security",
                "title": "Implement Zero Trust Architecture",
                "description": "Adopt zero trust principles across all components",
                "effort": "High",
                "impact": "Critical"
            },
            {
                "priority": "HIGH",
                "category": "Compliance",
                "title": "Enable Comprehensive Logging",
                "description": "Implement centralized logging and monitoring",
                "effort": "Medium",
                "impact": "High"
            },
            {
                "priority": "MEDIUM",
                "category": "Architecture",
                "title": "Review Network Segmentation",
                "description": "Ensure proper network isolation between components",
                "effort": "Medium",
                "impact": "Medium"
            },
            {
                "priority": "LOW",
                "category": "Cost",
                "title": "Optimize Resource Usage",
                "description": "Review and optimize cloud resource allocation",
                "effort": "Low",
                "impact": "Low"
            }
        ]


class SimpleVectorDB:
    """Banco vetorial simplificado para chat"""
    
    def __init__(self):
        self.documents = []
        self.knowledge_base = self._load_knowledge_base()
    
    def _load_knowledge_base(self) -> List[Dict]:
        """Carrega knowledge base básica"""
        return [
            {
                "topic": "STRIDE",
                "content": """STRIDE é um modelo de ameaças desenvolvido pela Microsoft:
                - Spoofing: Falsificação de identidade
                - Tampering: Alteração não autorizada
                - Repudiation: Negação de ações
                - Information Disclosure: Exposição de informações
                - Denial of Service: Negação de serviço
                - Elevation of Privilege: Elevação de privilégios"""
            },
            {
                "topic": "AWS Security",
                "content": """Principais serviços de segurança AWS:
                - IAM: Gerenciamento de identidades e acessos
                - GuardDuty: Detecção de ameaças
                - Security Hub: Central de segurança
                - WAF: Web Application Firewall
                - Shield: Proteção DDoS"""
            },
            {
                "topic": "Azure Security",
                "content": """Principais serviços de segurança Azure:
                - Azure AD: Active Directory
                - Key Vault: Gerenciamento de segredos
                - Security Center: Central de segurança
                - Sentinel: SIEM
                - Azure Firewall: Firewall gerenciado"""
            },
            {
                "topic": "Best Practices",
                "content": """Melhores práticas de segurança cloud:
                - Princípio do menor privilégio
                - Defesa em profundidade
                - Criptografia em repouso e trânsito
                - Monitoramento contínuo
                - Backup e recuperação
                - Compliance e auditoria"""
            }
        ]
    
    def add_analysis(self, analysis: Dict):
        """Adiciona análise ao banco"""
        self.documents.append({
            "type": "analysis",
            "content": analysis,
            "timestamp": datetime.now().isoformat()
        })
    
    def search(self, query: str, k: int = 3) -> List[Dict]:
        """Busca simples por palavras-chave"""
        query_lower = query.lower()
        results = []
        
        # Buscar na knowledge base
        for doc in self.knowledge_base:
            if any(word in doc["content"].lower() for word in query_lower.split()):
                results.append(doc)
        
        # Buscar nas análises
        for doc in self.documents:
            if doc["type"] == "analysis":
                content_str = json.dumps(doc["content"])
                if any(word in content_str.lower() for word in query_lower.split()):
                    results.append(doc)
        
        return results[:k]


def create_streamlit_interface():
    """Interface Streamlit simplificada"""
    
    st.set_page_config(
        page_title="STRIDE Security Analyzer",
        page_icon="🔒",
        layout="wide"
    )
    
    # CSS customizado
    st.markdown("""
    <style>
    .main { padding: 1rem; }
    .stAlert { margin-top: 1rem; }
    div[data-testid="metric-container"] {
        background-color: #f0f2f6;
        border: 1px solid #c9d1d9;
        padding: 1rem;
        border-radius: 0.5rem;
        margin: 0.5rem 0;
    }
    </style>
    """, unsafe_allow_html=True)
    
    st.title("🔒 STRIDE Security Analyzer")
    st.markdown("**Análise de segurança de diagramas de arquitetura cloud**")
    
    # Inicializar componentes
    if 'analyzer' not in st.session_state:
        st.session_state.analyzer = SimpleSTRIDEAnalyzer()
        st.session_state.vector_db = SimpleVectorDB()
        st.session_state.chat_history = []
    
    # Tabs
    tab1, tab2, tab3 = st.tabs(["📤 Análise", "📊 Resultados", "💬 Chat"])
    
    with tab1:
        st.header("Upload e Análise")
        
        # Upload de arquivo
        uploaded_file = st.file_uploader(
            "Selecione o diagrama de arquitetura",
            type=['png', 'jpg', 'jpeg'],
            help="Faça upload de um diagrama de arquitetura cloud"
        )
        
        if uploaded_file:
            # Salvar arquivo temporário
            temp_path = Path(f"temp_{uploaded_file.name}")
            with open(temp_path, 'wb') as f:
                f.write(uploaded_file.getbuffer())
            
            # Exibir imagem
            col1, col2 = st.columns([2, 1])
            
            with col1:
                st.image(str(temp_path), caption="Diagrama carregado", use_column_width=True)
            
            with col2:
                st.subheader("Opções de Análise")
                
                use_openai = False
                if OPENAI_AVAILABLE:
                    use_openai = st.checkbox("🤖 Usar OpenAI Vision", value=False)
                    if use_openai and not os.getenv("OPENAI_API_KEY"):
                        st.warning("Configure OPENAI_API_KEY no ambiente")
                        use_openai = False
                
                analyze_colors = st.checkbox("🎨 Análise de Cores", value=True)
                generate_report = st.checkbox("📄 Gerar Relatório", value=True)
            
            if st.button("🚀 Iniciar Análise", type="primary"):
                with st.spinner("Analisando arquitetura..."):
                    
                    # Executar análise
                    if use_openai:
                        result = st.session_state.analyzer.analyze_with_openai(str(temp_path))
                    else:
                        result = st.session_state.analyzer.analyze_basic(str(temp_path))
                    
                    # Salvar resultado
                    st.session_state.analysis_result = result
                    st.session_state.vector_db.add_analysis(result)
                    
                    # Exibir métricas
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        risk_score = result.get('risk_score', 0)
                        st.metric("Risk Score", f"{risk_score}/10")
                    
                    with col2:
                        threats_count = len(result.get('threats', []))
                        st.metric("Threats", threats_count)
                    
                    with col3:
                        recs_count = len(result.get('recommendations', []))
                        st.metric("Recommendations", recs_count)
                    
                    if "error" not in result:
                        st.success("✅ Análise concluída com sucesso!")
                    else:
                        st.error(f"❌ Erro na análise: {result['error']}")
                
                # Limpar arquivo temporário
                temp_path.unlink()
    
    with tab2:
        st.header("Resultados da Análise")
        
        if 'analysis_result' in st.session_state:
            result = st.session_state.analysis_result
            
            # Informações gerais
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("📋 Informações Gerais")
                
                if "image_info" in result:
                    st.write(f"**Dimensões:** {result['image_info']['width']}x{result['image_info']['height']}")
                    st.write(f"**Tamanho:** {result['image_info']['size_mb']:.2f} MB")
                
                if "color_analysis" in result:
                    st.write(f"**Provider Detectado:** {result['color_analysis']['dominant_provider']}")
                    st.write(f"**Confiança:** {result['color_analysis']['confidence']*100:.1f}%")
                
                st.write(f"**Timestamp:** {result.get('timestamp', 'N/A')}")
            
            with col2:
                st.subheader("📊 Estatísticas")
                st.write(f"**Risk Score:** {result.get('risk_score', 0)}/10")
                st.write(f"**Total de Threats:** {len(result.get('threats', []))}")
                st.write(f"**Recomendações:** {len(result.get('recommendations', []))}")
            
            # Threats STRIDE
            st.subheader("🎯 Ameaças STRIDE Identificadas")
            
            threats = result.get('threats', [])
            if threats:
                for threat in threats:
                    severity = threat.get('severity', 'medium')
                    severity_colors = {
                        'critical': '🔴',
                        'high': '🟠',
                        'medium': '🟡',
                        'low': '🟢'
                    }
                    
                    with st.expander(f"{severity_colors.get(severity, '⚪')} {threat.get('category')} - {severity.upper()}"):
                        st.write(f"**Descrição:** {threat.get('description')}")
                        st.write(f"**Impacto:** {threat.get('impact')}")
                        st.write(f"**Mitigação:** {threat.get('mitigation')}")
            else:
                st.info("Nenhuma ameaça específica detectada")
            
            # Recomendações
            st.subheader("💡 Recomendações")
            
            recommendations = result.get('recommendations', [])
            if recommendations:
                for rec in recommendations:
                    # Verificar se rec é um dicionário
                    if isinstance(rec, dict):
                        priority_colors = {
                            'IMMEDIATE': '🔴',
                            'HIGH': '🟠',
                            'MEDIUM': '🟡',
                            'LOW': '🟢'
                        }
                        
                        col1, col2 = st.columns([3, 1])
                        with col1:
                            priority = rec.get('priority', 'MEDIUM')
                            title = rec.get('title', 'Recomendação')
                            description = rec.get('description', '')
                            st.write(f"{priority_colors.get(priority, '⚪')} **{title}**")
                            st.write(f"*{description}*")
                        with col2:
                            category = rec.get('category', 'General')
                            effort = rec.get('effort', 'Medium')
                            st.write(f"**Categoria:** {category}")
                            st.write(f"**Esforço:** {effort}")
                    elif isinstance(rec, str):
                        # Se for string simples, apenas exibir
                        st.write(f"• {rec}")
            else:
                st.info("Nenhuma recomendação específica")
            
            # Exportar
            st.subheader("📤 Exportar Relatório")
            
            col1, col2 = st.columns(2)
            with col1:
                if st.button("📄 Exportar JSON"):
                    json_str = json.dumps(result, indent=2, default=str)
                    st.download_button(
                        label="⬇️ Download JSON",
                        data=json_str,
                        file_name=f"stride_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                        mime="application/json"
                    )
            
            with col2:
                if st.button("📊 Gerar Relatório HTML"):
                    html = generate_html_report(result)
                    st.download_button(
                        label="⬇️ Download HTML",
                        data=html,
                        file_name=f"stride_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.html",
                        mime="text/html"
                    )
        else:
            st.info("Execute uma análise primeiro na aba 'Análise'")
    
    with tab3:
        st.header("Chat sobre Segurança")
        
        st.info("💬 Faça perguntas sobre segurança cloud e STRIDE")
        
        # Exibir histórico
        for message in st.session_state.chat_history:
            with st.chat_message(message["role"]):
                st.write(message["content"])
        
        # Input do usuário
        if prompt := st.chat_input("Digite sua pergunta..."):
            # Adicionar ao histórico
            st.session_state.chat_history.append({"role": "user", "content": prompt})
            
            with st.chat_message("user"):
                st.write(prompt)
            
            # Gerar resposta
            with st.chat_message("assistant"):
                # Buscar contexto relevante
                relevant_docs = st.session_state.vector_db.search(prompt)
                
                # Gerar resposta baseada no contexto
                if OPENAI_AVAILABLE and os.getenv("OPENAI_API_KEY"):
                    response = generate_ai_response(prompt, relevant_docs)
                else:
                    response = generate_simple_response(prompt, relevant_docs)
                
                st.write(response)
                st.session_state.chat_history.append({"role": "assistant", "content": response})


def generate_html_report(result: Dict) -> str:
    """Gera relatório HTML"""
    risk_score = result.get('risk_score', 0)
    risk_color = '#28a745' if risk_score < 4 else '#ffc107' if risk_score < 7 else '#dc3545'
    
    html = f"""<!DOCTYPE html>
<html>
<head>
    <title>STRIDE Security Report</title>
    <meta charset="UTF-8">
    <style>
        body {{ font-family: 'Segoe UI', Arial, sans-serif; margin: 20px; background: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 10px; margin-bottom: 30px; text-align: center; }}
        .metric {{ display: inline-block; padding: 20px; margin: 10px; background: #f8f9fa; border-radius: 8px; text-align: center; min-width: 150px; }}
        .metric-value {{ font-size: 2em; font-weight: bold; color: #2c3e50; }}
        .risk-score {{ color: {risk_color}; }}
        .threat {{ border-left: 4px solid #dc3545; padding: 15px; margin: 10px 0; background: #f8f9fa; }}
        .recommendation {{ border-left: 4px solid #28a745; padding: 15px; margin: 10px 0; background: #f8f9fa; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>STRIDE Security Analysis Report</h1>
            <p>{result.get('timestamp', 'N/A')}</p>
        </div>
        
        <div style="text-align: center;">
            <div class="metric">
                <div>Risk Score</div>
                <div class="metric-value risk-score">{risk_score}/10</div>
            </div>
            <div class="metric">
                <div>Threats</div>
                <div class="metric-value">{len(result.get('threats', []))}</div>
            </div>
            <div class="metric">
                <div>Recommendations</div>
                <div class="metric-value">{len(result.get('recommendations', []))}</div>
            </div>
        </div>
        
        <h2>Threats Identified</h2>
        {"".join([f'<div class="threat"><strong>{t.get("category")}</strong> - {t.get("description")}</div>' for t in result.get('threats', [])])}
        
        <h2>Recommendations</h2>
        {"".join([f'<div class="recommendation"><strong>{r.get("title")}</strong> - {r.get("description")}</div>' for r in result.get('recommendations', [])])}
    </div>
</body>
</html>"""
    
    return html


def generate_ai_response(prompt: str, context: List[Dict]) -> str:
    """Gera resposta usando OpenAI"""
    try:
        client = OpenAI()
        
        context_str = "\n".join([doc.get("content", "") for doc in context])
        
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": "You are a cloud security expert. Answer in Portuguese."},
                {"role": "user", "content": f"Context: {context_str}\n\nQuestion: {prompt}"}
            ],
            max_tokens=500,
            temperature=0.7
        )
        
        return response.choices[0].message.content
    except:
        return generate_simple_response(prompt, context)


def generate_simple_response(prompt: str, context: List[Dict]) -> str:
    """Gera resposta simples baseada em regras"""
    prompt_lower = prompt.lower()
    
    # Respostas baseadas em palavras-chave
    if "stride" in prompt_lower:
        return """STRIDE é um modelo de modelagem de ameaças desenvolvido pela Microsoft:
        
• **Spoofing**: Falsificação de identidade
• **Tampering**: Alteração não autorizada de dados
• **Repudiation**: Negação de ações realizadas
• **Information Disclosure**: Exposição não autorizada de informações
• **Denial of Service**: Tornar o sistema indisponível
• **Elevation of Privilege**: Obter permissões não autorizadas"""
    
    elif "aws" in prompt_lower:
        return """Para segurança em AWS, considere:
        
• **IAM**: Configure políticas de menor privilégio
• **VPC**: Isole recursos em redes privadas
• **GuardDuty**: Ative detecção de ameaças
• **CloudTrail**: Habilite auditoria completa
• **KMS**: Use criptografia gerenciada"""
    
    elif "azure" in prompt_lower:
        return """Para segurança em Azure:
        
• **Azure AD**: Configure autenticação forte
• **Key Vault**: Gerencie segredos centralmente
• **Security Center**: Use a central de segurança
• **Sentinel**: Implemente SIEM
• **Azure Policy**: Defina políticas de governança"""
    
    elif "risco" in prompt_lower or "risk" in prompt_lower:
        return """O risk score é calculado baseado em:
        
• Número e severidade das ameaças identificadas
• Presença de controles de segurança
• Configurações de rede e acesso
• Conformidade com best practices
• Exposição de dados sensíveis"""
    
    else:
        if context:
            return f"Baseado no contexto disponível, encontrei {len(context)} informações relevantes sobre sua pergunta. As principais práticas de segurança incluem: princípio do menor privilégio, defesa em profundidade, monitoramento contínuo e criptografia de dados."
        else:
            return "Posso ajudar com questões sobre segurança cloud, STRIDE, AWS, Azure, GCP e melhores práticas de arquitetura. Faça uma pergunta específica para obter uma resposta mais detalhada."


# Executar aplicação
if __name__ == "__main__":
    create_streamlit_interface()