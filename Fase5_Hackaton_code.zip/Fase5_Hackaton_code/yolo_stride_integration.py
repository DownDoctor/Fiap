# yolo_stride_integration.py
"""
Sistema de integração do YOLO treinado com o STRIDE Analyzer
Mostra exatamente como o modelo melhora a análise
"""

from ultralytics import YOLO
import cv2
import numpy as np
from typing import Dict, List, Tuple, Optional
import json
from pathlib import Path
from dataclasses import dataclass, asdict
from datetime import datetime

@dataclass
class DetectedComponent:
    """Componente detectado pelo YOLO"""
    name: str
    provider: str
    service_type: str
    confidence: float
    position: Tuple[int, int]
    bbox: List[int]
    relationships: List[str] = None
    
class YOLOArchitectureAnalyzer:
    """Analisador de arquitetura usando YOLO treinado"""
    
    def __init__(self, model_path: str = "./cloud_icons_training/best_cloud_icons.pt"):
        """
        Inicializa com o modelo YOLO treinado
        """
        self.model = YOLO(model_path)
        
        # Mapeamento de classes para informações detalhadas
        self.service_mapping = {
            'aws_ec2': {
                'provider': 'AWS',
                'type': 'compute',
                'full_name': 'EC2 Instance',
                'threats': ['Unauthorized access', 'Data exposure', 'DDoS'],
                'compliance': ['PCI-DSS', 'HIPAA'],
                'cost_range': '$50-500/month',
                'best_practices': ['Use IAM roles', 'Enable monitoring', 'Regular patching']
            },
            'aws_s3': {
                'provider': 'AWS',
                'type': 'storage',
                'full_name': 'S3 Bucket',
                'threats': ['Public exposure', 'Data leakage', 'Ransomware'],
                'compliance': ['GDPR', 'SOC2'],
                'cost_range': '$20-200/month',
                'best_practices': ['Enable versioning', 'Use encryption', 'Block public access']
            },
            'aws_rds': {
                'provider': 'AWS',
                'type': 'database',
                'full_name': 'RDS Database',
                'threats': ['SQL injection', 'Data breach', 'Privilege escalation'],
                'compliance': ['PCI-DSS', 'HIPAA', 'SOC2'],
                'cost_range': '$100-1000/month',
                'best_practices': ['Enable encryption', 'Regular backups', 'Use VPC']
            },
            'aws_lambda': {
                'provider': 'AWS',
                'type': 'serverless',
                'full_name': 'Lambda Function',
                'threats': ['Code injection', 'Privilege escalation', 'Resource exhaustion'],
                'compliance': ['SOC2'],
                'cost_range': '$0-100/month',
                'best_practices': ['Least privilege IAM', 'Input validation', 'Timeout limits']
            },
            'azure_vm': {
                'provider': 'Azure',
                'type': 'compute',
                'full_name': 'Virtual Machine',
                'threats': ['Unauthorized access', 'Malware', 'Data exposure'],
                'compliance': ['ISO 27001', 'SOC2'],
                'cost_range': '$60-600/month',
                'best_practices': ['Use Managed Identity', 'Enable Azure Security Center']
            },
            'gcp_compute_engine': {
                'provider': 'GCP',
                'type': 'compute',
                'full_name': 'Compute Engine',
                'threats': ['SSH brute force', 'Data exposure', 'Privilege escalation'],
                'compliance': ['PCI-DSS', 'HIPAA'],
                'cost_range': '$40-400/month',
                'best_practices': ['Use OS Login', 'Enable Cloud Armor']
            },
            'k8s_pod': {
                'provider': 'Kubernetes',
                'type': 'container',
                'full_name': 'Kubernetes Pod',
                'threats': ['Container escape', 'Secret exposure', 'Resource hijacking'],
                'compliance': ['CIS Benchmark'],
                'cost_range': 'Variable',
                'best_practices': ['Use RBAC', 'Network policies', 'Pod security policies']
            }
        }
    
    def analyze_architecture_image(self, image_path: str) -> Dict:
        """
        Analisa imagem de arquitetura com YOLO
        
        Returns:
            Dict com componentes detectados e análise inicial
        """
        print("🔍 Executando detecção YOLO...")
        
        # Detectar componentes
        results = self.model(image_path, conf=0.3)
        
        # Processar detecções
        detected_components = []
        architecture_context = {
            'providers': set(),
            'service_types': set(),
            'total_components': 0,
            'architecture_patterns': [],
            'potential_risks': [],
            'compliance_frameworks': set(),
            'estimated_cost': {'min': 0, 'max': 0}
        }
        
        for r in results:
            boxes = r.boxes
            if boxes is not None:
                for box in boxes:
                    # Extrair informações da detecção
                    x1, y1, x2, y2 = box.xyxy[0].tolist()
                    confidence = box.conf[0].item()
                    class_id = int(box.cls[0].item())
                    class_name = self.model.names[class_id]
                    
                    # Obter metadados do serviço
                    service_info = self.service_mapping.get(class_name, {})
                    
                    component = {
                        'id': f"comp_{len(detected_components)}",
                        'name': class_name,
                        'display_name': service_info.get('full_name', class_name),
                        'provider': service_info.get('provider', 'Unknown'),
                        'type': service_info.get('type', 'generic'),
                        'confidence': round(confidence, 2),
                        'position': {
                            'x': int((x1 + x2) / 2),
                            'y': int((y1 + y2) / 2)
                        },
                        'bbox': [int(x1), int(y1), int(x2), int(y2)],
                        'threats': service_info.get('threats', []),
                        'compliance': service_info.get('compliance', []),
                        'best_practices': service_info.get('best_practices', []),
                        'cost_estimate': service_info.get('cost_range', 'Unknown')
                    }
                    
                    detected_components.append(component)
                    
                    # Atualizar contexto da arquitetura
                    architecture_context['providers'].add(component['provider'])
                    architecture_context['service_types'].add(component['type'])
                    architecture_context['compliance_frameworks'].update(component['compliance'])
        
        architecture_context['total_components'] = len(detected_components)
        architecture_context['providers'] = list(architecture_context['providers'])
        architecture_context['service_types'] = list(architecture_context['service_types'])
        architecture_context['compliance_frameworks'] = list(architecture_context['compliance_frameworks'])
        
        # Analisar padrões arquiteturais
        patterns = self._identify_architecture_patterns(detected_components)
        architecture_context['architecture_patterns'] = patterns
        
        # Identificar riscos potenciais baseados nos componentes
        risks = self._identify_potential_risks(detected_components)
        architecture_context['potential_risks'] = risks
        
        # Estimar custos
        architecture_context['estimated_cost'] = self._estimate_total_cost(detected_components)
        
        # Detectar conexões prováveis
        connections = self._infer_connections(detected_components)
        
        return {
            'timestamp': datetime.now().isoformat(),
            'detected_components': detected_components,
            'architecture_context': architecture_context,
            'inferred_connections': connections,
            'yolo_confidence': self._calculate_overall_confidence(detected_components)
        }
    
    def _identify_architecture_patterns(self, components: List[Dict]) -> List[str]:
        """Identifica padrões arquiteturais baseados nos componentes detectados"""
        patterns = []
        
        # Contar tipos de serviços
        type_counts = {}
        for comp in components:
            svc_type = comp['type']
            type_counts[svc_type] = type_counts.get(svc_type, 0) + 1
        
        # Identificar padrões
        if type_counts.get('serverless', 0) >= 2:
            patterns.append('Serverless Architecture')
        
        if type_counts.get('container', 0) >= 2:
            patterns.append('Microservices Architecture')
        
        if type_counts.get('database', 0) >= 2:
            patterns.append('Multi-Database Pattern')
        
        if len(set(c['provider'] for c in components)) > 1:
            patterns.append('Multi-Cloud Architecture')
        
        if type_counts.get('compute', 0) >= 3:
            patterns.append('Distributed Computing')
        
        if any('api' in c['name'].lower() for c in components):
            patterns.append('API-First Architecture')
        
        return patterns
    
    def _identify_potential_risks(self, components: List[Dict]) -> List[Dict]:
        """Identifica riscos potenciais baseados nos componentes"""
        risks = []
        
        # Verificar exposição de storage
        storage_components = [c for c in components if c['type'] == 'storage']
        if storage_components:
            risks.append({
                'category': 'Information Disclosure',
                'severity': 'high',
                'description': f'Detected {len(storage_components)} storage components that may be publicly exposed',
                'affected_components': [s['name'] for s in storage_components]
            })
        
        # Verificar databases sem encryption
        db_components = [c for c in components if c['type'] == 'database']
        if db_components:
            risks.append({
                'category': 'Tampering',
                'severity': 'critical',
                'description': 'Database components require encryption verification',
                'affected_components': [d['name'] for d in db_components]
            })
        
        # Verificar componentes compute sem proteção
        compute_components = [c for c in components if c['type'] == 'compute']
        if compute_components:
            risks.append({
                'category': 'Elevation of Privilege',
                'severity': 'high',
                'description': 'Compute instances need proper IAM configuration',
                'affected_components': [c['name'] for c in compute_components]
            })
        
        # Multi-cloud complexity
        providers = set(c['provider'] for c in components)
        if len(providers) > 1:
            risks.append({
                'category': 'Denial of Service',
                'severity': 'medium',
                'description': 'Multi-cloud architecture increases complexity and potential failure points',
                'affected_components': list(providers)
            })
        
        return risks
    
    def _estimate_total_cost(self, components: List[Dict]) -> Dict:
        """Estima custo total baseado nos componentes"""
        total_min = 0
        total_max = 0
        
        for comp in components:
            cost_range = comp.get('cost_estimate', '$0-0/month')
            if '$' in cost_range:
                # Parse cost range
                try:
                    parts = cost_range.replace('$', '').replace('/month', '').split('-')
                    if len(parts) == 2:
                        total_min += int(parts[0])
                        total_max += int(parts[1])
                except:
                    pass
        
        return {
            'min': total_min,
            'max': total_max,
            'estimated_monthly': (total_min + total_max) / 2,
            'estimated_yearly': ((total_min + total_max) / 2) * 12
        }
    
    def _infer_connections(self, components: List[Dict]) -> List[Dict]:
        """Infere conexões prováveis entre componentes"""
        connections = []
        
        # Regras de conexão baseadas em tipos
        connection_rules = {
            ('compute', 'database'): 'data_access',
            ('compute', 'storage'): 'file_access',
            ('serverless', 'database'): 'query',
            ('compute', 'compute'): 'service_call',
            ('container', 'container'): 'microservice_communication',
            ('compute', 'serverless'): 'function_invocation'
        }
        
        for i, comp1 in enumerate(components):
            for comp2 in components[i+1:]:
                # Verificar se há regra de conexão
                type_pair = (comp1['type'], comp2['type'])
                type_pair_rev = (comp2['type'], comp1['type'])
                
                connection_type = connection_rules.get(type_pair) or connection_rules.get(type_pair_rev)
                
                if connection_type:
                    # Calcular distância
                    dist = np.sqrt(
                        (comp1['position']['x'] - comp2['position']['x'])**2 +
                        (comp1['position']['y'] - comp2['position']['y'])**2
                    )
                    
                    # Conectar se próximos
                    if dist < 500:  # threshold de distância
                        connections.append({
                            'source': comp1['id'],
                            'source_name': comp1['name'],
                            'target': comp2['id'],
                            'target_name': comp2['name'],
                            'type': connection_type,
                            'distance': int(dist),
                            'security_concern': self._get_connection_security_concern(comp1, comp2)
                        })
        
        return connections
    
    def _get_connection_security_concern(self, comp1: Dict, comp2: Dict) -> str:
        """Identifica preocupações de segurança na conexão"""
        if comp1['type'] == 'database' or comp2['type'] == 'database':
            return 'Requires encryption in transit'
        if comp1['type'] == 'storage' or comp2['type'] == 'storage':
            return 'Validate access controls'
        if comp1['provider'] != comp2['provider']:
            return 'Cross-provider communication needs secure channel'
        return 'Standard security practices apply'
    
    def _calculate_overall_confidence(self, components: List[Dict]) -> float:
        """Calcula confiança geral da detecção"""
        if not components:
            return 0.0
        
        confidences = [c['confidence'] for c in components]
        return round(sum(confidences) / len(confidences), 2)
    
    def generate_llm_context(self, analysis_result: Dict) -> str:
        """
        Gera contexto estruturado para passar para a LLM
        Este é o que vai para o GPT-4 Vision melhorar sua análise
        """
        components = analysis_result['detected_components']
        context = analysis_result['architecture_context']
        
        llm_context = f"""
## PRE-DETECTED CLOUD COMPONENTS (via YOLO):

Total Components: {context['total_components']}
Providers: {', '.join(context['providers'])}
Architecture Patterns: {', '.join(context['architecture_patterns'])}
Service Types: {', '.join(context['service_types'])}

### Detected Services with High Confidence:
"""
        
        for comp in components:
            llm_context += f"""
- **{comp['display_name']}** ({comp['provider']})
  - Type: {comp['type']}
  - Position: ({comp['position']['x']}, {comp['position']['y']})
  - Confidence: {comp['confidence']}
  - Known Threats: {', '.join(comp['threats'][:2]) if comp['threats'] else 'Standard'}
  - Compliance: {', '.join(comp['compliance'][:2]) if comp['compliance'] else 'N/A'}
"""
        
        llm_context += f"""

### Identified Security Risks:
"""
        for risk in context['potential_risks']:
            llm_context += f"""
- **{risk['category']}** (Severity: {risk['severity']})
  - {risk['description']}
  - Affected: {', '.join(risk['affected_components'][:3])}
"""
        
        llm_context += f"""

### Cost Estimation:
- Monthly: ${context['estimated_cost']['estimated_monthly']:.0f}
- Yearly: ${context['estimated_cost']['estimated_yearly']:.0f}

### Compliance Frameworks Detected:
{', '.join(context['compliance_frameworks']) if context['compliance_frameworks'] else 'None identified'}

IMPORTANT: Use this pre-detected information to enhance your analysis. 
Focus on the relationships between these components and identify:
1. Missing security controls
2. STRIDE threats specific to these services
3. Compliance gaps for the detected frameworks
4. Architecture improvements based on the patterns identified
"""
        
        return llm_context
    
    def generate_stride_recommendations(self, analysis_result: Dict) -> List[Dict]:
        """
        Gera recomendações STRIDE específicas baseadas nos componentes detectados
        """
        recommendations = []
        components = analysis_result['detected_components']
        
        # Recomendações por tipo de serviço
        for comp in components:
            comp_recs = []
            
            # Spoofing
            if comp['type'] in ['compute', 'serverless', 'container']:
                comp_recs.append({
                    'stride_category': 'Spoofing',
                    'component': comp['name'],
                    'recommendation': f"Enable MFA and use {comp['provider']} IAM roles for {comp['display_name']}",
                    'priority': 'high',
                    'implementation': comp['best_practices'][0] if comp['best_practices'] else 'Review authentication'
                })
            
            # Tampering
            if comp['type'] in ['database', 'storage']:
                comp_recs.append({
                    'stride_category': 'Tampering',
                    'component': comp['name'],
                    'recommendation': f"Enable encryption at rest and versioning for {comp['display_name']}",
                    'priority': 'critical',
                    'implementation': 'Use provider-managed encryption keys'
                })
            
            # Repudiation
            if comp['type'] in ['compute', 'serverless']:
                comp_recs.append({
                    'stride_category': 'Repudiation',
                    'component': comp['name'],
                    'recommendation': f"Enable comprehensive logging for {comp['display_name']}",
                    'priority': 'medium',
                    'implementation': f"Use {comp['provider']} native logging services"
                })
            
            # Information Disclosure
            if comp['type'] == 'storage':
                comp_recs.append({
                    'stride_category': 'Information Disclosure',
                    'component': comp['name'],
                    'recommendation': f"Review and restrict public access for {comp['display_name']}",
                    'priority': 'critical',
                    'implementation': 'Block public access by default, use presigned URLs'
                })
            
            # Denial of Service
            if comp['type'] in ['compute', 'serverless', 'container']:
                comp_recs.append({
                    'stride_category': 'Denial of Service',
                    'component': comp['name'],
                    'recommendation': f"Implement rate limiting and auto-scaling for {comp['display_name']}",
                    'priority': 'high',
                    'implementation': 'Configure DDoS protection and resource limits'
                })
            
            # Elevation of Privilege
            if comp['type'] in ['compute', 'container']:
                comp_recs.append({
                    'stride_category': 'Elevation of Privilege',
                    'component': comp['name'],
                    'recommendation': f"Apply least privilege principle for {comp['display_name']}",
                    'priority': 'critical',
                    'implementation': 'Use role-based access control with minimal permissions'
                })
            
            recommendations.extend(comp_recs)
        
        return recommendations


# Integração com o stride_analyzer_enhanced.py
class EnhancedSTRIDEAnalyzerWithYOLO:
    """
    Versão melhorada do EnhancedSTRIDEAnalyzer que usa YOLO
    """
    
    def __init__(self, yolo_model_path: str = None):
        self.yolo_analyzer = YOLOArchitectureAnalyzer(yolo_model_path) if yolo_model_path else None
        self.vision_api_available = self._check_openai_available()
    
    def _check_openai_available(self):
        try:
            from openai import OpenAI
            return True
        except:
            return False
    
    def analyze_with_yolo_enhanced(self, image_path: str, use_vision_api: bool = True) -> Dict:
        """
        Análise completa usando YOLO + Vision API (se disponível)
        """
        print("🚀 Iniciando análise aprimorada com YOLO...")
        
        # 1. Detecção rápida com YOLO
        yolo_result = self.yolo_analyzer.analyze_architecture_image(image_path)
        print(f"✅ YOLO detectou {len(yolo_result['detected_components'])} componentes")
        
        # 2. Gerar contexto para LLM
        llm_context = self.yolo_analyzer.generate_llm_context(yolo_result)
        
        # 3. Análise com Vision API (se disponível)
        if use_vision_api and self.vision_api_available:
            vision_result = self._analyze_with_vision_api(image_path, llm_context)
            
            # Combinar resultados
            combined_result = self._merge_results(yolo_result, vision_result)
        else:
            # Usar apenas YOLO
            combined_result = yolo_result
        
        # 4. Gerar recomendações STRIDE específicas
        stride_recommendations = self.yolo_analyzer.generate_stride_recommendations(yolo_result)
        combined_result['stride_recommendations'] = stride_recommendations
        
        # 5. Calcular risk score
        combined_result['risk_assessment'] = self._calculate_risk_assessment(combined_result)
        
        return combined_result
    
    def _analyze_with_vision_api(self, image_path: str, yolo_context: str) -> Dict:
        """
        Análise com OpenAI Vision usando contexto do YOLO
        """
        from openai import OpenAI
        import base64
        
        client = OpenAI()
        
        # Preparar imagem
        with open(image_path, "rb") as image_file:
            base64_image = base64.b64encode(image_file.read()).decode('utf-8')
        
        # Prompt otimizado com contexto YOLO
        system_prompt = """You are an expert cloud security architect. 
        You have been provided with pre-detected components from the architecture.
        Use this information to provide a more accurate and detailed analysis."""
        
        user_prompt = f"""{yolo_context}

Based on the pre-detected components above and the architecture diagram, provide:
1. Detailed security analysis using STRIDE methodology
2. Specific vulnerabilities for each detected service
3. Compliance gaps based on the frameworks identified
4. Cost optimization opportunities
5. Architecture improvements

Return a comprehensive JSON analysis."""
        
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {
                    "role": "user",
                    "content": [
                        {"type": "text", "text": user_prompt},
                        {
                            "type": "image_url",
                            "image_url": {
                                "url": f"data:image/jpeg;base64,{base64_image}",
                                "detail": "high"
                            }
                        }
                    ]
                }
            ],
            max_tokens=3000,
            temperature=0.1,
            response_format={"type": "json_object"}
        )
        
        return json.loads(response.choices[0].message.content)
    
    def _merge_results(self, yolo_result: Dict, vision_result: Dict) -> Dict:
        """
        Combina resultados do YOLO com Vision API
        """
        merged = {
            'timestamp': datetime.now().isoformat(),
            'analysis_method': 'YOLO + Vision API',
            
            # Componentes do YOLO (mais precisos para ícones)
            'detected_components': yolo_result['detected_components'],
            'architecture_context': yolo_result['architecture_context'],
            
            # Análise detalhada da Vision API
            'detailed_analysis': vision_result,
            
            # Confiança combinada
            'confidence_scores': {
                'yolo_confidence': yolo_result['yolo_confidence'],
                'overall_confidence': (yolo_result['yolo_confidence'] + 0.9) / 2  # Vision assume 90%
            }
        }
        
        return merged
    
    def _calculate_risk_assessment(self, result: Dict) -> Dict:
        """
        Calcula avaliação de risco baseada em todos os dados
        """
        risk_factors = {
            'component_risks': 0,
            'architecture_risks': 0,
            'compliance_risks': 0,
            'cost_risks': 0
        }
        
        # Riscos por componente
        for comp in result.get('detected_components', []):
            if comp.get('threats'):
                risk_factors['component_risks'] += len(comp['threats']) * 2
        
        # Riscos arquiteturais
        patterns = result.get('architecture_context', {}).get('architecture_patterns', [])
        if 'Multi-Cloud Architecture' in patterns:
            risk_factors['architecture_risks'] += 5
        
        # Riscos de compliance
        frameworks = result.get('architecture_context', {}).get('compliance_frameworks', [])
        risk_factors['compliance_risks'] = len(frameworks) * 3
        
        # Riscos de custo
        cost = result.get('architecture_context', {}).get('estimated_cost', {})
        if cost.get('estimated_monthly', 0) > 1000:
            risk_factors['cost_risks'] = 5
        
        # Calcular score total
        total_risk = sum(risk_factors.values())
        risk_score = min(10, total_risk / 10)
        
        return {
            'risk_score': round(risk_score, 1),
            'risk_level': 'Critical' if risk_score > 7 else 'High' if risk_score > 5 else 'Medium' if risk_score > 3 else 'Low',
            'risk_factors': risk_factors,
            'top_risks': self._identify_top_risks(result)
        }
    
    def _identify_top_risks(self, result: Dict) -> List[str]:
        """
        Identifica os principais riscos
        """
        top_risks = []
        
        # Verificar componentes críticos
        for comp in result.get('detected_components', []):
            if comp['type'] == 'database' and 'encryption' not in str(comp.get('best_practices', [])):
                top_risks.append(f"Unencrypted database: {comp['name']}")
            if comp['type'] == 'storage':
                top_risks.append(f"Potential public exposure: {comp['name']}")
        
        return top_risks[:5]


# Exemplo de uso completo
if __name__ == "__main__":
    print("="*60)
    print("🎯 DEMONSTRAÇÃO: YOLO + STRIDE Integration")
    print("="*60)
    
    # 1. Carregar modelo YOLO treinado
    model_path = "./cloud_icons_training/best_cloud_icons.pt"
    
    if not Path(model_path).exists():
        print("⚠️ Modelo YOLO não encontrado. Treine primeiro!")
        exit(1)
    
    # 2. Analisar uma imagem
    test_image = "architecture_diagram.jpg"  # Sua imagem aqui
    
    if not Path(test_image).exists():
        print("⚠️ Imagem de teste não encontrada")
        # Criar imagem de exemplo
        img = np.ones((800, 1200, 3), dtype=np.uint8) * 240
        cv2.imwrite(test_image, img)
    
    # 3. Executar análise
    analyzer = EnhancedSTRIDEAnalyzerWithYOLO(model_path)
    result = analyzer.analyze_with_yolo_enhanced(test_image, use_vision_api=False)
    
    # 4. Exibir resultados
    print("\n📊 RESULTADOS DA ANÁLISE:")
    print(f"Componentes detectados: {len(result['detected_components'])}")
    print(f"Providers: {', '.join(result['architecture_context']['providers'])}")
    print(f"Padrões identificados: {', '.join(result['architecture_context']['architecture_patterns'])}")
    print(f"Risk Score: {result['risk_assessment']['risk_score']}/10")
    
    print("\n🎯 TOP RECOMENDAÇÕES STRIDE:")
    for rec in result['stride_recommendations'][:5]:
        print(f"- [{rec['stride_category']}] {rec['recommendation']}")
        print(f"  Componente: {rec['component']} | Prioridade: {rec['priority']}")
    
    print("\n💰 ESTIMATIVA DE CUSTOS:")
    cost = result['architecture_context']['estimated_cost']
    print(f"Mensal: ${cost['estimated_monthly']:.2f}")
    print(f"Anual: ${cost['estimated_yearly']:.2f}")
    
    # Salvar resultado
    with open('yolo_analysis_result.json', 'w') as f:
        json.dump(result, f, indent=2, default=str)
    print("\n✅ Resultado salvo em: yolo_analysis_result.json")