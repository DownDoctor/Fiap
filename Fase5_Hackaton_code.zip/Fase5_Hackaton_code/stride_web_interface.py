#!/usr/bin/env python3
"""
STRIDE Enhanced Web Interface com Streamlit
Interface web moderna para análise de segurança multi-cloud com STRIDE
"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from plotly.subplots import make_subplots
import time
import json
import base64
from datetime import datetime
from pathlib import Path
import io
from PIL import Image
import sys
import os

# Configuração da página Streamlit
st.set_page_config(
    page_title="STRIDE Security Analyzer",
    page_icon="🔒",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Adicionar CSS customizado
st.markdown("""
<style>
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        color: white;
        text-align: center;
    }
    
    .architecture-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        border-left: 5px solid #007bff;
        margin: 1rem 0;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    
    .metric-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        text-align: center;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    
    .progress-container {
        background: #f8f9fa;
        padding: 2rem;
        border-radius: 10px;
        margin: 1rem 0;
    }
    
    .threat-critical { color: #dc3545; font-weight: bold; }
    .threat-high { color: #fd7e14; font-weight: bold; }
    .threat-medium { color: #ffc107; font-weight: bold; }
    .threat-low { color: #28a745; font-weight: bold; }
    
    /* Sidebar styling improvements */
    .sidebar .sidebar-content {
        background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
    }
    
    /* Checkbox styling */
    .stCheckbox > label {
        font-weight: 500;
        color: #2c3e50;
    }
    
    /* Button styling */
    .stButton > button {
        border-radius: 8px;
        border: none;
        background: linear-gradient(45deg, #667eea, #764ba2);
        color: white;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(0,0,0,0.15);
    }
    
    /* Multiselect styling */
    .stMultiSelect > div > div {
        border-radius: 8px;
    }
</style>
""", unsafe_allow_html=True)

# Importar classes do sistema STRIDE (simulação para demonstração)
class MockSTRIDEAnalyzer:
    """Simulador do analisador STRIDE para demonstração"""
    
    def __init__(self):
        self.architectures = {
            "AWS API Gateway": {
                "provider": "AWS",
                "type": "api_gateway",
                "components": ["API Gateway", "Lambda", "DynamoDB", "CloudWatch"],
                "complexity": 75,
                "icon": "🟠"
            },
            "Azure API Management": {
                "provider": "Azure",
                "type": "api_management", 
                "components": ["API Management", "Logic Apps", "SQL Database", "Active Directory"],
                "complexity": 80,
                "icon": "🔵"
            },
            "AWS Microservices": {
                "provider": "AWS",
                "type": "microservices",
                "components": ["EKS", "ALB", "RDS", "ElastiCache", "Service Mesh"],
                "complexity": 90,
                "icon": "🟠"
            },
            "GCP Cloud Run": {
                "provider": "GCP",
                "type": "serverless",
                "components": ["Cloud Run", "Cloud SQL", "Cloud Storage", "IAM"],
                "complexity": 70,
                "icon": "🟡"
            },
            "Hybrid Multi-Cloud": {
                "provider": "Multi-Cloud",
                "type": "hybrid",
                "components": ["AWS Gateway", "Azure AD", "GCP Storage", "Kubernetes"],
                "complexity": 95,
                "icon": "🌐"
            },
            "Kubernetes Native": {
                "provider": "K8s",
                "type": "container_orchestration",
                "components": ["Pods", "Services", "Ingress", "ConfigMaps", "Secrets"],
                "complexity": 85,
                "icon": "⚙️"
            }
        }
    
    def analyze_architecture(self, arch_name, progress_callback=None):
        """Simula análise de arquitetura com progresso"""
        
        arch_config = self.architectures[arch_name]
        total_steps = 8
        
        # Simular steps da análise
        steps = [
            "🔍 Detectando componentes...",
            "🎭 Análise STRIDE - Spoofing...",
            "🔧 Análise STRIDE - Tampering...", 
            "📝 Análise STRIDE - Repudiation...",
            "📄 Análise STRIDE - Information Disclosure...",
            "⚡ Análise STRIDE - Denial of Service...",
            "⬆️ Análise STRIDE - Elevation of Privilege...",
            "📊 Gerando relatório..."
        ]
        
        results = {
            "architecture_name": arch_name,
            "provider": arch_config["provider"],
            "type": arch_config["type"],
            "components": arch_config["components"],
            "total_threats": 0,
            "threats_by_severity": {"critical": 0, "high": 0, "medium": 0, "low": 0},
            "risk_score": 0.0,
            "stride_distribution": {},
            "recommendations": [],
            "analysis_time": 0
        }
        
        start_time = time.time()
        
        for i, step in enumerate(steps):
            if progress_callback:
                progress_callback(i + 1, total_steps, step)
            
            # Simular tempo de processamento
            time.sleep(0.5)
            
            # Simular geração de dados baseado no step
            if "Spoofing" in step:
                threats = max(1, int(arch_config["complexity"] / 20))
                results["stride_distribution"]["spoofing"] = threats
                results["total_threats"] += threats
                
            elif "Tampering" in step:
                threats = max(1, int(arch_config["complexity"] / 25))
                results["stride_distribution"]["tampering"] = threats
                results["total_threats"] += threats
                
            elif "Information Disclosure" in step:
                threats = max(2, int(arch_config["complexity"] / 15))
                results["stride_distribution"]["information_disclosure"] = threats
                results["total_threats"] += threats
                
            elif "Denial of Service" in step:
                threats = max(1, int(arch_config["complexity"] / 30))
                results["stride_distribution"]["denial_of_service"] = threats
                results["total_threats"] += threats
        
        # Calcular distribuição por severidade
        total = results["total_threats"]
        if total > 0:
            results["threats_by_severity"]["critical"] = max(1, int(total * 0.15))
            results["threats_by_severity"]["high"] = max(1, int(total * 0.25))
            results["threats_by_severity"]["medium"] = max(1, int(total * 0.35))
            results["threats_by_severity"]["low"] = total - sum([
                results["threats_by_severity"]["critical"],
                results["threats_by_severity"]["high"], 
                results["threats_by_severity"]["medium"]
            ])
        
        # Calcular risk score
        results["risk_score"] = min(10.0, (arch_config["complexity"] / 10) + 
                                   (results["threats_by_severity"]["critical"] * 0.5))
        
        # Gerar recomendações
        results["recommendations"] = [
            f"Implementar autenticação robusta para {arch_config['type']}",
            f"Configurar monitoramento de segurança para {arch_config['provider']}",
            f"Estabelecer controles de acesso granulares",
            f"Implementar logging e auditoria abrangentes"
        ]
        
        results["analysis_time"] = time.time() - start_time
        
        return results

def init_session_state():
    """Inicializa o estado da sessão"""
    if 'analysis_results' not in st.session_state:
        st.session_state.analysis_results = {}
    if 'analysis_in_progress' not in st.session_state:
        st.session_state.analysis_in_progress = False
    if 'selected_architectures' not in st.session_state:
        st.session_state.selected_architectures = []

def render_header():
    """Renderiza o cabeçalho principal"""
    st.markdown("""
    <div class="main-header">
        <h1>🔒 STRIDE Security Analyzer Enhanced</h1>
        <p>Análise de Segurança Multi-Cloud com Interface Web Moderna</p>
        <p><strong>Microsoft STRIDE Methodology</strong> | <em>Powered by Streamlit</em></p>
    </div>
    """, unsafe_allow_html=True)

def render_sidebar():
    """Renderiza a barra lateral com controles"""
    st.sidebar.markdown("## ⚙️ Configurações de Análise")
    
    analyzer = MockSTRIDEAnalyzer()
    
    # Seleção de arquiteturas
    st.sidebar.markdown("### 🗗️ Selecionar Arquiteturas")
    
    selected_archs = []
    for arch_name, config in analyzer.architectures.items():
        col1, col2 = st.sidebar.columns([1, 4])
        with col1:
            st.markdown(config["icon"])
        with col2:
            if st.checkbox(f"**{arch_name}**", key=f"arch_{arch_name}"):
                selected_archs.append(arch_name)
        
        if f"arch_{arch_name}" in st.session_state and st.session_state[f"arch_{arch_name}"]:
            st.sidebar.markdown(f"   📋 Componentes: {len(config['components'])}")
            st.sidebar.markdown(f"   🎯 Complexidade: {config['complexity']}/100")
    
    st.session_state.selected_architectures = selected_archs
    
    # Configurações adicionais
    st.sidebar.markdown("### 🔧 Opções Avançadas")
    
    enable_thumbnails = st.sidebar.checkbox("📸 Gerar thumbnails", value=True)
    detailed_analysis = st.sidebar.checkbox("🔍 Análise detalhada", value=True)
    export_formats = st.sidebar.multiselect(
        "📄 Formatos de exportação",
        ["HTML", "JSON", "PDF", "CSV"],
        default=["HTML", "PDF"]
    )
    
    # Botão de análise
    st.sidebar.markdown("---")
    
    if len(selected_archs) == 0:
        st.sidebar.warning("⚠️ Selecione pelo menos uma arquitetura")
        analysis_disabled = True
    else:
        analysis_disabled = False
    
    if st.sidebar.button(
        f"🚀 Analisar {len(selected_archs)} Arquitetura(s)",
        disabled=analysis_disabled or st.session_state.analysis_in_progress,
        type="primary"
    ):
        return True, {
            'thumbnails': enable_thumbnails,
            'detailed': detailed_analysis,
            'formats': export_formats
        }
    
    return False, None

def render_architecture_overview():
    """Renderiza visão geral das arquiteturas selecionadas"""
    if not st.session_state.selected_architectures:
        st.info("👈 Selecione arquiteturas na barra lateral para começar")
        return
    
    st.markdown("## 🗗️ Arquiteturas Selecionadas")
    
    analyzer = MockSTRIDEAnalyzer()
    
    cols = st.columns(min(3, len(st.session_state.selected_architectures)))
    
    for i, arch_name in enumerate(st.session_state.selected_architectures):
        config = analyzer.architectures[arch_name]
        
        with cols[i % 3]:
            with st.container():
                st.markdown(f"""
                <div class="architecture-card">
                    <h3>{config['icon']} {arch_name}</h3>
                    <p><strong>Provedor:</strong> {config['provider']}</p>
                    <p><strong>Tipo:</strong> {config['type'].replace('_', ' ').title()}</p>
                    <p><strong>Componentes:</strong> {len(config['components'])}</p>
                    <p><strong>Complexidade:</strong> {config['complexity']}/100</p>
                </div>
                """, unsafe_allow_html=True)
                
                # Mostrar componentes
                with st.expander("📋 Ver componentes"):
                    for component in config['components']:
                        st.markdown(f"• {component}")

def run_analysis_with_progress(selected_configs):
    """Executa análise com barra de progresso"""
    analyzer = MockSTRIDEAnalyzer()
    
    st.session_state.analysis_in_progress = True
    st.session_state.analysis_results = {}
    
    # Container para o progresso geral
    progress_container = st.container()
    
    with progress_container:
        st.markdown("## 📊 Progresso da Análise")
        
        # Progresso geral
        overall_progress = st.progress(0)
        overall_status = st.empty()
        
        # Métricas em tempo real
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            threats_metric = st.empty()
        with col2:
            components_metric = st.empty()
        with col3:
            risk_metric = st.empty()
        with col4:
            time_metric = st.empty()
        
        total_architectures = len(st.session_state.selected_architectures)
        
        start_time = time.time()
        
        for arch_idx, arch_name in enumerate(st.session_state.selected_architectures):
            # Container específico para esta arquitetura
            arch_container = st.container()
            
            with arch_container:
                st.markdown(f"### {analyzer.architectures[arch_name]['icon']} Analisando: {arch_name}")
                
                # Progresso específico da arquitetura
                arch_progress = st.progress(0)
                arch_status = st.empty()
                
                def progress_callback(step, total_steps, message):
                    # Atualizar progresso da arquitetura
                    arch_progress.progress(step / total_steps)
                    arch_status.text(f"📋 {message}")
                    
                    # Atualizar progresso geral
                    overall_progress_value = (arch_idx + (step / total_steps)) / total_architectures
                    overall_progress.progress(overall_progress_value)
                    overall_status.text(f"🎯 Arquitetura {arch_idx + 1}/{total_architectures}: {arch_name}")
                    
                    # Atualizar métricas em tempo real
                    elapsed_time = time.time() - start_time
                    
                    with threats_metric:
                        total_threats = sum([
                            res.get('total_threats', 0) 
                            for res in st.session_state.analysis_results.values()
                        ])
                        st.metric("🎯 Ameaças", total_threats)
                    
                    with components_metric:
                        total_components = sum([
                            len(res.get('components', [])) 
                            for res in st.session_state.analysis_results.values()
                        ])
                        st.metric("📦 Componentes", total_components)
                    
                    with risk_metric:
                        if st.session_state.analysis_results:
                            avg_risk = sum([
                                res.get('risk_score', 0) 
                                for res in st.session_state.analysis_results.values()
                            ]) / len(st.session_state.analysis_results)
                            st.metric("⚠️ Risk Score", f"{avg_risk:.1f}/10")
                    
                    with time_metric:
                        st.metric("⏱️ Tempo", f"{elapsed_time:.1f}s")
                
                # Executar análise
                result = analyzer.analyze_architecture(arch_name, progress_callback)
                st.session_state.analysis_results[arch_name] = result
                
                # Mostrar resultado da arquitetura
                arch_status.success(f"✅ {arch_name} analisado com sucesso!")
        
        # Finalizar progresso
        overall_progress.progress(1.0)
        overall_status.success("🎉 Análise completa de todas as arquiteturas!")
        
        time.sleep(1)  # Pausa para mostrar o resultado
    
    st.session_state.analysis_in_progress = False

def render_analysis_results():
    """Renderiza os resultados da análise"""
    if not st.session_state.analysis_results:
        return
    
    st.markdown("## 📊 Resultados da Análise")
    
    # Resumo geral
    total_threats = sum([res['total_threats'] for res in st.session_state.analysis_results.values()])
    avg_risk = sum([res['risk_score'] for res in st.session_state.analysis_results.values()]) / len(st.session_state.analysis_results)
    total_components = sum([len(res['components']) for res in st.session_state.analysis_results.values()])
    
    # Métricas principais
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        st.metric(
            "🎯 Total de Ameaças", 
            total_threats,
            help="Número total de ameaças identificadas em todas as arquiteturas"
        )
    
    with col2:
        st.metric(
            "📦 Total de Componentes", 
            total_components,
            help="Número total de componentes analisados"
        )
    
    with col3:
        risk_color = "normal"
        if avg_risk >= 8:
            risk_color = "inverse"
        elif avg_risk >= 6:
            risk_color = "off"
        
        st.metric(
            "⚠️ Risk Score Médio", 
            f"{avg_risk:.1f}/10",
            help="Score médio de risco calculado usando metodologia STRIDE"
        )
    
    with col4:
        architectures_count = len(st.session_state.analysis_results)
        st.metric(
            "🗗️ Arquiteturas", 
            architectures_count,
            help="Número de arquiteturas analisadas"
        )
    
    # Gráficos de análise
    render_analysis_charts()
    
    # Resultados detalhados por arquitetura
    render_detailed_results()
    
    # Relatórios e exportação
    render_reports_section()

def render_analysis_charts():
    """Renderiza gráficos de análise"""
    st.markdown("### 📈 Visualizações")
    
    # Preparar dados para gráficos
    results = st.session_state.analysis_results
    
    # Gráfico 1: Distribuição de ameaças por severidade
    severity_data = []
    for arch_name, result in results.items():
        for severity, count in result['threats_by_severity'].items():
            severity_data.append({
                'Architecture': arch_name,
                'Severity': severity.title(),
                'Count': count
            })
    
    if severity_data:
        df_severity = pd.DataFrame(severity_data)
        
        col1, col2 = st.columns(2)
        
        with col1:
            fig_severity = px.bar(
                df_severity, 
                x='Architecture', 
                y='Count', 
                color='Severity',
                title="📊 Distribuição de Ameaças por Severidade",
                color_discrete_map={
                    'Critical': '#dc3545',
                    'High': '#fd7e14', 
                    'Medium': '#ffc107',
                    'Low': '#28a745'
                }
            )
            fig_severity.update_layout(height=400)
            st.plotly_chart(fig_severity, use_container_width=True)
        
        with col2:
            # Gráfico de pizza - Total por severidade
            total_by_severity = df_severity.groupby('Severity')['Count'].sum().reset_index()
            
            fig_pie = px.pie(
                total_by_severity,
                values='Count',
                names='Severity',
                title="🥧 Distribuição Total por Severidade",
                color_discrete_map={
                    'Critical': '#dc3545',
                    'High': '#fd7e14',
                    'Medium': '#ffc107', 
                    'Low': '#28a745'
                }
            )
            fig_pie.update_layout(height=400)
            st.plotly_chart(fig_pie, use_container_width=True)
    
    # Gráfico 2: Risk Score por arquitetura
    col1, col2 = st.columns(2)
    
    with col1:
        risk_data = []
        for arch_name, result in results.items():
            risk_data.append({
                'Architecture': arch_name,
                'Risk Score': result['risk_score'],
                'Total Threats': result['total_threats']
            })
        
        df_risk = pd.DataFrame(risk_data)
        
        fig_risk = px.bar(
            df_risk,
            x='Architecture',
            y='Risk Score',
            title="📈 Risk Score por Arquitetura",
            color='Risk Score',
            color_continuous_scale=['green', 'yellow', 'red']
        )
        fig_risk.update_layout(height=400)
        st.plotly_chart(fig_risk, use_container_width=True)
    
    with col2:
        # Gráfico de dispersão: Risk Score vs Total de Ameaças
        fig_scatter = px.scatter(
            df_risk,
            x='Total Threats',
            y='Risk Score',
            size='Total Threats',
            hover_data=['Architecture'],
            title="🎯 Risk Score vs Total de Ameaças",
            color='Risk Score',
            color_continuous_scale=['green', 'yellow', 'red']
        )
        fig_scatter.update_layout(height=400)
        st.plotly_chart(fig_scatter, use_container_width=True)
    
    # Gráfico 3: Distribuição STRIDE
    stride_data = []
    for arch_name, result in results.items():
        for threat_type, count in result['stride_distribution'].items():
            stride_data.append({
                'Architecture': arch_name,
                'STRIDE Category': threat_type.replace('_', ' ').title(),
                'Count': count
            })
    
    if stride_data:
        df_stride = pd.DataFrame(stride_data)
        
        fig_stride = px.bar(
            df_stride,
            x='STRIDE Category',
            y='Count',
            color='Architecture',
            title="🎭 Distribuição por Categoria STRIDE",
            barmode='group'
        )
        fig_stride.update_layout(height=500)
        st.plotly_chart(fig_stride, use_container_width=True)

def render_detailed_results():
    """Renderiza resultados detalhados por arquitetura"""
    st.markdown("### 🔍 Resultados Detalhados")
    
    for arch_name, result in st.session_state.analysis_results.items():
        with st.expander(f"📋 {arch_name} - {result['total_threats']} ameaças identificadas"):
            
            col1, col2 = st.columns(2)
            
            with col1:
                st.markdown("#### 📊 Estatísticas")
                st.markdown(f"**Provedor:** {result['provider']}")
                st.markdown(f"**Tipo:** {result['type'].replace('_', ' ').title()}")
                st.markdown(f"**Risk Score:** {result['risk_score']:.1f}/10")
                st.markdown(f"**Tempo de Análise:** {result['analysis_time']:.1f}s")
                
                st.markdown("#### 🎯 Ameaças por Severidade")
                for severity, count in result['threats_by_severity'].items():
                    if count > 0:
                        color_class = f"threat-{severity}"
                        st.markdown(f'<span class="{color_class}">• {severity.title()}: {count}</span>', 
                                  unsafe_allow_html=True)
            
            with col2:
                st.markdown("#### 🎭 Distribuição STRIDE")
                for threat_type, count in result['stride_distribution'].items():
                    if count > 0:
                        emoji_map = {
                            'spoofing': '🎭',
                            'tampering': '🔧', 
                            'information_disclosure': '📄',
                            'denial_of_service': '⚡'
                        }
                        emoji = emoji_map.get(threat_type, '🔒')
                        st.markdown(f"{emoji} **{threat_type.replace('_', ' ').title()}:** {count}")
                
                st.markdown("#### 📦 Componentes")
                for component in result['components']:
                    st.markdown(f"• {component}")
            
            # Recomendações
            st.markdown("#### 💡 Recomendações Principais")
            for i, rec in enumerate(result['recommendations'], 1):
                st.markdown(f"{i}. {rec}")

def render_reports_section():
    """Renderiza seção de relatórios e exportação"""
    st.markdown("### 📄 Relatórios e Exportação")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("#### 🌐 Relatório HTML Integrado")
        
        # Simular conteúdo HTML do relatório
        html_content = generate_integrated_html_report()
        
        # Mostrar HTML em iframe
        st.components.v1.html(html_content, height=600, scrolling=True)
    
    with col2:
        st.markdown("#### 📤 Opções de Exportação")
        
        # Botões de exportação
        if st.button("📄 Exportar para PDF", type="primary"):
            pdf_file = generate_pdf_report()
            if pdf_file:
                st.success("✅ PDF gerado com sucesso!")
                
                with open(pdf_file, "rb") as f:
                    st.download_button(
                        label="⬇️ Download PDF",
                        data=f.read(),
                        file_name=f"stride_report_{datetime.now().strftime('%Y%m%d_%H%M%S')}.pdf",
                        mime="application/pdf"
                    )
        
        if st.button("📊 Exportar JSON"):
            json_data = json.dumps(st.session_state.analysis_results, indent=2, default=str)
            st.download_button(
                label="⬇️ Download JSON", 
                data=json_data,
                file_name=f"stride_analysis_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json",
                mime="application/json"
            )
        
        if st.button("📈 Exportar CSV"):
            csv_data = generate_csv_report()
            st.download_button(
                label="⬇️ Download CSV",
                data=csv_data,
                file_name=f"stride_threats_{datetime.now().strftime('%Y%m%d_%H%M%S')}.csv",
                mime="text/csv"
            )
        
        # Estatísticas do relatório
        st.markdown("#### 📊 Estatísticas do Relatório")
        total_architectures = len(st.session_state.analysis_results)
        total_threats = sum([res['total_threats'] for res in st.session_state.analysis_results.values()])
        
        st.info(f"""
        **📋 Resumo do Relatório:**
        - 🗗️ Arquiteturas analisadas: {total_architectures}
        - 🎯 Total de ameaças: {total_threats}
        - 📅 Gerado em: {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}
        - 🔬 Metodologia: Microsoft STRIDE
        """)

def generate_integrated_html_report():
    """Gera relatório HTML integrado para exibição"""
    if not st.session_state.analysis_results:
        return "<p>Nenhum resultado de análise disponível</p>"
    
    # Calcular estatísticas gerais
    total_threats = sum([res['total_threats'] for res in st.session_state.analysis_results.values()])
    avg_risk = sum([res['risk_score'] for res in st.session_state.analysis_results.values()]) / len(st.session_state.analysis_results)
    
    html = f"""
    <div style="font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; padding: 20px; background: #f8f9fa;">
        <div style="background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); color: white; padding: 30px; border-radius: 10px; margin-bottom: 30px; text-align: center;">
            <h1 style="margin: 0; font-size: 2.5em;">🔒 Relatório STRIDE Enhanced</h1>
            <p style="margin: 10px 0 0 0; font-size: 1.2em;">Análise de Segurança Multi-Cloud</p>
            <p style="margin: 5px 0 0 0;">Gerado em: {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}</p>
        </div>
        
        <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px; margin-bottom: 30px;">
            <div style="background: white; padding: 20px; border-radius: 10px; text-align: center; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                <h3 style="color: #2c3e50; margin: 0 0 10px 0;">🎯 Total de Ameaças</h3>
                <div style="font-size: 2em; font-weight: bold; color: #dc3545;">{total_threats}</div>
            </div>
            <div style="background: white; padding: 20px; border-radius: 10px; text-align: center; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                <h3 style="color: #2c3e50; margin: 0 0 10px 0;">📊 Risk Score Médio</h3>
                <div style="font-size: 2em; font-weight: bold; color: #fd7e14;">{avg_risk:.1f}/10</div>
            </div>
            <div style="background: white; padding: 20px; border-radius: 10px; text-align: center; box-shadow: 0 2px 10px rgba(0,0,0,0.1);">
                <h3 style="color: #2c3e50; margin: 0 0 10px 0;">🗗️ Arquiteturas</h3>
                <div style="font-size: 2em; font-weight: bold; color: #28a745;">{len(st.session_state.analysis_results)}</div>
            </div>
        </div>
    """
    
    # Adicionar detalhes por arquitetura
    for arch_name, result in st.session_state.analysis_results.items():
        risk_color = "#28a745" if result['risk_score'] < 4 else "#ffc107" if result['risk_score'] < 7 else "#dc3545"
        
        html += f"""
        <div style="background: white; padding: 25px; margin: 20px 0; border-radius: 10px; box-shadow: 0 4px 15px rgba(0,0,0,0.1); border-left: 5px solid {risk_color};">
            <h2 style="color: #2c3e50; margin: 0 0 20px 0;">🗗️ {arch_name}</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(150px, 1fr)); gap: 15px; margin-bottom: 20px;">
                <div>
                    <strong>Provedor:</strong> {result['provider']}<br>
                    <strong>Tipo:</strong> {result['type'].replace('_', ' ').title()}<br>
                    <strong>Risk Score:</strong> <span style="color: {risk_color}; font-weight: bold;">{result['risk_score']:.1f}/10</span>
                </div>
                <div>
                    <strong>Total de Ameaças:</strong> {result['total_threats']}<br>
                    <strong>Componentes:</strong> {len(result['components'])}<br>
                    <strong>Tempo de Análise:</strong> {result['analysis_time']:.1f}s
                </div>
            </div>
            
            <h3 style="color: #2c3e50;">🎯 Ameaças por Severidade</h3>
            <div style="display: flex; gap: 10px; flex-wrap: wrap; margin-bottom: 20px;">
        """
        
        severity_colors = {
            'critical': '#dc3545',
            'high': '#fd7e14',
            'medium': '#ffc107', 
            'low': '#28a745'
        }
        
        for severity, count in result['threats_by_severity'].items():
            if count > 0:
                color = severity_colors.get(severity, '#6c757d')
                html += f"""
                <span style="background: {color}; color: white; padding: 5px 12px; border-radius: 20px; font-size: 0.9em; font-weight: bold;">
                    {severity.title()}: {count}
                </span>
                """
        
        html += f"""
            </div>
            
            <h3 style="color: #2c3e50;">🎭 Distribuição STRIDE</h3>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 10px;">
        """
        
        stride_emojis = {
            'spoofing': '🎭',
            'tampering': '🔧',
            'information_disclosure': '📄',
            'denial_of_service': '⚡'
        }
        
        for threat_type, count in result['stride_distribution'].items():
            if count > 0:
                emoji = stride_emojis.get(threat_type, '🔒')
                html += f"""
                <div style="background: #f8f9fa; padding: 10px; border-radius: 5px; text-align: center;">
                    {emoji}<br>
                    <strong>{threat_type.replace('_', ' ').title()}</strong><br>
                    <span style="color: #007bff; font-weight: bold;">{count}</span>
                </div>
                """
        
        html += "</div></div>"
    
    html += """
        <div style="text-align: center; margin-top: 30px; padding: 20px; background: #e9ecef; border-radius: 10px;">
            <p style="margin: 0; color: #6c757d;">
                <strong>🔒 Relatório gerado pelo STRIDE Security Analyzer Enhanced</strong><br>
                Metodologia: Microsoft STRIDE | Interface Web: Streamlit
            </p>
        </div>
    </div>
    """
    
    return html