# enhanced_image_analyzer_yolo_integration.py
"""
Extensão da classe RealImageAnalyzer para incluir detecção YOLO
Esta extensão se integra perfeitamente com o código existente
"""

from yolo_cloud_detector import YOLOCloudDetector
import numpy as np
from typing import Dict, List, Optional
from PIL import Image
import os

# Importar as variáveis globais necessárias do módulo principal
try:
    from stride_analyzer_enhanced import (
        RealImageAnalyzer, 
        CV2_AVAILABLE, 
        OCR_AVAILABLE, 
        OPENAI_AVAILABLE
    )
    
    # Se CV2 está disponível, importar também
    if CV2_AVAILABLE:
        import cv2
        
except ImportError:
    # Fallback - definir localmente se não conseguir importar
    CV2_AVAILABLE = False
    OCR_AVAILABLE = False
    OPENAI_AVAILABLE = False
    
    try:
        import cv2
        CV2_AVAILABLE = True
    except ImportError:
        pass


class RealImageAnalyzerWithYOLO(RealImageAnalyzer):
    """
    Versão estendida do RealImageAnalyzer que inclui detecção YOLO
    de ícones de cloud providers.
    """
    
    def __init__(self):
        # Inicializar classe pai
        super().__init__()
        
        # Adicionar atributos de disponibilidade (corrigindo o erro)
        self.cv2_available = CV2_AVAILABLE
        self.ocr_available = OCR_AVAILABLE
        self.openai_available = OPENAI_AVAILABLE and os.getenv('OPENAI_API_KEY')
        
        # Adicionar detector YOLO
        self.yolo_detector = YOLOCloudDetector()
        
        # Flag para indicar se YOLO está disponível
        self.yolo_available = self.yolo_detector.model is not None
        
        if self.yolo_available:
            print("✅ Detecção YOLO de ícones cloud ativada")
        else:
            print("⚠️ Detecção YOLO não disponível - usando métodos alternativos")
    
    def analyze_image_content(self, image_file) -> Dict:
        """
        Versão estendida que inclui análise YOLO como método primário.
        YOLO tem prioridade máxima por ser treinado especificamente.
        """
        try:
            # Preparar imagem
            image = Image.open(image_file)
            img_array = np.array(image) if self.cv2_available else None
            
            # Executar todas as análises, incluindo YOLO
            results = {
                'yolo_analysis': self._analyze_with_yolo(image) if self.yolo_available else {},
                'cv_analysis': self._analyze_with_opencv(img_array) if self.cv2_available and img_array is not None else {},
                'ocr_analysis': self._analyze_with_ocr(image) if self.ocr_available else {},
                'color_analysis': self._analyze_colors(img_array) if self.cv2_available and img_array is not None else {},
                'openai_analysis': self._analyze_with_openai(image_file) if self.openai_client else None
            }
            
            # Combinar resultados com YOLO tendo prioridade máxima
            components = self._combine_detection_results(results)
            
            return {
                'success': True,
                'detected_components': components,
                'analysis_details': results,
                'component_count': len(components),
                'yolo_enabled': self.yolo_available
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'detected_components': [],
                'component_count': 0
            }
    
    def _analyze_with_yolo(self, image: Image) -> Dict:
        """
        Executa análise usando o modelo YOLO treinado para ícones de cloud.
        Este é o método mais preciso para detectar serviços específicos.
        """
        if not self.yolo_available:
            return {'error': 'YOLO não disponível', 'detections': []}
        
        try:
            # Executar detecção
            result = self.yolo_detector.detect(image, confidence_threshold=0.45)
            
            if result['success']:
                print(f"🎯 YOLO detectou {result['total_detections']} ícones de cloud")
                
                # Log de estatísticas se disponível
                if 'stats' in result:
                    stats = result['stats']
                    if 'providers' in stats:
                        print(f"   Providers: {stats['providers']}")
                    if 'dominant_provider' in stats:
                        print(f"   Provider dominante: {stats['dominant_provider']}")
                    if stats.get('is_multi_cloud'):
                        print(f"   ⚠️ Arquitetura multi-cloud detectada!")
                
                return result
            else:
                return {'error': result.get('error', 'Detecção falhou'), 'detections': []}
                
        except Exception as e:
            return {'error': f'Erro no YOLO: {str(e)}', 'detections': []}
    
    # ... (resto dos métodos permanece o mesmo)