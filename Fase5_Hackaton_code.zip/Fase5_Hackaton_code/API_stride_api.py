#!/usr/bin/env python3
"""
API REST para STRIDE - VERSÃO CORRIGIDA COM ANÁLISE COMPLETA
"""

import os
import base64
import json
import hashlib
import traceback
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any
from io import BytesIO
import sys
import tempfile
import asyncio
import threading

from fastapi import FastAPI, HTTPException, File, UploadFile, Response, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from pydantic import BaseModel, Field
import uvicorn

# Configuração
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass

# Path do módulo
current_dir = Path(__file__).parent
if str(current_dir) not in sys.path:
    sys.path.insert(0, str(current_dir))
# ======================== CONFIGURAÇÃO ========================

# Configurações da API
API_PORT = int(os.getenv("API_PORT", "8000"))
IMAGE_OUTPUT_DIR = os.getenv("IMAGE_OUTPUT_DIR", "reports/images")
PUBLIC_URL = os.getenv("PUBLIC_URL", f"http://localhost:{API_PORT}")
NGROK_DOMAIN = os.getenv("NGROK_DOMAIN", "26553e27434f.ngrok-free.app")

# Se estiver usando ngrok, usar o domínio ngrok
if NGROK_DOMAIN:
    PUBLIC_URL = f"https://{NGROK_DOMAIN}"
    
# Importar conversor HTML->Imagem
try:
    from html_to_image_service import HTMLToImageConverter
    IMAGE_CONVERTER_AVAILABLE = True
    print("✅ Conversor HTML->Imagem disponível")
except ImportError as e:
    IMAGE_CONVERTER_AVAILABLE = False
    print(f"⚠️ Conversor HTML->Imagem não disponível: {e}")


# Importações
try:
    from PIL import Image
    PIL_AVAILABLE = True
except ImportError:
    PIL_AVAILABLE = False

try:
    from stride_analyzer_enhanced_YOLO import RealSTRIDEAnalyzer, generate_enhanced_html_report
    STRIDE_AVAILABLE = True
    print("✅ stride_analyzer_enhanced importado")
except ImportError as e:
    STRIDE_AVAILABLE = False
    print(f"❌ Erro ao importar stride_analyzer_enhanced: {e}")

app = FastAPI(
    title="STRIDE Threat Model Analyzer API",
    version="2.0.0",
    description="API para análise STRIDE com conversão HTML->Imagem",
    docs_url="/docs"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ======================== MODELOS ========================

class ImageAnalysisRequest(BaseModel):
    image_base64: str
    filename: Optional[str] = None
    analysis_options: Optional[Dict[str, Any]] = None
    output_format: Optional[str] = "image"  # "image", "html", ou "both"
    image_width: Optional[int] = 1400
    image_height: Optional[int] = None

class AnalysisResponse(BaseModel):
    success: bool
    analysis_id: str
    timestamp: str
    risk_score: float
    threats_count: int
    components_count: int
    report_image_url: Optional[str] = None
    report_image_path: Optional[str] = None
    report_html_url: Optional[str] = None
    html_base64: Optional[str] = None
    summary: Optional[Dict[str, Any]] = None
    error: Optional[str] = None

# ======================== SERVIÇO CORRIGIDO ========================

class STRIDEAnalyzerService:
    def __init__(self):
        self.analyzer = None
        self.image_converter = None
        
        # Inicializar STRIDE Analyzer
        if STRIDE_AVAILABLE:
            try:
                self.analyzer = RealSTRIDEAnalyzer()
                print("✅ RealSTRIDEAnalyzer inicializado")
            except Exception as e:
                print(f"❌ Erro ao criar RealSTRIDEAnalyzer: {e}")
        
        # Inicializar conversor de imagem
        if IMAGE_CONVERTER_AVAILABLE:
            try:
                # Criar diretório de imagens
                Path(IMAGE_OUTPUT_DIR).mkdir(parents=True, exist_ok=True)
                
                self.image_converter = HTMLToImageConverter(
                    output_dir=IMAGE_OUTPUT_DIR,
                    base_url=PUBLIC_URL
                )
                print(f"✅ Conversor de imagem inicializado")
                print(f"📁 Diretório de saída: {IMAGE_OUTPUT_DIR}")
                print(f"🌐 URL pública: {PUBLIC_URL}")
            except Exception as e:
                print(f"❌ Erro ao criar conversor: {e}")

    async def analyze_and_convert(self, 
                                  image_data: bytes, 
                                  filename: str = None,
                                  options: dict = None,
                                  output_format: str = "image",
                                  image_width: int = 1400,
                                  image_height: int = None) -> Dict:
        """
        Analisa imagem e converte resultado para formato solicitado
        """
        
        print(f"\n📸 Processando: {filename}")
        print(f"📊 Formato de saída: {output_format}")
        
        # 1. Executar análise STRIDE
        analysis_result = await self._run_stride_analysis(image_data, filename, options)
        
        if not analysis_result.get('success', False):
            return analysis_result
        
        # 2. Gerar HTML
        html_report = self._generate_html_report(analysis_result)
        
        # 3. Converter baseado no formato solicitado
        result = {
            'success': True,
            'analysis_id': analysis_result.get('analysis_id'),
            'timestamp': analysis_result.get('timestamp'),
            'risk_score': analysis_result.get('risk_score', 0),
            'threats_count': analysis_result.get('threats_count', 0),
            'components_count': analysis_result.get('components_count', 0),
            'summary': {
                'components': analysis_result.get('components_count', 0),
                'threats': analysis_result.get('threats_count', 0),
                'risk_score': analysis_result.get('risk_score', 0),
                'cloud_providers': analysis_result.get('cloud_providers', {})
            }
        }
        
        if output_format in ["image", "both"]:
            # Converter HTML para imagem
            if self.image_converter:
                try:
                    image_result = await self.image_converter.convert_html_to_image_async(
                        html_report,
                        filename=f"stride_{analysis_result.get('analysis_id', 'report')}.png",
                        width=image_width,
                        height=image_height
                    )
                    
                    if image_result['success']:
                        result['report_image_url'] = image_result['url']
                        result['report_image_path'] = image_result['path']
                        print(f"✅ Imagem gerada: {image_result['url']}")
                    else:
                        print(f"⚠️ Falha ao gerar imagem: {image_result.get('error')}")
                        # Fallback para HTML
                        output_format = "html"
                except Exception as e:
                    print(f"❌ Erro ao converter para imagem: {e}")
                    output_format = "html"
            else:
                print("⚠️ Conversor de imagem não disponível, usando HTML")
                output_format = "html"
        
        if output_format in ["html", "both"]:
            # Salvar HTML e retornar URL
            html_filename = f"stride_{analysis_result.get('analysis_id', 'report')}.html"
            html_path = Path(IMAGE_OUTPUT_DIR) / html_filename
            
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(html_report)
            
            result['report_html_url'] = f"{PUBLIC_URL}/images/{html_filename}"
            result['html_base64'] = base64.b64encode(html_report.encode('utf-8')).decode('utf-8')
            print(f"📄 HTML salvo: {result['report_html_url']}")
        
        return result    

    def _error_response(self, error_msg: str, filename: str) -> Dict:
        """Resposta de erro padronizada"""
        return {
            'success': False,
            'analysis_id': hashlib.md5(f"error_{datetime.now()}".encode()).hexdigest()[:8],
            'timestamp': datetime.now().isoformat(),
            'image_info': {'filename': filename or 'unknown.png'},
            'threats': [],
            'detected_components': [],
            'risk_score': 0.0,
            'stride_analysis': {},
            'cloud_providers': {},
            'compliance_score': 0,
            'recommendations': [],
            'error': error_msg,
            'threats_count': 0,
            'components_count': 0
        }

    async def _run_stride_analysis(self, image_data: bytes, filename: str, options: dict) -> Dict:
        """Executa análise STRIDE"""
        
        if not self.analyzer:
            return {
                'success': False,
                'error': 'STRIDE Analyzer não disponível'
            }
        
        temp_file = None
        try:
            # Validar imagem
            import io
            from PIL import Image
            
            test_img = Image.open(io.BytesIO(image_data))
            print(f"✅ Imagem válida: {test_img.size} pixels")
            
            # Salvar em arquivo temporário
            with tempfile.NamedTemporaryFile(suffix='.png', delete=False) as temp_file:
                temp_file.write(image_data)
                temp_path = temp_file.name
            
            # Criar objeto compatível
            class StreamlitFile:
                def __init__(self, path, name):
                    self.name = name
                    with open(path, 'rb') as f:
                        self._data = f.read()
                
                def getvalue(self):
                    return self._data
                
                def read(self):
                    return self._data
            
            file_obj = StreamlitFile(temp_path, filename or 'image.png')
            
            # Executar análise em thread separada (para não bloquear async)
            loop = asyncio.get_event_loop()
            result = await loop.run_in_executor(
                None,
                self.analyzer.analyze_image,
                file_obj,
                options.get('use_yolo', True) if options else True,
                options.get('use_vision', True) if options else True
            )
            
            # Limpar arquivo temporário
            if temp_file and os.path.exists(temp_path):
                os.unlink(temp_path)
            
            if result and result.get('success', False):
                result['threats_count'] = len(result.get('threats', []))
                result['components_count'] = len(result.get('detected_components', []))
                return result
            else:
                return {'success': False, 'error': 'Análise falhou'}
                
        except Exception as e:
            print(f"❌ Erro na análise: {e}")
            if temp_file and 'temp_path' in locals() and os.path.exists(temp_path):
                os.unlink(temp_path)
            return {'success': False, 'error': str(e)}
    
    def _generate_html_report(self, analysis_result: Dict) -> str:
        """Gera relatório HTML"""
        try:
            if STRIDE_AVAILABLE and analysis_result.get('success', False):
                return generate_enhanced_html_report(analysis_result)
        except Exception as e:
            print(f"❌ Erro ao gerar HTML: {e}")
        
        # HTML fallback básico
        return f"""
        <!DOCTYPE html>
        <html>
        <head>
            <title>STRIDE Report</title>
            <style>
                body {{ font-family: Arial; margin: 20px; }}
                .header {{ background: #2c3e50; color: white; padding: 20px; }}
            </style>
        </head>
        <body>
            <div class="header">
                <h1>STRIDE Analysis Report</h1>
            </div>
            <p>Components: {analysis_result.get('components_count', 0)}</p>
            <p>Threats: {analysis_result.get('threats_count', 0)}</p>
            <p>Risk Score: {analysis_result.get('risk_score', 0)}/10</p>
        </body>
        </html>
        """

# Instanciar serviço
stride_service = STRIDEAnalyzerService()

# ======================== ENDPOINTS ========================

@app.post("/analyze", response_model=AnalysisResponse)
async def analyze_image_endpoint(request: ImageAnalysisRequest):
    """
    Endpoint principal - analisa imagem e retorna link da imagem do relatório
    """
    try:
        print(f"\n{'='*60}")
        print(f"📨 Nova requisição: {request.filename}")
        print(f"   Output: {request.output_format}")
        print(f"   Dimensões: {request.image_width}x{request.image_height or 'auto'}")
        print(f"{'='*60}")
        
        # Processar base64
        base64_str = request.image_base64
        if 'base64,' in base64_str:
            base64_str = base64_str.split('base64,')[1]
        
        base64_str = base64_str.strip().replace(' ', '').replace('\n', '').replace('\r', '')
        
        # Decodificar
        try:
            image_data = base64.b64decode(base64_str)
            print(f"✅ Imagem decodificada: {len(image_data)} bytes")
        except Exception as e:
            raise ValueError(f"Base64 inválido: {e}")
        
        if len(image_data) == 0:
            raise ValueError("Imagem vazia")
        
        # Executar análise e conversão
        result = await stride_service.analyze_and_convert(
            image_data,
            request.filename,
            request.analysis_options,
            request.output_format,
            request.image_width,
            request.image_height
        )
        
        # Preparar resposta
        response = AnalysisResponse(
            success=result.get('success', False),
            analysis_id=result.get('analysis_id', 'unknown'),
            timestamp=result.get('timestamp', datetime.now().isoformat()),
            risk_score=result.get('risk_score', 0),
            threats_count=result.get('threats_count', 0),
            components_count=result.get('components_count', 0),
            report_image_url=result.get('report_image_url'),
            report_image_path=result.get('report_image_path'),
            report_html_url=result.get('report_html_url'),
            html_base64=result.get('html_base64'),
            summary=result.get('summary'),
            error=result.get('error')
        )
        
        print(f"\n✅ RESPOSTA:")
        print(f"   Success: {response.success}")
        if response.report_image_url:
            print(f"   🖼️ Imagem: {response.report_image_url}")
        if response.report_html_url:
            print(f"   📄 HTML: {response.report_html_url}")
        print(f"{'='*60}\n")
        
        return response
        
    except Exception as e:
        print(f"❌ ERRO: {str(e)}")
        traceback.print_exc()
        
        return AnalysisResponse(
            success=False,
            analysis_id="error",
            timestamp=datetime.now().isoformat(),
            risk_score=0.0,
            threats_count=0,
            components_count=0,
            error=str(e)
        )

@app.get("/images/{filename}")
async def serve_image(filename: str):
    """Serve imagens e HTMLs gerados"""
    file_path = Path(IMAGE_OUTPUT_DIR) / filename
    
    if not file_path.exists():
        raise HTTPException(status_code=404, detail="File not found")
    
    # Determinar tipo MIME
    if filename.endswith('.png'):
        media_type = "image/png"
    elif filename.endswith('.jpg') or filename.endswith('.jpeg'):
        media_type = "image/jpeg"
    elif filename.endswith('.html'):
        media_type = "text/html"
    else:
        media_type = "application/octet-stream"
    
    return FileResponse(
        file_path,
        media_type=media_type,
        headers={
            "Cache-Control": "public, max-age=3600",
            "Access-Control-Allow-Origin": "*"
        }
    )


@app.get("/")
async def root():
    """Status da API"""
    return {
        "status": "online",
        "version": "3.0.0",
        "public_url": PUBLIC_URL,
        "features": {
            "stride_analyzer": STRIDE_AVAILABLE,
            "image_converter": IMAGE_CONVERTER_AVAILABLE,
            "output_formats": ["image", "html", "both"]
        },
        "endpoints": {
            "analyze": "/analyze",
            "images": "/images/{filename}",
            "docs": "/docs"
        }
    }

@app.delete("/cleanup")
async def cleanup_old_files(max_age_hours: int = 24):
    """Remove arquivos antigos"""
    try:
        if stride_service.image_converter:
            stride_service.image_converter.cleanup_old_images(max_age_hours)
        
        # Contar arquivos removidos
        return {
            "success": True,
            "message": f"Arquivos mais velhos que {max_age_hours} horas foram removidos"
        }
    except Exception as e:
        return {"success": False, "error": str(e)}

if __name__ == "__main__":
    print("\n" + "="*60)
    print("🚀 STRIDE API v2.0 - VERSÃO CORRIGIDA")
    print("="*60)
    print(f"📍 Local: http://localhost:8000")
    print(f"📚 Docs: http://localhost:8000/docs")
    print(f"🔧 Debug Mode: {os.getenv('DEBUG_MODE', 'false')}")
    print("="*60 + "\n")
    
    uvicorn.run(app, host="0.0.0.0", port=8000)
    # ========== EXEMPLO DE USO COMPLETO ==========
"""
COMO USAR COM NGROK:

1. Instale o ngrok:
   - Download em: https://ngrok.com/download
   - Ou: brew install ngrok (Mac)
   - Ou: snap install ngrok (Linux)

2. Configure seu token (apenas uma vez):
   ngrok authtoken YOUR_AUTH_TOKEN

3. Crie um arquivo .env com o domínio ngrok:
   NGROK_DOMAIN=72d2267b9332.ngrok-free.app
   API_PORT=8000

4. Inicie a API:
   python stride_api.py

5. Em outro terminal, inicie o ngrok:
   ngrok http 8000

   Ou para domínio customizado:
   ngrok http --domain=72d2267b9332.ngrok-free.app 8000

6. Teste a conexão:
   curl https://72d2267b9332.ngrok-free.app/ngrok-status

7. Use no N8N ou qualquer lugar:
   POST https://72d2267b9332.ngrok-free.app/analyze
"""