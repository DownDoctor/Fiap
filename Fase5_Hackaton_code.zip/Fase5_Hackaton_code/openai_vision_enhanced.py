# openai_vision_enhanced.py
"""
Integração aprimorada com OpenAI Vision
"""

from openai import OpenAI
import base64
import json
from typing import Dict, List, Optional
import cv2
import numpy as np

class EnhancedVisionAnalyzer:
    """Analisador de visão com prompts otimizados"""
    
    def __init__(self, api_key: str):
        self.client = OpenAI(api_key=api_key)
        self.analysis_cache = {}
        
    def analyze_architecture_detailed(self, image_path: str, 
                                     ocr_results: Dict = None,
                                     detected_icons: List = None) -> Dict:
        """Análise detalhada com contexto adicional"""
        
        # Preparar imagem
        base64_image = self._encode_image(image_path)
        
        # Criar prompt estruturado com contexto
        system_prompt = self._create_system_prompt()
        user_prompt = self._create_user_prompt(ocr_results, detected_icons)
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": user_prompt},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{base64_image}",
                                    "detail": "high"
                                }
                            }
                        ]
                    }
                ],
                max_tokens=4096,
                temperature=0.1,
                response_format={"type": "json_object"}
            )
            
            result = json.loads(response.choices[0].message.content)
            
            # Enriquecer com análise adicional
            result['enhanced_analysis'] = self._perform_enhanced_analysis(result, image_path)
            
            return result
            
        except Exception as e:
            return {"error": str(e)}
    
    def _create_system_prompt(self) -> str:
        """Cria prompt de sistema otimizado"""
        
        return """You are an expert cloud architect and security analyst specializing in:
        - AWS, Azure, GCP, and Kubernetes architectures
        - Security threat modeling (STRIDE methodology)
        - Compliance frameworks (SOC2, GDPR, HIPAA, PCI DSS)
        - Best practices and design patterns
        
        Analyze architecture diagrams with extreme attention to detail, identifying:
        1. Every cloud service and component (with confidence scores)
        2. Data flows and connections (protocols, ports, security)
        3. Security boundaries and trust zones
        4. Architecture patterns and anti-patterns
        5. Potential security vulnerabilities
        6. Compliance considerations
        7. Cost optimization opportunities
        8. Performance bottlenecks
        9. High availability and disaster recovery aspects
        10. Integration points and dependencies"""
    
    def _create_user_prompt(self, ocr_results: Dict = None, detected_icons: List = None) -> str:
        """Cria prompt de usuário com contexto"""
        
        context_info = ""
        
        if ocr_results:
            texts = ocr_results.get('combined', [])[:20]  # Top 20 textos
            context_info += f"\nOCR detected texts: {json.dumps([t.get('text') for t in texts])}\n"
        
        if detected_icons:
            icons = [{'name': icon.name, 'provider': icon.provider} for icon in detected_icons[:20]]
            context_info += f"\nDetected icons: {json.dumps(icons)}\n"
        
        return f"""Analyze this cloud architecture diagram comprehensively.
        
{context_info}

Return a detailed JSON analysis with this exact structure:
{{
    "architecture_summary": {{
        "type": "microservices|serverless|monolithic|hybrid|data_pipeline|api_gateway",
        "primary_cloud": "AWS|Azure|GCP|Multi-Cloud|Hybrid",
        "estimated_monthly_cost": "cost range in USD",
        "complexity_score": 1-10,
        "maturity_level": "initial|developing|mature|optimized"
    }},
    "services": [
        {{
            "name": "exact service name",
            "provider": "AWS|Azure|GCP|Kubernetes",
            "category": "compute|storage|database|networking|security|monitoring|integration",
            "purpose": "what this service does in the architecture",
            "configuration": {{}},
            "dependencies": ["list of dependent services"],
            "confidence": 0.0-1.0,
            "alternatives": ["suggested alternative services"],
            "best_practices_score": 1-10
        }}
    ],
    "connections": [
        {{
            "source": "service name",
            "target": "service name",
            "protocol": "HTTPS|TCP|UDP|gRPC|AMQP|WebSocket",
            "port": "port number or range",
            "encryption": "TLS|mTLS|IPSec|None",
            "authentication": "OAuth|JWT|API Key|Certificate|None",
            "data_classification": "public|internal|confidential|restricted"
        }}
    ],
    "security_analysis": {{
        "security_score": 1-10,
        "identified_vulnerabilities": [
            {{
                "type": "STRIDE category",
                "severity": "critical|high|medium|low",
                "description": "detailed description",
                "affected_components": ["components"],
                "cve_references": ["if applicable"],
                "mitigation": "recommended fix"
            }}
        ],
        "missing_controls": ["list of missing security controls"],
        "compliance_gaps": {{
            "SOC2": ["gaps"],
            "GDPR": ["gaps"],
            "HIPAA": ["gaps"],
            "PCI_DSS": ["gaps"]
        }}
    }},
    "recommendations": {{
        "immediate_actions": ["critical fixes needed now"],
        "short_term": ["improvements for next 30 days"],
        "long_term": ["strategic improvements"],
        "cost_optimization": ["ways to reduce costs"],
        "performance": ["performance improvements"],
        "security": ["security enhancements"]
    }},
    "patterns_detected": {{
        "design_patterns": ["patterns used correctly"],
        "anti_patterns": ["problematic patterns detected"],
        "best_practices_followed": ["good practices observed"],
        "best_practices_missing": ["missing best practices"]
    }}
}}"""
    
    def _perform_enhanced_analysis(self, base_result: Dict, image_path: str) -> Dict:
        """Realiza análise aprimorada adicional"""
        
        enhanced = {
            'risk_assessment': self._calculate_risk_scores(base_result),
            'cost_analysis': self._estimate_costs(base_result),
            'scalability_analysis': self._analyze_scalability(base_result),
            'compliance_readiness': self._assess_compliance_readiness(base_result)
        }
        
        return enhanced
    
    def _calculate_risk_scores(self, result: Dict) -> Dict:
        """Calcula scores de risco detalhados"""
        
        vulnerabilities = result.get('security_analysis', {}).get('identified_vulnerabilities', [])
        
        risk_scores = {
            'overall_risk': 0,
            'by_category': {},
            'by_component': {}
        }
        
        # Calcular por categoria STRIDE
        stride_categories = ['spoofing', 'tampering', 'repudiation', 
                           'information_disclosure', 'denial_of_service', 
                           'elevation_of_privilege']
        
        for category in stride_categories:
            category_vulns = [v for v in vulnerabilities 
                             if category in v.get('type', '').lower()]
            
            if category_vulns:
                severity_scores = {'critical': 10, 'high': 8, 'medium': 5, 'low': 2}
                total_score = sum(severity_scores.get(v.get('severity', 'low'), 2) 
                                for v in category_vulns)
                risk_scores['by_category'][category] = min(10, total_score)
        
        # Score geral
        if risk_scores['by_category']:
            risk_scores['overall_risk'] = np.mean(list(risk_scores['by_category'].values()))
        
        return risk_scores
    
    def _estimate_costs(self, result: Dict) -> Dict:
        """Estima custos da arquitetura"""
        
        services = result.get('services', [])
        
        # Custos aproximados por tipo de serviço (USD/mês)
        cost_estimates = {
            'compute': {'small': 50, 'medium': 200, 'large': 800},
            'storage': {'small': 20, 'medium': 100, 'large': 500},
            'database': {'small': 100, 'medium': 500, 'large': 2000},
            'networking': {'small': 30, 'medium': 150, 'large': 600},
            'monitoring': {'small': 20, 'medium': 80, 'large': 300}
        }
        
        total_cost = 0
        cost_breakdown = {}
        
        for service in services:
            category = service.get('category', 'compute')
            # Assumir tamanho médio por padrão
            size = 'medium'
            
            if category in cost_estimates:
                cost = cost_estimates[category].get(size, 100)
                total_cost += cost
                
                provider = service.get('provider', 'unknown')
                if provider not in cost_breakdown:
                    cost_breakdown[provider] = 0
                cost_breakdown[provider] += cost
        
        return {
            'estimated_monthly_cost': total_cost,
            'cost_breakdown': cost_breakdown,
            'cost_optimization_potential': total_cost * 0.3  # Assume 30% de potencial de otimização
        }
    
    def _encode_image(self, image_path: str) -> str:
        """Codifica imagem em base64"""
        
        with open(image_path, "rb") as image_file:
            return base64.b64encode(image_file.read()).decode('utf-8')