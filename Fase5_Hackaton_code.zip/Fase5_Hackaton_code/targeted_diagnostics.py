#!/usr/bin/env python3
"""
Diagnóstico focado nos problemas específicos identificados
"""

import yaml
import json
from pathlib import Path
from ultralytics import YOLO
import cv2
import numpy as np

def diagnose_yolo_classes():
    """Diagnostica problema específico do YOLO sempre retornando 'Cloud Genérica'"""
    
    print("🤖 DIAGNÓSTICO ESPECÍFICO: YOLO CLASSES")
    print("=" * 50)
    
    # 1. Localizar modelo
    model_paths = [
        "./cloud_icons_training/best_cloud_icons.pt",
        "./cloud_icons_training/runs/detect/train/weights/best.pt",
        "./models/cloud_icons_detector.pt",
        "./quick_model.pt"
    ]
    
    model_path = None
    for path in model_paths:
        if Path(path).exists():
            model_path = path
            break
    
    if not model_path:
        print("❌ PROBLEMA IDENTIFICADO: Nenhum modelo YOLO encontrado!")
        print("💡 SOLUÇÃO: Execute o treinamento primeiro")
        print("   python complete_yolo_training_pipeline.py")
        return False
    
    print(f"✅ Modelo encontrado: {model_path}")
    
    # 2. Carregar e inspecionar modelo
    try:
        model = YOLO(model_path)
        print(f"✅ Modelo carregado")
        print(f"📊 Total de classes: {len(model.names)}")
        
        # 3. DIAGNÓSTICO CRÍTICO: Verificar nomes das classes
        print(f"\n🔍 CLASSES DETECTADAS NO MODELO:")
        unique_names = set(model.names.values())
        
        for class_id, class_name in model.names.items():
            print(f"   {class_id}: '{class_name}'")
        
        # 4. IDENTIFICAR PROBLEMA ESPECÍFICO
        if len(unique_names) == 1:
            single_name = list(unique_names)[0]
            print(f"\n❌ PROBLEMA IDENTIFICADO: Todas as classes têm o mesmo nome!")
            print(f"   Nome único: '{single_name}'")
            print(f"   Total de IDs: {len(model.names)}")
            print(f"\n💡 CAUSA: Dataset com labels incorretos ou problema no treinamento")
            return False
            
        elif 'generic' in " ".join(model.names.values()).lower():
            print(f"\n⚠️ PROBLEMA PARCIAL: Classes muito genéricas")
            generic_classes = [name for name in model.names.values() if 'generic' in name.lower()]
            print(f"   Classes genéricas: {generic_classes}")
            
        else:
            print(f"\n✅ Classes parecem específicas")
            print(f"   Nomes únicos: {len(unique_names)}")
            print(f"   Exemplos: {list(unique_names)[:5]}")
        
        # 5. Verificar arquivo YAML correspondente
        yaml_paths = [
            Path(model_path).parent.parent / "data.yaml",
            "./cloud_icons_training/dataset.yaml",
            "./cloud_icons_training/data.yaml"
        ]
        
        yaml_found = False
        for yaml_path in yaml_paths:
            if yaml_path.exists():
                print(f"\n📄 Verificando YAML: {yaml_path}")
                
                with open(yaml_path, 'r') as f:
                    config = yaml.safe_load(f)
                
                yaml_names = config.get('names', [])
                yaml_nc = config.get('nc', 0)
                
                print(f"   Classes no YAML (nc): {yaml_nc}")
                print(f"   Nomes no YAML: {len(yaml_names)}")
                
                if len(yaml_names) != len(model.names):
                    print(f"   ❌ INCONSISTÊNCIA: YAML tem {len(yaml_names)} nomes, modelo tem {len(model.names)}")
                
                if yaml_names:
                    print(f"   Exemplos YAML: {yaml_names[:5]}")
                    
                    # Comparar nomes
                    yaml_set = set(yaml_names)
                    model_set = set(model.names.values())
                    
                    if yaml_set != model_set:
                        print(f"   ❌ NOMES DIFERENTES entre YAML e modelo!")
                        print(f"   Apenas no YAML: {yaml_set - model_set}")
                        print(f"   Apenas no modelo: {model_set - yaml_set}")
                
                yaml_found = True
                break
        
        if not yaml_found:
            print(f"\n⚠️ Nenhum arquivo YAML encontrado!")
        
        # 6. TESTE RÁPIDO DE DETECÇÃO
        print(f"\n🧪 TESTE DE DETECÇÃO RÁPIDA:")
        
        # Criar imagem de teste
        test_img = np.ones((640, 640, 3), dtype=np.uint8) * 240
        cv2.rectangle(test_img, (200, 200), (400, 400), (0, 100, 255), -1)
        cv2.putText(test_img, "TEST", (250, 300), cv2.FONT_HERSHEY_SIMPLEX, 2, (255, 255, 255), 3)
        
        test_path = "diagnostic_test.jpg"
        cv2.imwrite(test_path, test_img)
        
        # Fazer predição
        results = model(test_path, conf=0.1, verbose=False)
        
        detected_classes = set()
        total_detections = 0
        
        for r in results:
            if r.boxes is not None:
                for box in r.boxes:
                    cls = int(box.cls[0].item())
                    class_name = model.names[cls]
                    conf = box.conf[0].item()
                    
                    detected_classes.add(class_name)
                    total_detections += 1
                    
                    print(f"   Detectado: '{class_name}' (ID: {cls}, Conf: {conf:.3f})")
        
        # Limpar arquivo de teste
        Path(test_path).unlink(missing_ok=True)
        
        if total_detections == 0:
            print(f"   ❌ Nenhuma detecção - modelo pode não estar funcionando")
        elif len(detected_classes) == 1:
            print(f"   ❌ CONFIRMADO: Sempre detecta '{list(detected_classes)[0]}'")
            return False
        else:
            print(f"   ✅ Detecta classes diferentes: {detected_classes}")
        
        return len(detected_classes) > 1
        
    except Exception as e:
        print(f"❌ Erro ao carregar modelo: {str(e)}")
        return False

def diagnose_stride_components():
    """Diagnostica problema dos 3 componentes fixos"""
    
    print(f"\n🎯 DIAGNÓSTICO ESPECÍFICO: STRIDE COMPONENTES FIXOS")
    print("=" * 55)
    
    stride_file = Path("stride_analyzer_enhanced.py")
    
    if not stride_file.exists():
        print("❌ Arquivo stride_analyzer_enhanced.py não encontrado!")
        return False
    
    # Ler e analisar código
    with open(stride_file, 'r', encoding='utf-8') as f:
        content = f.read()
    
    # Procurar pelo padrão problemático
    hardcoded_patterns = [
        "Application Server",
        "Database Server", 
        "Network Gateway",
        "components = [",
        "'name': 'Application Server'",
        "'name': 'Database Server'",
        "'name': 'Network Gateway'"
    ]
    
    problems_found = []
    
    for pattern in hardcoded_patterns:
        if pattern in content:
            problems_found.append(pattern)
    
    if problems_found:
        print(f"❌ PROBLEMA CONFIRMADO: Componentes hardcoded encontrados!")
        print(f"   Padrões encontrados: {len(problems_found)}")
        for pattern in problems_found[:3]:
            print(f"     - '{pattern}'")
        
        # Localizar função específica
        if '_detect_components_dynamic' in content:
            print(f"✅ Função _detect_components_dynamic encontrada")
            
            # Extrair função
            start = content.find('def _detect_components_dynamic')
            if start > 0:
                # Encontrar próxima função
                end = content.find('\n    def ', start + 1)
                if end == -1:
                    end = content.find('\nclass ', start + 1)
                if end == -1:
                    end = len(content)
                
                function_content = content[start:end]
                
                # Contar componentes hardcoded na função
                hardcoded_count = function_content.count("'name':")
                print(f"   Componentes hardcoded na função: {hardcoded_count}")
                
                if "else:" in function_content and hardcoded_count >= 3:
                    print(f"   ❌ CONFIRMADO: Fallback com 3 componentes fixos!")
                    return False
        
        return False
    else:
        print(f"✅ Nenhum padrão hardcoded óbvio encontrado")
        return True

def diagnose_integration_problems():
    """Diagnostica problemas de integração entre YOLO e STRIDE"""
    
    print(f"\n🔗 DIAGNÓSTICO: INTEGRAÇÃO YOLO-STRIDE") 
    print("=" * 40)
    
    # Verificar se stride usa YOLO corretamente
    stride_file = Path("stride_analyzer_enhanced.py")
    
    if stride_file.exists():
        with open(stride_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        # Verificar imports e uso do YOLO
        yolo_indicators = [
            "from ultralytics import YOLO",
            "import ultralytics", 
            "YOLO(",
            "use_yolo",
            "_detect_with_yolo",
            "yolo_components"
        ]
        
        yolo_usage = [indicator for indicator in yolo_indicators if indicator in content]
        
        print(f"🔍 Indicadores de uso do YOLO encontrados: {len(yolo_usage)}")
        for indicator in yolo_usage:
            print(f"   ✅ {indicator}")
        
        if len(yolo_usage) < 3:
            print(f"❌ PROBLEMA: Integração YOLO incompleta ou ausente")
            return False
        
        # Verificar se há caminho para modelo
        model_path_patterns = [
            "cloud_icons_training",
            "best_cloud_icons.pt",
            "model_path",
            "yolo_model"
        ]
        
        model_refs = [pattern for pattern in model_path_patterns if pattern in content]
        print(f"🔍 Referências ao modelo: {len(model_refs)}")
        
        if len(model_refs) == 0:
            print(f"❌ PROBLEMA: Nenhuma referência ao modelo YOLO")
            return False
        
    return True

def provide_targeted_solutions():
    """Fornece soluções específicas para os problemas identificados"""
    
    print(f"\n🔧 SOLUÇÕES ESPECÍFICAS")
    print("=" * 25)
    
    print("1. 🎯 Para YOLO sempre 'Cloud Genérica':")
    print("   # Verificar dataset.yaml")
    print("   python -c \"import yaml; print(yaml.safe_load(open('./cloud_icons_training/dataset.yaml')))\"")
    print("   ")
    print("   # Retreinar com mais variabilidade")
    print("   python complete_yolo_training_pipeline.py")
    print("   # Escolher opção 1 (Treinamento Completo)")
    
    print("\n2. 🔧 Para componentes sempre fixos:")
    print("   python fix_stride_components.py")
    
    print("\n3. 🧪 Para testar correções:")
    print("   python test_fixes.py")
    
    print("\n4. 🚀 Para testar sistema integrado:")
    print("   streamlit run stride_analyzer_enhanced.py")

def main():
    """Executa diagnóstico completo focado"""
    
    print("🎯 DIAGNÓSTICO FOCADO NOS PROBLEMAS REPORTADOS")
    print("=" * 55)
    print("Problema 1: Sempre 3 componentes e 7 ameaças")
    print("Problema 2: YOLO sempre 'Cloud Genérica'")
    print("=" * 55)
    
    # Diagnósticos específicos
    yolo_ok = diagnose_yolo_classes()
    stride_ok = diagnose_stride_components()
    integration_ok = diagnose_integration_problems()
    
    # Resumo
    print(f"\n{'='*55}")
    print("📊 RESUMO DO DIAGNÓSTICO:")
    print(f"   YOLO Classes:      {'✅ OK' if yolo_ok else '❌ PROBLEMA'}")
    print(f"   STRIDE Components: {'✅ OK' if stride_ok else '❌ PROBLEMA'}")
    print(f"   Integração:        {'✅ OK' if integration_ok else '❌ PROBLEMA'}")
    
    if not yolo_ok:
        print(f"\n🤖 YOLO: Modelo retorna sempre a mesma classe")
        print(f"   💡 Retreinar com dataset mais diversificado")
    
    if not stride_ok:
        print(f"\n🎯 STRIDE: Componentes hardcoded encontrados")
        print(f"   💡 Aplicar correção na lógica de detecção")
    
    if not integration_ok:
        print(f"\n🔗 INTEGRAÇÃO: Problemas na conexão YOLO-STRIDE")
        print(f"   💡 Melhorar integração entre os sistemas")
    
    # Soluções direcionadas
    if not (yolo_ok and stride_ok and integration_ok):
        provide_targeted_solutions()
    else:
        print(f"\n🎉 NENHUM PROBLEMA DETECTADO!")
        print(f"Os problemas podem estar em outro lugar ou já foram corrigidos.")
    
    print(f"{'='*55}")

if __name__ == "__main__":
    main()