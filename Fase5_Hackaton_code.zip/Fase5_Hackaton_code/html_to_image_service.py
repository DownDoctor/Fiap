#!/usr/bin/env python3
"""
Serviço para converter HTML em imagem com múltiplos backends
Suporta: Playwright, Selenium, e html2image
"""

import os
import base64
import hashlib
import tempfile
import asyncio
from pathlib import Path
from typing import Optional, Dict, Tuple
from datetime import datetime, timedelta
import logging

logger = logging.getLogger(__name__)

# Tentar importar diferentes backends
PLAYWRIGHT_AVAILABLE = False
SELENIUM_AVAILABLE = False
HTML2IMAGE_AVAILABLE = False

try:
    from playwright.async_api import async_playwright
    PLAYWRIGHT_AVAILABLE = True
    logger.info("✅ Playwright disponível")
except ImportError:
    logger.warning("⚠️ Playwright não disponível")

try:
    from selenium import webdriver
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.chrome.service import Service
    SELENIUM_AVAILABLE = True
    logger.info("✅ Selenium disponível")
except ImportError:
    logger.warning("⚠️ Selenium não disponível")

try:
    from html2image import Html2Image
    HTML2IMAGE_AVAILABLE = True
    logger.info("✅ html2image disponível")
except ImportError:
    logger.warning("⚠️ html2image não disponível")

try:
    import imgkit
    import pdfkit
    WKHTML_AVAILABLE = True
    logger.info("✅ wkhtmltoimage disponível")
except ImportError:
    WKHTML_AVAILABLE = False
    logger.warning("⚠️ wkhtmltoimage não disponível")


class HTMLToImageConverter:
    """Conversor de HTML para imagem com múltiplos backends"""
    
    def __init__(self, output_dir: str = "reports/images", base_url: str = None):
        """
        Args:
            output_dir: Diretório para salvar as imagens
            base_url: URL base para servir as imagens (ex: http://localhost:8000)
        """
        self.output_dir = Path(output_dir)
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        self.base_url = base_url or "http://localhost:8000"
        
        # Cache de imagens geradas
        self.image_cache = {}
        
        # Configurar backend preferencial
        self.backend = self._select_backend()
        
        logger.info(f"📁 Output dir: {self.output_dir}")
        logger.info(f"🌐 Base URL: {self.base_url}")
        logger.info(f"🔧 Backend: {self.backend}")
    
    def _select_backend(self) -> str:
        """Seleciona o melhor backend disponível"""
        if PLAYWRIGHT_AVAILABLE:
            return "playwright"
        elif SELENIUM_AVAILABLE:
            return "selenium"
        elif HTML2IMAGE_AVAILABLE:
            return "html2image"
        elif WKHTML_AVAILABLE:
            return "wkhtmltoimage"
        else:
            return "none"
    
    async def convert_html_to_image_async(self, html_content: str, 
                                          filename: Optional[str] = None,
                                          width: int = 1200,
                                          height: int = None) -> Dict:
        """
        Converte HTML em imagem de forma assíncrona
        
        Returns:
            Dict com informações da imagem gerada
        """
        
        # Gerar nome único se não fornecido
        if not filename:
            content_hash = hashlib.md5(html_content.encode()).hexdigest()[:8]
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            filename = f"stride_report_{content_hash}_{timestamp}.png"
        
        # Caminho completo
        image_path = self.output_dir / filename
        
        # Verificar cache
        cache_key = hashlib.md5(html_content.encode()).hexdigest()
        if cache_key in self.image_cache:
            cached = self.image_cache[cache_key]
            if Path(cached['path']).exists():
                logger.info(f"📦 Retornando imagem do cache: {cached['filename']}")
                return cached
        
        # Converter baseado no backend
        success = False
        
        if self.backend == "playwright":
            success = await self._convert_with_playwright(html_content, image_path, width, height)
        elif self.backend == "selenium":
            success = await self._convert_with_selenium(html_content, image_path, width, height)
        elif self.backend == "html2image":
            success = await self._convert_with_html2image(html_content, image_path, width, height)
        elif self.backend == "wkhtmltoimage":
            success = await self._convert_with_wkhtml(html_content, image_path, width)
        else:
            # Fallback: salvar como HTML
            html_path = image_path.with_suffix('.html')
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            result = {
                'success': False,
                'filename': html_path.name,
                'path': str(html_path),
                'url': f"{self.base_url}/images/{html_path.name}",
                'size': len(html_content),
                'format': 'html',
                'error': 'No image conversion backend available'
            }
            return result
        
        if success and image_path.exists():
            # Obter tamanho da imagem
            file_size = image_path.stat().st_size
            
            # Gerar resultado
            result = {
                'success': True,
                'filename': filename,
                'path': str(image_path),
                'url': f"{self.base_url}/images/{filename}",
                'size': file_size,
                'format': 'png',
                'width': width,
                'height': height or 'auto',
                'backend': self.backend,
                'timestamp': datetime.now().isoformat()
            }
            
            # Adicionar ao cache
            self.image_cache[cache_key] = result
            
            logger.info(f"✅ Imagem gerada: {filename} ({file_size/1024:.1f} KB)")
            return result
        
        else:
            return {
                'success': False,
                'error': 'Failed to generate image',
                'backend': self.backend
            }
    
    async def _convert_with_playwright(self, html_content: str, output_path: Path, 
                                      width: int, height: Optional[int]) -> bool:
        """Converte usando Playwright (mais robusto)"""
        if not PLAYWRIGHT_AVAILABLE:
            return False
        
        try:
            async with async_playwright() as p:
                # Lançar browser headless
                browser = await p.chromium.launch(headless=True)
                page = await browser.new_page()
                
                # Configurar viewport
                await page.set_viewport_size({
                    'width': width,
                    'height': height or 800
                })
                
                # Carregar HTML
                await page.set_content(html_content)
                
                # Aguardar renderização
                await page.wait_for_timeout(1000)
                
                # Capturar screenshot
                await page.screenshot(
                    path=str(output_path),
                    full_page=True
                )
                
                await browser.close()
                
            return True
            
        except Exception as e:
            logger.error(f"Erro no Playwright: {e}")
            return False
    
    async def _convert_with_selenium(self, html_content: str, output_path: Path,
                                    width: int, height: Optional[int]) -> bool:
        """Converte usando Selenium"""
        if not SELENIUM_AVAILABLE:
            return False
        
        try:
            # Configurar Chrome options
            chrome_options = Options()
            chrome_options.add_argument('--headless')
            chrome_options.add_argument('--no-sandbox')
            chrome_options.add_argument('--disable-dev-shm-usage')
            chrome_options.add_argument(f'--window-size={width},{height or 800}')
            
            # Criar driver
            driver = webdriver.Chrome(options=chrome_options)
            
            # Salvar HTML temporário
            with tempfile.NamedTemporaryFile(suffix='.html', delete=False) as tmp:
                tmp.write(html_content.encode('utf-8'))
                tmp_path = tmp.name
            
            # Carregar HTML
            driver.get(f"file://{tmp_path}")
            
            # Aguardar renderização
            await asyncio.sleep(1)
            
            # Capturar screenshot
            driver.save_screenshot(str(output_path))
            
            # Limpar
            driver.quit()
            os.unlink(tmp_path)
            
            return True
            
        except Exception as e:
            logger.error(f"Erro no Selenium: {e}")
            return False
    
    async def _convert_with_html2image(self, html_content: str, output_path: Path,
                                      width: int, height: Optional[int]) -> bool:
        """Converte usando html2image"""
        if not HTML2IMAGE_AVAILABLE:
            return False
        
        try:
            hti = Html2Image(
                output_path=str(output_path.parent),
                size=(width, height or 800)
            )
            
            # Gerar imagem
            hti.screenshot(
                html_str=html_content,
                save_as=output_path.name
            )
            
            return True
            
        except Exception as e:
            logger.error(f"Erro no html2image: {e}")
            return False
    
    async def _convert_with_wkhtml(self, html_content: str, output_path: Path,
                                  width: int) -> bool:
        """Converte usando wkhtmltoimage"""
        if not WKHTML_AVAILABLE:
            return False
        
        try:
            options = {
                'format': 'png',
                'width': width,
                'enable-local-file-access': None
            }
            
            # Salvar HTML temporário
            with tempfile.NamedTemporaryFile(suffix='.html', delete=False) as tmp:
                tmp.write(html_content.encode('utf-8'))
                tmp_path = tmp.name
            
            # Converter
            imgkit.from_file(tmp_path, str(output_path), options=options)
            
            # Limpar
            os.unlink(tmp_path)
            
            return True
            
        except Exception as e:
            logger.error(f"Erro no wkhtmltoimage: {e}")
            return False
    
    def convert_html_to_image(self, html_content: str, **kwargs) -> Dict:
        """Versão síncrona do conversor"""
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        try:
            return loop.run_until_complete(
                self.convert_html_to_image_async(html_content, **kwargs)
            )
        finally:
            loop.close()
    
    def cleanup_old_images(self, max_age_hours: int = 24):
        """Remove imagens antigas"""
        cutoff_time = datetime.now() - timedelta(hours=max_age_hours)
        
        for image_file in self.output_dir.glob("*.png"):
            if datetime.fromtimestamp(image_file.stat().st_mtime) < cutoff_time:
                try:
                    image_file.unlink()
                    logger.info(f"🗑️ Removida imagem antiga: {image_file.name}")
                except:
                    pass


class ImageHostingService:
    """Serviço para hospedar e servir as imagens geradas"""
    
    def __init__(self, images_dir: str = "reports/images", port: int = 8001):
        self.images_dir = Path(images_dir)
        self.port = port
        self.base_url = f"http://localhost:{port}"
    
    def start_server(self):
        """Inicia servidor HTTP simples para servir imagens"""
        import http.server
        import socketserver
        import threading
        
        class ImageHandler(http.server.SimpleHTTPRequestHandler):
            def __init__(self, *args, **kwargs):
                super().__init__(*args, directory=str(self.server.images_dir), **kwargs)
            
            def end_headers(self):
                # Adicionar CORS headers
                self.send_header('Access-Control-Allow-Origin', '*')
                self.send_header('Access-Control-Allow-Methods', 'GET')
                self.send_header('Cache-Control', 'public, max-age=3600')
                super().end_headers()
        
        handler = ImageHandler
        handler.images_dir = self.images_dir
        
        with socketserver.TCPServer(("", self.port), handler) as httpd:
            logger.info(f"🌐 Servidor de imagens rodando em {self.base_url}")
            
            # Rodar em thread separada
            server_thread = threading.Thread(target=httpd.serve_forever)
            server_thread.daemon = True
            server_thread.start()
            
            return httpd


# Função helper para instalação de dependências
def install_dependencies():
    """Script para instalar as dependências necessárias"""
    
    print("📦 Instalando dependências para conversão HTML->Imagem...")
    print("\nEscolha o backend desejado:")
    print("1. Playwright (Recomendado - mais robusto)")
    print("2. Selenium (Boa alternativa)")
    print("3. html2image (Simples)")
    print("4. wkhtmltoimage (Leve)")
    print("5. Todos")
    
    choice = input("\nEscolha (1-5): ")
    
    commands = []
    
    if choice in ['1', '5']:
        commands.append("pip install playwright")
        commands.append("playwright install chromium")
    
    if choice in ['2', '5']:
        commands.append("pip install selenium")
        print("\n⚠️ Selenium também precisa do ChromeDriver instalado")
        print("   Download: https://chromedriver.chromium.org/")
    
    if choice in ['3', '5']:
        commands.append("pip install html2image")
    
    if choice in ['4', '5']:
        commands.append("pip install imgkit")
        print("\n⚠️ wkhtmltoimage precisa ser instalado separadamente:")
        print("   Ubuntu/Debian: sudo apt-get install wkhtmltopdf")
        print("   Mac: brew install wkhtmltopdf")
        print("   Windows: Download de https://wkhtmltopdf.org/")
    
    print("\n📝 Comandos a executar:")
    for cmd in commands:
        print(f"   {cmd}")
    
    if input("\nExecutar comandos? (s/n): ").lower() == 's':
        import subprocess
        for cmd in commands:
            print(f"\n▶️ Executando: {cmd}")
            subprocess.run(cmd, shell=True)
    
    print("\n✅ Instalação concluída!")


if __name__ == "__main__":
    import sys
    
    if len(sys.argv) > 1 and sys.argv[1] == "install":
        install_dependencies()
    else:
        # Teste do conversor
        print("🧪 Testando conversor HTML->Imagem")
        
        html_test = """
        <!DOCTYPE html>
        <html>
        <head>
            <style>
                body { font-family: Arial; padding: 20px; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); }
                .card { background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
                h1 { color: #2c3e50; }
                .metric { display: inline-block; margin: 10px; padding: 15px; background: #f0f0f0; border-radius: 5px; }
            </style>
        </head>
        <body>
            <div class="card">
                <h1>🔒 STRIDE Security Report - Test</h1>
                <div class="metric">
                    <h3>Components</h3>
                    <p style="font-size: 2em;">15</p>
                </div>
                <div class="metric">
                    <h3>Threats</h3>
                    <p style="font-size: 2em;">23</p>
                </div>
                <div class="metric">
                    <h3>Risk Score</h3>
                    <p style="font-size: 2em;">7.5/10</p>
                </div>
            </div>
        </body>
        </html>
        """
        
        converter = HTMLToImageConverter()
        result = converter.convert_html_to_image(html_test, filename="test_report.png")
        
        if result['success']:
            print(f"✅ Teste bem-sucedido!")
            print(f"📷 Imagem salva: {result['path']}")
            print(f"🔗 URL: {result['url']}")
        else:
            print(f"❌ Teste falhou: {result.get('error')}")
            print(f"\n💡 Execute 'python {sys.argv[0]} install' para instalar dependências")