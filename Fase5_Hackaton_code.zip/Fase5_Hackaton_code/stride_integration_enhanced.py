"""
Integração STRIDE aprimorada com suporte a thumbnails e metadados de imagem
Versão enhanced que combina análise STRIDE com extração de thumbnails
"""

import json
import logging
import os
from pathlib import Path
from typing import List, Dict
from datetime import datetime

# Importar classes existentes
from multi_cloud_security_analyzer import (
    MultiCloudSecurityAnalyzer,
    CloudComponent,
    CloudProvider,
    ArchitectureType
)

from stride_analyzer import (
    STRIDEThreatModeler,
    STRIDEReportGenerator,
    STRIDEThreat,
    STRIDEThreatType,
    ThreatSeverity
)

from enhanced_image_analyzer import (
    ImageMetadataExtractor,
    EnhancedMultiCloudAnalyzerWithThumbnail
)

logger = logging.getLogger(__name__)

def safe_enum_to_string(value, default='unknown'):
    """Converte enum para string de forma segura"""
    if hasattr(value, 'value'):
        return str(value.value)
    return str(value) if value is not None else default


class STRIDEAnalyzerWithImageSupport(MultiCloudSecurityAnalyzer):
    """
    Analisador STRIDE com suporte completo a imagens (thumbnails + metadados)
    """
    
    def __init__(self):
        super().__init__()
        self.stride_modeler = STRIDEThreatModeler()
        self.stride_reporter = STRIDEReportGenerator()
        self.image_extractor = ImageMetadataExtractor()
        self.reports_dir = Path("reports")
        self.reports_dir.mkdir(exist_ok=True)
    
    def analyze_architecture_with_enhanced_stride(self, image_path: str, generate_html: bool = True) -> Dict:
        """
        Análise STRIDE completa com extração de thumbnail e metadados da imagem
        """
        print(f"🔄 Iniciando análise STRIDE aprimorada: {image_path}")
        
        try:
            # 1. Extrair metadados da imagem (incluindo thumbnail)
            print("📸 Extraindo metadados da imagem...")
            image_metadata = self.image_extractor.extract_image_metadata(image_path)
            
            if "error" in image_metadata:
                return {"error": f"Erro nos metadados: {image_metadata['error']}"}
            
            print(f"✅ Imagem: {image_metadata['file_info']['filename']}")
            print(f"📊 Resolução: {image_metadata['image_properties']['resolution']}")
            print(f"🎨 Tipo: {image_metadata['analysis_info']['diagram_type']}")
            
            # 2. Executar análise tradicional de componentes
            print("🔍 Detectando componentes de nuvem...")
            components, architecture_type = self.image_processor.detect_cloud_components(image_path)
            
            if not components:
                print("⚠️ Nenhum componente detectado. Usando componentes simulados.")
                components, architecture_type = self._create_demo_components_from_image_type(
                    image_metadata['analysis_info']['diagram_type']
                )
            
            # 3. Executar análise STRIDE
            print(f"🎭 Executando análise STRIDE para {len(components)} componentes...")
            stride_threats = self.stride_modeler.analyze_threats(components, architecture_type)
            
            # 4. Gerar relatório STRIDE
            stride_report = self.stride_reporter.generate_stride_report(
                stride_threats, components, architecture_type
            )
            
            # 5. Combinar com metadados da imagem
            enhanced_report = self._create_enhanced_stride_report(
                stride_report, image_metadata, components, architecture_type
            )
            
            # 6. Gerar arquivos de saída
            if generate_html:
                output_files = self._generate_enhanced_output_files(
                    enhanced_report, image_path
                )
                enhanced_report['generated_files'] = output_files
                
                print(f"📊 JSON: {output_files['json_report']}")
                print(f"🌐 HTML: {output_files['html_report']}")
                print(f"📋 Resumo: {output_files['executive_summary']}")
            
            print(f"✅ Análise concluída: {len(stride_threats)} ameaças identificadas")
            
            return enhanced_report
            
        except Exception as e:
            logger.error(f"Erro durante análise STRIDE aprimorada: {e}")
            return {"error": str(e)}
    
    def _create_demo_components_from_image_type(self, diagram_type: str):
        """Cria componentes de demonstração baseados no tipo de diagrama detectado"""
        
        if "API" in diagram_type or "Gateway" in diagram_type:
            components = [
                CloudComponent("API Gateway", "networking", CloudProvider.AWS, (0,0), 0.9, {}, "networking"),
                CloudComponent("Lambda", "compute", CloudProvider.AWS, (0,0), 0.8, {}, "compute"),
                CloudComponent("DynamoDB", "database", CloudProvider.AWS, (0,0), 0.9, {}, "database"),
                CloudComponent("CloudWatch", "monitoring", CloudProvider.AWS, (0,0), 0.7, {}, "monitoring")
            ]
            architecture_type = ArchitectureType.API_GATEWAY
            
        elif "Microservice" in diagram_type or "Container" in diagram_type:
            components = [
                CloudComponent("EKS", "compute", CloudProvider.AWS, (0,0), 0.9, {}, "compute"),
                CloudComponent("ALB", "networking", CloudProvider.AWS, (0,0), 0.9, {}, "networking"),
                CloudComponent("RDS", "database", CloudProvider.AWS, (0,0), 0.9, {}, "database"),
                CloudComponent("Service Mesh", "networking", CloudProvider.API_MANAGEMENT, (0,0), 0.8, {}, "networking")
            ]
            architecture_type = ArchitectureType.MICROSERVICES
            
        elif "Azure" in diagram_type:
            components = [
                CloudComponent("API Management", "api_management", CloudProvider.AZURE, (0,0), 0.9, {}, "networking"),
                CloudComponent("Logic Apps", "integration", CloudProvider.AZURE, (0,0), 0.8, {}, "integration"),
                CloudComponent("SQL Database", "database", CloudProvider.AZURE, (0,0), 0.9, {}, "database"),
                CloudComponent("Active Directory", "security", CloudProvider.AZURE, (0,0), 0.9, {}, "security")
            ]
            architecture_type = ArchitectureType.API_GATEWAY
            
        else:
            # Arquitetura genérica
            components = [
                CloudComponent("API Gateway", "networking", CloudProvider.AWS, (0,0), 0.9, {}, "networking"),
                CloudComponent("Database", "database", CloudProvider.GENERIC, (0,0), 0.9, {}, "database"),
                CloudComponent("REST API", "communication", CloudProvider.API_MANAGEMENT, (0,0), 0.8, {}, "communication")
            ]
            architecture_type = ArchitectureType.CLOUD_NATIVE
        
        return components, architecture_type
    
    def _create_enhanced_stride_report(self, stride_report: Dict, image_metadata: Dict, 
                                     components: List[CloudComponent], architecture_type: ArchitectureType) -> Dict:
        """Cria relatório STRIDE aprimorado com metadados da imagem"""
        
        enhanced_report = {
            "analysis_metadata": {
                "timestamp": stride_report.get('timestamp'),
                "methodology": "Microsoft STRIDE Multi-Cloud Analysis with Enhanced Image Support",
                "version": "3.0",
                "has_thumbnail": True,
                "has_image_metadata": True
            },
            
            # Metadados da imagem original (com thumbnail)
            "source_image": image_metadata,
            
            # Análise arquitetural
            "architecture_analysis": {
                **stride_report.get('architecture_analysis', {}),
                "image_derived_type": image_metadata.get('analysis_info', {}).get('diagram_type'),
                "image_complexity_score": image_metadata.get('analysis_info', {}).get('complexity_score', 0),
                "components_detected_from_image": len(components)
            },
            
            # Análise STRIDE completa
            "stride_analysis": stride_report.get('stride_analysis', {}),
            "stride_threats": stride_report.get('detailed_threats', []),
            "risk_assessment": stride_report.get('risk_assessment', {}),
            "attack_surface_analysis": stride_report.get('attack_surface_analysis', {}),
            
            # Análise de compliance
            "compliance_impact": stride_report.get('compliance_impact', {}),
            
            # Recomendações
            "recommendations": stride_report.get('recommendations', {}),
            "mitigation_analysis": stride_report.get('mitigation_analysis', {}),
            
            # Controles de segurança
            "security_controls": stride_report.get('security_controls', {}),
            
            # Dados dos componentes
            "components_detected": [self._component_to_dict(comp) for comp in components],
            "components_by_provider": self._group_components_by_provider(components)
        }
        
        return enhanced_report
    
    def _component_to_dict(self, component: CloudComponent) -> Dict:
        """Converte CloudComponent para dicionário"""
        return {
            'name': component.name,
            'service_type': component.service_type,
            'provider': component.provider.value,
            'location': component.location,
            'confidence': component.confidence,
            'properties': component.properties,
            'category': component.category
        }
    
    def _group_components_by_provider(self, components: List[CloudComponent]) -> Dict:
        """Agrupa componentes por provedor"""
        grouped = {}
        for comp in components:
            provider = comp.provider.value
            if provider not in grouped:
                grouped[provider] = []
            grouped[provider].append(self._component_to_dict(comp))
        return grouped
    
    def _generate_enhanced_output_files(self, report: Dict, original_image_path: str) -> Dict:
        """Gera arquivos de saída aprimorados"""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename_base = Path(original_image_path).stem
        
        # 1. Salvar JSON
        json_filename = self.reports_dir / f"stride_enhanced_analysis_{filename_base}_{timestamp}.json"
        with open(json_filename, 'w', encoding='utf-8') as f:
            json.dump(report, f, indent=2, ensure_ascii=False, default=str)
        
        # 2. Gerar HTML aprimorado
        html_filename = self.reports_dir / f"stride_enhanced_report_{filename_base}_{timestamp}.html"
        html_content = self._create_enhanced_html_with_thumbnail(report)
        
        with open(html_filename, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        # 3. Gerar resumo executivo aprimorado
        summary_filename = self.reports_dir / f"enhanced_executive_summary_{filename_base}_{timestamp}.txt"
        summary_content = self._generate_enhanced_executive_summary(report)
        
        with open(summary_filename, 'w', encoding='utf-8') as f:
            f.write(summary_content)
        
        return {
            'json_report': str(json_filename),
            'html_report': str(html_filename),
            'executive_summary': str(summary_filename)
        }
    
    def _create_enhanced_html_with_thumbnail(self, report: Dict) -> str:
        """Cria HTML aprimorado com thumbnail da imagem"""
        
        # Extrair dados
        image_metadata = report.get('source_image', {})
        arch_analysis = report.get('architecture_analysis', {})
        risk_assessment = report.get('risk_assessment', {})
        threats = report.get('stride_threats', [])
        stride_analysis = report.get('stride_analysis', {})
        
        # Informações da imagem
        file_info = image_metadata.get('file_info', {})
        image_props = image_metadata.get('image_properties', {})
        thumbnail = image_metadata.get('thumbnail', {})
        analysis_info = image_metadata.get('analysis_info', {})
        
        # Dados da análise
        arch_type = arch_analysis.get('type', 'Unknown')
        total_threats = len(threats)
        risk_score = risk_assessment.get('overall_risk_score', 0)
        risk_level = arch_analysis.get('risk_level', 'Unknown')
        
        html = f"""
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório STRIDE Enhanced - {file_info.get('filename', 'Análise')}</title>
    <style>
        {self._get_enhanced_css_styles()}
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container">
        <!-- Header aprimorado -->
        <div class="header">
            <h1>🔒 Relatório STRIDE Security Analysis Enhanced</h1>
            <div class="subtitle">
                Análise de: <strong>{file_info.get('filename', 'Imagem não identificada')}</strong><br>
                Metodologia: Microsoft STRIDE com Análise de Imagem | Gerado em: {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}
            </div>
        </div>
        
        <!-- Seção da imagem original aprimorada -->
        <div class="section image-section">
            <h2>📸 Imagem Original Analisada</h2>
            <div class="image-info-grid">
                <div class="thumbnail-container">
                    <img src="data:image/jpeg;base64,{thumbnail.get('base64_data', '')}" 
                         alt="Thumbnail do diagrama" class="thumbnail-image">
                    <div class="thumbnail-caption">
                        <strong>{analysis_info.get('diagram_type', 'Diagrama')}</strong>
                    </div>
                    <div class="thumbnail-stats">
                        <small>Complexidade: {analysis_info.get('complexity_score', 0)}/100</small>
                    </div>
                </div>
                <div class="image-metadata">
                    <h3>📋 Informações Detalhadas do Arquivo</h3>
                    <div class="metadata-grid">
                        <div class="metadata-item">
                            <span class="label">Nome do Arquivo:</span>
                            <span class="value">{file_info.get('filename', 'N/A')}</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Tamanho:</span>
                            <span class="value">{file_info.get('file_size_mb', 0)} MB</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Resolução:</span>
                            <span class="value">{image_props.get('resolution', 'N/A')}</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Formato:</span>
                            <span class="value">{file_info.get('format', 'N/A').upper()}</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Aspect Ratio:</span>
                            <span class="value">{image_props.get('aspect_ratio', 'N/A')}</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Total de Pixels:</span>
                            <span class="value">{image_props.get('total_pixels', 0):,}</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Tipo de Diagrama:</span>
                            <span class="value">{analysis_info.get('diagram_type', 'N/A')}</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Complexidade Visual:</span>
                            <span class="value">{analysis_info.get('complexity_score', 0)}/100</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Densidade de Texto:</span>
                            <span class="value">{analysis_info.get('text_density', 'N/A')}</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Perfil de Cores:</span>
                            <span class="value">{analysis_info.get('color_profile', 'N/A')}</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Resumo Executivo Enhanced -->
        <div class="section">
            <h2>📊 Resumo Executivo Enhanced</h2>
            <div class="dashboard">
                <div class="metric-card">
                    <h3>Tipo de Arquitetura</h3>
                    <div class="metric-value" style="font-size: 1.5em;">{arch_type.replace('_', ' ').title()}</div>
                    <div class="metric-description">
                        Detectado: {arch_analysis.get('image_derived_type', 'Via análise')}
                    </div>
                </div>
                <div class="metric-card {self._get_risk_class(risk_score)}">
                    <h3>Score de Risco</h3>
                    <div class="metric-value">{risk_score}/10</div>
                    <div class="metric-description">Nível: {risk_level}</div>
                </div>
                <div class="metric-card">
                    <h3>Total de Ameaças</h3>
                    <div class="metric-value">{total_threats}</div>
                    <div class="metric-description">Identificadas via STRIDE</div>
                </div>
                <div class="metric-card">
                    <h3>Componentes</h3>
                    <div class="metric-value">{arch_analysis.get('components_detected_from_image', 0)}</div>
                    <div class="metric-description">Detectados na imagem</div>
                </div>
                <div class="metric-card">
                    <h3>Complexidade da Imagem</h3>
                    <div class="metric-value">{analysis_info.get('complexity_score', 0)}</div>
                    <div class="metric-description">Score visual/100</div>
                </div>
                <div class="metric-card">
                    <h3>Status da Análise</h3>
                    <div class="metric-value" style="font-size: 1.2em;">
                        {self._get_status_emoji(risk_score)}
                    </div>
                    <div class="metric-description">{self._get_status_text(risk_score)}</div>
                </div>
            </div>
        </div>
        
        {self._create_stride_dashboard_html(stride_analysis)}
        {self._create_threats_summary_html(threats)}
        {self._create_recommendations_html(report)}
        
        <!-- Footer aprimorado -->
        <div class="footer">
            <p>🔒 Relatório gerado pelo <strong>Multi-Cloud Security Analyzer Enhanced</strong></p>
            <p>Metodologia: <strong>Microsoft STRIDE</strong> com <strong>Análise Avançada de Imagem</strong></p>
            <p>Imagem analisada: <strong>{file_info.get('filename', 'N/A')}</strong> | 
               Resolução: {image_props.get('resolution', 'N/A')} | 
               Tipo: {analysis_info.get('diagram_type', 'N/A')}</p>
            <p style="font-size: 0.8em; color: #adb5bd;">
                Relatório Enhanced com thumbnail, metadados e análise visual da imagem original
            </p>
        </div>
    </div>
    
    <script>
        {self._get_interactive_scripts_enhanced(threats, image_metadata)}
    </script>
</body>
</html>
        """
        
        return html
    
    def _get_enhanced_css_styles(self) -> str:
        """CSS aprimorado para suporte a thumbnails e metadados"""
        return """
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6; color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .container {
            max-width: 1400px; margin: 20px auto; padding: 20px;
            background: white; box-shadow: 0 0 30px rgba(0,0,0,0.15);
            border-radius: 15px;
        }
        
        .header {
            text-align: center; padding: 40px 0;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white; border-radius: 15px; margin-bottom: 30px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.15);
        }
        
        .header h1 { font-size: 2.8em; margin-bottom: 15px; text-shadow: 2px 2px 4px rgba(0,0,0,0.3); }
        .header .subtitle { font-size: 1.3em; opacity: 0.95; line-height: 1.4; }
        
        .section {
            margin-bottom: 40px; padding: 30px;
            background: #f8f9fa; border-radius: 15px;
            border-left: 6px solid #007bff;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }
        
        .section h2 {
            color: #2c3e50; margin-bottom: 25px; font-size: 2em;
            display: flex; align-items: center;
        }
        
        .image-section {
            border-left-color: #28a745;
            background: linear-gradient(135deg, #f8f9fa 0%, #e9ecef 100%);
        }
        
        .image-info-grid {
            display: grid;
            grid-template-columns: 250px 1fr;
            gap: 40px;
            align-items: start;
        }
        
        .thumbnail-container {
            text-align: center;
            background: white;
            padding: 20px;
            border-radius: 15px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.12);
            border: 3px solid #e9ecef;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        
        .thumbnail-container:hover {
            transform: translateY(-5px);
            box-shadow: 0 12px 35px rgba(0,0,0,0.18);
        }
        
        .thumbnail-image {
            width: 180px;
            height: 180px;
            border-radius: 12px;
            border: 2px solid #dee2e6;
            object-fit: cover;
            transition: transform 0.3s ease;
        }
        
        .thumbnail-image:hover {
            transform: scale(1.05);
        }
        
        .thumbnail-caption {
            margin-top: 15px;
            font-size: 1.1em;
            color: #2c3e50;
            font-weight: 600;
        }
        
        .thumbnail-stats {
            margin-top: 8px;
            color: #6c757d;
            font-size: 0.85em;
        }
        
        .image-metadata {
            background: white;
            padding: 25px;
            border-radius: 15px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.08);
        }
        
        .image-metadata h3 {
            color: #2c3e50;
            margin-bottom: 20px;
            font-size: 1.4em;
            border-bottom: 2px solid #e9ecef;
            padding-bottom: 10px;
        }
        
        .metadata-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 15px;
        }
        
        .metadata-item {
            display: flex;
            justify-content: space-between;
            align-items: center;
            padding: 12px 0;
            border-bottom: 1px solid #f1f3f4;
            transition: background-color 0.2s ease;
        }
        
        .metadata-item:hover {
            background-color: #f8f9fa;
            margin: 0 -10px;
            padding: 12px 10px;
            border-radius: 8px;
        }
        
        .metadata-item .label {
            font-weight: 600;
            color: #495057;
            font-size: 0.9em;
        }
        
        .metadata-item .value {
            color: #6c757d;
            text-align: right;
            font-weight: 500;
        }
        
        .dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
            gap: 25px; margin-bottom: 30px;
        }
        
        .metric-card {
            background: white; padding: 30px; border-radius: 15px;
            box-shadow: 0 6px 20px rgba(0,0,0,0.1); text-align: center;
            transition: transform 0.3s ease, box-shadow 0.3s ease; 
            border-top: 5px solid #007bff;
        }
        
        .metric-card:hover { 
            transform: translateY(-8px); 
            box-shadow: 0 12px 35px rgba(0,0,0,0.15);
        }
        
        .metric-card h3 {
            color: #6c757d; font-size: 0.95em; text-transform: uppercase;
            letter-spacing: 1px; margin-bottom: 15px; font-weight: 600;
        }
        
        .metric-value {
            font-size: 2.8em; font-weight: bold;
            color: #2c3e50; margin-bottom: 10px;
        }
        
        .metric-description { 
            color: #6c757d; font-size: 0.95em; 
            line-height: 1.4;
        }
        
        .critical { border-top-color: #dc3545; }
        .high { border-top-color: #fd7e14; }
        .medium { border-top-color: #ffc107; }
        .low { border-top-color: #28a745; }
        
        .footer {
            text-align: center; padding: 25px; margin-top: 40px;
            border-top: 2px solid #dee2e6; color: #6c757d;
            background: #f8f9fa; border-radius: 15px;
        }
        
        .footer p {
            margin-bottom: 8px;
        }
        
        @media (max-width: 768px) {
            .image-info-grid {
                grid-template-columns: 1fr;
                gap: 25px;
            }
            .metadata-grid {
                grid-template-columns: 1fr;
            }
            .container { margin: 10px; padding: 15px; }
            .dashboard { grid-template-columns: 1fr; }
            .thumbnail-image { width: 150px; height: 150px; }
            .header h1 { font-size: 2.2em; }
        }
        """
    
    def _get_interactive_scripts_enhanced(self, threats: list, image_metadata: dict) -> str:
        """Scripts JavaScript aprimorados com informações da imagem"""
        return f"""
        // Animações de entrada aprimoradas
        const observerOptions = {{
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        }};
        
        const observer = new IntersectionObserver((entries) => {{
            entries.forEach(entry => {{
                if (entry.isIntersecting) {{
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }}
            }});
        }}, observerOptions);
        
        // Aplicar animações
        document.querySelectorAll('.metric-card, .section').forEach(element => {{
            element.style.opacity = '0';
            element.style.transform = 'translateY(30px)';
            element.style.transition = 'opacity 0.8s ease, transform 0.8s ease';
            observer.observe(element);
        }});
        
        // Efeitos especiais no thumbnail
        const thumbnail = document.querySelector('.thumbnail-image');
        if (thumbnail) {{
            thumbnail.addEventListener('mouseenter', function() {{
                this.style.transform = 'scale(1.08) rotate(2deg)';
                this.style.transition = 'transform 0.4s ease';
                this.style.filter = 'brightness(1.1) contrast(1.1)';
            }});
            
            thumbnail.addEventListener('mouseleave', function() {{
                this.style.transform = 'scale(1) rotate(0deg)';
                this.style.filter = 'brightness(1) contrast(1)';
            }});
            
            // Tooltip com informações da imagem
            thumbnail.title = `Arquivo: {image_metadata.get('file_info', {}).get('filename', 'N/A')}\\nResolução: {image_metadata.get('image_properties', {}).get('resolution', 'N/A')}\\nTipo: {image_metadata.get('analysis_info', {}).get('diagram_type', 'N/A')}`;
        }}
        
        // Contador animado para métricas
        const animateCounters = () => {{
            const counters = document.querySelectorAll('.metric-value');
            counters.forEach(counter => {{
                const target = parseInt(counter.textContent) || parseFloat(counter.textContent) || 0;
                const increment = target / 60;
                let current = 0;
                
                const timer = setInterval(() => {{
                    current += increment;
                    if (current >= target) {{
                        counter.textContent = target;
                        clearInterval(timer);
                    }} else {{
                        if (target % 1 === 0) {{
                            counter.textContent = Math.floor(current);
                        }} else {{
                            counter.textContent = current.toFixed(1);
                        }}
                    }}
                }}, 20);
            }});
        }};
        
        // Iniciar animações após carregamento
        window.addEventListener('load', () => {{
            setTimeout(animateCounters, 800);
        }});
        """
    def _create_stride_dashboard_html(self, stride_analysis: Dict) -> str:
        """Cria dashboard das categorias STRIDE"""
        statistics = stride_analysis.get('statistics', {})
        
        stride_cards = ""
        stride_categories = {
            'spoofing': {'emoji': '🎭', 'name': 'Spoofing', 'description': 'Falsificação de Identidade'},
            'tampering': {'emoji': '🔧', 'name': 'Tampering', 'description': 'Violação de Integridade'},
            'repudiation': {'emoji': '📝', 'name': 'Repudiation', 'description': 'Não-Repúdio'},
            'information_disclosure': {'emoji': '📄', 'name': 'Information Disclosure', 'description': 'Vazamento de Dados'},
            'denial_of_service': {'emoji': '⚡', 'name': 'Denial of Service', 'description': 'Negação de Serviço'},
            'elevation_of_privilege': {'emoji': '⬆️', 'name': 'Elevation of Privilege', 'description': 'Escalação de Privilégios'}
        }
        
        for category_key, category_info in stride_categories.items():
            stats = statistics.get(category_key, {})
            total_count = stats.get('total_count', 0)
            avg_risk = stats.get('avg_risk_score', 0)
            critical_count = stats.get('critical_count', 0)
            
            risk_class = self._get_risk_class(avg_risk)
            
            stride_cards += f"""
            <div class="metric-card {risk_class}">
                <h3>{category_info['emoji']} {category_info['name']}</h3>
                <div class="metric-value">{total_count}</div>
                <div class="metric-description">
                    Risk Score: {avg_risk}/10<br>
                    {category_info['description']}
                    {f'<br>🚨 {critical_count} Críticas' if critical_count > 0 else ''}
                </div>
            </div>
            """
        
        return f"""
        <div class="section">
            <h2>🎯 Análise por Categoria STRIDE</h2>
            <div class="dashboard">
                {stride_cards}
            </div>
        </div>
        """
    
    def _create_threats_summary_html(self, threats: list) -> str:
        """Cria resumo de ameaças em HTML"""
        if not threats:
            return ""
        
        # Contar por severidade
        severity_count = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
        for threat in threats:
            severity = threat.get('severity', 'medium')
            if severity in severity_count:
                severity_count[severity] += 1
        
        # Top 5 ameaças
        sorted_threats = sorted(threats, key=lambda x: x.get('risk_score', 0), reverse=True)
        
        html = f"""
        <div class="section">
            <h2>📈 Distribuição de Ameaças</h2>
            <div class="dashboard">
                <div class="metric-card critical">
                    <h3>Críticas</h3>
                    <div class="metric-value">{severity_count['critical']}</div>
                    <div class="metric-description">Requerem ação imediata</div>
                </div>
                <div class="metric-card high">
                    <h3>Altas</h3>
                    <div class="metric-value">{severity_count['high']}</div>
                    <div class="metric-description">Atenção prioritária</div>
                </div>
                <div class="metric-card medium">
                    <h3>Médias</h3>
                    <div class="metric-value">{severity_count['medium']}</div>
                    <div class="metric-description">Monitoramento necessário</div>
                </div>
                <div class="metric-card low">
                    <h3>Baixas</h3>
                    <div class="metric-value">{severity_count['low']}</div>
                    <div class="metric-description">Melhorias graduais</div>
                </div>
            </div>
            
            <h3>🔥 Top 5 Ameaças por Risk Score</h3>
            <div style="background: white; border-radius: 15px; padding: 25px; margin-top: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.08);">
        """
        
        for i, threat in enumerate(sorted_threats[:5], 1):
            # Corrigir acesso aos campos do threat
            threat_type = threat.get('threat_type', 'unknown')
            if hasattr(threat_type, 'value'):
                threat_type = threat_type.value
            threat_type = str(threat_type).replace('_', ' ').title()
            
            component = threat.get('component', 'N/A')
            severity = threat.get('severity', 'medium')
            if hasattr(severity, 'value'):
                severity = severity.value
            severity = str(severity)
            
            risk_score = threat.get('risk_score', 0)
            description = threat.get('description', 'N/A')
            if len(str(description)) > 120:
                description = str(description)[:120] + "..."
            
            severity_colors = {
                'critical': '#dc3545',
                'high': '#fd7e14', 
                'medium': '#ffc107',
                'low': '#28a745'
            }
            
            html += f"""
                <div style="border-left: 5px solid {severity_colors.get(severity, '#6c757d')}; 
                           padding: 20px; margin: 15px 0; background: #f8f9fa; border-radius: 0 12px 12px 0;
                           transition: transform 0.2s ease, box-shadow 0.2s ease;"
                     onmouseover="this.style.transform='translateX(5px)'; this.style.boxShadow='0 6px 20px rgba(0,0,0,0.1)'"
                     onmouseout="this.style.transform='translateX(0)'; this.style.boxShadow='none'">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 12px;">
                        <strong style="color: #2c3e50; font-size: 1.1em;">{i}. {threat_type} | {component}</strong>
                        <span style="background: {severity_colors.get(severity, '#6c757d')}; color: white; 
                                   padding: 6px 12px; border-radius: 15px; font-size: 0.85em; font-weight: bold;">
                            {severity.upper()} - {risk_score}/10
                        </span>
                    </div>
                    <p style="color: #6c757d; margin: 0; font-size: 0.95em; line-height: 1.4;">{description}</p>
                </div>
            """
        
        html += """
            </div>
        </div>
        """
        
        return html
    
    def _create_recommendations_html(self, report: Dict) -> str:
        """Cria seção de recomendações em HTML"""
        recommendations = report.get('recommendations', {})
        immediate_actions = recommendations.get('immediate_actions', [])
        
        if not immediate_actions:
            return ""
        
        html = """
        <div class="section">
            <h2>💡 Ações Imediatas Recomendadas</h2>
            <div style="background: white; border-radius: 15px; padding: 25px; box-shadow: 0 4px 15px rgba(0,0,0,0.08);">
        """
        
        for i, action in enumerate(immediate_actions[:5], 1):
            priority = action.get('priority', 'MEDIUM')
            component = action.get('component', 'N/A')
            description = action.get('description', 'Ação não especificada')
            timeline = action.get('timeline', 'N/A')
            risk_score = action.get('risk_score', 0)
            
            priority_colors = {
                'CRITICAL': '#dc3545',
                'HIGH': '#fd7e14',
                'MEDIUM': '#ffc107',
                'LOW': '#28a745'
            }
            
            html += f"""
                <div style="border: 2px solid #dee2e6; border-radius: 12px; padding: 25px; margin: 20px 0;
                           border-left: 6px solid {priority_colors.get(priority, '#6c757d')};
                           transition: all 0.3s ease; background: linear-gradient(135deg, #ffffff 0%, #f8f9fa 100%);"
                     onmouseover="this.style.borderColor='{priority_colors.get(priority, '#6c757d')}'; this.style.transform='translateY(-3px)'; this.style.boxShadow='0 8px 25px rgba(0,0,0,0.12)'"
                     onmouseout="this.style.borderColor='#dee2e6'; this.style.transform='translateY(0)'; this.style.boxShadow='none'">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 15px;">
                        <h4 style="margin: 0; color: #2c3e50; font-size: 1.2em;">{i}. {description}</h4>
                        <span style="background: {priority_colors.get(priority, '#6c757d')}; color: white;
                                   padding: 8px 16px; border-radius: 25px; font-size: 0.85em; font-weight: bold;
                                   box-shadow: 0 2px 8px rgba(0,0,0,0.15);">
                            {priority}
                        </span>
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 20px;">
                        <div style="background: #f8f9fa; padding: 12px; border-radius: 8px;">
                            <strong style="color: #495057;">Componente:</strong><br>
                            <span style="color: #6c757d;">{component}</span>
                        </div>
                        <div style="background: #f8f9fa; padding: 12px; border-radius: 8px;">
                            <strong style="color: #495057;">Timeline:</strong><br>
                            <span style="color: #6c757d;">{timeline}</span>
                        </div>
                        <div style="background: #f8f9fa; padding: 12px; border-radius: 8px;">
                            <strong style="color: #495057;">Risk Score:</strong><br>
                            <span style="color: #6c757d;">{risk_score}/10</span>
                        </div>
                    </div>
                </div>
            """
        
        html += """
            </div>
        </div>
        """
        
        return html
    
    def _generate_enhanced_executive_summary(self, report: Dict) -> str:
        """Gera resumo executivo aprimorado incluindo informações da imagem"""
        from datetime import datetime
        
        image_metadata = report.get('source_image', {})
        file_info = image_metadata.get('file_info', {})
        image_props = image_metadata.get('image_properties', {})
        analysis_info = image_metadata.get('analysis_info', {})
        
        arch_analysis = report.get('architecture_analysis', {})
        risk_assessment = report.get('risk_assessment', {})
        threats = report.get('stride_threats', [])
        
        summary = f"""
RESUMO EXECUTIVO ENHANCED - ANÁLISE DE SEGURANÇA STRIDE COM IMAGEM
{'=' * 75}

📅 Data da Análise: {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}
🔬 Metodologia: Microsoft STRIDE Threat Modeling with Enhanced Image Analysis
🎯 Versão: Enhanced 3.0 com Suporte a Thumbnail e Metadados

📸 IMAGEM ANALISADA - DETALHES COMPLETOS
{'-' * 45}
Arquivo: {file_info.get('filename', 'Não identificado')}
Caminho: {file_info.get('full_path', 'N/A')}
Tamanho do Arquivo: {file_info.get('file_size_mb', 0)} MB
Resolução da Imagem: {image_props.get('resolution', 'N/A')}
Formato: {file_info.get('format', 'N/A').upper()}
Aspect Ratio: {image_props.get('aspect_ratio', 'N/A')}
Total de Pixels: {image_props.get('total_pixels', 0):,}
Canais de Cor: {image_props.get('channels', 'N/A')}

🎨 ANÁLISE VISUAL DA IMAGEM
{'-' * 30}
Tipo de Diagrama Detectado: {analysis_info.get('diagram_type', 'Não identificado')}
Score de Complexidade Visual: {analysis_info.get('complexity_score', 0)}/100
Densidade de Texto: {analysis_info.get('text_density', 'Não determinada')}
Perfil de Cores: {analysis_info.get('color_profile', 'Não determinado')}

🗡️ ARQUITETURA DETECTADA
{'-' * 30}
Tipo Principal: {arch_analysis.get('type', 'Unknown').replace('_', ' ').title()}
Tipo Derivado da Imagem: {arch_analysis.get('image_derived_type', 'Via análise automática')}
Componentes Detectados: {arch_analysis.get('components_detected_from_image', 0)}
Score de Complexidade da Imagem: {arch_analysis.get('image_complexity_score', 0)}/100

🎯 RESULTADOS DA ANÁLISE STRIDE
{'-' * 35}
Total de Ameaças: {len(threats)}
Risk Score Geral: {risk_assessment.get('overall_risk_score', 0)}/10
Nível de Risco: {arch_analysis.get('risk_level', 'Unknown')}

📊 DISTRIBUIÇÃO POR SEVERIDADE
{'-' * 35}"""
        
        # Contar por severidade
        severity_count = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
        for threat in threats:
            severity = threat.get('severity', 'medium')
            if severity in severity_count:
                severity_count[severity] += 1
        
        for severity, count in severity_count.items():
            if count > 0:
                emoji = {'critical': '🚨', 'high': '🔴', 'medium': '🟡', 'low': '🟢', 'info': 'ℹ️'}.get(severity, '⚪')
                summary += f"\n{emoji} {severity.upper()}: {count} ameaças"
        
        # Top 3 ameaças
        sorted_threats = sorted(threats, key=lambda x: x.get('risk_score', 0), reverse=True)
        if sorted_threats:
            summary += f"\n\n🚨 TOP 3 AMEAÇAS CRÍTICAS\n{'-' * 30}"
            for i, threat in enumerate(sorted_threats[:3], 1):
                threat_type = str(threat.get('threat_type', 'unknown')).replace('_', ' ').title()
                component = threat.get('component', 'unknown')
                risk_score = threat.get('risk_score', 0)
                summary += f"\n{i}. {threat_type} em {component} (Risk: {risk_score}/10)"
        
        # Conclusão aprimorada
        summary += f"\n\n🎯 CONCLUSÃO ENHANCED\n{'-' * 25}"
        overall_risk = risk_assessment.get('overall_risk_score', 0)
        
        if overall_risk >= 8.0:
            summary += f"\nA arquitetura apresenta RISCOS CRÍTICOS que requerem ação imediata."
        elif overall_risk >= 6.0:
            summary += f"\nA arquitetura apresenta riscos ALTOS que necessitam atenção prioritária."
        elif overall_risk >= 4.0:
            summary += f"\nA arquitetura apresenta riscos MÉDIOS que devem ser monitorados."
        else:
            summary += f"\nA arquitetura apresenta nível de risco ACEITÁVEL."
        
        summary += f"\n\nO diagrama '{file_info.get('filename', 'analisado')}' foi processado com sucesso"
        summary += f"\nutilizando análise visual avançada e metodologia STRIDE."
        summary += f"\nTipo de diagrama detectado: {analysis_info.get('diagram_type', 'Não identificado')}"
        summary += f"\nComplexidade visual: {analysis_info.get('complexity_score', 0)}/100"
        summary += f"\nTotal de {len(threats)} ameaças identificadas com thumbnail integrado."
        
        summary += f"\n\n📋 RECURSOS ENHANCED INCLUÍDOS\n{'-' * 35}"
        summary += f"\n✅ Thumbnail da imagem original integrado no relatório HTML"
        summary += f"\n✅ Metadados completos do arquivo de imagem"
        summary += f"\n✅ Análise visual automática do tipo de diagrama"
        summary += f"\n✅ Score de complexidade visual calculado"
        summary += f"\n✅ Informações detalhadas de resolução e formato"
        summary += f"\n✅ Relatório HTML responsivo com interatividade"
        
        return summary
    
    # Métodos utilitários
    def _get_risk_class(self, risk_score: float) -> str:
        """Retorna classe CSS baseada no risk score"""
        if risk_score >= 8.0:
            return 'critical'
        elif risk_score >= 6.0:
            return 'high'
        elif risk_score >= 4.0:
            return 'medium'
        else:
            return 'low'
    
    def _get_status_emoji(self, risk_score: float) -> str:
        """Retorna emoji baseado no risk score"""
        if risk_score >= 8.0:
            return '🚨'
        elif risk_score >= 6.0:
            return '⚠️'
        elif risk_score >= 4.0:
            return '🟡'
        else:
            return '✅'
    
    def _get_status_text(self, risk_score: float) -> str:
        """Retorna texto de status"""
        if risk_score >= 8.0:
            return 'Ação Imediata Necessária'
        elif risk_score >= 6.0:
            return 'Atenção Requerida'
        elif risk_score >= 4.0:
            return 'Monitoramento Necessário'
        else:
            return 'Status Aceitável'


# ============================================================================
# NOVA CLASSE PARA GERENCIAMENTO COMPLETO DE RELATÓRIOS COM THUMBNAILS
# ============================================================================

class EnhancedSTRIDEReportManager:
    """Gerenciador completo de relatórios STRIDE com suporte a thumbnails"""
    
    def __init__(self):
        self.analyzer = STRIDEAnalyzerWithImageSupport()
        self.reports_dir = Path("reports")
        self.reports_dir.mkdir(exist_ok=True)
    
    def analyze_and_generate_enhanced_reports(self, image_path: str = None, 
                                            architecture_type: str = "api_gateway") -> dict:
        """
        Executa análise completa e gera relatórios com thumbnails
        """
        print("🚀 Iniciando análise STRIDE Enhanced com thumbnails...")
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        try:
            if image_path and os.path.exists(image_path):
                print(f"📸 Analisando imagem com thumbnails: {image_path}")
                report = self.analyzer.analyze_architecture_with_enhanced_stride(image_path)
            else:
                print("⚠️ Imagem não encontrada. Modo demo não suportado nesta versão.")
                print("💡 Por favor, forneça uma imagem válida para análise completa.")
                return {"error": "Imagem requerida para análise Enhanced"}
            
            if "error" in report:
                print(f"❌ Erro na análise: {report['error']}")
                return {"error": report["error"]}
            
            # Verificar se os arquivos foram gerados
            generated_files = report.get('generated_files', {})
            
            # Extrair estatísticas
            stats = self._extract_enhanced_analysis_stats(report)
            self._print_enhanced_analysis_summary(stats, report)
            
            return {
                "json_report": generated_files.get('json_report'),
                "html_report": generated_files.get('html_report'), 
                "executive_summary": generated_files.get('executive_summary'),
                "stats": stats,
                "image_metadata": report.get('source_image', {}),
                "success": True
            }
            
        except Exception as e:
            print(f"❌ Erro durante geração de relatórios Enhanced: {e}")
            import traceback
            traceback.print_exc()
            return {"error": str(e), "success": False}
    
    def _extract_enhanced_analysis_stats(self, report: dict) -> dict:
        """Extrai estatísticas aprimoradas da análise"""
        threats = report.get('stride_threats', [])
        arch_analysis = report.get('architecture_analysis', {})
        risk_assessment = report.get('risk_assessment', {})
        image_metadata = report.get('source_image', {})
        
        stats = {
            'total_threats': len(threats),
            'architecture_type': arch_analysis.get('type', 'unknown'),
            'total_components': arch_analysis.get('components_detected_from_image', 0),
            'overall_risk_score': risk_assessment.get('overall_risk_score', 0),
            'risk_level': arch_analysis.get('risk_level', 'unknown'),
            'severity_distribution': {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0},
            'stride_distribution': {},
            'top_threats': [],
            # Estatísticas da imagem
            'image_stats': {
                'filename': image_metadata.get('file_info', {}).get('filename', 'N/A'),
                'file_size_mb': image_metadata.get('file_info', {}).get('file_size_mb', 0),
                'resolution': image_metadata.get('image_properties', {}).get('resolution', 'N/A'),
                'diagram_type': image_metadata.get('analysis_info', {}).get('diagram_type', 'N/A'),
                'complexity_score': image_metadata.get('analysis_info', {}).get('complexity_score', 0),
                'color_profile': image_metadata.get('analysis_info', {}).get('color_profile', 'N/A'),
                'has_thumbnail': bool(image_metadata.get('thumbnail', {}).get('base64_data'))
            }
        }
        
        # Distribuição por severidade
        for threat in threats:
            severity = threat.get('severity', 'medium')
            # Corrigir acesso ao valor do enum
            if hasattr(severity, 'value'):
                severity = severity.value
            severity = str(severity)
            if severity in stats['severity_distribution']:
                stats['severity_distribution'][severity] += 1
        
        # Distribuição STRIDE
        for threat in threats:
            threat_type = threat.get('threat_type', 'unknown')
            # Corrigir acesso ao valor do enum
            if hasattr(threat_type, 'value'):
                threat_type = threat_type.value
            threat_type = str(threat_type)
            stats['stride_distribution'][threat_type] = stats['stride_distribution'].get(threat_type, 0) + 1
        
        # Top 5 ameaças
        sorted_threats = sorted(threats, key=lambda x: x.get('risk_score', 0), reverse=True)
        stats['top_threats'] = []
        for t in sorted_threats[:5]:
            threat_type = t.get('threat_type', 'unknown')
            if hasattr(threat_type, 'value'):
                threat_type = threat_type.value
            
            severity = t.get('severity', 'unknown')
            if hasattr(severity, 'value'):
                severity = severity.value
                
            stats['top_threats'].append({
                'threat_type': str(threat_type),
                'component': t.get('component', 'unknown'),
                'risk_score': t.get('risk_score', 0),
                'severity': str(severity)
            })
        
        return stats
    
    def _print_enhanced_analysis_summary(self, stats: dict, report: dict):
        """Imprime resumo aprimorado da análise no console"""
        image_stats = stats['image_stats']
        
        print(f"\n📊 RESUMO DA ANÁLISE STRIDE ENHANCED")
        print("=" * 55)
        
        # Informações da imagem
        print(f"📸 IMAGEM ANALISADA:")
        print(f"  📁 Arquivo: {image_stats['filename']}")
        print(f"  📏 Resolução: {image_stats['resolution']}")
        print(f"  💾 Tamanho: {image_stats['file_size_mb']} MB")
        print(f"  🎨 Tipo: {image_stats['diagram_type']}")
        print(f"  🔢 Complexidade: {image_stats['complexity_score']}/100")
        print(f"  🖼️ Thumbnail: {'✅ Incluído' if image_stats['has_thumbnail'] else '❌ Não gerado'}")
        
        # Informações da análise
        print(f"\n🗡️ ANÁLISE DE ARQUITETURA:")
        print(f"  🏗️ Tipo: {stats['architecture_type'].replace('_', ' ').title()}")
        print(f"  📦 Componentes: {stats['total_components']}")
        print(f"  🎯 Ameaças: {stats['total_threats']}")
        print(f"  📊 Risk Score: {stats['overall_risk_score']}/10")
        print(f"  🚨 Nível: {stats['risk_level']}")
        
        print(f"\n📋 DISTRIBUIÇÃO POR SEVERIDADE:")
        severity_emojis = {'critical': '🚨', 'high': '🔴', 'medium': '🟡', 'low': '🟢', 'info': 'ℹ️'}
        for severity, count in stats['severity_distribution'].items():
            if count > 0:
                emoji = severity_emojis.get(severity, '⚪')
                print(f"  {emoji} {severity.upper()}: {count}")
        
        print(f"\n🎭 DISTRIBUIÇÃO STRIDE:")
        stride_emojis = {
            'spoofing': '🎭', 'tampering': '🔧', 'repudiation': '📝',
            'information_disclosure': '📄', 'denial_of_service': '⚡', 'elevation_of_privilege': '⬆️'
        }
        for threat_type, count in stats['stride_distribution'].items():
            if count > 0:
                emoji = stride_emojis.get(threat_type, '🔒')
                name = str(threat_type).replace('_', ' ').title()
                print(f"  {emoji} {name}: {count}")
        
        if stats['top_threats']:
            print(f"\n🔥 TOP 5 AMEAÇAS:")
            for i, threat in enumerate(stats['top_threats'], 1):
                emoji = stride_emojis.get(threat['threat_type'], '🔒')
                print(f"  {i}. {emoji} {threat['threat_type'].replace('_', ' ').title()} | {threat['component']} | {threat['risk_score']}/10")


# ============================================================================
# DEMONSTRAÇÃO E EXEMPLO DE USO
# ============================================================================

def demonstrate_enhanced_stride_with_thumbnails():
    """Demonstração completa do sistema STRIDE Enhanced com thumbnails"""
    print("🚀 DEMONSTRAÇÃO: STRIDE ENHANCED COM THUMBNAILS")
    print("=" * 60)
    
    manager = EnhancedSTRIDEReportManager()
    
    # Procurar imagens disponíveis
    image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp']
    test_images = []
    
    for ext in image_extensions:
        test_images.extend(Path(".").glob(f"*{ext}"))
        test_images.extend(Path(".").glob(f"*diagram*{ext}"))
        test_images.extend(Path(".").glob(f"*architecture*{ext}"))
    
    if not test_images:
        print("⚠️ Nenhuma imagem encontrada para demonstração")
        print("💡 Para testar o sistema Enhanced:")
        print("1. Coloque uma imagem de diagrama no diretório atual")
        print("2. Formatos suportados: PNG, JPG, JPEG, BMP, TIFF, WEBP")
        print("3. Execute: python stride_integration_enhanced.py --image sua_imagem.png")
        return False
    
    # Usar a primeira imagem encontrada
    test_image = test_images[0]
    print(f"📸 Usando imagem para demonstração: {test_image}")
    print(f"📏 Tamanho do arquivo: {test_image.stat().st_size / 1024:.1f} KB")
    
    try:
        # Executar análise Enhanced
        result = manager.analyze_and_generate_enhanced_reports(str(test_image))
        
        if result.get('success'):
            print(f"\n✅ ANÁLISE ENHANCED CONCLUÍDA COM SUCESSO!")
            print(f"📊 Relatórios gerados com thumbnail integrado")
            
            # Mostrar informações dos arquivos gerados
            print(f"\n📁 ARQUIVOS GERADOS:")
            if result.get('json_report'):
                json_size = Path(result['json_report']).stat().st_size / 1024
                print(f"  📄 JSON: {result['json_report']} ({json_size:.1f} KB)")
            
            if result.get('html_report'):
                html_size = Path(result['html_report']).stat().st_size / 1024
                print(f"  🌐 HTML: {result['html_report']} ({html_size:.1f} KB)")
            
            if result.get('executive_summary'):
                summary_size = Path(result['executive_summary']).stat().st_size / 1024
                print(f"  📋 Resumo: {result['executive_summary']} ({summary_size:.1f} KB)")
            
            # Mostrar informações da imagem
            image_metadata = result.get('image_metadata', {})
            if image_metadata:
                print(f"\n🖼️ INFORMAÇÕES DA IMAGEM EXTRAÍDAS:")
                file_info = image_metadata.get('file_info', {})
                image_props = image_metadata.get('image_properties', {})
                analysis_info = image_metadata.get('analysis_info', {})
                
                print(f"  📁 Nome: {file_info.get('filename', 'N/A')}")
                print(f"  📐 Resolução: {image_props.get('resolution', 'N/A')}")
                print(f"  🎨 Tipo detectado: {analysis_info.get('diagram_type', 'N/A')}")
                print(f"  📊 Complexidade: {analysis_info.get('complexity_score', 0)}/100")
                print(f"  🖼️ Thumbnail: {'✅ Gerado' if image_metadata.get('thumbnail', {}).get('base64_data') else '❌ Erro'}")
            
            print(f"\n🌐 COMO VISUALIZAR O RELATÓRIO:")
            print(f"1. Abra o arquivo HTML no navegador:")
            print(f"   {result.get('html_report', 'N/A')}")
            print(f"2. O thumbnail da imagem original estará integrado")
            print(f"3. Metadados completos da imagem estarão visíveis")
            print(f"4. Relatório totalmente responsivo e interativo")
            
            return True
        else:
            print(f"❌ Erro na análise: {result.get('error')}")
            return False
            
    except Exception as e:
        print(f"❌ Erro durante demonstração: {e}")
        import traceback
        traceback.print_exc()
        return False


def interactive_enhanced_stride_analyzer():
    """Interface interativa para o analisador Enhanced"""
    print("\n🎮 ANALISADOR STRIDE ENHANCED INTERATIVO")
    print("=" * 50)
    
    manager = EnhancedSTRIDEReportManager()
    
    while True:
        print("\n📋 OPÇÕES DISPONÍVEIS:")
        print("1. 📸 Analisar imagem com thumbnails")
        print("2. 📁 Listar imagens no diretório")
        print("3. 🔍 Procurar imagens automaticamente")
        print("4. 📊 Ver relatórios gerados")
        print("5. 🧪 Demo com imagem automática")
        print("6. ℹ️ Informações sobre thumbnails")
        print("0. ❌ Sair")
        
        choice = input("\n🎯 Escolha uma opção (0-6): ").strip()
        
        if choice == '0':
            print("👋 Encerrando analisador Enhanced")
            break
            
        elif choice == '1':
            image_path = input("📸 Digite o caminho da imagem: ").strip()
            if image_path.startswith('"') and image_path.endswith('"'):
                image_path = image_path[1:-1]  # Remove aspas se houver
                
            if Path(image_path).exists():
                print(f"🔄 Processando imagem: {image_path}")
                result = manager.analyze_and_generate_enhanced_reports(image_path)
                
                if result.get('success'):
                    print(f"✅ Análise concluída!")
                    print(f"🌐 HTML com thumbnail: {result.get('html_report', 'N/A')}")
                    
                    # Perguntar se quer abrir o relatório
                    open_report = input("\n🌐 Deseja abrir o relatório HTML? (s/n): ").strip().lower()
                    if open_report == 's':
                        try:
                            import webbrowser
                            webbrowser.open(f"file://{Path(result['html_report']).absolute()}")
                            print("🚀 Relatório aberto no navegador!")
                        except Exception as e:
                            print(f"❌ Erro ao abrir navegador: {e}")
                else:
                    print(f"❌ Erro: {result.get('error', 'Desconhecido')}")
            else:
                print("❌ Arquivo não encontrado")
                
        elif choice == '2':
            print("\n📁 IMAGENS NO DIRETÓRIO ATUAL:")
            image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp']
            images_found = []
            
            for ext in image_extensions:
                images_found.extend(Path(".").glob(f"*{ext}"))
                images_found.extend(Path(".").glob(f"*{ext.upper()}"))
            
            if images_found:
                for i, img in enumerate(images_found, 1):
                    size_kb = img.stat().st_size / 1024
                    print(f"  {i}. 📸 {img.name} ({size_kb:.1f} KB)")
            else:
                print("  ⚠️ Nenhuma imagem encontrada")
                
        elif choice == '3':
            print("\n🔍 PROCURANDO IMAGENS AUTOMATICAMENTE...")
            search_terms = ['diagram', 'architecture', 'aws', 'azure', 'gcp', 'cloud']
            image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp']
            found_images = []
            
            for term in search_terms:
                for ext in image_extensions:
                    found_images.extend(Path(".").glob(f"*{term}*{ext}"))
            
            if found_images:
                print(f"✅ Encontradas {len(found_images)} imagens relevantes:")
                for i, img in enumerate(found_images[:10], 1):  # Mostrar só 10
                    size_kb = img.stat().st_size / 1024
                    print(f"  {i}. 🎯 {img.name} ({size_kb:.1f} KB)")
                
                choice_img = input(f"\n📸 Escolha uma imagem (1-{min(len(found_images), 10)}) ou Enter para cancelar: ").strip()
                if choice_img.isdigit():
                    idx = int(choice_img) - 1
                    if 0 <= idx < len(found_images):
                        selected_img = found_images[idx]
                        print(f"🔄 Analisando: {selected_img}")
                        
                        result = manager.analyze_and_generate_enhanced_reports(str(selected_img))
                        if result.get('success'):
                            print(f"✅ Análise concluída com thumbnails!")
                            print(f"🌐 Relatório: {result.get('html_report', 'N/A')}")
            else:
                print("⚠️ Nenhuma imagem relevante encontrada")
                
        elif choice == '4':
            print("\n📊 RELATÓRIOS GERADOS:")
            reports_dir = Path("reports")
            if reports_dir.exists():
                html_files = list(reports_dir.glob("*enhanced*.html"))
                json_files = list(reports_dir.glob("*enhanced*.json"))
                
                if html_files:
                    print(f"🌐 Relatórios HTML Enhanced ({len(html_files)}):")
                    for html_file in sorted(html_files, key=lambda p: p.stat().st_mtime, reverse=True)[:5]:
                        size_kb = html_file.stat().st_size / 1024
                        mod_time = datetime.fromtimestamp(html_file.stat().st_mtime)
                        print(f"  📄 {html_file.name} ({size_kb:.1f} KB) - {mod_time.strftime('%d/%m/%Y %H:%M')}")
                
                if json_files:
                    print(f"\n📊 Relatórios JSON Enhanced ({len(json_files)}):")
                    for json_file in sorted(json_files, key=lambda p: p.stat().st_mtime, reverse=True)[:3]:
                        size_kb = json_file.stat().st_size / 1024
                        print(f"  📋 {json_file.name} ({size_kb:.1f} KB)")
            else:
                print("📁 Diretório de relatórios não encontrado")
                
        elif choice == '5':
            print("\n🧪 EXECUTANDO DEMONSTRAÇÃO AUTOMÁTICA...")
            success = demonstrate_enhanced_stride_with_thumbnails()
            if success:
                print("🎉 Demonstração concluída com sucesso!")
            else:
                print("❌ Demonstração falhou - verifique se há imagens disponíveis")
                
        elif choice == '6':
            print("\n💡 INFORMAÇÕES SOBRE THUMBNAILS E ENHANCED MODE:")
            print("=" * 55)
            print("🖼️ RECURSOS DE THUMBNAIL:")
            print("  • Thumbnail de 150x150 pixels gerado automaticamente")
            print("  • Mantém aspect ratio original da imagem")
            print("  • Codificado em Base64 e integrado no HTML")
            print("  • Fundo branco para imagens transparentes")
            print("  • Otimizado com qualidade JPEG 85%")
            
            print("\n📊 METADADOS EXTRAÍDOS:")
            print("  • Nome e caminho completo do arquivo")
            print("  • Tamanho do arquivo em MB")
            print("  • Resolução e aspect ratio")
            print("  • Número de canais de cor")
            print("  • Total de pixels da imagem")
            
            print("\n🎨 ANÁLISE VISUAL:")
            print("  • Detecção automática do tipo de diagrama")
            print("  • Score de complexidade visual (0-100)")
            print("  • Densidade de texto na imagem")
            print("  • Perfil de cores (Monocromático/Colorido)")
            
            print("\n🌐 RELATÓRIO HTML ENHANCED:")
            print("  • Thumbnail integrado com hover effects")
            print("  • Metadados detalhados em grid responsivo")
            print("  • Animações e transições suaves")
            print("  • Design otimizado para mobile e desktop")
            print("  • Informações técnicas da imagem visíveis")
            
        else:
            print("❌ Opção inválida")


def create_enhanced_cli_interface():
    """Cria interface de linha de comando para o Enhanced STRIDE"""
    import argparse
    
    parser = argparse.ArgumentParser(
        description='STRIDE Enhanced Analyzer com suporte a thumbnails e metadados de imagem',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemplos de uso Enhanced:

  # Análise com thumbnails integrados
  python stride_integration_enhanced.py --image diagram.png

  # Análise múltiplas imagens com thumbnails
  python stride_integration_enhanced.py --batch-images *.png

  # Modo interativo Enhanced
  python stride_integration_enhanced.py --interactive

  # Demonstração automática
  python stride_integration_enhanced.py --demo

  # Análise com configurações personalizadas
  python stride_integration_enhanced.py --image diagram.png --thumbnail-size 200x200

Recursos Enhanced:
  ✅ Thumbnails automáticos integrados nos relatórios HTML
  ✅ Extração completa de metadados de imagem
  ✅ Detecção automática do tipo de diagrama
  ✅ Score de complexidade visual
  ✅ Relatórios HTML responsivos e interativos
  ✅ Análise STRIDE completa com visualização aprimorada
        """
    )
    
    parser.add_argument('--image', '-i', help='Caminho para imagem do diagrama')
    parser.add_argument('--batch-images', nargs='+', help='Múltiplas imagens para análise')
    parser.add_argument('--output-dir', help='Diretório de saída (padrão: reports/)')
    parser.add_argument('--thumbnail-size', help='Tamanho do thumbnail (ex: 200x200)', default='150x150')
    parser.add_argument('--interactive', action='store_true', help='Modo interativo Enhanced')
    parser.add_argument('--demo', action='store_true', help='Demonstração automática')
    parser.add_argument('--verbose', '-v', action='store_true', help='Modo verboso')
    parser.add_argument('--open-browser', action='store_true', help='Abrir relatório no navegador automaticamente')
    
    return parser


def handle_enhanced_cli_args(args):
    """Processa argumentos da linha de comando Enhanced"""
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    if args.demo:
        demonstrate_enhanced_stride_with_thumbnails()
        return
    
    if args.interactive:
        interactive_enhanced_stride_analyzer()
        return
    
    if args.image:
        if not Path(args.image).exists():
            print(f"❌ Arquivo não encontrado: {args.image}")
            return
        
        print(f"🔄 Analisando imagem Enhanced: {args.image}")
        manager = EnhancedSTRIDEReportManager()
        
        # Configurar thumbnail size se especificado
        if args.thumbnail_size and 'x' in args.thumbnail_size:
            try:
                w, h = map(int, args.thumbnail_size.split('x'))
                # Aqui você poderia modificar o tamanho do thumbnail se necessário
                print(f"📐 Tamanho do thumbnail: {w}x{h}")
            except ValueError:
                print(f"⚠️ Tamanho de thumbnail inválido: {args.thumbnail_size}")
        
        result = manager.analyze_and_generate_enhanced_reports(args.image)
        
        if result.get('success'):
            print(f"✅ Análise Enhanced concluída!")
            print(f"🌐 Relatório HTML: {result.get('html_report')}")
            print(f"📊 Relatório JSON: {result.get('json_report')}")
            
            # Mostrar estatísticas da imagem
            image_stats = result.get('stats', {}).get('image_stats', {})
            if image_stats:
                print(f"\n📸 INFORMAÇÕES DA IMAGEM:")
                print(f"  📁 Arquivo: {image_stats.get('filename')}")
                print(f"  📐 Resolução: {image_stats.get('resolution')}")
                print(f"  🎨 Tipo: {image_stats.get('diagram_type')}")
                print(f"  📊 Complexidade: {image_stats.get('complexity_score')}/100")
                print(f"  🖼️ Thumbnail: {'✅ Incluído' if image_stats.get('has_thumbnail') else '❌ Erro'}")
            
            # Abrir no navegador se solicitado
            if args.open_browser and result.get('html_report'):
                try:
                    import webbrowser
                    webbrowser.open(f"file://{Path(result['html_report']).absolute()}")
                    print("🚀 Relatório aberto no navegador!")
                except Exception as e:
                    print(f"❌ Erro ao abrir navegador: {e}")
        else:
            print(f"❌ Erro na análise: {result.get('error')}")
    
    elif args.batch_images:
        print(f"📦 Processando {len(args.batch_images)} imagens em lote...")
        manager = EnhancedSTRIDEReportManager()
        successful = 0
        
        for image_path in args.batch_images:
            if Path(image_path).exists():
                print(f"\n🔄 Processando: {image_path}")
                result = manager.analyze_and_generate_enhanced_reports(image_path)
                
                if result.get('success'):
                    successful += 1
                    print(f"✅ Sucesso: {Path(result.get('html_report', '')).name}")
                else:
                    print(f"❌ Erro: {result.get('error')}")
            else:
                print(f"⚠️ Arquivo não encontrado: {image_path}")
        
        print(f"\n📊 RESULTADO DO LOTE:")
        print(f"✅ Sucessos: {successful}/{len(args.batch_images)}")
        print(f"📁 Relatórios salvos em: reports/")
    
    else:
        print("❌ Especifique uma imagem com --image, modo --interactive ou --demo")
        print("💡 Use --help para ver todas as opções disponíveis")


def main():
    """Função principal do Enhanced STRIDE Analyzer"""
    import sys
    
    print("🔒 STRIDE ENHANCED ANALYZER WITH THUMBNAILS")
    print("=" * 50)
    print("Sistema avançado de análise STRIDE com suporte completo a thumbnails")
    print("e metadados de imagem integrados nos relatórios HTML.\n")
    
    if len(sys.argv) > 1:
        # Modo CLI
        parser = create_enhanced_cli_interface()
        args = parser.parse_args()
        handle_enhanced_cli_args(args)
    else:
        # Modo interativo padrão
        print("🎮 Iniciando modo interativo...")
        interactive_enhanced_stride_analyzer()


if __name__ == "__main__":
    main()#!/usr/bin/env python3