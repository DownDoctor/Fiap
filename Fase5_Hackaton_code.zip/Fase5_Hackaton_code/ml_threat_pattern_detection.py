# ml_threat_pattern_detection.py
"""
Sistema de Machine Learning para detecção de padrões de ameaças STRIDE
Utiliza modelos treinados para identificar ameaças automaticamente
"""

import numpy as np
import pandas as pd
from sklearn.ensemble import RandomForestClassifier, GradientBoostingClassifier
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.preprocessing import StandardScaler, LabelEncoder
from sklearn.metrics import classification_report, confusion_matrix
import xgboost as xgb
import joblib
from typing import Dict, List, Tuple, Optional, Any
import json
from pathlib import Path
from dataclasses import dataclass, asdict
import logging
from datetime import datetime
import torch
import torch.nn as nn
import torch.nn.functional as F
from transformers import AutoTokenizer, AutoModel

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


@dataclass
class ThreatPattern:
    """Padrão de ameaça identificado"""
    pattern_id: str
    stride_category: str
    confidence: float
    components_involved: List[str]
    attack_vector: str
    severity: str
    likelihood: str
    indicators: List[str]
    mitigations: List[str]
    references: List[str]


class ThreatFeatureExtractor:
    """Extrator de features para ML"""
    
    def __init__(self):
        self.component_encoder = LabelEncoder()
        self.provider_encoder = LabelEncoder()
        self.service_encoder = LabelEncoder()
        self.scaler = StandardScaler()
        self.is_fitted = False
    
    def extract_features(self, architecture_data: Dict) -> np.ndarray:
        """Extrai features de arquitetura para ML"""
        features = []
        
        # 1. Features de componentes
        components = architecture_data.get('components', [])
        comp_features = self._extract_component_features(components)
        features.extend(comp_features)
        
        # 2. Features de conexões
        connections = architecture_data.get('connections', [])
        conn_features = self._extract_connection_features(connections)
        features.extend(conn_features)
        
        # 3. Features de topologia
        topo_features = self._extract_topology_features(components, connections)
        features.extend(topo_features)
        
        # 4. Features de segurança
        sec_features = self._extract_security_features(architecture_data)
        features.extend(sec_features)
        
        # 5. Features de complexidade
        complex_features = self._extract_complexity_features(architecture_data)
        features.extend(complex_features)
        
        return np.array(features).reshape(1, -1)
    
    def _extract_component_features(self, components: List[Dict]) -> List[float]:
        """Extrai features dos componentes"""
        features = []
        
        # Contagem por tipo
        type_counts = {}
        provider_counts = {}
        
        for comp in components:
            comp_type = comp.get('type', 'unknown')
            provider = comp.get('provider', 'unknown')
            
            type_counts[comp_type] = type_counts.get(comp_type, 0) + 1
            provider_counts[provider] = provider_counts.get(provider, 0) + 1
        
        # Features básicas
        features.append(len(components))  # Total de componentes
        features.append(len(type_counts))  # Diversidade de tipos
        features.append(len(provider_counts))  # Número de providers
        
        # Proporções por categoria
        categories = ['compute', 'storage', 'database', 'networking', 'security', 'monitoring']
        total = max(len(components), 1)
        
        for cat in categories:
            count = type_counts.get(cat, 0)
            features.append(count / total)
        
        # Multi-cloud indicator
        features.append(1.0 if len(provider_counts) > 1 else 0.0)
        
        # Componentes expostos
        exposed_count = sum(1 for c in components 
                          if c.get('security_posture') == 'exposed')
        features.append(exposed_count / total)
        
        return features
    
    def _extract_connection_features(self, connections: List[Dict]) -> List[float]:
        """Extrai features das conexões"""
        features = []
        
        if not connections:
            return [0] * 10  # Features vazias
        
        # Análise de protocolos
        protocols = {}
        encrypted = 0
        authenticated = 0
        
        for conn in connections:
            protocol = conn.get('protocol', 'unknown')
            protocols[protocol] = protocols.get(protocol, 0) + 1
            
            if conn.get('encryption') not in ['None', 'Unknown', None]:
                encrypted += 1
            
            if conn.get('authentication') not in ['None', None]:
                authenticated += 1
        
        total = len(connections)
        
        # Features
        features.append(total)  # Total de conexões
        features.append(len(protocols))  # Diversidade de protocolos
        features.append(encrypted / total)  # Taxa de criptografia
        features.append(authenticated / total)  # Taxa de autenticação
        
        # Protocolos inseguros
        insecure_protocols = ['HTTP', 'FTP', 'Telnet', 'SMTP']
        insecure_count = sum(protocols.get(p, 0) for p in insecure_protocols)
        features.append(insecure_count / total if total > 0 else 0)
        
        # Classificação de dados
        data_classifications = {}
        for conn in connections:
            classification = conn.get('data_classification', 'unknown')
            data_classifications[classification] = data_classifications.get(classification, 0) + 1
        
        # Proporção de dados sensíveis
        sensitive = data_classifications.get('confidential', 0) + data_classifications.get('restricted', 0)
        features.append(sensitive / total if total > 0 else 0)
        
        # Direção das conexões
        bidirectional = sum(1 for c in connections if c.get('direction') == 'bidirectional')
        features.append(bidirectional / total)
        
        # Padding para tamanho fixo
        while len(features) < 10:
            features.append(0)
        
        return features[:10]
    
    def _extract_topology_features(self, components: List[Dict], 
                                  connections: List[Dict]) -> List[float]:
        """Extrai features da topologia da rede"""
        features = []
        
        if not components:
            return [0] * 8
        
        # Construir grafo de conectividade
        connectivity = {}
        for conn in connections:
            source = conn.get('source')
            target = conn.get('target')
            
            if source:
                connectivity[source] = connectivity.get(source, {'in': 0, 'out': 0})
                connectivity[source]['out'] += 1
            
            if target:
                connectivity[target] = connectivity.get(target, {'in': 0, 'out': 0})
                connectivity[target]['in'] += 1
        
        # Métricas de topologia
        if connectivity:
            degrees = [c['in'] + c['out'] for c in connectivity.values()]
            
            features.append(np.mean(degrees))  # Grau médio
            features.append(np.std(degrees))   # Desvio padrão do grau
            features.append(np.max(degrees) if degrees else 0)    # Grau máximo
            
            # Componentes isolados
            isolated = len(components) - len(connectivity)
            features.append(isolated / len(components))
            
            # Hubs (componentes com alto grau)
            threshold = np.mean(degrees) + np.std(degrees) if degrees else 0
            hubs = sum(1 for d in degrees if d > threshold)
            features.append(hubs / len(components))
            
            # Single points of failure
            critical = sum(1 for c in connectivity.values() 
                         if c['in'] > 3 or c['out'] > 3)
            features.append(critical / len(components))
        else:
            features.extend([0] * 6)
        
        # Densidade da rede
        max_connections = len(components) * (len(components) - 1)
        density = len(connections) / max_connections if max_connections > 0 else 0
        features.append(density)
        
        # Clustering coefficient aproximado
        triangles = self._count_triangles(connectivity, connections)
        features.append(triangles / max(len(components), 1))
        
        return features[:8]
    
    def _count_triangles(self, connectivity: Dict, connections: List[Dict]) -> int:
        """Conta triângulos no grafo (para clustering coefficient)"""
        triangles = 0
        
        # Criar adjacency list
        adj = {}
        for conn in connections:
            source = conn.get('source')
            target = conn.get('target')
            
            if source and target:
                if source not in adj:
                    adj[source] = set()
                if target not in adj:
                    adj[target] = set()
                
                adj[source].add(target)
                if conn.get('direction') == 'bidirectional':
                    adj[target].add(source)
        
        # Contar triângulos
        for node in adj:
            neighbors = adj[node]
            for n1 in neighbors:
                for n2 in neighbors:
                    if n1 != n2 and n1 in adj and n2 in adj.get(n1, set()):
                        triangles += 1
        
        return triangles // 3  # Cada triângulo é contado 3 vezes
    
    def _extract_security_features(self, architecture_data: Dict) -> List[float]:
        """Extrai features de segurança"""
        features = []
        
        components = architecture_data.get('components', [])
        
        # Componentes de segurança
        security_components = [c for c in components if c.get('type') == 'security']
        features.append(len(security_components) / max(len(components), 1))
        
        # Presença de componentes críticos de segurança
        critical_security = ['waf', 'firewall', 'iam', 'kms', 'vault', 'shield']
        has_critical = 0
        
        for comp in components:
            service = comp.get('service', '').lower()
            if any(cs in service for cs in critical_security):
                has_critical += 1
        
        features.append(has_critical / max(len(critical_security), 1))
        
        # Zonas de segurança
        zones = set()
        for comp in components:
            zone = comp.get('security_zone', comp.get('subnet', 'default'))
            zones.add(zone)
        
        features.append(len(zones))  # Número de zonas
        
        # Compliance indicators
        compliance_services = ['cloudtrail', 'config', 'monitor', 'sentinel', 'audit']
        has_compliance = sum(1 for c in components 
                           if any(cs in c.get('service', '').lower() 
                                 for cs in compliance_services))
        features.append(has_compliance / max(len(compliance_services), 1))
        
        return features
    
    def _extract_complexity_features(self, architecture_data: Dict) -> List[float]:
        """Extrai features de complexidade"""
        features = []
        
        components = architecture_data.get('components', [])
        connections = architecture_data.get('connections', [])
        
        # Complexidade básica
        features.append(len(components) + len(connections))
        
        # Complexidade de configuração
        total_config_items = 0
        for comp in components:
            config = comp.get('configuration', {})
            total_config_items += len(config)
        
        features.append(total_config_items / max(len(components), 1))
        
        # Dependências
        dependencies = 0
        for comp in components:
            deps = comp.get('dependencies', [])
            dependencies += len(deps)
        
        features.append(dependencies / max(len(components), 1))
        
        # Diversidade de serviços
        services = set()
        for comp in components:
            service = comp.get('service', 'unknown')
            services.add(service)
        
        features.append(len(services) / max(len(components), 1))
        
        return features
    
    def fit(self, architecture_samples: List[Dict]):
        """Ajusta os encoders com amostras de arquitetura"""
        all_components = []
        all_providers = []
        all_services = []
        
        for arch in architecture_samples:
            for comp in arch.get('components', []):
                all_components.append(comp.get('type', 'unknown'))
                all_providers.append(comp.get('provider', 'unknown'))
                all_services.append(comp.get('service', 'unknown'))
        
        if all_components:
            self.component_encoder.fit(all_components)
        if all_providers:
            self.provider_encoder.fit(all_providers)
        if all_services:
            self.service_encoder.fit(all_services)
        
        self.is_fitted = True


class STRIDEThreatClassifier:
    """Classificador de ameaças STRIDE usando ML"""
    
    def __init__(self, model_type: str = 'xgboost'):
        self.model_type = model_type
        self.models = {}  # Um modelo por categoria STRIDE
        self.feature_extractor = ThreatFeatureExtractor()
        self.stride_categories = [
            'spoofing', 'tampering', 'repudiation',
            'information_disclosure', 'denial_of_service', 
            'elevation_of_privilege'
        ]
        
        # Inicializar modelos
        for category in self.stride_categories:
            self.models[category] = self._create_model()
    
    def _create_model(self):
        """Cria modelo baseado no tipo especificado"""
        if self.model_type == 'xgboost':
            return xgb.XGBClassifier(
                n_estimators=100,
                max_depth=6,
                learning_rate=0.1,
                objective='binary:logistic',
                random_state=42
            )
        elif self.model_type == 'random_forest':
            return RandomForestClassifier(
                n_estimators=100,
                max_depth=10,
                random_state=42
            )
        elif self.model_type == 'gradient_boosting':
            return GradientBoostingClassifier(
                n_estimators=100,
                max_depth=5,
                learning_rate=0.1,
                random_state=42
            )
        else:
            raise ValueError(f"Tipo de modelo não suportado: {self.model_type}")
    
    def train(self, training_data: List[Tuple[Dict, Dict]]):
        """Treina modelos com dados de treinamento"""
        logger.info(f"Treinando {len(self.models)} modelos STRIDE...")
        
        # Preparar dados
        X = []
        y = {category: [] for category in self.stride_categories}
        
        for architecture, threats in training_data:
            features = self.feature_extractor.extract_features(architecture)
            X.append(features[0])
            
            # Labels para cada categoria
            threat_categories = set()
            for threat in threats.get('stride_threats', []):
                category = threat.get('category', '').lower().replace(' ', '_')
                threat_categories.add(category)
            
            for category in self.stride_categories:
                y[category].append(1 if category in threat_categories else 0)
        
        X = np.array(X)
        
        # Treinar modelo para cada categoria
        for category in self.stride_categories:
            y_cat = np.array(y[category])
            
            if len(np.unique(y_cat)) > 1:  # Só treinar se houver exemplos positivos e negativos
                # Split train/test
                X_train, X_test, y_train, y_test = train_test_split(
                    X, y_cat, test_size=0.2, random_state=42, stratify=y_cat
                )
                
                # Treinar
                self.models[category].fit(X_train, y_train)
                
                # Avaliar
                score = self.models[category].score(X_test, y_test)
                logger.info(f"Model {category}: Accuracy = {score:.3f}")
                
                # Cross-validation
                cv_scores = cross_val_score(self.models[category], X, y_cat, cv=5)
                logger.info(f"Model {category}: CV Score = {cv_scores.mean():.3f} (+/- {cv_scores.std() * 2:.3f})")
    
    def predict(self, architecture: Dict) -> List[ThreatPattern]:
        """Prediz ameaças para uma arquitetura"""
        features = self.feature_extractor.extract_features(architecture)
        
        threats = []
        
        for category in self.stride_categories:
            # Predição com probabilidade
            try:
                prob = self.models[category].predict_proba(features)[0][1]
                
                if prob > 0.3:  # Threshold ajustável
                    threat = self._generate_threat_pattern(
                        category, prob, architecture
                    )
                    threats.append(threat)
            except:
                # Modelo não treinado ou erro
                continue
        
        return threats
    
    def _generate_threat_pattern(self, category: str, confidence: float,
                                architecture: Dict) -> ThreatPattern:
        """Gera padrão de ameaça baseado na predição"""
        
        # Mapear severity baseado em confidence
        if confidence > 0.8:
            severity = 'critical'
        elif confidence > 0.6:
            severity = 'high'
        elif confidence > 0.4:
            severity = 'medium'
        else:
            severity = 'low'
        
        # Identificar componentes relevantes
        components_involved = self._identify_vulnerable_components(
            category, architecture
        )
        
        # Gerar indicadores e mitigações
        indicators = self._get_threat_indicators(category, architecture)
        mitigations = self._get_mitigations(category, architecture)
        
        return ThreatPattern(
            pattern_id=f"{category}_{datetime.now().timestamp()}",
            stride_category=category,
            confidence=confidence,
            components_involved=components_involved,
            attack_vector=self._get_attack_vector(category),
            severity=severity,
            likelihood='high' if confidence > 0.7 else 'medium',
            indicators=indicators,
            mitigations=mitigations,
            references=self._get_references(category)
        )
    
    def _identify_vulnerable_components(self, category: str, 
                                       architecture: Dict) -> List[str]:
        """Identifica componentes vulneráveis para a categoria"""
        vulnerable = []
        components = architecture.get('components', [])
        
        vulnerability_map = {
            'spoofing': ['iam', 'authentication', 'identity'],
            'tampering': ['storage', 'database', 'cache'],
            'repudiation': ['logging', 'audit', 'monitoring'],
            'information_disclosure': ['storage', 'database', 'api'],
            'denial_of_service': ['compute', 'networking', 'api'],
            'elevation_of_privilege': ['iam', 'compute', 'container']
        }
        
        vulnerable_types = vulnerability_map.get(category, [])
        
        for comp in components:
            comp_type = comp.get('type', '').lower()
            service = comp.get('service', '').lower()
            
            if any(vt in comp_type or vt in service for vt in vulnerable_types):
                vulnerable.append(comp.get('name', comp.get('id', 'unknown')))
        
        return vulnerable[:5]  # Top 5
    
    def _get_threat_indicators(self, category: str, architecture: Dict) -> List[str]:
        """Obtém indicadores de ameaça"""
        indicators_map = {
            'spoofing': [
                'Ausência de MFA',
                'Tokens sem expiração',
                'Credenciais hardcoded',
                'Falta de certificate pinning'
            ],
            'tampering': [
                'Dados sem integridade verificada',
                'Falta de assinatura digital',
                'Logs modificáveis',
                'Configurações não versionadas'
            ],
            'repudiation': [
                'Logs insuficientes',
                'Falta de audit trail',
                'Eventos não correlacionados',
                'Timestamps não confiáveis'
            ],
            'information_disclosure': [
                'Dados não criptografados',
                'APIs sem autenticação',
                'Verbose error messages',
                'Metadados expostos'
            ],
            'denial_of_service': [
                'Sem rate limiting',
                'Recursos não limitados',
                'Falta de auto-scaling',
                'Sem proteção DDoS'
            ],
            'elevation_of_privilege': [
                'Permissões excessivas',
                'Falta de least privilege',
                'Roles mal configurados',
                'Boundaries não definidos'
            ]
        }
        
        return indicators_map.get(category, [])
    
    def _get_mitigations(self, category: str, architecture: Dict) -> List[str]:
        """Obtém mitigações recomendadas"""
        mitigations_map = {
            'spoofing': [
                'Implementar MFA obrigatório',
                'Usar tokens JWT com expiração curta',
                'Implementar certificate pinning',
                'Usar managed identities'
            ],
            'tampering': [
                'Implementar checksums/hashes',
                'Usar assinatura digital',
                'Logs imutáveis com blockchain',
                'Versionamento de configurações'
            ],
            'repudiation': [
                'Logging centralizado',
                'Audit trail completo',
                'Correlação de eventos com SIEM',
                'Timestamps com NTP sincronizado'
            ],
            'information_disclosure': [
                'Criptografia em repouso e trânsito',
                'API Gateway com autenticação',
                'Error handling apropriado',
                'Data masking/tokenization'
            ],
            'denial_of_service': [
                'Implementar rate limiting',
                'Resource quotas',
                'Auto-scaling policies',
                'DDoS protection (CloudFlare/AWS Shield)'
            ],
            'elevation_of_privilege': [
                'Princípio do menor privilégio',
                'RBAC bem definido',
                'Regular access reviews',
                'Permission boundaries'
            ]
        }
        
        return mitigations_map.get(category, [])
    
    def _get_attack_vector(self, category: str) -> str:
        """Obtém vetor de ataque típico"""
        vectors = {
            'spoofing': 'Identity theft via compromised credentials',
            'tampering': 'Data manipulation through unauthorized access',
            'repudiation': 'Action denial due to insufficient logging',
            'information_disclosure': 'Data exposure through misconfiguration',
            'denial_of_service': 'Resource exhaustion attack',
            'elevation_of_privilege': 'Privilege escalation exploit'
        }
        
        return vectors.get(category, 'Unknown vector')
    
    def _get_references(self, category: str) -> List[str]:
        """Obtém referências relevantes"""
        references = {
            'spoofing': [
                'OWASP A07:2021 - Identification and Authentication Failures',
                'CWE-287: Improper Authentication',
                'NIST 800-63B: Authentication and Lifecycle Management'
            ],
            'tampering': [
                'OWASP A08:2021 - Software and Data Integrity Failures',
                'CWE-494: Download of Code Without Integrity Check',
                'ISO 27001 A.12.2: Protection from malware'
            ],
            'repudiation': [
                'OWASP A09:2021 - Security Logging and Monitoring Failures',
                'CWE-778: Insufficient Logging',
                'NIST 800-92: Guide to Computer Security Log Management'
            ],
            'information_disclosure': [
                'OWASP A01:2021 - Broken Access Control',
                'CWE-200: Information Exposure',
                'GDPR Article 32: Security of processing'
            ],
            'denial_of_service': [
                'OWASP A10:2021 - Server-Side Request Forgery',
                'CWE-400: Uncontrolled Resource Consumption',
                'NIST 800-61: Incident Response Guide'
            ],
            'elevation_of_privilege': [
                'OWASP A04:2021 - Insecure Design',
                'CWE-269: Improper Privilege Management',
                'ISO 27001 A.9.2: User access management'
            ]
        }
        
        return references.get(category, [])
    
    def save_models(self, path: str):
        """Salva modelos treinados"""
        model_path = Path(path)
        model_path.mkdir(parents=True, exist_ok=True)
        
        for category, model in self.models.items():
            joblib.dump(model, model_path / f"{category}_model.pkl")
        
        # Salvar feature extractor
        joblib.dump(self.feature_extractor, model_path / "feature_extractor.pkl")
        
        logger.info(f"Modelos salvos em: {model_path}")
    
    def load_models(self, path: str):
        """Carrega modelos treinados"""
        model_path = Path(path)
        
        for category in self.stride_categories:
            model_file = model_path / f"{category}_model.pkl"
            if model_file.exists():
                self.models[category] = joblib.load(model_file)
        
        # Carregar feature extractor
        extractor_file = model_path / "feature_extractor.pkl"
        if extractor_file.exists():
            self.feature_extractor = joblib.load(extractor_file)
        
        logger.info(f"Modelos carregados de: {model_path}")


class DeepThreatAnalyzer(nn.Module):
    """Analisador deep learning para ameaças complexas"""
    
    def __init__(self, input_dim: int = 50, hidden_dim: int = 128, 
                 num_classes: int = 6):
        super(DeepThreatAnalyzer, self).__init__()
        
        # Encoder
        self.encoder = nn.Sequential(
            nn.Linear(input_dim, hidden_dim),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim, hidden_dim * 2),
            nn.ReLU(),
            nn.Dropout(0.3),
            nn.Linear(hidden_dim * 2, hidden_dim)
        )
        
        # Attention mechanism
        self.attention = nn.MultiheadAttention(hidden_dim, num_heads=4)
        
        # Classifier heads (um para cada categoria STRIDE)
        self.classifiers = nn.ModuleList([
            nn.Sequential(
                nn.Linear(hidden_dim, 64),
                nn.ReLU(),
                nn.Dropout(0.2),
                nn.Linear(64, 1),
                nn.Sigmoid()
            ) for _ in range(num_classes)
        ])
        
        self.num_classes = num_classes
    
    def forward(self, x):
        # Encode features
        encoded = self.encoder(x)
        
        # Self-attention
        attended, _ = self.attention(
            encoded.unsqueeze(0), 
            encoded.unsqueeze(0), 
            encoded.unsqueeze(0)
        )
        attended = attended.squeeze(0)
        
        # Multi-label classification
        outputs = []
        for classifier in self.classifiers:
            outputs.append(classifier(attended))
        
        return torch.cat(outputs, dim=1)


class ThreatPatternDatabase:
    """Banco de dados de padrões de ameaças conhecidos"""
    
    def __init__(self, db_path: str = "./threat_patterns.db"):
        self.db_path = Path(db_path)
        self.patterns = self._load_patterns()
        self.statistics = {}
    
    def _load_patterns(self) -> Dict[str, List[ThreatPattern]]:
        """Carrega padrões conhecidos"""
        patterns = {
            'spoofing': [
                ThreatPattern(
                    pattern_id='SPF001',
                    stride_category='spoofing',
                    confidence=0.95,
                    components_involved=['API Gateway', 'Authentication Service'],
                    attack_vector='Credential stuffing attack',
                    severity='critical',
                    likelihood='high',
                    indicators=['No MFA', 'Weak password policy', 'No rate limiting'],
                    mitigations=['Implement MFA', 'Strong password requirements', 'Account lockout policy'],
                    references=['OWASP A07:2021', 'CWE-307']
                ),
                ThreatPattern(
                    pattern_id='SPF002',
                    stride_category='spoofing',
                    confidence=0.85,
                    components_involved=['JWT Service', 'API'],
                    attack_vector='Token replay attack',
                    severity='high',
                    likelihood='medium',
                    indicators=['Long token expiration', 'No token rotation', 'Missing jti claim'],
                    mitigations=['Short token lifetime', 'Token rotation', 'Implement jti for one-time use'],
                    references=['RFC 7519', 'OWASP JWT Security']
                )
            ],
            'tampering': [
                ThreatPattern(
                    pattern_id='TMP001',
                    stride_category='tampering',
                    confidence=0.9,
                    components_involved=['Database', 'API'],
                    attack_vector='SQL Injection',
                    severity='critical',
                    likelihood='high',
                    indicators=['Direct SQL queries', 'No input validation', 'String concatenation'],
                    mitigations=['Use prepared statements', 'Input validation', 'Least privilege DB user'],
                    references=['OWASP A03:2021', 'CWE-89']
                )
            ],
            'information_disclosure': [
                ThreatPattern(
                    pattern_id='INF001',
                    stride_category='information_disclosure',
                    confidence=0.88,
                    components_involved=['S3 Bucket', 'CloudFront'],
                    attack_vector='Misconfigured bucket policy',
                    severity='high',
                    likelihood='high',
                    indicators=['Public bucket', 'No encryption', 'Directory listing enabled'],
                    mitigations=['Private bucket policy', 'Enable SSE', 'Disable listing'],
                    references=['AWS S3 Security Best Practices', 'CWE-732']
                )
            ]
        }
        
        # Adicionar mais padrões conforme necessário
        return patterns
    
    def match_patterns(self, architecture: Dict, threshold: float = 0.7) -> List[ThreatPattern]:
        """Busca padrões que correspondem à arquitetura"""
        matched = []
        
        components = {c.get('name', c.get('id', '')).lower() 
                     for c in architecture.get('components', [])}
        
        for category, patterns in self.patterns.items():
            for pattern in patterns:
                # Calcular score de match
                score = self._calculate_match_score(pattern, architecture, components)
                
                if score > threshold:
                    # Ajustar confidence baseado no match
                    adjusted_pattern = ThreatPattern(
                        pattern_id=pattern.pattern_id,
                        stride_category=pattern.stride_category,
                        confidence=pattern.confidence * score,
                        components_involved=pattern.components_involved,
                        attack_vector=pattern.attack_vector,
                        severity=pattern.severity,
                        likelihood=pattern.likelihood,
                        indicators=pattern.indicators,
                        mitigations=pattern.mitigations,
                        references=pattern.references
                    )
                    matched.append(adjusted_pattern)
        
        return matched
    
    def _calculate_match_score(self, pattern: ThreatPattern, 
                              architecture: Dict, components: set) -> float:
        """Calcula score de correspondência"""
        score = 0.0
        weights = {
            'components': 0.4,
            'indicators': 0.3,
            'architecture_type': 0.3
        }
        
        # Match de componentes
        pattern_components = {c.lower() for c in pattern.components_involved}
        component_match = len(pattern_components & components) / max(len(pattern_components), 1)
        score += component_match * weights['components']
        
        # Match de indicadores
        indicators_found = 0
        for indicator in pattern.indicators:
            # Verificação simplificada - em produção seria mais sofisticada
            if self._check_indicator(indicator, architecture):
                indicators_found += 1
        
        indicator_match = indicators_found / max(len(pattern.indicators), 1)
        score += indicator_match * weights['indicators']
        
        # Match de tipo de arquitetura
        arch_type = architecture.get('architecture_analysis', {}).get('type', '')
        if self._is_architecture_vulnerable(arch_type, pattern.stride_category):
            score += weights['architecture_type']
        
        return score
    
    def _check_indicator(self, indicator: str, architecture: Dict) -> bool:
        """Verifica se um indicador está presente"""
        indicator_lower = indicator.lower()
        
        # Verificações específicas
        if 'no mfa' in indicator_lower:
            # Verificar se há componentes de autenticação sem MFA
            for comp in architecture.get('components', []):
                if 'auth' in comp.get('name', '').lower():
                    if not comp.get('configuration', {}).get('mfa_enabled', False):
                        return True
        
        elif 'no encryption' in indicator_lower:
            # Verificar conexões sem criptografia
            for conn in architecture.get('connections', []):
                if conn.get('encryption') in ['None', None]:
                    return True
        
        # Adicionar mais verificações conforme necessário
        return False
    
    def _is_architecture_vulnerable(self, arch_type: str, 
                                   stride_category: str) -> bool:
        """Verifica se tipo de arquitetura é vulnerável à categoria"""
        vulnerabilities = {
            'microservices': ['spoofing', 'tampering', 'denial_of_service'],
            'serverless': ['spoofing', 'information_disclosure', 'denial_of_service'],
            'monolithic': ['tampering', 'elevation_of_privilege'],
            'api_gateway': ['spoofing', 'denial_of_service', 'information_disclosure']
        }
        
        return stride_category in vulnerabilities.get(arch_type, [])
    
    def add_pattern(self, pattern: ThreatPattern):
        """Adiciona novo padrão ao banco"""
        category = pattern.stride_category
        
        if category not in self.patterns:
            self.patterns[category] = []
        
        self.patterns[category].append(pattern)
        
        # Atualizar estatísticas
        self._update_statistics(pattern)
    
    def _update_statistics(self, pattern: ThreatPattern):
        """Atualiza estatísticas do banco"""
        category = pattern.stride_category
        
        if category not in self.statistics:
            self.statistics[category] = {
                'total': 0,
                'severity_distribution': {},
                'common_components': {}
            }
        
        stats = self.statistics[category]
        stats['total'] += 1
        
        # Distribuição de severidade
        severity = pattern.severity
        stats['severity_distribution'][severity] = \
            stats['severity_distribution'].get(severity, 0) + 1
        
        # Componentes comuns
        for comp in pattern.components_involved:
            stats['common_components'][comp] = \
                stats['common_components'].get(comp, 0) + 1
    
    def export_patterns(self, output_path: str):
        """Exporta padrões para arquivo"""
        output = {
            'patterns': {},
            'statistics': self.statistics,
            'metadata': {
                'version': '1.0',
                'timestamp': datetime.now().isoformat(),
                'total_patterns': sum(len(p) for p in self.patterns.values())
            }
        }
        
        # Converter patterns para dict
        for category, patterns in self.patterns.items():
            output['patterns'][category] = [asdict(p) for p in patterns]
        
        with open(output_path, 'w') as f:
            json.dump(output, f, indent=2)
        
        logger.info(f"Padrões exportados para: {output_path}")


class IntegratedThreatDetectionSystem:
    """Sistema integrado de detecção de ameaças"""
    
    def __init__(self):
        self.ml_classifier = STRIDEThreatClassifier()
        self.pattern_db = ThreatPatternDatabase()
        self.deep_analyzer = None  # Inicializado sob demanda
        self.cache = {}
    
    def analyze_threats(self, architecture: Dict, 
                       use_ml: bool = True,
                       use_patterns: bool = True,
                       use_deep: bool = False) -> Dict:
        """Análise completa de ameaças"""
        
        # Verificar cache
        cache_key = self._get_cache_key(architecture)
        if cache_key in self.cache:
            logger.info("Retornando resultado do cache")
            return self.cache[cache_key]
        
        threats = []
        
        # 1. Detecção baseada em padrões
        if use_patterns:
            pattern_threats = self.pattern_db.match_patterns(architecture)
            threats.extend(pattern_threats)
            logger.info(f"Padrões detectados: {len(pattern_threats)}")
        
        # 2. Detecção com ML
        if use_ml:
            try:
                ml_threats = self.ml_classifier.predict(architecture)
                threats.extend(ml_threats)
                logger.info(f"ML detectou: {len(ml_threats)}")
            except Exception as e:
                logger.warning(f"ML falhou: {str(e)}")
        
        # 3. Análise deep learning (se disponível)
        if use_deep and self.deep_analyzer:
            try:
                deep_threats = self._deep_analysis(architecture)
                threats.extend(deep_threats)
                logger.info(f"Deep learning detectou: {len(deep_threats)}")
            except Exception as e:
                logger.warning(f"Deep analysis falhou: {str(e)}")
        
        # Consolidar e deduplicar
        consolidated = self._consolidate_threats(threats)
        
        # Gerar relatório
        report = self._generate_threat_report(consolidated, architecture)
        
        # Cachear resultado
        self.cache[cache_key] = report
        
        return report
    
    def _deep_analysis(self, architecture: Dict) -> List[ThreatPattern]:
        """Análise com deep learning"""
        if not self.deep_analyzer:
            return []
        
        # Extrair features
        features = self.ml_classifier.feature_extractor.extract_features(architecture)
        features_tensor = torch.FloatTensor(features)
        
        # Predição
        with torch.no_grad():
            outputs = self.deep_analyzer(features_tensor)
            probabilities = outputs.numpy()[0]
        
        # Converter para ThreatPatterns
        threats = []
        categories = ['spoofing', 'tampering', 'repudiation',
                     'information_disclosure', 'denial_of_service',
                     'elevation_of_privilege']
        
        for i, prob in enumerate(probabilities):
            if prob > 0.3:  # Threshold
                threat = ThreatPattern(
                    pattern_id=f"DL_{categories[i]}_{datetime.now().timestamp()}",
                    stride_category=categories[i],
                    confidence=float(prob),
                    components_involved=[],
                    attack_vector=f"Deep learning detected {categories[i]} pattern",
                    severity='high' if prob > 0.7 else 'medium',
                    likelihood='high' if prob > 0.6 else 'medium',
                    indicators=[],
                    mitigations=[],
                    references=[]
                )
                threats.append(threat)
        
        return threats
    
    def _consolidate_threats(self, threats: List[ThreatPattern]) -> List[ThreatPattern]:
        """Consolida e deduplica ameaças"""
        consolidated = {}
        
        for threat in threats:
            # Criar chave única baseada em categoria e componentes
            key = f"{threat.stride_category}_{','.join(sorted(threat.components_involved))}"
            
            if key not in consolidated:
                consolidated[key] = threat
            else:
                # Mesclar informações
                existing = consolidated[key]
                
                # Usar maior confidence
                if threat.confidence > existing.confidence:
                    existing.confidence = threat.confidence
                
                # Combinar indicadores e mitigações
                existing.indicators = list(set(existing.indicators + threat.indicators))
                existing.mitigations = list(set(existing.mitigations + threat.mitigations))
                existing.references = list(set(existing.references + threat.references))
        
        return list(consolidated.values())
    
    def _generate_threat_report(self, threats: List[ThreatPattern], 
                               architecture: Dict) -> Dict:
        """Gera relatório completo de ameaças"""
        
        # Estatísticas
        severity_count = {}
        category_count = {}
        
        for threat in threats:
            severity_count[threat.severity] = severity_count.get(threat.severity, 0) + 1
            category_count[threat.stride_category] = category_count.get(threat.stride_category, 0) + 1
        
        # Calcular risk score
        risk_score = self._calculate_overall_risk(threats)
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'analysis_method': 'Integrated ML + Pattern Matching',
            'total_threats': len(threats),
            'risk_score': risk_score,
            'risk_level': self._get_risk_level(risk_score),
            'threats': [asdict(t) for t in threats],
            'statistics': {
                'by_severity': severity_count,
                'by_category': category_count,
                'average_confidence': np.mean([t.confidence for t in threats]) if threats else 0
            },
            'top_risks': self._identify_top_risks(threats),
            'recommendations': self._generate_recommendations(threats, architecture),
            'compliance_impact': self._assess_compliance_impact(threats)
        }
        
        return report
    
    def _calculate_overall_risk(self, threats: List[ThreatPattern]) -> float:
        """Calcula risk score geral"""
        if not threats:
            return 0.0
        
        severity_scores = {
            'critical': 10,
            'high': 7,
            'medium': 4,
            'low': 1
        }
        
        total_score = 0
        for threat in threats:
            severity = threat.severity
            confidence = threat.confidence
            
            score = severity_scores.get(severity, 4) * confidence
            total_score += score
        
        # Normalizar para escala 0-10
        max_possible = len(threats) * 10
        normalized = min(10, (total_score / max_possible) * 10) if max_possible > 0 else 0
        
        return round(normalized, 1)
    
    def _get_risk_level(self, risk_score: float) -> str:
        """Determina nível de risco"""
        if risk_score >= 8:
            return 'CRITICAL'
        elif risk_score >= 6:
            return 'HIGH'
        elif risk_score >= 4:
            return 'MEDIUM'
        elif risk_score >= 2:
            return 'LOW'
        else:
            return 'MINIMAL'
    
    def _identify_top_risks(self, threats: List[ThreatPattern]) -> List[Dict]:
        """Identifica principais riscos"""
        # Ordenar por severity e confidence
        sorted_threats = sorted(
            threats,
            key=lambda t: (
                {'critical': 4, 'high': 3, 'medium': 2, 'low': 1}[t.severity],
                t.confidence
            ),
            reverse=True
        )
        
        top_risks = []
        for threat in sorted_threats[:5]:
            top_risks.append({
                'category': threat.stride_category,
                'severity': threat.severity,
                'confidence': threat.confidence,
                'description': threat.attack_vector,
                'affected_components': threat.components_involved,
                'primary_mitigation': threat.mitigations[0] if threat.mitigations else 'Review security controls'
            })
        
        return top_risks
    
    def _generate_recommendations(self, threats: List[ThreatPattern], 
                                 architecture: Dict) -> Dict:
        """Gera recomendações baseadas nas ameaças"""
        recommendations = {
            'immediate': [],
            'short_term': [],
            'long_term': []
        }
        
        # Priorizar por severidade
        critical_threats = [t for t in threats if t.severity == 'critical']
        high_threats = [t for t in threats if t.severity == 'high']
        medium_threats = [t for t in threats if t.severity == 'medium']
        
        # Immediate actions (critical threats)
        for threat in critical_threats[:3]:
            for mitigation in threat.mitigations[:2]:
                recommendations['immediate'].append({
                    'action': mitigation,
                    'reason': f"Mitigate {threat.stride_category} threat",
                    'components': threat.components_involved,
                    'priority': 'CRITICAL'
                })
        
        # Short term (high threats)
        for threat in high_threats[:3]:
            for mitigation in threat.mitigations[:1]:
                recommendations['short_term'].append({
                    'action': mitigation,
                    'reason': f"Address {threat.stride_category} vulnerability",
                    'components': threat.components_involved,
                    'priority': 'HIGH'
                })
        
        # Long term (medium threats and architectural improvements)
        for threat in medium_threats[:2]:
            for mitigation in threat.mitigations[:1]:
                recommendations['long_term'].append({
                    'action': mitigation,
                    'reason': f"Improve {threat.stride_category} controls",
                    'components': threat.components_involved,
                    'priority': 'MEDIUM'
                })
        
        return recommendations
    
    def _assess_compliance_impact(self, threats: List[ThreatPattern]) -> Dict:
        """Avalia impacto em compliance"""
        compliance_mapping = {
            'spoofing': ['SOC2 CC6.1', 'ISO 27001 A.9', 'GDPR Article 32'],
            'tampering': ['SOC2 CC6.6', 'ISO 27001 A.12', 'PCI DSS 10.2'],
            'repudiation': ['SOC2 CC7.2', 'ISO 27001 A.12.4', 'HIPAA §164.312(b)'],
            'information_disclosure': ['GDPR Article 32-34', 'HIPAA §164.312(a)', 'PCI DSS 3.4'],
            'denial_of_service': ['SOC2 A1.2', 'ISO 27001 A.17', 'NIST 800-53 CP'],
            'elevation_of_privilege': ['SOC2 CC6.3', 'ISO 27001 A.9.2', 'PCI DSS 7']
        }
        
        affected_controls = set()
        
        for threat in threats:
            controls = compliance_mapping.get(threat.stride_category, [])
            affected_controls.update(controls)
        
        return {
            'affected_frameworks': list(set(c.split()[0] for c in affected_controls)),
            'affected_controls': list(affected_controls),
            'compliance_risk': 'HIGH' if len(affected_controls) > 5 else 'MEDIUM' if len(affected_controls) > 2 else 'LOW'
        }
    
    def _get_cache_key(self, architecture: Dict) -> str:
        """Gera chave de cache"""
        # Usar hash dos componentes principais
        components = sorted([c.get('name', '') for c in architecture.get('components', [])])
        key_data = f"{','.join(components)}_{len(architecture.get('connections', []))}"
        
        import hashlib
        return hashlib.md5(key_data.encode()).hexdigest()
    
    def train_models(self, training_data: List[Tuple[Dict, Dict]]):
        """Treina modelos ML com dados de treinamento"""
        self.ml_classifier.train(training_data)
        
        # Atualizar padrões no banco baseado no treinamento
        for architecture, threats in training_data:
            for threat_data in threats.get('stride_threats', []):
                pattern = ThreatPattern(
                    pattern_id=f"TRAIN_{datetime.now().timestamp()}",
                    stride_category=threat_data.get('category', '').lower().replace(' ', '_'),
                    confidence=0.8,
                    components_involved=threat_data.get('components', []),
                    attack_vector=threat_data.get('description', ''),
                    severity=threat_data.get('severity', 'medium'),
                    likelihood=threat_data.get('likelihood', 'medium'),
                    indicators=threat_data.get('indicators', []),
                    mitigations=threat_data.get('mitigations', []),
                    references=threat_data.get('references', [])
                )
                self.pattern_db.add_pattern(pattern)


# Exemplo de uso
if __name__ == "__main__":
    # Criar sistema integrado
    threat_system = IntegratedThreatDetectionSystem()
    
    # Arquitetura de exemplo
    test_architecture = {
        'components': [
            {'name': 'API Gateway', 'type': 'networking', 'provider': 'AWS'},
            {'name': 'Lambda', 'type': 'compute', 'provider': 'AWS'},
            {'name': 'DynamoDB', 'type': 'database', 'provider': 'AWS'},
            {'name': 'S3', 'type': 'storage', 'provider': 'AWS', 'security_posture': 'exposed'}
        ],
        'connections': [
            {'source': 'API Gateway', 'target': 'Lambda', 'encryption': 'TLS'},
            {'source': 'Lambda', 'target': 'DynamoDB', 'encryption': 'None'},
            {'source': 'Lambda', 'target': 'S3', 'encryption': 'TLS'}
        ]
    }
    
    # Analisar ameaças
    report = threat_system.analyze_threats(
        test_architecture,
        use_ml=True,
        use_patterns=True,
        use_deep=False
    )
    
    # Exibir resultados
    print(f"\n=== Threat Analysis Report ===")
    print(f"Risk Score: {report['risk_score']}/10 ({report['risk_level']})")
    print(f"Total Threats: {report['total_threats']}")
    print(f"\nTop Risks:")
    for risk in report['top_risks']:
        print(f"  - [{risk['severity'].upper()}] {risk['category']}: {risk['description']}")
    print(f"\nImmediate Actions:")
    for rec in report['recommendations']['immediate']:
        print(f"  - {rec['action']}")
    
    # Salvar relatório
    with open("threat_analysis_report.json", "w") as f:
        json.dump(report, f, indent=2)