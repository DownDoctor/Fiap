
"""
openai_bridge.py — compat layer for OpenAI SDKs (chat.completions & responses)
- Avoids passing unsupported kwargs like `response_format` to Responses API
- Falls back to Chat Completions if Responses API isn't available
- Provides simple helpers used by the STRIDE app
"""

from typing import Tuple, Dict, Any, Optional
import os, json, time

try:
    from openai import OpenAI
except Exception as e:
    OpenAI = None

# ---------------------------- internal utils ----------------------------

def _mk_client():
    if OpenAI is None:
        raise RuntimeError("Pacote 'openai' não encontrado. Instale com `pip install openai`.")
    api_key = os.getenv("OPENAI_API_KEY")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY ausente no ambiente.")
    return OpenAI()

def _responses_create_compat(client, **kwargs):
    """
    Chama client.responses.create(**kwargs) removendo argumentos não suportados
    (ex.: 'response_format') quando o SDK é antigo.
    """
    try:
        return client.responses.create(**kwargs)
    except TypeError as e:
        # Se a SDK não aceitar response_format, remova e tente de novo
        if "response_format" in str(e):
            kwargs.pop("response_format", None)
            return client.responses.create(**kwargs)
        raise

def _call_responses_json(prompt: str, model: str, temperature: float, max_output_tokens: int, schema: Optional[Dict]=None):
    """
    Tenta usar Responses API (nova). Se schema existir e for suportado, passa json_schema.
    Caso a SDK não aceite, a _responses_create_compat remove e segue.
    Retorna (text, meta_dict).
    """
    client = _mk_client()

    args = {
        "model": model,
        "input": prompt,
        "temperature": float(temperature) if temperature is not None else 0.0,
    }
    if max_output_tokens:
        args["max_output_tokens"] = int(max_output_tokens)

    # json_schema é opcional; SDKs antigas podem não suportar
    if schema:
        args["response_format"] = {
            "type": "json_schema",
            "json_schema": {
                "name": "Output",
                "schema": schema,
                "strict": True
            }
        }

    start = time.time()
    resp = _responses_create_compat(client, **args)
    elapsed = time.time() - start

    # Extração de texto compat
    text = None
    response_id = getattr(resp, "id", None)
    model_used = getattr(resp, "model", model)
    try:
        # SDK nova: resp.output_text
        text = getattr(resp, "output_text", None)
    except Exception:
        text = None
    if not text:
        # fallback: tentar achar texto em estruturas conhecidas
        try:
            # ex.: resp.output[0].content[0].text
            output = getattr(resp, "output", None)
            if output and isinstance(output, list) and output and hasattr(output[0], "content"):
                c0 = output[0].content
                if c0 and isinstance(c0, list):
                    maybe = getattr(c0[0], "text", None) or getattr(c0[0], "content", None)
                    if maybe:
                        text = maybe
        except Exception:
            pass

    if not text:
        # último recurso: converter resp em string
        text = str(resp)

    meta = {
        "model": model_used,
        "response_id": response_id,
        "elapsed": elapsed,
        "api": "responses",
    }
    return text, meta

def _call_chat_json(prompt: str, model: str, temperature: float, max_output_tokens: int, force_json: bool):
    """
    Usa Chat Completions como fallback. Se force_json=True, pede JSON puro com response_format=json_object quando suportado.
    Retorna (text, meta_dict).
    """
    client = _mk_client()
    msgs = [
        {"role": "system", "content": "Você é um assistente técnico. Responda em português. Se for requisitado JSON, devolva apenas JSON puro."},
        {"role": "user", "content": prompt},
    ]
    kwargs = {
        "model": model,
        "messages": msgs,
        "temperature": float(temperature) if temperature is not None else 0.0,
    }
    if max_output_tokens:
        kwargs["max_tokens"] = int(max_output_tokens)

    # Alguns SDKs aceitam response_format={"type":"json_object"}
    if force_json:
        try:
            kwargs["response_format"] = {"type": "json_object"}
        except Exception:
            pass

    start = time.time()
    resp = client.chat.completions.create(**kwargs)
    elapsed = time.time() - start

    text = resp.choices[0].message.content if resp and resp.choices else ""
    meta = {
        "model": getattr(resp, "model", model),
        "response_id": getattr(resp, "id", None),
        "elapsed": elapsed,
        "api": "chat.completions",
        "input_tokens": getattr(getattr(resp, "usage", None), "prompt_tokens", None) or (getattr(resp, "usage", {}) or {}).get("prompt_tokens"),
        "output_tokens": getattr(getattr(resp, "usage", None), "completion_tokens", None) or (getattr(resp, "usage", {}) or {}).get("completion_tokens"),
    }
    return text, meta

def _force_json_parse(text: str) -> Any:
    try:
        return json.loads(text)
    except Exception:
        # tentar extrair bloco JSON se vier texto + JSON
        import re
        m = re.search(r"\{.*\}", text, re.DOTALL)
        if m:
            try:
                return json.loads(m.group(0))
            except Exception:
                pass
        return {"raw_text": text}

# ---------------------------- public helpers ----------------------------

def summarize_report_with_llm(report: Dict[str, Any],
                              model: str = "gpt-4o-mini",
                              temperature: float = 0.2,
                              max_output_tokens: int = 600):
    """
    Produz um resumo executivo (curto e objetivo) do relatório STRIDE (não JSON).
    Sempre evita `response_format` na Responses API para compatibilidade.
    """
    prompt = (
        "Faça um resumo executivo (curto e objetivo) deste relatório STRIDE. "
        "Realce Cloud principal, riscos mais críticos e próximas ações em bullet points.\n\n"
        f"RELATÓRIO:\n{json.dumps(report, ensure_ascii=False)}"
    )
    # 1) Tenta Responses (sem response_format)
    try:
        text, meta = _call_responses_json(prompt, model, temperature, max_output_tokens, schema=None)
        return text, meta
    except Exception:
        # 2) Fallback Chat
        text, meta = _call_chat_json(prompt, model, temperature, max_output_tokens, force_json=False)
        return text, meta

def draft_stride_threats_with_llm(context: Dict[str, Any],
                                  model: str = "gpt-4o-mini",
                                  temperature: float = 0.2,
                                  max_output_tokens: int = 1500):
    """
    Produz um rascunho JSON com ameaças STRIDE (apenas JSON puro).
    NÃO exige response_format; quando disponível, usamos json_schema, senão instruímos no prompt.
    """
    # Schema básico para orientar output (não obrigatório)
    schema = {
        "type": "object",
        "properties": {
            "top_threats": {"type": "array", "items": {"type": "object"}},
            "statistics": {"type": "object"},
            "recommendations": {"type": "array", "items": {"type": "object"}}
        },
        "required": ["top_threats"],
        "additionalProperties": True,
    }
    prompt = (
        "Gere um JSON com rascunho de ameaças STRIDE a partir do contexto fornecido. "
        "Retorne APENAS JSON válido, sem explicações.\n\n"
        f"CONTEXTO:\n{json.dumps(context, ensure_ascii=False)}"
    )

    # 1) Tenta Responses com schema (compat removerá se não suportar)
    try:
        text, meta = _call_responses_json(prompt, model, temperature, max_output_tokens, schema=schema)
        data = _force_json_parse(text)
        return data, meta
    except Exception:
        # 2) Fallback Chat pedindo JSON
        text, meta = _call_chat_json("Retorne apenas JSON.\n" + prompt, model, temperature, max_output_tokens, force_json=True)
        data = _force_json_parse(text)
        return data, meta

def extract_architecture_entities_with_llm(context: Dict[str, Any],
                                           model: str = "gpt-4o-mini",
                                           temperature: float = 0.2,
                                           max_output_tokens: int = 1500):
    """
    Extração opcional de entidades/relacionamentos da arquitetura via LLM (JSON).
    """
    schema = {
        "type": "object",
        "properties": {
            "components": {"type": "array", "items": {"type": "object"}},
            "connections": {"type": "array", "items": {"type": "object"}}
        },
        "required": ["components"],
        "additionalProperties": True,
    }
    prompt = (
        "A partir do contexto, extraia componentes e conexões da arquitetura como JSON. "
        "Retorne APENAS JSON válido, sem explicações.\n\n"
        f"CONTEXTO:\n{json.dumps(context, ensure_ascii=False)}"
    )
    try:
        text, meta = _call_responses_json(prompt, model, temperature, max_output_tokens, schema=schema)
        data = _force_json_parse(text)
        return data, meta
    except Exception:
        text, meta = _call_chat_json("Retorne apenas JSON.\n" + prompt, model, temperature, max_output_tokens, force_json=True)
        data = _force_json_parse(text)
        return data, meta
