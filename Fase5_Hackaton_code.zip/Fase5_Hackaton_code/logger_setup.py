# logger_setup.py
"""
Sistema de logging configurável para STRIDE Analyzer Enhanced
"""

import logging
import sys
from pathlib import Path
from logging.handlers import RotatingFileHandler
from typing import Optional
from datetime import datetime

from config import config

def setup_logger(name: str = 'stride_analyzer', 
                level: Optional[str] = None,
                log_file: Optional[str] = None) -> logging.Logger:
    """
    Configura sistema de logging com rotação de arquivos
    
    Args:
        name: Nome do logger
        level: Nível de log (DEBUG, INFO, WARNING, ERROR, CRITICAL)
        log_file: Caminho para arquivo de log (opcional)
    
    Returns:
        Logger configurado
    """
    
    # Configuração de nível
    log_level = level or config.LOG_LEVEL
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)
    
    # Criar logger
    logger = logging.getLogger(name)
    logger.setLevel(numeric_level)
    
    # Evitar duplicação de handlers
    if logger.handlers:
        return logger
    
    # Formatter personalizado
    formatter = logging.Formatter(
        '%(asctime)s | %(name)s | %(levelname)-8s | %(funcName)s:%(lineno)d | %(message)s',
        datefmt='%Y-%m-%d %H:%M:%S'
    )
    
    # Console handler (se habilitado)
    if config.ENABLE_CONSOLE_LOGGING:
        console_handler = logging.StreamHandler(sys.stdout)
        console_handler.setLevel(numeric_level)
        console_handler.setFormatter(formatter)
        logger.addHandler(console_handler)
    
    # File handler com rotação
    log_file_path = log_file or config.LOG_FILE
    if log_file_path:
        # Criar diretório se não existir
        Path(log_file_path).parent.mkdir(parents=True, exist_ok=True)
        
        file_handler = RotatingFileHandler(
            filename=log_file_path,
            maxBytes=config.LOG_MAX_SIZE_MB * 1024 * 1024,  # MB to bytes
            backupCount=config.LOG_BACKUP_COUNT,
            encoding='utf-8'
        )
        file_handler.setLevel(numeric_level)
        file_handler.setFormatter(formatter)
        logger.addHandler(file_handler)
    
    return logger

def log_system_info(logger: logging.Logger):
    """Log informações do sistema na inicialização"""
    
    logger.info("=" * 60)
    logger.info("🚀 STRIDE Analyzer Enhanced - System Starting")
    logger.info("=" * 60)
    
    # Informações de configuração
    config_summary = config.get_config_summary()
    for key, value in config_summary.items():
        logger.info(f"Config | {key}: {value}")
    
    # Informações de dependências
    try:
        import streamlit
        logger.info(f"Streamlit version: {streamlit.__version__}")
    except ImportError:
        logger.warning("Streamlit not available")
    
    try:
        import openai
        logger.info(f"OpenAI version: {openai.__version__}")
        logger.info(f"OpenAI configured: {config.openai_available}")
    except ImportError:
        logger.warning("OpenAI not available")
    
    try:
        import ultralytics
        logger.info(f"YOLO available: {config.yolo_available}")
    except ImportError:
        logger.info("YOLO not available (optional)")
    
    try:
        import chromadb
        logger.info("Advanced RAG: ChromaDB available")
    except ImportError:
        logger.info("Advanced RAG: Using simple vector DB")
    
    logger.info("System initialization completed")
    logger.info("=" * 60)

def log_analysis_start(logger: logging.Logger, image_path: str, analysis_id: str):
    """Log início de análise"""
    logger.info(f"📊 Analysis started: {analysis_id}")
    logger.info(f"   Image: {Path(image_path).name}")
    logger.info(f"   Timestamp: {datetime.now().isoformat()}")

def log_analysis_complete(logger: logging.Logger, analysis_id: str, 
                         duration: float, success: bool, 
                         components_count: int = 0, threats_count: int = 0):
    """Log conclusão de análise"""
    status = "✅ SUCCESS" if success else "❌ FAILED"
    logger.info(f"📊 Analysis completed: {analysis_id} | {status}")
    logger.info(f"   Duration: {duration:.2f}s")
    if success:
        logger.info(f"   Components: {components_count}")
        logger.info(f"   Threats: {threats_count}")

def log_chat_interaction(logger: logging.Logger, query: str, 
                        response_length: int, has_analysis: bool):
    """Log interação do chat"""
    logger.info(f"💬 Chat interaction")
    logger.info(f"   Query: {query[:100]}{'...' if len(query) > 100 else ''}")
    logger.info(f"   Response length: {response_length} chars")
    logger.info(f"   Has analysis context: {has_analysis}")

def log_error(logger: logging.Logger, error: Exception, context: str = ""):
    """Log erro com contexto"""
    logger.error(f"❌ Error in {context}: {type(error).__name__}: {str(error)}")
    logger.debug("Exception details:", exc_info=True)

# Logger global para uso em todo o sistema
main_logger = setup_logger('stride_analyzer')