#!/usr/bin/env python3
"""
HTML Report Generator for STRIDE Analysis
Gera relatórios HTML elegantes e profissionais para análise STRIDE
"""

import json
import os
from datetime import datetime
from typing import Dict, List
from pathlib import Path

class STRIDEHTMLReportGenerator:
    """Gerador de relatórios HTML para análise STRIDE"""
    
    def _create_cloud_stamp(self) -> str:
        """Renderiza um 'stamp' de Cloud (primária / multicloud) logo abaixo do cabeçalho."""
        cs = getattr(self, "_cloud_summary", {}) or {}
        label = cs.get("label") or "Cloud: Desconhecida"
        providers = cs.get("providers") or {}
        if not isinstance(providers, dict):
            providers = {}

        # badges por provedor detectado
        badges = []
        for name in ["aws", "azure", "gcp", "kubernetes"]:
            count = providers.get(name) or providers.get(name.upper())
            if count:
                badges.append(f'<span class="badge-cloud {name}">{name.upper()} <span class="badge-count">{count}</span></span>')

        # if nothing matched, show generic
        if not badges and providers:
            for k, v in providers.items():
                badges.append(f'<span class="badge-cloud generic">{str(k).upper()} <span class="badge-count">{v}</span></span>')

        badges_html = " ".join(badges) if badges else '<span class="badge-cloud generic">N/D</span>'

        return f"""
        <div class="cloud-stamp">
            <div class="cloud-stamp-label">☁️ {label}</div>
            <div class="cloud-stamp-badges">{badges_html}</div>
        </div>
        """

    def _set_cloud_context(self, report: Dict):
        """Stores cloud context for reference resolution."""
        self._cloud_summary = report.get('cloud_summary', {}) if isinstance(report, dict) else {}
        self._primary_provider = (self._cloud_summary.get('primary') or "").lower()

    def _reference_links_for(self, item: Dict) -> list[tuple[str, str]]:
        """Return a list of (label, url) official references for a threat or recommendation card."""
        if not isinstance(item, dict):
            return []
        t = str(item.get('threat_type', '')).lower()
        comp = str(item.get('component', '')).lower()
        desc = " ".join([str(item.get('description','')), str(item.get('recommendation',''))]).lower()

        refs = []

        # General STRIDE references (Microsoft)
        stride_refs = {
            'spoofing': [('Microsoft STRIDE – Spoofing', 'https://learn.microsoft.com/azure/security/develop/threat-modeling-tool-threats#spoofing')],
            'tampering': [('Microsoft STRIDE – Tampering', 'https://learn.microsoft.com/azure/security/develop/threat-modeling-tool-threats#tampering')],
            'repudiation': [('Microsoft STRIDE – Repudiation', 'https://learn.microsoft.com/azure/security/develop/threat-modeling-tool-threats#repudiation')],
            'information_disclosure': [('Microsoft STRIDE – Information Disclosure', 'https://learn.microsoft.com/azure/security/develop/threat-modeling-tool-threats#information-disclosure')],
            'denial_of_service': [('Microsoft STRIDE – Denial of Service', 'https://learn.microsoft.com/azure/security/develop/threat-modeling-tool-threats#denial-of-service')],
            'elevation_of_privilege': [('Microsoft STRIDE – Elevation of Privilege', 'https://learn.microsoft.com/azure/security/develop/threat-modeling-tool-threats#elevation-of-privilege')],
        }
        for key, links in stride_refs.items():
            if key == t:
                refs.extend(links)

        # OWASP cheat sheets
        owasp_refs = []
        if any(k in desc or k in comp for k in ['auth', 'login', 'spoof']):
            owasp_refs.append(('OWASP Authentication Cheat Sheet', 'https://cheatsheetseries.owasp.org/cheatsheets/Authentication_Cheat_Sheet.html'))
        if any(k in desc or k in comp for k in ['authoriz', 'rbac', 'abac', 'permission']):
            owasp_refs.append(('OWASP Authorization Cheat Sheet', 'https://cheatsheetseries.owasp.org/cheatsheets/Authorization_Cheat_Sheet.html'))
        if any(k in desc or k in comp for k in ['tls', 'https', 'in transit', 'mti', 'ssl']):
            owasp_refs.append(('OWASP Transport Layer Protection', 'https://cheatsheetseries.owasp.org/cheatsheets/Transport_Layer_Protection_Cheat_Sheet.html'))
        if any(k in desc or k in comp for k in ['encrypt', 'kms', 'key', 'secret']):
            owasp_refs.append(('OWASP Cryptographic Storage', 'https://cheatsheetseries.owasp.org/cheatsheets/Cryptographic_Storage_Cheat_Sheet.html'))
            owasp_refs.append(('OWASP Secrets Management', 'https://cheatsheetseries.owasp.org/cheatsheets/Secret_Management_Cheat_Sheet.html'))
        if any(k in desc or k in comp for k in ['input', 'validation', 'sanitize', 'xss', 'sql']):
            owasp_refs.append(('OWASP Input Validation', 'https://cheatsheetseries.owasp.org/cheatsheets/Input_Validation_Cheat_Sheet.html'))
        if any(k in desc or k in comp for k in ['log', 'audit', 'repudiation']):
            owasp_refs.append(('OWASP Logging', 'https://cheatsheetseries.owasp.org/cheatsheets/Logging_Cheat_Sheet.html'))
        refs.extend(owasp_refs)

        prov = getattr(self, "_primary_provider", "")
        # Provider-specific links
        if prov == 'aws':
            if any(k in comp or k in desc for k in ['waf', 'cloudfront']):
                refs.append(('AWS WAF', 'https://docs.aws.amazon.com/waf/latest/developerguide/what-is-aws-waf.html'))
            if 'alb' in comp or 'load balancer' in comp or 'elb' in comp or 'https' in desc:
                refs.append(('ALB HTTPS', 'https://docs.aws.amazon.com/elasticloadbalancing/latest/application/create-https-listener.html'))
            if 's3' in comp or 'storage' in desc:
                refs.append(('S3 – Server-Side Encryption', 'https://docs.aws.amazon.com/AmazonS3/latest/userguide/UsingServerSideEncryption.html'))
            if 'rds' in comp or 'database' in desc:
                refs.append(('RDS – Encryption at Rest', 'https://docs.aws.amazon.com/AmazonRDS/latest/UserGuide/Overview.Encryption.html'))
            if 'vpc' in comp or 'security group' in desc or 'nacl' in desc:
                refs.append(('VPC Security', 'https://docs.aws.amazon.com/vpc/latest/userguide/vpc-security.html'))
            if 'iam' in comp or 'permission' in desc or 'role' in desc:
                refs.append(('IAM Best Practices', 'https://docs.aws.amazon.com/IAM/latest/UserGuide/best-practices.html'))
            if 'kms' in comp or 'key' in desc:
                refs.append(('AWS KMS', 'https://docs.aws.amazon.com/kms/latest/developerguide/overview.html'))
            if 'secret' in comp or 'secrets manager' in desc:
                refs.append(('AWS Secrets Manager', 'https://docs.aws.amazon.com/secretsmanager/latest/userguide/intro.html'))
            refs.append(('AWS Well-Architected – Security', 'https://docs.aws.amazon.com/wellarchitected/latest/security-pillar/welcome.html'))
        elif prov == 'azure':
            if 'waf' in comp or 'front door' in comp or 'application gateway' in comp:
                refs.append(('Azure WAF (App Gateway)', 'https://learn.microsoft.com/azure/web-application-firewall/ag/ag-overview'))
                refs.append(('Azure Front Door WAF', 'https://learn.microsoft.com/azure/web-application-firewall/afds/afds-overview'))
            if 'storage' in comp or 'blob' in comp or 'encryption' in desc:
                refs.append(('Azure Storage Encryption', 'https://learn.microsoft.com/azure/storage/common/storage-service-encryption'))
            if 'sql' in comp or 'database' in desc:
                refs.append(('Azure SQL – TDE', 'https://learn.microsoft.com/azure/azure-sql/database/transparent-data-encryption-tde-overview'))
            if 'vnet' in comp or 'nsg' in desc or 'firewall' in desc:
                refs.append(('Azure Virtual Network Security', 'https://learn.microsoft.com/azure/virtual-network/'))
            if 'rbac' in desc or 'role' in desc or 'aad' in comp or 'entra' in comp:
                refs.append(('Azure RBAC Best Practices', 'https://learn.microsoft.com/azure/role-based-access-control/best-practices'))
            if 'key vault' in comp or 'secret' in desc:
                refs.append(('Azure Key Vault', 'https://learn.microsoft.com/azure/key-vault/general/overview'))
            refs.append(('Azure Well-Architected – Security', 'https://learn.microsoft.com/azure/well-architected/security/'))
        elif prov == 'gcp':
            if 'armor' in comp or 'waf' in comp:
                refs.append(('Cloud Armor', 'https://cloud.google.com/armor/docs'))
            if 'load' in comp or 'https' in desc:
                refs.append(('HTTPS Load Balancing', 'https://cloud.google.com/load-balancing/docs/https'))
            if 'storage' in comp or 'bucket' in comp:
                refs.append(('Cloud Storage Encryption', 'https://cloud.google.com/storage/docs/encryption'))
            if 'sql' in comp or 'spanner' in comp or 'database' in desc:
                refs.append(('Cloud SQL Security', 'https://cloud.google.com/sql/docs/security'))
            if 'vpc' in comp or 'firewall' in desc:
                refs.append(('VPC Firewalls', 'https://cloud.google.com/vpc/docs/firewalls'))
            if 'iam' in comp or 'role' in desc or 'permission' in desc:
                refs.append(('IAM Best Practices', 'https://cloud.google.com/iam/docs/using-iam-securely'))
            if 'kms' in comp or 'key' in desc:
                refs.append(('Cloud KMS', 'https://cloud.google.com/kms/docs'))
            refs.append(('Google Cloud Security Foundations', 'https://cloud.google.com/architecture/security-foundations'))
        else:
            # Unknown provider: add general references
            refs.append(('STRIDE Threats (Microsoft)', 'https://learn.microsoft.com/azure/security/develop/threat-modeling-tool-threats'))
            refs.append(('OWASP Proactive Controls', 'https://owasp.org/www-project-proactive-controls/'))
            refs.append(('OWASP ASVS', 'https://owasp.org/www-project-application-security-verification-standard/'))

        # Deduplicate by URL preserving order
        seen = set()
        out = []
        for label, url in refs:
            if url not in seen:
                out.append((label, url))
                seen.add(url)

        return out

    def _refs_html(self, item: Dict, max_links: int = 3) -> str:
        """Return a small HTML snippet with reference links for the given item."""
        links = self._reference_links_for(item)[:max_links]
        if not links:
            return ""
        tags = " ".join([f'<a class="ref-link" href="{u}" target="_blank" rel="noopener">{label}</a>' for label, u in links])
        return f'<div class="refs">🔗 {tags}</div>'

    def __init__(self):
        self.template_dir = Path(__file__).parent / "templates"
        self.assets_dir = Path(__file__).parent / "assets"
        
    def generate_html_report(self, json_report: Dict, output_path: str = None) -> str:
        """
        Gera relatório HTML completo a partir do JSON da análise STRIDE
        """
        if output_path is None:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = f"stride_report_{timestamp}.html"
        
        # Gerar HTML completo
        html_content = self._create_full_html_report(json_report)
        
        # Salvar arquivo
        with open(output_path, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        print(f"✅ Relatório HTML gerado: {output_path}")
        return output_path
    
    def _create_full_html_report(self, report: Dict) -> str:
        """Cria o HTML completo do relatório"""
        
        # Contexto de cloud para resolver referências
        self._set_cloud_context(report)

        # Extrair dados principais
        arch_analysis = report.get('architecture_analysis', {})
        stride_analysis = report.get('stride_analysis', {})
        risk_assessment = report.get('risk_assessment', {})
        threats = report.get('detailed_threats', [])
        
        html = f"""
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório STRIDE Security Analysis</title>
    {self._get_css_styles()}
    {self._get_javascript()}
</head>
<body>
    <div class="container">
        {self._create_header(report)}
        {self._create_cloud_stamp()}
        {self._create_executive_summary(arch_analysis, risk_assessment)}
        {self._create_stride_dashboard(stride_analysis)}
        {self._create_threat_matrix(threats)}
        {self._create_risk_assessment_section(risk_assessment)}
        {self._create_attack_paths_section(report.get('attack_surface_analysis', {}))}
        {self._create_compliance_section(report.get('compliance_impact', {}))}
        {self._create_recommendations_section(report.get('recommendations', {}))}
        {self._create_implementation_roadmap(report.get('mitigation_analysis', {}))}
        {self._create_detailed_threats_table(threats)}
        {self._create_footer()}
    </div>
    
    <script>
        {self._get_interactive_scripts()}
    </script>
</body>
</html>
        """
        
        return html
    
    def _get_css_styles(self) -> str:
        """Retorna estilos CSS modernos e responsivos"""
        return """
<style>
    * {
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }
    
    body {
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        line-height: 1.6;
        color: #333;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
    }
    
    .container {
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
        background: white;
        box-shadow: 0 0 20px rgba(0,0,0,0.1);
        border-radius: 10px;
        margin-top: 20px;
        margin-bottom: 20px;
    }
    
    .header {
        text-align: center;
        padding: 30px 0;
        background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        color: white;
        border-radius: 10px;
        margin-bottom: 30px;
    }
    
    .header h1 {
        font-size: 2.5em;
        margin-bottom: 10px;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }
    
    .header .subtitle {
        font-size: 1.2em;
        opacity: 0.9;
    }
    
    .section {
        margin-bottom: 40px;
        padding: 25px;
        background: #f8f9fa;
        border-radius: 10px;
        border-left: 5px solid #007bff;
    }
    
    .section h2 {
        color: #2c3e50;
        margin-bottom: 20px;
        font-size: 1.8em;
        display: flex;
        align-items: center;
    }
    
    .section h2::before {
        content: "🔒";
        margin-right: 10px;
        font-size: 1.2em;
    }
    
    .dashboard {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }
    
    .metric-card {
        background: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        text-align: center;
        transition: transform 0.3s ease;
        border-top: 4px solid #007bff;
    }
    
    .metric-card:hover {
        transform: translateY(-5px);
    }
    
    .metric-card h3 {
        color: #6c757d;
        font-size: 0.9em;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 10px;
    }
    
    .metric-value {
        font-size: 2.5em;
        font-weight: bold;
        color: #2c3e50;
        margin-bottom: 5px;
    }
    
    .metric-description {
        color: #6c757d;
        font-size: 0.9em;
    }
    
    .critical { border-top-color: #dc3545; }
    .high { border-top-color: #fd7e14; }
    .medium { border-top-color: #ffc107; }
    .low { border-top-color: #28a745; }
    
    .threat-matrix {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
        margin: 20px 0;
    }
    
    .stride-category {
        background: white;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        border-left: 5px solid #007bff;
    }
    
    .stride-category h4 {
        font-size: 1.2em;
        margin-bottom: 15px;
        color: #2c3e50;
        display: flex;
        align-items: center;
        justify-content: space-between;
    }
    
    .threat-count {
        background: #007bff;
        color: white;
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 0.8em;
        font-weight: bold;
    }
    
    .risk-score {
        font-size: 1.5em;
        font-weight: bold;
        text-align: center;
        margin: 10px 0;
    }
    
    .risk-critical { color: #dc3545; }
    .risk-high { color: #fd7e14; }
    .risk-medium { color: #ffc107; }
    .risk-low { color: #28a745; }
    
    .threat-table {
        width: 100%;
        border-collapse: collapse;
        margin: 20px 0;
        background: white;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }
    
    .threat-table th {
        background: #2c3e50;
        color: white;
        padding: 15px 10px;
        text-align: left;
        font-weight: 600;
    }
    
    .threat-table td {
        padding: 12px 10px;
        border-bottom: 1px solid #dee2e6;
    }
    
    .threat-table tr:hover {
        background: #f8f9fa;
    }
    
    .severity-badge {
        padding: 5px 10px;
        border-radius: 20px;
        font-size: 0.8em;
        font-weight: bold;
        text-transform: uppercase;
    }
    
    .badge-critical {
        background: #dc3545;
        color: white;
    }
    
    .badge-high {
        background: #fd7e14;
        color: white;
    }
    
    .badge-medium {
        background: #ffc107;
        color: #212529;
    }
    
    .badge-low {
        background: #28a745;
        color: white;
    }
    
    .progress-bar {
        width: 100%;
        height: 20px;
        background: #e9ecef;
        border-radius: 10px;
        overflow: hidden;
        margin: 10px 0;
    }
    
    .progress-fill {
        height: 100%;
        background: linear-gradient(90deg, #28a745 0%, #ffc107 50%, #dc3545 100%);
        transition: width 0.3s ease;
    }
    
    .recommendations {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
        margin: 20px 0;
    }
    
    .recommendation-card {
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        border-left: 5px solid #28a745;
    }
    
    .recommendation-card h4 {
        color: #2c3e50;
        margin-bottom: 10px;
    }
    
    .recommendation-card p {
        color: #6c757d;
        margin-bottom: 10px;
    }
    
    .priority-high { border-left-color: #dc3545; }
    .priority-medium { border-left-color: #ffc107; }
    .priority-low { border-left-color: #28a745; }
    
    .roadmap {
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
        gap: 20px;
        margin: 20px 0;
    }
    
    .roadmap-phase {
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        border-top: 5px solid #007bff;
    }
    
    .roadmap-phase h4 {
        color: #2c3e50;
        margin-bottom: 15px;
        text-align: center;
    }
    
    .roadmap-item {
        background: #f8f9fa;
        padding: 10px;
        margin: 10px 0;
        border-radius: 5px;
        border-left: 3px solid #007bff;
    }
    
    .footer {
        text-align: center;
        padding: 20px;
        margin-top: 40px;
        border-top: 1px solid #dee2e6;
        color: #6c757d;
    }
    
    .collapsible {
        cursor: pointer;
        padding: 10px;
        background: #e9ecef;
        border: none;
        border-radius: 5px;
        width: 100%;
        text-align: left;
        font-weight: bold;
        margin: 10px 0;
        transition: background 0.3s ease;
    }
    
    .collapsible:hover {
        background: #dee2e6;
    }
    
    .content {
        padding: 0 15px;
        display: none;
        overflow: hidden;
        background: white;
        border-radius: 0 0 5px 5px;
    }
    
    .content.active {
        display: block;
        padding: 15px;
    }
    
    .chart-container {
        width: 100%;
        height: 300px;
        margin: 20px 0;
        background: white;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }
    
    @media (max-width: 768px) {
        .container {
            margin: 10px;
            padding: 15px;
        }
        
        .header h1 {
            font-size: 2em;
        }
        
        .dashboard {
            grid-template-columns: 1fr;
        }
        
        .threat-matrix {
            grid-template-columns: 1fr;
        }
    }

        .refs { margin-top: 6px; font-size: 0.9em; color: #495057; }
        .ref-link { margin-right: 8px; text-decoration: none; border-bottom: 1px dotted #6c757d; }
        .ref-link:hover { border-bottom-style: solid; }

        .cloud-stamp {
            background: white;
            margin: -10px 0 20px 0;
            padding: 12px 16px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.06);
            display: flex;
            align-items: center;
            justify-content: space-between;
            border-left: 4px solid #0d6efd;
        }
        .cloud-stamp-label {
            font-weight: 600;
            color: #0d6efd;
        }
        .cloud-stamp-badges { display: flex; flex-wrap: wrap; gap: 8px; }
        .badge-cloud {
            background: #f1f3f5;
            color: #212529;
            border-radius: 999px;
            padding: 6px 10px;
            font-size: 0.85em;
            display: inline-flex;
            align-items: center;
            gap: 6px;
            border: 1px solid #e9ecef;
        }
        .badge-cloud .badge-count {
            background: #fff;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 0 6px;
            font-size: 0.75em;
        }
        .badge-cloud.aws { border-color: #f1f3f5; background: #fff7e6; color: #8a6d3b; }
        .badge-cloud.azure { border-color: #e8f3ff; background: #e8f3ff; color: #1f5fbf; }
        .badge-cloud.gcp { border-color: #f3e8ff; background: #f3e8ff; color: #6f42c1; }
        .badge-cloud.kubernetes { border-color: #e6fffb; background: #e6fffb; color: #0b7285; }
        .badge-cloud.generic { background: #f8f9fa; color: #343a40; }
</style>
        """
    
    def _get_javascript(self) -> str:
        """Retorna scripts JavaScript para interatividade"""
        return """
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
        """
    
    def _create_header(self, report: Dict) -> str:
        """Cria o cabeçalho do relatório"""
        timestamp = report.get('timestamp', datetime.now().isoformat())
        methodology = report.get('methodology', 'Microsoft STRIDE')
        
        return f"""
        <div class="header">
            <h1>🔒 STRIDE Security Analysis Report</h1>
            <div class="subtitle">
                Metodologia: {methodology}<br>
                Gerado em: {self._format_datetime(timestamp)}
            </div>
        </div>
        """
    
    def _create_executive_summary(self, arch_analysis: Dict, risk_assessment: Dict) -> str:
        """Cria o resumo executivo"""
        arch_type = arch_analysis.get('type', 'Unknown')
        total_components = arch_analysis.get('total_components', 0)
        total_threats = arch_analysis.get('total_threats', 0)
        risk_level = arch_analysis.get('risk_level', 'Unknown')
        overall_risk_score = risk_assessment.get('overall_risk_score', 0)
        
        # Determinar classe CSS baseada no risco
        risk_class = self._get_risk_class(overall_risk_score)
        
        return f"""
        <div class="section">
            <h2>📊 Resumo Executivo</h2>
            <div class="dashboard">
                <div class="metric-card">
                    <h3>Tipo de Arquitetura</h3>
                    <div class="metric-value" style="font-size: 1.5em;">{arch_type.replace('_', ' ').title()}</div>
                    <div class="metric-description">{total_components} componentes analisados</div>
                </div>
                <div class="metric-card {risk_class}">
                    <h3>Score de Risco</h3>
                    <div class="metric-value">{overall_risk_score}/10</div>
                    <div class="metric-description">Nível: {risk_level}</div>
                </div>
                <div class="metric-card">
                    <h3>Total de Ameaças</h3>
                    <div class="metric-value">{total_threats}</div>
                    <div class="metric-description">Identificadas pela análise STRIDE</div>
                </div>
                <div class="metric-card">
                    <h3>Status Geral</h3>
                    <div class="metric-value" style="font-size: 1.2em;">
                        {self._get_status_emoji(overall_risk_score)}
                    </div>
                    <div class="metric-description">{self._get_status_text(overall_risk_score)}</div>
                </div>
            </div>
        </div>
        """
    
    def _create_stride_dashboard(self, stride_analysis: Dict) -> str:
        """Cria dashboard das categorias STRIDE"""
        statistics = stride_analysis.get('statistics', {})
        
        stride_cards = ""
        stride_categories = {
            'spoofing': {'emoji': '🎭', 'name': 'Spoofing', 'description': 'Falsificação de Identidade'},
            'tampering': {'emoji': '🔧', 'name': 'Tampering', 'description': 'Violação de Integridade'},
            'repudiation': {'emoji': '📝', 'name': 'Repudiation', 'description': 'Não-Repúdio'},
            'information_disclosure': {'emoji': '🔍', 'name': 'Information Disclosure', 'description': 'Vazamento de Dados'},
            'denial_of_service': {'emoji': '⚡', 'name': 'Denial of Service', 'description': 'Negação de Serviço'},
            'elevation_of_privilege': {'emoji': '⬆️', 'name': 'Elevation of Privilege', 'description': 'Escalação de Privilégios'}
        }
        
        for category_key, category_info in stride_categories.items():
            stats = statistics.get(category_key, {})
            total_count = stats.get('total_count', 0)
            avg_risk = stats.get('avg_risk_score', 0)
            critical_count = stats.get('critical_count', 0)
            
            risk_class = self._get_risk_class(avg_risk)
            
            stride_cards += f"""
            <div class="stride-category">
                <h4>
                    {category_info['emoji']} {category_info['name']}
                    <span class="threat-count">{total_count}</span>
                </h4>
                <div class="risk-score {risk_class}">{avg_risk}/10</div>
                <p style="color: #6c757d; font-size: 0.9em;">{category_info['description']}</p>
                {f'<p style="color: #dc3545; font-weight: bold;">🚨 {critical_count} Críticas</p>' if critical_count > 0 else ''}
            </div>
            """
        
        return f"""
        <div class="section">
            <h2>🎯 Análise por Categoria STRIDE</h2>
            <div class="threat-matrix">
                {stride_cards}
            </div>
        </div>
        """
    
    def _create_threat_matrix(self, threats: List[Dict]) -> str:
        """Cria matriz visual de ameaças"""
        if not threats:
            return ""
        
        # Contar ameaças por severidade
        severity_count = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
        for threat in threats:
            severity = threat.get('severity', 'medium')
            if severity in severity_count:
                severity_count[severity] += 1
        
        total_threats = len(threats)
        
        return f"""
        <div class="section">
            <h2>📈 Distribuição de Ameaças</h2>
            <div class="dashboard">
                <div class="metric-card critical">
                    <h3>Críticas</h3>
                    <div class="metric-value">{severity_count['critical']}</div>
                    <div class="metric-description">{self._calculate_percentage(severity_count['critical'], total_threats)}% do total</div>
                </div>
                <div class="metric-card high">
                    <h3>Altas</h3>
                    <div class="metric-value">{severity_count['high']}</div>
                    <div class="metric-description">{self._calculate_percentage(severity_count['high'], total_threats)}% do total</div>
                </div>
                <div class="metric-card medium">
                    <h3>Médias</h3>
                    <div class="metric-value">{severity_count['medium']}</div>
                    <div class="metric-description">{self._calculate_percentage(severity_count['medium'], total_threats)}% do total</div>
                </div>
                <div class="metric-card low">
                    <h3>Baixas</h3>
                    <div class="metric-value">{severity_count['low']}</div>
                    <div class="metric-description">{self._calculate_percentage(severity_count['low'], total_threats)}% do total</div>
                </div>
            </div>
            
            <div class="chart-container">
                <canvas id="threatChart"></canvas>
            </div>
        </div>
        """
    
    def _create_risk_assessment_section(self, risk_assessment: Dict) -> str:
        """Cria seção de avaliação de risco"""
        overall_score = risk_assessment.get('overall_risk_score', 0)
        risk_class = self._get_risk_class(overall_score)
        
        return f"""
        <div class="section">
            <h2>⚖️ Avaliação de Risco</h2>
            <div class="dashboard">
                <div class="metric-card {risk_class}">
                    <h3>Score Geral de Risco</h3>
                    <div class="metric-value">{overall_score}/10</div>
                    <div class="progress-bar">
                        <div class="progress-fill" style="width: {overall_score * 10}%"></div>
                    </div>
                </div>
            </div>
            
            <button class="collapsible">📊 Detalhes da Avaliação de Risco</button>
            <div class="content">
                <p><strong>Metodologia:</strong> Score calculado baseado na combinação de likelihood e impact das ameaças identificadas.</p>
                <p><strong>Fatores considerados:</strong></p>
                <ul>
                    <li>Severidade das ameaças (Critical=10, High=8, Medium=5, Low=3, Info=1)</li>
                    <li>Exposição à rede (Internet=+1, Internal=0, Isolated=-1)</li>
                    <li>Classificação de dados (Secret=+2, Confidential=+1)</li>
                    <li>Complexidade de exploração</li>
                </ul>
            </div>
        </div>
        """
    
    def _create_attack_paths_section(self, attack_analysis: Dict) -> str:
        """Cria seção de caminhos de ataque"""
        attack_paths = attack_analysis.get('attack_paths', [])
        
        if not attack_paths:
            return ""
        
        paths_html = ""
        for i, path in enumerate(attack_paths[:5], 1):  # Top 5 caminhos
            risk_class = self._get_risk_class(path.get('overall_risk', 0))
            
            paths_html += f"""
            <div class="recommendation-card {risk_class}">
                <h4>🛤️ Caminho {i}: {path.get('entry_point', 'Unknown')} → {path.get('target', 'Unknown')}</h4>
                <p><strong>Risk Score:</strong> {path.get('overall_risk', 0)}/10</p>
                <p><strong>Tempo estimado:</strong> {path.get('estimated_time_to_compromise', 'Unknown')}</p>
                <p><strong>Passos do ataque:</strong></p>
                <ol>
            """
            
            for step in path.get('attack_steps', []):
                paths_html += f"<li>{step.get('description', 'Unknown step')}</li>"
            
            paths_html += "</ol></div>"
        
        return f"""
        <div class="section">
            <h2>🛤️ Caminhos de Ataque</h2>
            <div class="recommendations">
                {paths_html}
            </div>
        </div>
        """
    
    def _create_compliance_section(self, compliance_impact: Dict) -> str:
        """Cria seção de impacto em compliance"""
        dashboard = compliance_impact.get('dashboard', {})
        
        if not dashboard:
            return ""
        
        compliance_cards = ""
        for framework, impact in list(dashboard.items())[:6]:  # Top 6 frameworks
            total_threats = impact.get('total_threats', 0)
            avg_risk = impact.get('avg_risk_score', 0)
            critical_threats = impact.get('critical_threats', 0)
            
            risk_class = self._get_risk_class(avg_risk)
            
            compliance_cards += f"""
            <div class="metric-card {risk_class}">
                <h3>{framework}</h3>
                <div class="metric-value">{total_threats}</div>
                <div class="metric-description">
                    Ameaças impactando<br>
                    Risk Score: {avg_risk}/10
                    {f'<br>🚨 {critical_threats} críticas' if critical_threats > 0 else ''}
                </div>
            </div>
            """
        
        return f"""
        <div class="section">
            <h2>📜 Impacto em Compliance</h2>
            <div class="dashboard">
                {compliance_cards}
            </div>
        </div>
        """
    
    def _create_recommendations_section(self, recommendations: Dict) -> str:
        """Cria seção de recomendações"""
        immediate_actions = recommendations.get('immediate_actions', [])
        strategic_improvements = recommendations.get('strategic_improvements', [])
        
        recommendations_html = ""
        
        # Ações imediatas
        for action in immediate_actions[:5]:  # Top 5
            priority = action.get('priority', 'MEDIUM')
            priority_class = f"priority-{priority.lower()}"
            
            recommendations_html += f"""
            <div class="recommendation-card {priority_class}">
                <h4>🚨 {action.get('description', 'Ação imediata')}</h4>
                <p><strong>Componente:</strong> {action.get('component', 'N/A')}</p>{self._refs_html(action)}
                <p><strong>Ação específica:</strong> {action.get('specific_action', 'N/A')}</p>
                <p><strong>Timeline:</strong> {action.get('timeline', 'N/A')}</p>
                <p><strong>Risk Score:</strong> {action.get('risk_score', 'N/A')}/10</p>
            </div>
            """
        
        # Melhorias estratégicas
        for improvement in strategic_improvements[:3]:  # Top 3
            recommendations_html += f"""
            <div class="recommendation-card priority-medium">
                <h4>📈 {improvement.get('area', 'Melhoria estratégica')}</h4>
                <p>{improvement.get('description', 'N/A')}</p>
                <p><strong>Timeline:</strong> {improvement.get('timeline', 'N/A')}</p>
                <p><strong>Valor estratégico:</strong> {improvement.get('strategic_value', 'N/A')}</p>
                <p><strong>Investimento:</strong> {improvement.get('investment_required', 'N/A')}</p>
            </div>
            """
        
        return f"""
        <div class="section">
            <h2>💡 Recomendações</h2>
            <div class="recommendations">
                {recommendations_html}
            </div>
        </div>
        """
    
    def _create_implementation_roadmap(self, mitigation_analysis: Dict) -> str:
        """Cria roadmap de implementação"""
        roadmap = mitigation_analysis.get('implementation_roadmap', {})
        
        if not roadmap:
            return ""
        
        roadmap_html = ""
        phase_colors = {
            'phase_1_immediate': '#dc3545',
            'phase_2_short_term': '#fd7e14', 
            'phase_3_medium_term': '#ffc107',
            'phase_4_long_term': '#28a745'
        }
        
        phase_names = {
            'phase_1_immediate': 'Fase 1: Imediato',
            'phase_2_short_term': 'Fase 2: Curto Prazo',
            'phase_3_medium_term': 'Fase 3: Médio Prazo',
            'phase_4_long_term': 'Fase 4: Longo Prazo'
        }
        
        for phase_key, phase_data in roadmap.items():
            if phase_key in phase_names and phase_data.get('items'):
                phase_name = phase_names[phase_key]
                duration = phase_data.get('duration', 'N/A')
                items = phase_data.get('items', [])
                
                roadmap_html += f"""
                <div class="roadmap-phase" style="border-top-color: {phase_colors.get(phase_key, '#007bff')}">
                    <h4>{phase_name}</h4>
                    <p style="text-align: center; color: #6c757d; margin-bottom: 15px;">{duration}</p>
                """
                
                for item in items[:3]:  # Top 3 items por fase
                    threat_type = item.get('threat_type', 'unknown')
                    component = item.get('component', 'N/A')
                    risk_score = item.get('risk_score', 0)
                    
                    roadmap_html += f"""
                    <div class="roadmap-item">
                        <strong>{threat_type.replace('_', ' ').title()}</strong><br>
                        <small>{component} | Risk: {risk_score}/10</small>
                    </div>
                    """
                
                roadmap_html += "</div>"
        
        return f"""
        <div class="section">
            <h2>🗓️ Roadmap de Implementação</h2>
            <div class="roadmap">
                {roadmap_html}
            </div>
        </div>
        """
    
    def _create_detailed_threats_table(self, threats: List[Dict]) -> str:
        """Cria tabela detalhada de ameaças"""
        if not threats:
            return ""
        
        # Ordenar ameaças por risk score
        sorted_threats = sorted(threats, key=lambda x: x.get('risk_score', 0), reverse=True)
        
        table_rows = ""
        for threat in sorted_threats[:20]:  # Top 20 ameaças
            threat_id = threat.get('id', 'N/A')
            threat_type = threat.get('threat_type', 'unknown').replace('_', ' ').title()
            component = threat.get('component', 'N/A')
            severity = threat.get('severity', 'medium')
            risk_score = threat.get('risk_score', 0)
            description = threat.get('description', 'N/A')[:100] + "..." if len(threat.get('description', '')) > 100 else threat.get('description', 'N/A')
            
            severity_badge = f'<span class="severity-badge badge-{severity}">{severity}</span>'
            
            table_rows += f"""
            <tr onclick="toggleThreatDetails('{threat_id}')">
                <td>{threat_type}</td>
                <td>{component}</td>
                <td>{severity_badge}</td>
                <td class="risk-{self._get_risk_class_simple(risk_score)}">{risk_score}/10</td>
                <td>{description}{self._refs_html(threat)}</td>
            </tr>
            """
        
        return f"""
        <div class="section">
            <h2>📋 Ameaças Detalhadas</h2>
            <p style="margin-bottom: 20px;">Clique em uma linha para ver mais detalhes (Top 20 ameaças por risk score)</p>
            
            <table class="threat-table">
                <thead>
                    <tr>
                        <th>Tipo de Ameaça</th>
                        <th>Componente</th>
                        <th>Severidade</th>
                        <th>Risk Score</th>
                        <th>Descrição</th>
                    </tr>
                </thead>
                <tbody>
                    {table_rows}
                </tbody>
            </table>
            
            <button class="collapsible">📊 Estatísticas Detalhadas</button>
            <div class="content">
                <p><strong>Total de ameaças analisadas:</strong> {len(threats)}</p>
                <p><strong>Metodologia:</strong> Microsoft STRIDE (Spoofing, Tampering, Repudiation, Information Disclosure, Denial of Service, Elevation of Privilege)</p>
                <p><strong>Critérios de priorização:</strong> Risk Score = (Impact + Likelihood) / 2</p>
            </div>
        </div>
        """
    
    def _create_footer(self) -> str:
        """Cria rodapé do relatório"""
        return f"""
        <div class="footer">
            <p>🔒 Relatório gerado pelo <strong>Multi-Cloud Security Analyzer</strong> com metodologia <strong>Microsoft STRIDE</strong></p>
            <p>Gerado em {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}</p>
            <p style="font-size: 0.8em; color: #adb5bd;">
                Este relatório contém análise automatizada de ameaças. 
                Recomenda-se revisão manual por especialistas em segurança.
            </p>
        </div>
        """
    
    def _get_interactive_scripts(self) -> str:
        """Retorna scripts JavaScript para interatividade"""
        return """
        // Gráfico de distribuição de ameaças
        const ctx = document.getElementById('threatChart');
        if (ctx) {
            new Chart(ctx, {
                type: 'doughnut',
                data: {
                    labels: ['Críticas', 'Altas', 'Médias', 'Baixas'],
                    datasets: [{
                        data: [
                            document.querySelectorAll('.badge-critical').length,
                            document.querySelectorAll('.badge-high').length,
                            document.querySelectorAll('.badge-medium').length,
                            document.querySelectorAll('.badge-low').length
                        ],
                        backgroundColor: ['#dc3545', '#fd7e14', '#ffc107', '#28a745'],
                        borderWidth: 2
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: {
                        title: {
                            display: true,
                            text: 'Distribuição de Ameaças por Severidade'
                        },
                        legend: {
                            position: 'bottom'
                        }
                    }
                }
            });
        }
        
        // Funcionalidade de colapsar/expandir seções
        const collapsibles = document.querySelectorAll('.collapsible');
        collapsibles.forEach(button => {
            button.addEventListener('click', function() {
                this.classList.toggle('active');
                const content = this.nextElementSibling;
                content.classList.toggle('active');
            });
        });
        
        // Função para mostrar detalhes de ameaças (placeholder)
        function toggleThreatDetails(threatId) {
            // Implementar modal ou expansão de detalhes
            console.log('Showing details for threat:', threatId);
        }
        
        // Animações de entrada
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        // Aplicar animações aos cards
        document.querySelectorAll('.metric-card, .stride-category, .recommendation-card').forEach(card => {
            card.style.opacity = '0';
            card.style.transform = 'translateY(20px)';
            card.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(card);
        });
        
        // Contador animado para métricas
        const animateCounters = () => {
            const counters = document.querySelectorAll('.metric-value');
            counters.forEach(counter => {
                const target = parseInt(counter.textContent) || parseFloat(counter.textContent) || 0;
                const increment = target / 50;
                let current = 0;
                
                const timer = setInterval(() => {
                    current += increment;
                    if (current >= target) {
                        counter.textContent = target;
                        clearInterval(timer);
                    } else {
                        counter.textContent = Math.floor(current);
                    }
                }, 20);
            });
        };
        
        // Iniciar animações após carregamento
        window.addEventListener('load', () => {
            setTimeout(animateCounters, 500);
        });
        """
    
    # Métodos utilitários
    def _format_datetime(self, iso_string: str) -> str:
        """Formata string ISO datetime para exibição"""
        try:
            dt = datetime.fromisoformat(iso_string.replace('Z', '+00:00'))
            return dt.strftime('%d/%m/%Y às %H:%M:%S')
        except:
            return iso_string
    
    def _get_risk_class(self, risk_score: float) -> str:
        """Retorna classe CSS baseada no risk score"""
        if risk_score >= 8.0:
            return 'critical'
        elif risk_score >= 6.0:
            return 'high'
        elif risk_score >= 4.0:
            return 'medium'
        else:
            return 'low'
    
    def _get_risk_class_simple(self, risk_score: float) -> str:
        """Retorna classe CSS simples baseada no risk score"""
        if risk_score >= 8.0:
            return 'critical'
        elif risk_score >= 6.0:
            return 'high'
        elif risk_score >= 4.0:
            return 'medium'
        else:
            return 'low'
    
    def _get_status_emoji(self, risk_score: float) -> str:
        """Retorna emoji baseado no risk score"""
        if risk_score >= 8.0:
            return '🚨'
        elif risk_score >= 6.0:
            return '⚠️'
        elif risk_score >= 4.0:
            return '🟡'
        else:
            return '✅'
    
    def _get_status_text(self, risk_score: float) -> str:
        """Retorna texto de status baseado no risk score"""
        if risk_score >= 8.0:
            return 'Ação Imediata Necessária'
        elif risk_score >= 6.0:
            return 'Atenção Requerida'
        elif risk_score >= 4.0:
            return 'Monitoramento Necessário'
        else:
            return 'Status Aceitável'
    
    def _calculate_percentage(self, value: int, total: int) -> str:
        """Calcula porcentagem"""
        if total == 0:
            return "0"
        return f"{(value / total * 100):.1f}"

# Função de conveniência para gerar relatório HTML
def generate_html_from_json(json_file_path: str, output_html_path: str = None) -> str:
    """
    Gera relatório HTML a partir de arquivo JSON
    
    Args:
        json_file_path: Caminho para o arquivo JSON do relatório STRIDE
        output_html_path: Caminho para salvar o HTML (opcional)
    
    Returns:
        Caminho do arquivo HTML gerado
    """
    try:
        # Carregar JSON
        with open(json_file_path, 'r', encoding='utf-8') as f:
            report_data = json.load(f)
        
        # Gerar HTML
        generator = STRIDEHTMLReportGenerator()
        html_path = generator.generate_html_report(report_data, output_html_path)
        
        return html_path
        
    except Exception as e:
        print(f"❌ Erro ao gerar relatório HTML: {e}")
        return None

# Exemplo de uso direto
def example_generate_html_report():
    """Exemplo de como gerar relatório HTML"""
    print("🔄 Gerando relatório HTML de exemplo...")
    
    # Exemplo de estrutura de dados do relatório STRIDE
    sample_report = {
        "timestamp": datetime.now().isoformat(),
        "methodology": "Microsoft STRIDE Multi-Cloud Analysis",
        "architecture_analysis": {
            "type": "api_gateway",
            "total_components": 7,
            "total_threats": 23,
            "risk_level": "HIGH"
        },
        "stride_analysis": {
            "statistics": {
                "spoofing": {"total_count": 5, "avg_risk_score": 7.8, "critical_count": 2},
                "tampering": {"total_count": 3, "avg_risk_score": 6.5, "critical_count": 1},
                "repudiation": {"total_count": 2, "avg_risk_score": 5.2, "critical_count": 0},
                "information_disclosure": {"total_count": 8, "avg_risk_score": 8.1, "critical_count": 3},
                "denial_of_service": {"total_count": 4, "avg_risk_score": 7.0, "critical_count": 1},
                "elevation_of_privilege": {"total_count": 1, "avg_risk_score": 6.8, "critical_count": 0}
            }
        },
        "risk_assessment": {
            "overall_risk_score": 7.2
        },
        "detailed_threats": [
            {
                "id": "api_gateway_spoofing_1",
                "threat_type": "spoofing",
                "component": "API Gateway",
                "severity": "critical",
                "risk_score": 9.2,
                "description": "Falsificação de identidade através de tokens JWT manipulados"
            },
            {
                "id": "database_disclosure_1", 
                "threat_type": "information_disclosure",
                "component": "Database",
                "severity": "high",
                "risk_score": 8.5,
                "description": "Exposição de dados sensíveis através de mensagens de erro detalhadas"
            }
        ],
        "compliance_impact": {
            "dashboard": {
                "GDPR": {"total_threats": 8, "avg_risk_score": 7.8, "critical_threats": 3},
                "PCI DSS": {"total_threats": 5, "avg_risk_score": 7.2, "critical_threats": 2},
                "SOC 2": {"total_threats": 12, "avg_risk_score": 6.9, "critical_threats": 4}
            }
        },
        "recommendations": {
            "immediate_actions": [
                {
                    "description": "Implementar validação robusta de tokens JWT",
                    "component": "API Gateway",
                    "priority": "CRITICAL",
                    "specific_action": "Deploy JWT validation middleware",
                    "timeline": "0-15 days",
                    "risk_score": 9.2
                }
            ],
            "strategic_improvements": [
                {
                    "area": "API Security",
                    "description": "Implementar framework abrangente de segurança de APIs",
                    "timeline": "3-6 months",
                    "strategic_value": "High",
                    "investment_required": "Medium"
                }
            ]
        },
        "mitigation_analysis": {
            "implementation_roadmap": {
                "phase_1_immediate": {
                    "duration": "0-30 days",
                    "items": [
                        {
                            "threat_type": "spoofing",
                            "component": "API Gateway", 
                            "risk_score": 9.2
                        }
                    ]
                },
                "phase_2_short_term": {
                    "duration": "30-90 days",
                    "items": [
                        {
                            "threat_type": "information_disclosure",
                            "component": "Database",
                            "risk_score": 8.5
                        }
                    ]
                }
            }
        },
        "attack_surface_analysis": {
            "attack_paths": [
                {
                    "entry_point": "API Gateway",
                    "target": "Database",
                    "overall_risk": 8.7,
                    "estimated_time_to_compromise": "Hours to Days",
                    "attack_steps": [
                        {"description": "Compromise API Gateway through JWT manipulation"},
                        {"description": "Lateral movement to internal services"},
                        {"description": "Access and exfiltrate database contents"}
                    ]
                }
            ]
        }
    }
    
    # Salvar JSON de exemplo
    sample_json_path = "sample_stride_report.json"
    with open(sample_json_path, 'w', encoding='utf-8') as f:
        json.dump(sample_report, f, indent=2, ensure_ascii=False)
    
    # Gerar HTML
    generator = STRIDEHTMLReportGenerator()
    html_path = generator.generate_html_report(sample_report, "sample_stride_report.html")
    
    print(f"✅ Relatório HTML de exemplo gerado: {html_path}")
    print(f"📄 JSON de exemplo salvo: {sample_json_path}")
    print(f"🌐 Abra o arquivo HTML no seu navegador para visualizar!")
    
    return html_path

if __name__ == "__main__":
    # Exemplo de uso
    example_generate_html_report()