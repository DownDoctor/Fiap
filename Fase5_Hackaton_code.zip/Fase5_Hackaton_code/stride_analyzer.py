#!/usr/bin/env python3
"""
STRIDE Security Analyzer Extension
Implementa a metodologia Microsoft STRIDE para análise de ameaças em arquiteturas multi-cloud
S - Spoofing, T - Tampering, R - Repudiation, I - Information Disclosure, 
D - Denial of Service, E - Elevation of Privilege
"""

import json
import logging
from dataclasses import dataclass, asdict
from typing import List, Dict, Tuple, Set, Optional
from enum import Enum
from datetime import datetime
from abc import ABC, abstractmethod

# Importar classes existentes
from multi_cloud_security_analyzer import (
    CloudComponent, SecurityGap, CloudProvider, ArchitectureType
)

logger = logging.getLogger(__name__)

class STRIDEThreatType(Enum):
    """Categorias de ameaças STRIDE"""
    SPOOFING = "spoofing"                    # S - Falsificação de identidade
    TAMPERING = "tampering"                  # T - Violação de integridade
    REPUDIATION = "repudiation"              # R - Não-repúdio
    INFORMATION_DISCLOSURE = "information_disclosure"  # I - Divulgação de informações
    DENIAL_OF_SERVICE = "denial_of_service"  # D - Negação de serviço
    ELEVATION_OF_PRIVILEGE = "elevation_of_privilege"  # E - Elevação de privilégio

class ThreatSeverity(Enum):
    """Níveis de severidade das ameaças"""
    CRITICAL = "critical"
    HIGH = "high" 
    MEDIUM = "medium"
    LOW = "low"
    INFO = "info"

class AssetType(Enum):
    """Tipos de ativos para análise STRIDE"""
    PROCESS = "process"          # Código em execução
    DATA_STORE = "data_store"    # Armazenamento de dados
    DATA_FLOW = "data_flow"      # Fluxo de dados
    EXTERNAL_ENTITY = "external_entity"  # Entidade externa
    TRUST_BOUNDARY = "trust_boundary"    # Limite de confiança

@dataclass
class STRIDEThreat:
    """Representa uma ameaça identificada usando STRIDE"""
    id: str
    threat_type: STRIDEThreatType
    severity: ThreatSeverity
    asset_type: AssetType
    component: str
    provider: CloudProvider
    description: str
    attack_vector: str
    impact: str
    likelihood: str  # Very Low, Low, Medium, High, Very High
    risk_score: float  # 0.0 to 10.0
    mitigation_strategies: List[str]
    detection_methods: List[str]
    compliance_impact: List[str]
    architecture_type: Optional[ArchitectureType] = None
    cwe_references: List[str] = None  # Common Weakness Enumeration
    mitre_attack_techniques: List[str] = None  # MITRE ATT&CK

@dataclass 
class STRIDEComponent:
    """Componente enriquecido com informações STRIDE"""
    component: CloudComponent
    asset_type: AssetType
    trust_level: str  # HIGH, MEDIUM, LOW
    data_classification: str  # PUBLIC, INTERNAL, CONFIDENTIAL, SECRET
    entry_points: List[str]
    assets_processed: List[str]
    privileges_required: str
    network_exposure: str  # INTERNET, INTERNAL, ISOLATED

class STRIDEThreatModeler:
    """Modelador de ameaças usando metodologia STRIDE"""
    
    def __init__(self):
        self.threat_patterns = self._initialize_threat_patterns()
        self.component_mappings = self._initialize_component_mappings()
        
    def _initialize_threat_patterns(self) -> Dict:
        """Inicializa padrões de ameaças por tipo de componente"""
        return {
            # API Gateway / API Management
            'api_gateway': {
                STRIDEThreatType.SPOOFING: [
                    {
                        'description': 'Falsificação de identidade através de tokens JWT manipulados',
                        'attack_vector': 'Manipulação de tokens de autenticação',
                        'likelihood': 'Medium',
                        'impact': 'Acesso não autorizado a APIs protegidas',
                        'mitigations': [
                            'Implementar validação robusta de tokens JWT',
                            'Usar certificados para assinatura de tokens',
                            'Implementar token binding',
                            'Configurar blacklist de tokens comprometidos'
                        ],
                        'detections': [
                            'Monitoramento de tentativas de acesso com tokens inválidos',
                            'Análise de padrões de uso anômalos',
                            'Logs de validação de certificados'
                        ],
                        'cwe': ['CWE-287', 'CWE-290'],
                        'mitre': ['T1550.001']
                    },
                    {
                        'description': 'Spoofing de origem através de manipulação de headers HTTP',
                        'attack_vector': 'Manipulação de headers X-Forwarded-For, Origin, Referer',
                        'likelihood': 'High',
                        'impact': 'Bypass de controles de origem e CORS',
                        'mitigations': [
                            'Validação rigorosa de headers HTTP',
                            'Implementar allowlists de origens',
                            'Usar mutual TLS para verificação de origem',
                            'Configurar políticas CORS restritivas'
                        ],
                        'detections': [
                            'Monitoramento de headers suspeitos',
                            'Alertas para origens não autorizadas',
                            'Análise de padrões de tráfego'
                        ],
                        'cwe': ['CWE-346', 'CWE-942'],
                        'mitre': ['T1071.001']
                    }
                ],
                STRIDEThreatType.TAMPERING: [
                    {
                        'description': 'Manipulação de payloads de API em trânsito',
                        'attack_vector': 'Man-in-the-middle attacks em conexões não criptografadas',
                        'likelihood': 'Medium',
                        'impact': 'Corrupção de dados e lógica de negócio',
                        'mitigations': [
                            'Enforçar HTTPS para todas as comunicações',
                            'Implementar assinatura digital de payloads',
                            'Usar HMAC para integridade de mensagens',
                            'Certificate pinning em aplicações cliente'
                        ],
                        'detections': [
                            'Monitoramento de tentativas de conexão HTTP',
                            'Verificação de integridade de payloads',
                            'Análise de certificados SSL/TLS'
                        ],
                        'cwe': ['CWE-319', 'CWE-345'],
                        'mitre': ['T1557']
                    }
                ],
                STRIDEThreatType.REPUDIATION: [
                    {
                        'description': 'Falta de auditoria adequada de transações de API',
                        'attack_vector': 'Ausência de logs detalhados de requests/responses',
                        'likelihood': 'High',
                        'impact': 'Impossibilidade de rastrear ações maliciosas',
                        'mitigations': [
                            'Implementar logging estruturado de todas as transações',
                            'Usar assinatura digital para logs',
                            'Centralizar logs em sistema imutável',
                            'Implementar correlation IDs para rastreamento'
                        ],
                        'detections': [
                            'Monitoramento de gaps nos logs',
                            'Verificação de integridade de logs',
                            'Alertas para tentativas de manipulação'
                        ],
                        'cwe': ['CWE-117', 'CWE-778'],
                        'mitre': ['T1562.002']
                    }
                ],
                STRIDEThreatType.INFORMATION_DISCLOSURE: [
                    {
                        'description': 'Exposição de informações sensíveis em mensagens de erro',
                        'attack_vector': 'Error messages detalhadas revelando estrutura interna',
                        'likelihood': 'High',
                        'impact': 'Vazamento de informações de sistema e dados',
                        'mitigations': [
                            'Implementar mensagens de erro genéricas',
                            'Usar códigos de erro padronizados',
                            'Logs detalhados apenas internamente',
                            'Sanitização de responses de API'
                        ],
                        'detections': [
                            'Análise automática de responses de erro',
                            'Monitoramento de tentativas de enumeration',
                            'Scanning de informações expostas'
                        ],
                        'cwe': ['CWE-209', 'CWE-200'],
                        'mitre': ['T1190']
                    }
                ],
                STRIDEThreatType.DENIAL_OF_SERVICE: [
                    {
                        'description': 'Ataques de negação de serviço através de rate limiting inadequado',
                        'attack_vector': 'Flood de requests para overwhelm do API Gateway',
                        'likelihood': 'High',
                        'impact': 'Indisponibilidade de serviços críticos',
                        'mitigations': [
                            'Implementar rate limiting adaptativo',
                            'Usar API throttling baseado em usage plans',
                            'Deploy de WAF para proteção DDoS',
                            'Circuit breakers para proteção downstream'
                        ],
                        'detections': [
                            'Monitoramento de padrões de tráfego anômalos',
                            'Alertas para spike de requests',
                            'Métricas de latência e throughput'
                        ],
                        'cwe': ['CWE-770', 'CWE-400'],
                        'mitre': ['T1498', 'T1499']
                    }
                ],
                STRIDEThreatType.ELEVATION_OF_PRIVILEGE: [
                    {
                        'description': 'Bypass de controles de autorização através de manipulação de scopes',
                        'attack_vector': 'Manipulação de tokens OAuth para obter privilégios elevados',
                        'likelihood': 'Medium',
                        'impact': 'Acesso a recursos não autorizados',
                        'mitigations': [
                            'Implementar fine-grained authorization',
                            'Validação rigorosa de scopes OAuth',
                            'Principle of least privilege',
                            'Regular audit de permissões'
                        ],
                        'detections': [
                            'Monitoramento de escalação de privilégios',
                            'Análise de padrões de acesso anômalos',
                            'Alertas para scope manipulations'
                        ],
                        'cwe': ['CWE-269', 'CWE-264'],
                        'mitre': ['T1068']
                    }
                ]
            },
            
            # Microservices
            'microservice': {
                STRIDEThreatType.SPOOFING: [
                    {
                        'description': 'Service-to-service authentication spoofing',
                        'attack_vector': 'Falsificação de identidade entre microserviços',
                        'likelihood': 'Medium',
                        'impact': 'Acesso não autorizado a serviços internos',
                        'mitigations': [
                            'Implementar mutual TLS (mTLS)',
                            'Service mesh com identity enforcement',
                            'JWT para service-to-service auth',
                            'Certificate-based authentication'
                        ],
                        'detections': [
                            'Monitoramento de conexões sem mTLS',
                            'Análise de certificados inválidos',
                            'Padrões de comunicação anômalos'
                        ],
                        'cwe': ['CWE-287'],
                        'mitre': ['T1556']
                    }
                ],
                STRIDEThreatType.INFORMATION_DISCLOSURE: [
                    {
                        'description': 'Vazamento de dados através de logs centralizados',
                        'attack_vector': 'Dados sensíveis expostos em logs de aplicação',
                        'likelihood': 'High',
                        'impact': 'Exposição de informações confidenciais',
                        'mitigations': [
                            'Data masking em logs',
                            'Classificação automática de dados',
                            'Encryption de logs em transit e at rest',
                            'Access controls para sistemas de logging'
                        ],
                        'detections': [
                            'Scanning automático de logs para PII',
                            'Monitoramento de acesso a logs',
                            'Análise de padrões de data exfiltration'
                        ],
                        'cwe': ['CWE-532'],
                        'mitre': ['T1005']
                    }
                ]
            },
            
            # Database/Storage
            'database': {
                STRIDEThreatType.TAMPERING: [
                    {
                        'description': 'SQL Injection e NoSQL Injection attacks',
                        'attack_vector': 'Manipulação de queries através de input não sanitizado',
                        'likelihood': 'High',
                        'impact': 'Corrupção de dados e acesso não autorizado',
                        'mitigations': [
                            'Parameterized queries/prepared statements',
                            'Input validation e sanitization',
                            'ORM com proteção built-in',
                            'Database activity monitoring'
                        ],
                        'detections': [
                            'Pattern matching para injection attempts',
                            'Monitoramento de queries anômalas',
                            'Database access monitoring'
                        ],
                        'cwe': ['CWE-89', 'CWE-943'],
                        'mitre': ['T1190']
                    }
                ],
                STRIDEThreatType.INFORMATION_DISCLOSURE: [
                    {
                        'description': 'Exposição de dados através de backups não criptografados',
                        'attack_vector': 'Acesso a backups sem proteção adequada',
                        'likelihood': 'Medium',
                        'impact': 'Vazamento massivo de dados',
                        'mitigations': [
                            'Encryption de backups at rest e in transit',
                            'Access controls rigorosos para backups',
                            'Backup retention policies',
                            'Regular testing de restore procedures'
                        ],
                        'detections': [
                            'Monitoramento de acesso a backup storage',
                            'Verificação de encryption status',
                            'Audit trails para backup operations'
                        ],
                        'cwe': ['CWE-312'],
                        'mitre': ['T1005']
                    }
                ]
            }
        }
    
    def _initialize_component_mappings(self) -> Dict:
        """Mapeia componentes para asset types e configurações STRIDE"""
        return {
            # AWS Components
            'API Gateway': {
                'asset_type': AssetType.PROCESS,
                'threat_category': 'api_gateway',
                'trust_level': 'MEDIUM',
                'network_exposure': 'INTERNET',
                'entry_points': ['HTTP/HTTPS endpoints', 'WebSocket connections'],
                'privileges_required': 'API Keys, OAuth tokens'
            },
            'Lambda': {
                'asset_type': AssetType.PROCESS,
                'threat_category': 'microservice',
                'trust_level': 'HIGH',
                'network_exposure': 'INTERNAL',
                'entry_points': ['Event triggers', 'API Gateway integration'],
                'privileges_required': 'IAM roles'
            },
            'DynamoDB': {
                'asset_type': AssetType.DATA_STORE,
                'threat_category': 'database',
                'trust_level': 'HIGH',
                'network_exposure': 'INTERNAL',
                'entry_points': ['SDK/API calls'],
                'privileges_required': 'IAM policies'
            },
            'S3': {
                'asset_type': AssetType.DATA_STORE,
                'threat_category': 'database',
                'trust_level': 'MEDIUM',
                'network_exposure': 'INTERNET',
                'entry_points': ['REST API', 'SDK calls'],
                'privileges_required': 'IAM policies, Bucket policies'
            },
            'RDS': {
                'asset_type': AssetType.DATA_STORE,
                'threat_category': 'database',
                'trust_level': 'HIGH',
                'network_exposure': 'INTERNAL',
                'entry_points': ['Database connections'],
                'privileges_required': 'Database credentials'
            },
            'ALB': {
                'asset_type': AssetType.PROCESS,
                'threat_category': 'api_gateway',
                'trust_level': 'MEDIUM',
                'network_exposure': 'INTERNET',
                'entry_points': ['HTTP/HTTPS traffic'],
                'privileges_required': 'None (public)'
            },
            'EKS': {
                'asset_type': AssetType.PROCESS,
                'threat_category': 'microservice',
                'trust_level': 'MEDIUM',
                'network_exposure': 'INTERNAL',
                'entry_points': ['Kubernetes API', 'Pod networking'],
                'privileges_required': 'RBAC permissions'
            },
            
            # Azure Components
            'API Management': {
                'asset_type': AssetType.PROCESS,
                'threat_category': 'api_gateway',
                'trust_level': 'MEDIUM',
                'network_exposure': 'INTERNET',
                'entry_points': ['HTTP/HTTPS endpoints', 'Developer portal'],
                'privileges_required': 'API subscriptions, OAuth'
            },
            'Logic Apps': {
                'asset_type': AssetType.PROCESS,
                'threat_category': 'microservice',
                'trust_level': 'HIGH',
                'network_exposure': 'INTERNAL',
                'entry_points': ['Workflow triggers', 'HTTP triggers'],
                'privileges_required': 'Managed identity'
            },
            'SQL Database': {
                'asset_type': AssetType.DATA_STORE,
                'threat_category': 'database',
                'trust_level': 'HIGH',
                'network_exposure': 'INTERNAL',
                'entry_points': ['SQL connections'],
                'privileges_required': 'Database authentication'
            },
            'Storage Account': {
                'asset_type': AssetType.DATA_STORE,
                'threat_category': 'database',
                'trust_level': 'MEDIUM',
                'network_exposure': 'INTERNET',
                'entry_points': ['REST API', 'SDK'],
                'privileges_required': 'Storage keys, SAS tokens'
            },
            'Active Directory': {
                'asset_type': AssetType.EXTERNAL_ENTITY,
                'threat_category': 'identity',
                'trust_level': 'HIGH',
                'network_exposure': 'INTERNAL',
                'entry_points': ['Authentication endpoints'],
                'privileges_required': 'User credentials'
            },
            
            # Generic/API Components
            'REST API': {
                'asset_type': AssetType.PROCESS,
                'threat_category': 'api_gateway',
                'trust_level': 'MEDIUM',
                'network_exposure': 'INTERNET',
                'entry_points': ['HTTP endpoints'],
                'privileges_required': 'Authentication tokens'
            },
            'Microservice': {
                'asset_type': AssetType.PROCESS,
                'threat_category': 'microservice',
                'trust_level': 'MEDIUM',
                'network_exposure': 'INTERNAL',
                'entry_points': ['Service endpoints'],
                'privileges_required': 'Service authentication'
            },
            'Database': {
                'asset_type': AssetType.DATA_STORE,
                'threat_category': 'database',
                'trust_level': 'HIGH',
                'network_exposure': 'INTERNAL',
                'entry_points': ['Database connections'],
                'privileges_required': 'Database credentials'
            }
        }
    
    def analyze_threats(self, components: List[CloudComponent], 
                       architecture_type: ArchitectureType) -> List[STRIDEThreat]:
        """Analisa ameaças usando metodologia STRIDE"""
        threats = []
        
        # Enriquecer componentes com informações STRIDE
        stride_components = self._enrich_components(components)
        
        # Identificar trust boundaries
        trust_boundaries = self._identify_trust_boundaries(stride_components, architecture_type)
        
        # Analisar ameaças por componente
        for stride_comp in stride_components:
            component_threats = self._analyze_component_threats(stride_comp, architecture_type)
            threats.extend(component_threats)
        
        # Analisar ameaças de data flow
        data_flow_threats = self._analyze_data_flow_threats(stride_components, trust_boundaries)
        threats.extend(data_flow_threats)
        
        # Calcular risk scores
        for threat in threats:
            threat.risk_score = self._calculate_risk_score(threat)
        
        # Ordenar por risk score (maior primeiro)
        threats.sort(key=lambda t: t.risk_score, reverse=True)
        
        return threats
    
    def _enrich_components(self, components: List[CloudComponent]) -> List[STRIDEComponent]:
        """Enriquece componentes com informações STRIDE"""
        stride_components = []
        
        for comp in components:
            mapping = self.component_mappings.get(comp.name, {
                'asset_type': AssetType.PROCESS,
                'threat_category': 'generic',
                'trust_level': 'MEDIUM',
                'network_exposure': 'INTERNAL',
                'entry_points': ['Unknown'],
                'privileges_required': 'Unknown'
            })
            
            stride_comp = STRIDEComponent(
                component=comp,
                asset_type=mapping['asset_type'],
                trust_level=mapping['trust_level'],
                data_classification=self._classify_data(comp),
                entry_points=mapping['entry_points'],
                assets_processed=self._identify_assets_processed(comp),
                privileges_required=mapping['privileges_required'],
                network_exposure=mapping['network_exposure']
            )
            
            stride_components.append(stride_comp)
        
        return stride_components
    
    def _classify_data(self, component: CloudComponent) -> str:
        """Classifica dados processados pelo componente"""
        if component.category in ['database', 'storage']:
            return 'CONFIDENTIAL'
        elif component.category in ['security', 'identity']:
            return 'SECRET'
        elif component.category in ['monitoring', 'logging']:
            return 'INTERNAL'
        else:
            return 'INTERNAL'
    
    def _identify_assets_processed(self, component: CloudComponent) -> List[str]:
        """Identifica ativos processados pelo componente"""
        assets = []
        
        if component.category == 'database':
            assets.extend(['Customer data', 'Transactional data', 'User credentials'])
        elif component.category == 'security':
            assets.extend(['Authentication tokens', 'Authorization policies', 'Audit logs'])
        elif component.category == 'networking':
            assets.extend(['Network traffic', 'Request metadata', 'Session data'])
        elif component.category == 'compute':
            assets.extend(['Application data', 'Processing results', 'System logs'])
        else:
            assets.append('Application data')
        
        return assets
    
    def _identify_trust_boundaries(self, components: List[STRIDEComponent], 
                                 arch_type: ArchitectureType) -> List[Dict]:
        """Identifica limites de confiança na arquitetura"""
        boundaries = []
        
        # Boundary entre Internet e aplicação
        internet_facing = [c for c in components if c.network_exposure == 'INTERNET']
        if internet_facing:
            boundaries.append({
                'name': 'Internet-to-Application',
                'type': 'network',
                'from_trust': 'UNTRUSTED',
                'to_trust': 'INTERNAL',
                'components': [c.component.name for c in internet_facing],
                'security_controls': ['WAF', 'TLS', 'Authentication']
            })
        
        # Boundary entre aplicação e dados
        data_stores = [c for c in components if c.asset_type == AssetType.DATA_STORE]
        if data_stores:
            boundaries.append({
                'name': 'Application-to-Data',
                'type': 'data',
                'from_trust': 'INTERNAL',
                'to_trust': 'HIGH',
                'components': [c.component.name for c in data_stores],
                'security_controls': ['Encryption', 'Access Control', 'Audit Logging']
            })
        
        # Boundary multi-cloud (se aplicável)
        providers = set(c.component.provider for c in components)
        if len(providers) > 1:
            boundaries.append({
                'name': 'Multi-Cloud',
                'type': 'administrative',
                'from_trust': 'INTERNAL',
                'to_trust': 'INTERNAL',
                'components': list(providers),
                'security_controls': ['Identity Federation', 'Cross-Cloud Encryption', 'Unified Governance']
            })
        
        return boundaries
    
    def _analyze_component_threats(self, stride_comp: STRIDEComponent, 
                                 arch_type: ArchitectureType) -> List[STRIDEThreat]:
        """Analisa ameaças para um componente específico"""
        threats = []
        component = stride_comp.component
        
        # Obter padrões de ameaças baseados no tipo de componente
        threat_category = self.component_mappings.get(component.name, {}).get('threat_category', 'generic')
        patterns = self.threat_patterns.get(threat_category, {})
        
        # Gerar ameaças para cada categoria STRIDE aplicável
        for threat_type, threat_list in patterns.items():
            for i, pattern in enumerate(threat_list):
                threat_id = f"{component.name}_{threat_type.value}_{i+1}"
                
                # Ajustar likelihood baseado na exposição do componente
                adjusted_likelihood = self._adjust_likelihood(
                    pattern['likelihood'], 
                    stride_comp.network_exposure,
                    stride_comp.trust_level
                )
                
                threat = STRIDEThreat(
                    id=threat_id,
                    threat_type=threat_type,
                    severity=self._determine_severity(pattern, stride_comp),
                    asset_type=stride_comp.asset_type,
                    component=component.name,
                    provider=component.provider,
                    description=pattern['description'],
                    attack_vector=pattern['attack_vector'],
                    impact=pattern['impact'],
                    likelihood=adjusted_likelihood,
                    risk_score=0.0,  # Calculado posteriormente
                    mitigation_strategies=pattern['mitigations'],
                    detection_methods=pattern['detections'],
                    compliance_impact=self._map_compliance_impact(threat_type, component),
                    architecture_type=arch_type,
                    cwe_references=pattern.get('cwe', []),
                    mitre_attack_techniques=pattern.get('mitre', [])
                )
                
                threats.append(threat)
        
        return threats
    
    def _analyze_data_flow_threats(self, components: List[STRIDEComponent], 
                                 boundaries: List[Dict]) -> List[STRIDEThreat]:
        """Analisa ameaças específicas de fluxo de dados"""
        threats = []
        
        # Analisar comunicação entre componentes
        for i, comp1 in enumerate(components):
            for comp2 in components[i+1:]:
                if self._components_communicate(comp1, comp2):
                    flow_threats = self._analyze_communication_threats(comp1, comp2)
                    threats.extend(flow_threats)
        
        # Analisar ameaças nos trust boundaries
        for boundary in boundaries:
            boundary_threats = self._analyze_boundary_threats(boundary, components)
            threats.extend(boundary_threats)
        
        return threats
    
    def _components_communicate(self, comp1: STRIDEComponent, comp2: STRIDEComponent) -> bool:
        """Determina se dois componentes se comunicam"""
        # Lógica simples: APIs se comunicam com databases, microservices entre si, etc.
        categories1 = comp1.component.category
        categories2 = comp2.component.category
        
        communication_patterns = [
            ('networking', 'compute'),
            ('networking', 'database'),
            ('compute', 'database'),
            ('compute', 'compute'),  # microservices
            ('application', 'database'),
            ('security', 'compute')
        ]
        
        return (categories1, categories2) in communication_patterns or \
               (categories2, categories1) in communication_patterns
    
    def _analyze_communication_threats(self, comp1: STRIDEComponent, 
                                     comp2: STRIDEComponent) -> List[STRIDEThreat]:
        """Analisa ameaças na comunicação entre componentes"""
        threats = []
        
        # Ameaça de tampering em data flow
        if comp1.network_exposure == 'INTERNET' or comp2.network_exposure == 'INTERNET':
            threat = STRIDEThreat(
                id=f"dataflow_{comp1.component.name}_{comp2.component.name}_tampering",
                threat_type=STRIDEThreatType.TAMPERING,
                severity=ThreatSeverity.HIGH,
                asset_type=AssetType.DATA_FLOW,
                component=f"{comp1.component.name} -> {comp2.component.name}",
                provider=comp1.component.provider,
                description=f"Dados em trânsito entre {comp1.component.name} e {comp2.component.name} podem ser interceptados",
                attack_vector="Man-in-the-middle attack durante comunicação",
                impact="Corrupção ou exposição de dados em trânsito",
                likelihood="Medium",
                risk_score=0.0,
                mitigation_strategies=[
                    "Implementar TLS 1.3 para todas as comunicações",
                    "Usar certificate pinning",
                    "Implementar mutual TLS (mTLS)",
                    "Assinatura digital de payloads críticos"
                ],
                detection_methods=[
                    "Monitoramento de conexões não criptografadas",
                    "Análise de certificados SSL/TLS",
                    "Detecção de anomalias em padrões de tráfego",
                    "Verificação de integridade de mensagens"
                ],
                compliance_impact=["PCI DSS", "GDPR", "HIPAA"],
                cwe_references=["CWE-319", "CWE-345"],
                mitre_attack_techniques=["T1557"]
            )
            threats.append(threat)
        
        # Ameaça de information disclosure
        if comp2.asset_type == AssetType.DATA_STORE and comp2.data_classification in ['CONFIDENTIAL', 'SECRET']:
            threat = STRIDEThreat(
                id=f"dataflow_{comp1.component.name}_{comp2.component.name}_disclosure",
                threat_type=STRIDEThreatType.INFORMATION_DISCLOSURE,
                severity=ThreatSeverity.HIGH,
                asset_type=AssetType.DATA_FLOW,
                component=f"{comp1.component.name} -> {comp2.component.name}",
                provider=comp1.component.provider,
                description=f"Dados confidenciais podem ser expostos durante comunicação com {comp2.component.name}",
                attack_vector="Interceptação de dados sensíveis em comunicação",
                impact="Vazamento de informações confidenciais",
                likelihood="Medium",
                risk_score=0.0,
                mitigation_strategies=[
                    "Implementar data masking para dados sensíveis",
                    "Usar field-level encryption",
                    "Implementar tokenização de dados",
                    "Minimizar dados transmitidos (data minimization)"
                ],
                detection_methods=[
                    "Data loss prevention (DLP)",
                    "Monitoramento de volumes de dados anômalos",
                    "Classificação automática de dados",
                    "Análise de conteúdo de comunicações"
                ],
                compliance_impact=["GDPR", "LGPD", "HIPAA", "PCI DSS"],
                cwe_references=["CWE-200", "CWE-359"],
                mitre_attack_techniques=["T1005", "T1041"]
            )
            threats.append(threat)
        
        return threats
    
    def _analyze_boundary_threats(self, boundary: Dict, 
                                components: List[STRIDEComponent]) -> List[STRIDEThreat]:
        """Analisa ameaças específicas dos trust boundaries"""
        threats = []
        
        if boundary['name'] == 'Internet-to-Application':
            # Ameaças de spoofing na fronteira da internet
            threat = STRIDEThreat(
                id=f"boundary_{boundary['name']}_spoofing",
                threat_type=STRIDEThreatType.SPOOFING,
                severity=ThreatSeverity.CRITICAL,
                asset_type=AssetType.TRUST_BOUNDARY,
                component=boundary['name'],
                provider=CloudProvider.GENERIC,
                description="Ataques de spoofing na fronteira internet-aplicação",
                attack_vector="Falsificação de origem de requests externos",
                impact="Acesso não autorizado contornando controles perimetrais",
                likelihood="High",
                risk_score=0.0,
                mitigation_strategies=[
                    "Implementar Web Application Firewall (WAF)",
                    "Configurar geo-blocking para regiões de risco",
                    "Usar CAPTCHA para verificação humana",
                    "Implementar rate limiting agressivo"
                ],
                detection_methods=[
                    "Análise de padrões de tráfego geográfico",
                    "Detecção de user agents suspeitos",
                    "Monitoramento de IPs maliciosos conhecidos",
                    "Análise comportamental de requests"
                ],
                compliance_impact=["NIST Cybersecurity Framework", "ISO 27001"],
                cwe_references=["CWE-346"],
                mitre_attack_techniques=["T1190", "T1071"]
            )
            threats.append(threat)
            
            # Ameaças de DoS na fronteira
            threat = STRIDEThreat(
                id=f"boundary_{boundary['name']}_dos",
                threat_type=STRIDEThreatType.DENIAL_OF_SERVICE,
                severity=ThreatSeverity.HIGH,
                asset_type=AssetType.TRUST_BOUNDARY,
                component=boundary['name'],
                provider=CloudProvider.GENERIC,
                description="Ataques DDoS na fronteira da aplicação",
                attack_vector="Flood de requests para overwhelm da infraestrutura",
                impact="Indisponibilidade de serviços para usuários legítimos",
                likelihood="High",
                risk_score=0.0,
                mitigation_strategies=[
                    "Deploy de solução Anti-DDoS",
                    "Auto-scaling baseado em métricas de tráfego",
                    "Content Delivery Network (CDN) para distribuição",
                    "Circuit breakers para proteção de backend"
                ],
                detection_methods=[
                    "Monitoramento de spikes de tráfego",
                    "Análise de padrões de request anômalos",
                    "Métricas de latência e disponibilidade",
                    "Correlação com threat intelligence feeds"
                ],
                compliance_impact=["Business Continuity Standards"],
                cwe_references=["CWE-770"],
                mitre_attack_techniques=["T1498", "T1499"]
            )
            threats.append(threat)
        
        elif boundary['name'] == 'Multi-Cloud':
            # Ameaças específicas de multi-cloud
            threat = STRIDEThreat(
                id=f"boundary_{boundary['name']}_elevation",
                threat_type=STRIDEThreatType.ELEVATION_OF_PRIVILEGE,
                severity=ThreatSeverity.HIGH,
                asset_type=AssetType.TRUST_BOUNDARY,
                component=boundary['name'],
                provider=CloudProvider.GENERIC,
                description="Escalação de privilégios através de federação multi-cloud",
                attack_vector="Abuse de confiança entre provedores de nuvem",
                impact="Acesso não autorizado a recursos em múltiplas nuvens",
                likelihood="Medium",
                risk_score=0.0,
                mitigation_strategies=[
                    "Implementar Zero Trust Architecture",
                    "Governança unificada de identidades",
                    "Least privilege principle across clouds",
                    "Regular audit de permissões federadas"
                ],
                detection_methods=[
                    "Monitoramento de atividades cross-cloud",
                    "Análise de padrões de acesso anômalos",
                    "Audit logs centralizados",
                    "Identity and access analytics"
                ],
                compliance_impact=["SOC 2", "ISO 27001", "Cloud Security Standards"],
                cwe_references=["CWE-269"],
                mitre_attack_techniques=["T1078", "T1550"]
            )
            threats.append(threat)
        
        return threats
    
    def _adjust_likelihood(self, base_likelihood: str, network_exposure: str, trust_level: str) -> str:
        """Ajusta likelihood baseado na exposição e nível de confiança"""
        likelihood_values = {"Very Low": 1, "Low": 2, "Medium": 3, "High": 4, "Very High": 5}
        base_value = likelihood_values.get(base_likelihood, 3)
        
        # Ajustar baseado na exposição à rede
        if network_exposure == 'INTERNET':
            base_value += 1
        elif network_exposure == 'ISOLATED':
            base_value -= 1
        
        # Ajustar baseado no nível de confiança
        if trust_level == 'LOW':
            base_value += 1
        elif trust_level == 'HIGH':
            base_value -= 1
        
        # Garantir que está no range válido
        base_value = max(1, min(5, base_value))
        
        # Converter de volta para string
        for likelihood, value in likelihood_values.items():
            if value == base_value:
                return likelihood
        
        return base_likelihood
    
    def _determine_severity(self, pattern: Dict, stride_comp: STRIDEComponent) -> ThreatSeverity:
        """Determina severidade baseada no padrão e contexto do componente"""
        base_severity = ThreatSeverity.MEDIUM
        
        # Ajustar baseado na classificação de dados
        if stride_comp.data_classification in ['SECRET', 'CONFIDENTIAL']:
            if 'authentication' in pattern['description'].lower():
                base_severity = ThreatSeverity.CRITICAL
            elif 'disclosure' in pattern['description'].lower():
                base_severity = ThreatSeverity.HIGH
        
        # Ajustar baseado na exposição à rede
        if stride_comp.network_exposure == 'INTERNET':
            if base_severity == ThreatSeverity.MEDIUM:
                base_severity = ThreatSeverity.HIGH
        
        # Ajustar baseado no tipo de ativo
        if stride_comp.asset_type == AssetType.DATA_STORE and \
           stride_comp.data_classification == 'SECRET':
            base_severity = ThreatSeverity.CRITICAL
        
        return base_severity
    
    def _map_compliance_impact(self, threat_type: STRIDEThreatType, 
                             component: CloudComponent) -> List[str]:
        """Mapeia ameaças para impactos de compliance"""
        compliance_mapping = {
            STRIDEThreatType.SPOOFING: ["ISO 27001", "NIST", "SOC 2"],
            STRIDEThreatType.TAMPERING: ["PCI DSS", "GDPR", "HIPAA"],
            STRIDEThreatType.REPUDIATION: ["SOX", "SOC 2", "ISO 27001"],
            STRIDEThreatType.INFORMATION_DISCLOSURE: ["GDPR", "LGPD", "HIPAA", "PCI DSS"],
            STRIDEThreatType.DENIAL_OF_SERVICE: ["Business Continuity", "ISO 22301"],
            STRIDEThreatType.ELEVATION_OF_PRIVILEGE: ["SOC 2", "NIST", "ISO 27001"]
        }
        
        base_compliance = compliance_mapping.get(threat_type, [])
        
        # Adicionar compliance específico por categoria de componente
        if component.category in ['database', 'storage']:
            base_compliance.extend(["Data Protection Regulations"])
        
        if component.category == 'security':
            base_compliance.extend(["Security Standards"])
        
        return list(set(base_compliance))  # Remove duplicatas
    
    def _calculate_risk_score(self, threat: STRIDEThreat) -> float:
        """Calcula risk score usando fórmula: Impact x Likelihood"""
        likelihood_scores = {
            "Very Low": 1.0, "Low": 2.0, "Medium": 5.0, "High": 8.0, "Very High": 10.0
        }
        
        severity_scores = {
            ThreatSeverity.INFO: 1.0,
            ThreatSeverity.LOW: 3.0,
            ThreatSeverity.MEDIUM: 5.0,
            ThreatSeverity.HIGH: 8.0,
            ThreatSeverity.CRITICAL: 10.0
        }
        
        likelihood_score = likelihood_scores.get(threat.likelihood, 5.0)
        severity_score = severity_scores.get(threat.severity, 5.0)
        
        # Fórmula: (Impact + Likelihood) / 2, normalizada para 0-10
        risk_score = (severity_score + likelihood_score) / 2
        
        return round(risk_score, 1)

class STRIDEReportGenerator:
    """Gerador de relatórios específicos para análise STRIDE"""
    
    def generate_stride_report(self, threats: List[STRIDEThreat], 
                              components: List[CloudComponent],
                              architecture_type: ArchitectureType) -> Dict:
        """Gera relatório completo de análise STRIDE"""
        
        # Estatísticas por categoria STRIDE
        stride_stats = self._calculate_stride_statistics(threats)
        
        # Top ameaças por risk score
        top_threats = sorted(threats, key=lambda t: t.risk_score, reverse=True)[:10]
        
        # Análise de cobertura de mitigação
        mitigation_coverage = self._analyze_mitigation_coverage(threats)
        
        # Risk matrix
        risk_matrix = self._generate_risk_matrix(threats)
        
        # Compliance dashboard
        compliance_dashboard = self._generate_compliance_dashboard(threats)
        
        # Attack path analysis
        attack_paths = self._analyze_attack_paths(threats, components)
        
        # Security controls mapping
        controls_mapping = self._map_security_controls(threats)
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'methodology': 'Microsoft STRIDE',
            'architecture_analysis': {
                'type': architecture_type.value,
                'total_components': len(components),
                'total_threats': len(threats),
                'risk_level': self._calculate_overall_risk_level(threats)
            },
            'stride_analysis': {
                'statistics': stride_stats,
                'top_threats': [asdict(threat) for threat in top_threats],
                'risk_distribution': self._calculate_risk_distribution(threats),
                'threat_coverage': self._calculate_threat_coverage(threats, components)
            },
            'risk_assessment': {
                'risk_matrix': risk_matrix,
                'overall_risk_score': self._calculate_overall_risk_score(threats),
                'risk_appetite_analysis': self._analyze_risk_appetite(threats),
                'prioritization_matrix': self._create_prioritization_matrix(threats)
            },
            'mitigation_analysis': {
                'coverage_analysis': mitigation_coverage,
                'implementation_roadmap': self._create_mitigation_roadmap(threats),
                'cost_benefit_analysis': self._analyze_cost_benefit(threats),
                'quick_wins': self._identify_quick_wins(threats)
            },
            'compliance_impact': {
                'dashboard': compliance_dashboard,
                'gap_analysis': self._analyze_compliance_gaps(threats),
                'framework_mapping': self._map_compliance_frameworks(threats),
                'remediation_priority': self._prioritize_compliance_remediation(threats)
            },
            'attack_surface_analysis': {
                'attack_paths': attack_paths,
                'entry_points': self._identify_entry_points(components),
                'trust_boundaries': self._analyze_trust_boundaries_security(components),
                'lateral_movement_risks': self._analyze_lateral_movement(threats)
            },
            'security_controls': {
                'current_controls': controls_mapping,
                'control_gaps': self._identify_control_gaps(threats),
                'recommended_controls': self._recommend_security_controls(threats),
                'control_effectiveness': self._assess_control_effectiveness(threats)
            },
            'detailed_threats': [asdict(threat) for threat in threats],
            'recommendations': {
                'immediate_actions': self._get_immediate_actions(threats),
                'strategic_improvements': self._get_strategic_improvements(threats),
                'architecture_recommendations': self._get_architecture_recommendations(architecture_type, threats)
            }
        }
        
        return report
    
    def _calculate_stride_statistics(self, threats: List[STRIDEThreat]) -> Dict:
        """Calcula estatísticas por categoria STRIDE"""
        stats = {}
        
        for threat_type in STRIDEThreatType:
            type_threats = [t for t in threats if t.threat_type == threat_type]
            stats[threat_type.value] = {
                'total_count': len(type_threats),
                'avg_risk_score': round(sum(t.risk_score for t in type_threats) / len(type_threats), 1) if type_threats else 0,
                'max_risk_score': max(t.risk_score for t in type_threats) if type_threats else 0,
                'critical_count': len([t for t in type_threats if t.severity == ThreatSeverity.CRITICAL]),
                'high_count': len([t for t in type_threats if t.severity == ThreatSeverity.HIGH])
            }
        
        return stats
    
    def _analyze_mitigation_coverage(self, threats: List[STRIDEThreat]) -> Dict:
        """Analisa cobertura de estratégias de mitigação"""
        all_mitigations = []
        for threat in threats:
            all_mitigations.extend(threat.mitigation_strategies)
        
        # Contar frequência de cada mitigação
        mitigation_freq = {}
        for mitigation in all_mitigations:
            mitigation_freq[mitigation] = mitigation_freq.get(mitigation, 0) + 1
        
        # Classificar mitigações por categoria
        mitigation_categories = {
            'Technical': [],
            'Administrative': [],
            'Physical': []
        }
        
        technical_keywords = ['implement', 'configure', 'deploy', 'enable', 'install', 'encryption', 'firewall']
        administrative_keywords = ['policy', 'process', 'training', 'audit', 'governance', 'compliance']
        
        for mitigation, freq in mitigation_freq.items():
            mitigation_lower = mitigation.lower()
            if any(keyword in mitigation_lower for keyword in technical_keywords):
                mitigation_categories['Technical'].append({'mitigation': mitigation, 'frequency': freq})
            elif any(keyword in mitigation_lower for keyword in administrative_keywords):
                mitigation_categories['Administrative'].append({'mitigation': mitigation, 'frequency': freq})
            else:
                mitigation_categories['Technical'].append({'mitigation': mitigation, 'frequency': freq})
        
        return {
            'total_mitigations': len(set(all_mitigations)),
            'by_category': mitigation_categories,
            'most_common': sorted(mitigation_freq.items(), key=lambda x: x[1], reverse=True)[:10],
            'coverage_score': self._calculate_mitigation_coverage_score(threats)
        }
    
    def _calculate_mitigation_coverage_score(self, threats: List[STRIDEThreat]) -> float:
        """Calcula score de cobertura de mitigação"""
        total_threats = len(threats)
        threats_with_mitigations = len([t for t in threats if t.mitigation_strategies])
        
        if total_threats == 0:
            return 100.0
        
        return round((threats_with_mitigations / total_threats) * 100, 1)
    
    def _generate_risk_matrix(self, threats: List[STRIDEThreat]) -> Dict:
        """Gera matriz de risco (likelihood vs impact)"""
        matrix = {}
        
        for threat in threats:
            likelihood = threat.likelihood
            severity = threat.severity.value
            
            if likelihood not in matrix:
                matrix[likelihood] = {}
            
            if severity not in matrix[likelihood]:
                matrix[likelihood][severity] = []
            
            matrix[likelihood][severity].append({
                'id': threat.id,
                'component': threat.component,
                'risk_score': threat.risk_score,
                'threat_type': threat.threat_type.value
            })
        
        return matrix
    
    def _generate_compliance_dashboard(self, threats: List[STRIDEThreat]) -> Dict:
        """Gera dashboard de compliance"""
        compliance_impact = {}
        
        for threat in threats:
            for framework in threat.compliance_impact:
                if framework not in compliance_impact:
                    compliance_impact[framework] = {
                        'total_threats': 0,
                        'critical_threats': 0,
                        'high_threats': 0,
                        'avg_risk_score': 0,
                        'max_risk_score': 0,
                        'threat_types': set()
                    }
                
                impact = compliance_impact[framework]
                impact['total_threats'] += 1
                impact['max_risk_score'] = max(impact['max_risk_score'], threat.risk_score)
                impact['threat_types'].add(threat.threat_type.value)
                
                if threat.severity == ThreatSeverity.CRITICAL:
                    impact['critical_threats'] += 1
                elif threat.severity == ThreatSeverity.HIGH:
                    impact['high_threats'] += 1
        
        # Calcular médias e converter sets para listas
        for framework, impact in compliance_impact.items():
            if impact['total_threats'] > 0:
                framework_threats = [t for t in threats if framework in t.compliance_impact]
                impact['avg_risk_score'] = round(
                    sum(t.risk_score for t in framework_threats) / len(framework_threats), 1
                )
            impact['threat_types'] = list(impact['threat_types'])
        
        return compliance_impact
    
    def _analyze_attack_paths(self, threats: List[STRIDEThreat], 
                            components: List[CloudComponent]) -> List[Dict]:
        """Analisa possíveis caminhos de ataque"""
        attack_paths = []
        
        # Identificar componentes de entrada (internet-facing)
        entry_components = [
            comp for comp in components 
            if comp.category in ['networking', 'api_management'] or 
               'gateway' in comp.name.lower() or 'load balancer' in comp.name.lower()
        ]
        
        # Identificar componentes críticos (dados)
        critical_components = [
            comp for comp in components 
            if comp.category in ['database', 'storage']
        ]
        
        # Criar caminhos de ataque baseados em ameaças
        for entry in entry_components:
            for critical in critical_components:
                # Encontrar ameaças relacionadas
                related_threats = [
                    t for t in threats 
                    if t.component == entry.name or t.component == critical.name
                ]
                
                if related_threats:
                    path = {
                        'path_id': f"attack_path_{entry.name}_to_{critical.name}",
                        'entry_point': entry.name,
                        'target': critical.name,
                        'attack_steps': self._generate_attack_steps(entry, critical, related_threats),
                        'overall_risk': max(t.risk_score for t in related_threats),
                        'mitigations': self._consolidate_path_mitigations(related_threats),
                        'estimated_time_to_compromise': self._estimate_compromise_time(related_threats)
                    }
                    attack_paths.append(path)
        
        return sorted(attack_paths, key=lambda p: p['overall_risk'], reverse=True)
    
    def _generate_attack_steps(self, entry: CloudComponent, target: CloudComponent, 
                             threats: List[STRIDEThreat]) -> List[Dict]:
        """Gera passos de ataque para um caminho específico"""
        steps = []
        
        # Passo 1: Compromisso inicial (spoofing/authentication bypass)
        spoofing_threats = [t for t in threats if t.threat_type == STRIDEThreatType.SPOOFING]
        if spoofing_threats:
            steps.append({
                'step': 1,
                'description': f"Initial compromise via {entry.name}",
                'technique': spoofing_threats[0].attack_vector,
                'threat_id': spoofing_threats[0].id,
                'mitigations': spoofing_threats[0].mitigation_strategies[:3]
            })
        
        # Passo 2: Movimento lateral (elevation of privilege)
        elevation_threats = [t for t in threats if t.threat_type == STRIDEThreatType.ELEVATION_OF_PRIVILEGE]
        if elevation_threats:
            steps.append({
                'step': 2,
                'description': "Lateral movement and privilege escalation",
                'technique': elevation_threats[0].attack_vector,
                'threat_id': elevation_threats[0].id,
                'mitigations': elevation_threats[0].mitigation_strategies[:3]
            })
        
        # Passo 3: Acesso aos dados (information disclosure/tampering)
        data_threats = [t for t in threats if t.threat_type in [
            STRIDEThreatType.INFORMATION_DISCLOSURE, 
            STRIDEThreatType.TAMPERING
        ]]
        if data_threats:
            steps.append({
                'step': 3,
                'description': f"Access and compromise {target.name}",
                'technique': data_threats[0].attack_vector,
                'threat_id': data_threats[0].id,
                'mitigations': data_threats[0].mitigation_strategies[:3]
            })
        
        return steps
    
    def _consolidate_path_mitigations(self, threats: List[STRIDEThreat]) -> List[str]:
        """Consolida mitigações para um caminho de ataque"""
        all_mitigations = []
        for threat in threats:
            all_mitigations.extend(threat.mitigation_strategies)
        
        # Remove duplicatas e retorna top 5
        unique_mitigations = list(set(all_mitigations))
        return unique_mitigations[:5]
    
    def _estimate_compromise_time(self, threats: List[STRIDEThreat]) -> str:
        """Estima tempo para compromisso baseado nas ameaças"""
        max_risk = max(t.risk_score for t in threats) if threats else 0
        
        if max_risk >= 8.0:
            return "Minutes to Hours"
        elif max_risk >= 6.0:
            return "Hours to Days"
        elif max_risk >= 4.0:
            return "Days to Weeks"
        else:
            return "Weeks to Months"
    
    def _map_security_controls(self, threats: List[STRIDEThreat]) -> Dict:
        """Mapeia controles de segurança baseados nas ameaças"""
        controls = {
            'preventive': set(),
            'detective': set(),
            'corrective': set(),
            'deterrent': set()
        }
        
        for threat in threats:
            for mitigation in threat.mitigation_strategies:
                control_type = self._classify_control_type(mitigation)
                controls[control_type].add(mitigation)
            
            for detection in threat.detection_methods:
                controls['detective'].add(detection)
        
        # Converter sets para listas
        return {k: list(v) for k, v in controls.items()}
    
    def _classify_control_type(self, control: str) -> str:
        """Classifica tipo de controle de segurança"""
        control_lower = control.lower()
        
        if any(word in control_lower for word in ['implement', 'configure', 'deploy', 'enable']):
            return 'preventive'
        elif any(word in control_lower for word in ['monitor', 'detect', 'alert', 'log']):
            return 'detective'
        elif any(word in control_lower for word in ['backup', 'restore', 'recover', 'patch']):
            return 'corrective'
        else:
            return 'preventive'  # Default
    
    def _calculate_overall_risk_level(self, threats: List[STRIDEThreat]) -> str:
        """Calcula nível geral de risco"""
        if not threats:
            return "LOW"
        
        avg_risk = sum(t.risk_score for t in threats) / len(threats)
        critical_count = len([t for t in threats if t.severity == ThreatSeverity.CRITICAL])
        
        if critical_count > 0 or avg_risk >= 7.0:
            return "CRITICAL"
        elif avg_risk >= 5.0:
            return "HIGH"
        elif avg_risk >= 3.0:
            return "MEDIUM"
        else:
            return "LOW"
    
    def _calculate_risk_distribution(self, threats: List[STRIDEThreat]) -> Dict:
        """Calcula distribuição de riscos"""
        distribution = {
            'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0
        }
        
        for threat in threats:
            distribution[threat.severity.value] += 1
        
        total = len(threats)
        if total > 0:
            distribution_percent = {
                k: round((v / total) * 100, 1) for k, v in distribution.items()
            }
        else:
            distribution_percent = {k: 0 for k in distribution.keys()}
        
        return {
            'absolute': distribution,
            'percentage': distribution_percent
        }
    
    def _calculate_threat_coverage(self, threats: List[STRIDEThreat], 
                                 components: List[CloudComponent]) -> Dict:
        """Calcula cobertura de ameaças por componente"""
        component_threats = {}
        
        for threat in threats:
            if threat.component not in component_threats:
                component_threats[threat.component] = 0
            component_threats[threat.component] += 1
        
        total_components = len(components)
        covered_components = len(component_threats)
        
        coverage_percentage = (covered_components / total_components * 100) if total_components > 0 else 0
        
        return {
            'total_components': total_components,
            'covered_components': covered_components,
            'coverage_percentage': round(coverage_percentage, 1),
            'threats_per_component': component_threats,
            'uncovered_components': [
                comp.name for comp in components 
                if comp.name not in component_threats
            ]
        }
    
    def _calculate_overall_risk_score(self, threats: List[STRIDEThreat]) -> float:
        """Calcula score geral de risco"""
        if not threats:
            return 0.0
        
        # Weighted average baseado na severidade
        weights = {
            ThreatSeverity.CRITICAL: 5.0,
            ThreatSeverity.HIGH: 3.0,
            ThreatSeverity.MEDIUM: 2.0,
            ThreatSeverity.LOW: 1.0,
            ThreatSeverity.INFO: 0.5
        }
        
        total_weighted_score = 0
        total_weight = 0
        
        for threat in threats:
            weight = weights.get(threat.severity, 1.0)
            total_weighted_score += threat.risk_score * weight
            total_weight += weight
        
        return round(total_weighted_score / total_weight, 1) if total_weight > 0 else 0.0
    
    def _analyze_risk_appetite(self, threats: List[STRIDEThreat]) -> Dict:
        """Analisa apetite de risco baseado na distribuição de ameaças"""
        if not threats:
            return {
                'risk_appetite_level': 'LOW',
                'recommended_stance': 'Conservative',
                'risk_tolerance': 'Very Low',
                'justification': 'No threats identified'
            }
        
        # Calcular distribuição de severidade
        total_threats = len(threats)
        critical_count = len([t for t in threats if t.severity == ThreatSeverity.CRITICAL])
        high_count = len([t for t in threats if t.severity == ThreatSeverity.HIGH])
        
        critical_ratio = critical_count / total_threats
        high_ratio = high_count / total_threats
        
        # Determinar apetite de risco
        if critical_ratio > 0.3 or high_ratio > 0.5:
            risk_appetite = 'VERY_LOW'
            stance = 'Highly Conservative'
            tolerance = 'Minimal'
        elif critical_ratio > 0.1 or high_ratio > 0.3:
            risk_appetite = 'LOW'
            stance = 'Conservative'
            tolerance = 'Low'
        elif critical_ratio > 0.05 or high_ratio > 0.2:
            risk_appetite = 'MODERATE'
            stance = 'Balanced'
            tolerance = 'Moderate'
        else:
            risk_appetite = 'MODERATE_HIGH'
            stance = 'Risk Aware'
            tolerance = 'Moderate to High'
        
        return {
            'risk_appetite_level': risk_appetite,
            'recommended_stance': stance,
            'risk_tolerance': tolerance,
            'critical_threat_ratio': round(critical_ratio * 100, 1),
            'high_threat_ratio': round(high_ratio * 100, 1),
            'justification': f"{critical_count} critical and {high_count} high threats out of {total_threats} total"
        }
    
    def _create_prioritization_matrix(self, threats: List[STRIDEThreat]) -> Dict:
        """Cria matriz de priorização baseada em impacto vs facilidade de implementação"""
        matrix = {
            'quick_wins': [],      # High Impact, Low Effort
            'major_projects': [],  # High Impact, High Effort  
            'fill_ins': [],        # Low Impact, Low Effort
            'questionable': []     # Low Impact, High Effort
        }
        
        for threat in threats:
            impact_score = self._calculate_business_impact(threat)
            effort_score = self._estimate_mitigation_effort_score(threat)
            
            item = {
                'threat_id': threat.id,
                'component': threat.component,
                'threat_type': threat.threat_type.value,
                'impact_score': impact_score,
                'effort_score': effort_score,
                'risk_score': threat.risk_score
            }
            
            if impact_score >= 7 and effort_score <= 4:
                matrix['quick_wins'].append(item)
            elif impact_score >= 7 and effort_score > 4:
                matrix['major_projects'].append(item)
            elif impact_score < 7 and effort_score <= 4:
                matrix['fill_ins'].append(item)
            else:
                matrix['questionable'].append(item)
        
        # Ordenar cada categoria por risk score
        for category in matrix:
            matrix[category].sort(key=lambda x: x['risk_score'], reverse=True)
        
        return matrix
    
    def _calculate_business_impact(self, threat: STRIDEThreat) -> float:
        """Calcula impacto de negócio de uma ameaça"""
        base_impact = {
            ThreatSeverity.CRITICAL: 10,
            ThreatSeverity.HIGH: 8,
            ThreatSeverity.MEDIUM: 5,
            ThreatSeverity.LOW: 3,
            ThreatSeverity.INFO: 1
        }.get(threat.severity, 5)
        
        # Ajustar baseado no tipo de ameaça
        if threat.threat_type == STRIDEThreatType.INFORMATION_DISCLOSURE:
            base_impact *= 1.2  # Vazamento de dados tem alto impacto
        elif threat.threat_type == STRIDEThreatType.DENIAL_OF_SERVICE:
            base_impact *= 1.1  # Indisponibilidade impacta negócio
        
        # Ajustar baseado em compliance
        if len(threat.compliance_impact) > 2:
            base_impact *= 1.1  # Múltiplos frameworks afetados
        
        return min(10, base_impact)
    
    def _estimate_mitigation_effort_score(self, threat: STRIDEThreat) -> float:
        """Estima esforço para mitigar uma ameaça (1-10, onde 10 = muito esforço)"""
        # Esforço baseado no tipo de mitigação
        effort_keywords = {
            'implement': 6,
            'configure': 3,
            'enable': 2,
            'deploy': 5,
            'establish': 7,
            'develop': 8,
            'migrate': 9,
            'replace': 8
        }
        
        total_effort = 0
        mitigation_count = len(threat.mitigation_strategies)
        
        for mitigation in threat.mitigation_strategies:
            mitigation_lower = mitigation.lower()
            for keyword, effort in effort_keywords.items():
                if keyword in mitigation_lower:
                    total_effort += effort
                    break
            else:
                total_effort += 5  # Esforço médio se não encontrar keyword
        
        avg_effort = total_effort / mitigation_count if mitigation_count > 0 else 5
        return min(10, avg_effort)
    
    def _analyze_compliance_gaps(self, threats: List[STRIDEThreat]) -> Dict:
        """Analisa gaps de compliance baseado nas ameaças"""
        framework_gaps = {}
        
        for threat in threats:
            for framework in threat.compliance_impact:
                if framework not in framework_gaps:
                    framework_gaps[framework] = {
                        'total_gaps': 0,
                        'critical_gaps': 0,
                        'high_gaps': 0,
                        'affected_threat_types': set(),
                        'remediation_effort': 0
                    }
                
                gap = framework_gaps[framework]
                gap['total_gaps'] += 1
                gap['affected_threat_types'].add(threat.threat_type.value)
                gap['remediation_effort'] += self._estimate_mitigation_effort_score(threat)
                
                if threat.severity == ThreatSeverity.CRITICAL:
                    gap['critical_gaps'] += 1
                elif threat.severity == ThreatSeverity.HIGH:
                    gap['high_gaps'] += 1
        
        # Converter sets para listas e calcular scores
        for framework, gap_data in framework_gaps.items():
            gap_data['affected_threat_types'] = list(gap_data['affected_threat_types'])
            gap_data['avg_remediation_effort'] = gap_data['remediation_effort'] / gap_data['total_gaps']
            gap_data['compliance_risk_score'] = (
                gap_data['critical_gaps'] * 3 + 
                gap_data['high_gaps'] * 2 + 
                gap_data['total_gaps']
            )
        
        return framework_gaps
    
    def _map_compliance_frameworks(self, threats: List[STRIDEThreat]) -> Dict:
        """Mapeia ameaças para frameworks de compliance"""
        framework_mapping = {
            'NIST_CSF': {
                'identify': [],
                'protect': [],
                'detect': [],
                'respond': [],
                'recover': []
            },
            'ISO_27001': {
                'A.5': [],   # Information security policies
                'A.9': [],   # Access control
                'A.10': [],  # Cryptography
                'A.12': [],  # Operations security
                'A.13': [],  # Communications security
                'A.16': []   # Incident management
            },
            'OWASP': {
                'authentication': [],
                'authorization': [],
                'data_validation': [],
                'error_handling': [],
                'logging': []
            }
        }
        
        for threat in threats:
            # Mapear para NIST CSF
            if threat.threat_type == STRIDEThreatType.SPOOFING:
                framework_mapping['NIST_CSF']['identify'].append(threat.id)
                framework_mapping['NIST_CSF']['protect'].append(threat.id)
            elif threat.threat_type == STRIDEThreatType.INFORMATION_DISCLOSURE:
                framework_mapping['NIST_CSF']['protect'].append(threat.id)
            elif threat.threat_type == STRIDEThreatType.DENIAL_OF_SERVICE:
                framework_mapping['NIST_CSF']['respond'].append(threat.id)
            
            # Mapear para ISO 27001
            if 'authentication' in threat.description.lower():
                framework_mapping['ISO_27001']['A.9'].append(threat.id)
            if 'encryption' in threat.description.lower():
                framework_mapping['ISO_27001']['A.10'].append(threat.id)
            if 'logging' in threat.description.lower():
                framework_mapping['ISO_27001']['A.12'].append(threat.id)
            
            # Mapear para OWASP
            if threat.threat_type == STRIDEThreatType.SPOOFING:
                framework_mapping['OWASP']['authentication'].append(threat.id)
            elif threat.threat_type == STRIDEThreatType.ELEVATION_OF_PRIVILEGE:
                framework_mapping['OWASP']['authorization'].append(threat.id)
        
        return framework_mapping
    
    def _prioritize_compliance_remediation(self, threats: List[STRIDEThreat]) -> List[Dict]:
        """Prioriza remediação baseada em compliance"""
        compliance_priority = []
        
        # Agrupar por framework de compliance
        by_framework = {}
        for threat in threats:
            for framework in threat.compliance_impact:
                if framework not in by_framework:
                    by_framework[framework] = []
                by_framework[framework].append(threat)
        
        # Calcular prioridade por framework
        for framework, framework_threats in by_framework.items():
            critical_count = len([t for t in framework_threats if t.severity == ThreatSeverity.CRITICAL])
            total_risk = sum(t.risk_score for t in framework_threats)
            avg_risk = total_risk / len(framework_threats)
            
            priority_item = {
                'framework': framework,
                'total_threats': len(framework_threats),
                'critical_threats': critical_count,
                'average_risk_score': round(avg_risk, 1),
                'total_risk_exposure': round(total_risk, 1),
                'priority_score': critical_count * 3 + avg_risk,
                'recommended_timeline': self._get_remediation_timeline(critical_count, avg_risk)
            }
            
            compliance_priority.append(priority_item)
        
        # Ordenar por priority score
        compliance_priority.sort(key=lambda x: x['priority_score'], reverse=True)
        
        return compliance_priority
    
    def _get_remediation_timeline(self, critical_count: int, avg_risk: float) -> str:
        """Determina timeline de remediação baseado em criticidade"""
        if critical_count > 0 or avg_risk >= 8.0:
            return "Immediate (0-30 days)"
        elif avg_risk >= 6.0:
            return "Short-term (30-90 days)"
        elif avg_risk >= 4.0:
            return "Medium-term (90-180 days)"
        else:
            return "Long-term (180+ days)"
    
    def _identify_entry_points(self, components: List[CloudComponent]) -> List[Dict]:
        """Identifica pontos de entrada na arquitetura"""
        entry_points = []
        
        # Identificar componentes expostos à internet
        internet_facing = [
            'API Gateway', 'Application Gateway', 'Load Balancer', 'ALB', 'NLB',
            'CloudFront', 'CDN', 'API Management'
        ]
        
        for component in components:
            if any(service in component.name for service in internet_facing):
                entry_point = {
                    'component': component.name,
                    'provider': component.provider.value,
                    'category': component.category,
                    'exposure_level': 'Internet',
                    'attack_surface': 'High',
                    'security_priority': 'Critical'
                }
                entry_points.append(entry_point)
        
        # Identificar outros pontos críticos
        critical_services = ['Database', 'Storage', 'Active Directory', 'IAM']
        
        for component in components:
            if any(service in component.name for service in critical_services):
                entry_point = {
                    'component': component.name,
                    'provider': component.provider.value,
                    'category': component.category,
                    'exposure_level': 'Internal',
                    'attack_surface': 'Medium',
                    'security_priority': 'High'
                }
                entry_points.append(entry_point)
        
        return entry_points
    
    def _analyze_trust_boundaries_security(self, components: List[CloudComponent]) -> Dict:
        """Analisa segurança dos trust boundaries"""
        boundaries = {
            'internet_to_dmz': {
                'components': [],
                'security_controls': [],
                'risk_level': 'High',
                'recommendations': []
            },
            'dmz_to_internal': {
                'components': [],
                'security_controls': [],
                'risk_level': 'Medium',
                'recommendations': []
            },
            'internal_to_data': {
                'components': [],
                'security_controls': [],
                'risk_level': 'High',
                'recommendations': []
            }
        }
        
        # Classificar componentes por boundary
        for component in components:
            if component.category in ['networking', 'api_management']:
                boundaries['internet_to_dmz']['components'].append(component.name)
            elif component.category in ['compute', 'integration']:
                boundaries['dmz_to_internal']['components'].append(component.name)
            elif component.category in ['database', 'storage']:
                boundaries['internal_to_data']['components'].append(component.name)
        
        # Adicionar recomendações
        boundaries['internet_to_dmz']['recommendations'] = [
            'Implement Web Application Firewall (WAF)',
            'Configure DDoS protection',
            'Enable rate limiting',
            'Use strong authentication'
        ]
        
        boundaries['dmz_to_internal']['recommendations'] = [
            'Implement network segmentation',
            'Use least privilege access',
            'Enable monitoring and logging',
            'Deploy intrusion detection'
        ]
        
        boundaries['internal_to_data']['recommendations'] = [
            'Encrypt data at rest and in transit',
            'Implement database activity monitoring',
            'Use strong access controls',
            'Regular backup and recovery testing'
        ]
        
        return boundaries
    
    def _analyze_lateral_movement(self, threats: List[STRIDEThreat]) -> List[Dict]:
        """Analisa riscos de movimento lateral"""
        lateral_risks = []
        
        # Identificar ameaças que podem levar a movimento lateral
        movement_indicators = [
            'privilege', 'escalation', 'lateral', 'movement', 'compromise',
            'container', 'kubernetes', 'service', 'network'
        ]
        
        for threat in threats:
            description_lower = threat.description.lower()
            if any(indicator in description_lower for indicator in movement_indicators):
                risk = {
                    'threat_id': threat.id,
                    'component': threat.component,
                    'threat_type': threat.threat_type.value,
                    'risk_score': threat.risk_score,
                    'movement_vector': self._identify_movement_vector(threat),
                    'potential_targets': self._identify_potential_targets(threat),
                    'containment_strategies': threat.mitigation_strategies[:3]
                }
                lateral_risks.append(risk)
        
        # Ordenar por risk score
        lateral_risks.sort(key=lambda x: x['risk_score'], reverse=True)
        
        return lateral_risks
    
    def _identify_movement_vector(self, threat: STRIDEThreat) -> str:
        """Identifica vetor de movimento lateral"""
        description = threat.description.lower()
        
        if 'container' in description or 'kubernetes' in description:
            return 'Container Escape'
        elif 'service' in description:
            return 'Service-to-Service'
        elif 'network' in description:
            return 'Network Traversal'
        elif 'privilege' in description:
            return 'Privilege Escalation'
        else:
            return 'Unknown Vector'
    
    def _identify_potential_targets(self, threat: STRIDEThreat) -> List[str]:
        """Identifica potenciais alvos do movimento lateral"""
        # Baseado no componente e tipo de ameaça
        component_lower = threat.component.lower()
        
        if 'api' in component_lower or 'gateway' in component_lower:
            return ['Backend Services', 'Databases', 'Internal APIs']
        elif 'kubernetes' in component_lower or 'container' in component_lower:
            return ['Other Pods', 'Host System', 'Cluster Resources']
        elif 'lambda' in component_lower:
            return ['Other Functions', 'VPC Resources', 'IAM Roles']
        else:
            return ['Adjacent Services', 'Shared Resources']
    
    def _identify_control_gaps(self, threats: List[STRIDEThreat]) -> List[Dict]:
        """Identifica gaps nos controles de segurança"""
        control_gaps = []
        
        # Analisar mitigações faltantes por categoria
        required_controls = {
            'authentication': ['Multi-factor authentication', 'Strong password policy', 'Token validation'],
            'authorization': ['Role-based access control', 'Least privilege', 'Regular access review'],
            'encryption': ['Data at rest encryption', 'Data in transit encryption', 'Key management'],
            'monitoring': ['Security logging', 'Real-time monitoring', 'Incident response'],
            'network': ['Network segmentation', 'Firewall rules', 'Intrusion detection']
        }
        
        for category, controls in required_controls.items():
            category_threats = [
                t for t in threats 
                if category in ' '.join(t.mitigation_strategies).lower()
            ]
            
            if category_threats:
                gap = {
                    'control_category': category,
                    'affected_threats': len(category_threats),
                    'missing_controls': [],
                    'implementation_priority': self._calculate_control_priority(category_threats)
                }
                
                # Identificar controles específicos que estão faltando
                all_mitigations = ' '.join([
                    ' '.join(t.mitigation_strategies) for t in category_threats
                ]).lower()
                
                for control in controls:
                    if control.lower() not in all_mitigations:
                        gap['missing_controls'].append(control)
                
                if gap['missing_controls']:
                    control_gaps.append(gap)
        
        return control_gaps
    
    def _calculate_control_priority(self, threats: List[STRIDEThreat]) -> str:
        """Calcula prioridade de implementação de controle"""
        if not threats:
            return 'Low'
        
        avg_risk = sum(t.risk_score for t in threats) / len(threats)
        critical_count = len([t for t in threats if t.severity == ThreatSeverity.CRITICAL])
        
        if critical_count > 0 or avg_risk >= 8.0:
            return 'Critical'
        elif avg_risk >= 6.0:
            return 'High'
        elif avg_risk >= 4.0:
            return 'Medium'
        else:
            return 'Low'
    
    def _recommend_security_controls(self, threats: List[STRIDEThreat]) -> List[str]:
        """Recomenda controles de segurança baseado nas ameaças"""
        recommendations = set()
        
        # Análise por tipo de ameaça
        threat_types = [t.threat_type for t in threats]
        
        if STRIDEThreatType.SPOOFING in threat_types:
            recommendations.update([
                'Implement multi-factor authentication (MFA)',
                'Deploy certificate-based authentication',
                'Configure strong password policies',
                'Enable account lockout mechanisms'
            ])
        
        if STRIDEThreatType.TAMPERING in threat_types:
            recommendations.update([
                'Implement digital signatures for critical data',
                'Enable integrity monitoring',
                'Deploy file integrity monitoring (FIM)',
                'Use checksums for data validation'
            ])
        
        if STRIDEThreatType.REPUDIATION in threat_types:
            recommendations.update([
                'Implement comprehensive audit logging',
                'Deploy Security Information and Event Management (SIEM)',
                'Enable non-repudiation mechanisms',
                'Configure log integrity protection'
            ])
        
        if STRIDEThreatType.INFORMATION_DISCLOSURE in threat_types:
            recommendations.update([
                'Implement data loss prevention (DLP)',
                'Enable field-level encryption',
                'Deploy data classification and labeling',
                'Configure privacy controls and data masking'
            ])
        
        if STRIDEThreatType.DENIAL_OF_SERVICE in threat_types:
            recommendations.update([
                'Implement rate limiting and throttling',
                'Deploy DDoS protection services',
                'Configure auto-scaling capabilities',
                'Enable circuit breaker patterns'
            ])
        
        if STRIDEThreatType.ELEVATION_OF_PRIVILEGE in threat_types:
            recommendations.update([
                'Implement least privilege access controls',
                'Deploy privileged access management (PAM)',
                'Enable just-in-time (JIT) access',
                'Configure regular access reviews'
            ])
        
        return list(recommendations)
    
    def _assess_control_effectiveness(self, threats: List[STRIDEThreat]) -> Dict:
        """Avalia efetividade dos controles atuais"""
        effectiveness = {
            'overall_score': 0,
            'control_coverage': {},
            'gaps_identified': 0,
            'improvement_areas': []
        }
        
        if not threats:
            effectiveness['overall_score'] = 100
            return effectiveness
        
        # Calcular cobertura por categoria STRIDE
        for threat_type in STRIDEThreatType:
            type_threats = [t for t in threats if t.threat_type == threat_type]
            if type_threats:
                avg_risk = sum(t.risk_score for t in type_threats) / len(type_threats)
                # Inverter o score (menos risco = mais efetividade)
                effectiveness_score = max(0, 100 - (avg_risk * 10))
                effectiveness['control_coverage'][threat_type.value] = round(effectiveness_score, 1)
        
        # Score geral
        if effectiveness['control_coverage']:
            overall = sum(effectiveness['control_coverage'].values()) / len(effectiveness['control_coverage'])
            effectiveness['overall_score'] = round(overall, 1)
        
        # Identificar áreas de melhoria
        for threat_type, score in effectiveness['control_coverage'].items():
            if score < 70:
                effectiveness['improvement_areas'].append({
                    'area': threat_type,
                    'current_score': score,
                    'recommended_actions': f"Strengthen {threat_type} controls"
                })
        
        effectiveness['gaps_identified'] = len(effectiveness['improvement_areas'])
        
        return effectiveness
    
    def _create_mitigation_roadmap(self, threats: List[STRIDEThreat]) -> Dict:
        """Cria roadmap de implementação de mitigações"""
        roadmap = {
            'phase_1_immediate': {'duration': '0-30 days', 'items': []},
            'phase_2_short_term': {'duration': '30-90 days', 'items': []},
            'phase_3_medium_term': {'duration': '90-180 days', 'items': []},
            'phase_4_long_term': {'duration': '180+ days', 'items': []}
        }
        
        for threat in threats:
            # Determinar fase baseada na severidade e risk score
            if threat.severity == ThreatSeverity.CRITICAL or threat.risk_score >= 8.0:
                phase = 'phase_1_immediate'
            elif threat.severity == ThreatSeverity.HIGH or threat.risk_score >= 6.0:
                phase = 'phase_2_short_term'
            elif threat.severity == ThreatSeverity.MEDIUM or threat.risk_score >= 4.0:
                phase = 'phase_3_medium_term'
            else:
                phase = 'phase_4_long_term'
            
            # Criar item do roadmap
            roadmap_item = {
                'threat_id': threat.id,
                'component': threat.component,
                'threat_type': threat.threat_type.value,
                'description': threat.description,
                'risk_score': threat.risk_score,
                'mitigation_strategies': threat.mitigation_strategies[:3],  # Top 3
                'estimated_effort': self._estimate_implementation_effort(threat),
                'business_justification': self._create_business_justification(threat)
            }
            
            roadmap[phase]['items'].append(roadmap_item)
        
        # Ordenar itens por risk score dentro de cada fase
        for phase in roadmap:
            roadmap[phase]['items'].sort(key=lambda x: x['risk_score'], reverse=True)
        
        return roadmap
    
    def _estimate_implementation_effort(self, threat: STRIDEThreat) -> str:
        """Estima esforço de implementação"""
        effort_score = self._estimate_mitigation_effort_score(threat)
        
        if effort_score <= 3:
            return 'LOW'
        elif effort_score <= 6:
            return 'MEDIUM'
        elif effort_score <= 8:
            return 'HIGH'
        else:
            return 'VERY_HIGH'
    
    def _create_business_justification(self, threat: STRIDEThreat) -> str:
        """Cria justificativa de negócio para mitigação"""
        justifications = []
        
        # Justificativa baseada na severidade
        if threat.severity == ThreatSeverity.CRITICAL:
            justifications.append("Critical security vulnerability requiring immediate attention")
        elif threat.severity == ThreatSeverity.HIGH:
            justifications.append("High-risk security issue with significant business impact")
        
        # Justificativa baseada em compliance
        if threat.compliance_impact:
            frameworks = ', '.join(threat.compliance_impact[:3])
            justifications.append(f"Required for compliance with {frameworks}")
        
        # Justificativa baseada no tipo de ameaça
        if threat.threat_type == STRIDEThreatType.INFORMATION_DISCLOSURE:
            justifications.append("Prevents data breaches and privacy violations")
        elif threat.threat_type == STRIDEThreatType.DENIAL_OF_SERVICE:
            justifications.append("Ensures business continuity and service availability")
        
        return '; '.join(justifications) if justifications else "Improves overall security posture"
    
    def _analyze_cost_benefit(self, threats: List[STRIDEThreat]) -> Dict:
        """Analisa custo-benefício das mitigações"""
        analysis = {
            'total_estimated_cost': 0,
            'potential_savings': 0,
            'roi_timeframe_months': 12,
            'cost_breakdown': {
                'immediate_actions': 0,
                'short_term_projects': 0,
                'medium_term_initiatives': 0,
                'long_term_investments': 0
            },
            'risk_reduction_value': 0
        }
        
        for threat in threats:
            # Estimar custo baseado na complexidade da mitigação
            mitigation_cost = self._estimate_mitigation_cost(threat)
            
            # Categorizar por timeframe
            if threat.severity == ThreatSeverity.CRITICAL:
                analysis['cost_breakdown']['immediate_actions'] += mitigation_cost
            elif threat.severity == ThreatSeverity.HIGH:
                analysis['cost_breakdown']['short_term_projects'] += mitigation_cost
            elif threat.severity == ThreatSeverity.MEDIUM:
                analysis['cost_breakdown']['medium_term_initiatives'] += mitigation_cost
            else:
                analysis['cost_breakdown']['long_term_investments'] += mitigation_cost
            
            # Calcular valor da redução de risco
            risk_value = threat.risk_score * 1000  # $1000 por ponto de risco
            analysis['risk_reduction_value'] += risk_value
        
        analysis['total_estimated_cost'] = sum(analysis['cost_breakdown'].values())
        analysis['potential_savings'] = analysis['risk_reduction_value'] * 0.8  # 80% da redução de risco
        
        return analysis
    
    def _estimate_mitigation_cost(self, threat: STRIDEThreat) -> float:
        """Estima custo de mitigação de uma ameaça"""
        base_cost = {
            ThreatSeverity.CRITICAL: 15000,
            ThreatSeverity.HIGH: 10000,
            ThreatSeverity.MEDIUM: 5000,
            ThreatSeverity.LOW: 2000,
            ThreatSeverity.INFO: 500
        }.get(threat.severity, 5000)
        
        # Ajustar baseado no número de mitigações
        mitigation_count = len(threat.mitigation_strategies)
        cost_multiplier = 1 + (mitigation_count - 1) * 0.3
        
        # Ajustar baseado na complexidade (palavras-chave)
        complex_keywords = ['implement', 'deploy', 'establish', 'develop', 'migrate']
        complexity_factor = 1.0
        
        for mitigation in threat.mitigation_strategies:
            if any(keyword in mitigation.lower() for keyword in complex_keywords):
                complexity_factor += 0.2
        
        final_cost = base_cost * cost_multiplier * complexity_factor
        return round(final_cost, 2)
    
    def _identify_quick_wins(self, threats: List[STRIDEThreat]) -> List[Dict]:
        """Identifica quick wins (alto impacto, baixo esforço)"""
        quick_wins = []
        
        for threat in threats:
            impact_score = self._calculate_business_impact(threat)
            effort_score = self._estimate_mitigation_effort_score(threat)
            
            # Quick win: impacto >= 6 e esforço <= 4
            if impact_score >= 6 and effort_score <= 4:
                quick_win = {
                    'threat_id': threat.id,
                    'component': threat.component,
                    'threat_type': threat.threat_type.value,
                    'description': threat.description,
                    'impact_score': impact_score,
                    'effort_score': effort_score,
                    'risk_score': threat.risk_score,
                    'primary_mitigation': threat.mitigation_strategies[0] if threat.mitigation_strategies else 'Not specified',
                    'estimated_timeline': '1-2 weeks',
                    'business_value': f"High security improvement with minimal effort"
                }
                quick_wins.append(quick_win)
        
        # Ordenar por impacto/esforço ratio
        quick_wins.sort(key=lambda x: x['impact_score'] / max(x['effort_score'], 1), reverse=True)
        
        return quick_wins[:10]  # Top 10 quick wins
    
    def _get_immediate_actions(self, threats: List[STRIDEThreat]) -> List[Dict]:
        """Obtém ações imediatas (0-30 dias)"""
        immediate_actions = []
        
        # Filtrar ameaças críticas e de alto risco
        critical_threats = [
            t for t in threats 
            if t.severity == ThreatSeverity.CRITICAL or t.risk_score >= 8.0
        ]
        
        for threat in critical_threats[:5]:  # Top 5 ações imediatas
            action = {
                'priority': 'CRITICAL',
                'component': threat.component,
                'threat_type': threat.threat_type.value,
                'description': f"Address {threat.threat_type.value} vulnerability in {threat.component}",
                'specific_action': threat.mitigation_strategies[0] if threat.mitigation_strategies else 'Investigate and remediate',
                'risk_score': threat.risk_score,
                'timeline': '0-15 days',
                'owner': 'Security Team',
                'success_criteria': f"Risk score reduced below 6.0"
            }
            immediate_actions.append(action)
        
        return immediate_actions
    
    def _get_strategic_improvements(self, threats: List[STRIDEThreat]) -> List[Dict]:
        """Obtém melhorias estratégicas de longo prazo"""
        strategic_improvements = []
        
        # Analisar padrões de ameaças para identificar melhorias sistêmicas
        threat_patterns = {}
        for threat in threats:
            category = threat.threat_type.value
            if category not in threat_patterns:
                threat_patterns[category] = []
            threat_patterns[category].append(threat)
        
        # Gerar melhorias estratégicas baseadas nos padrões
        for category, category_threats in threat_patterns.items():
            if len(category_threats) >= 2:  # Múltiplas ameaças da mesma categoria
                avg_risk = sum(t.risk_score for t in category_threats) / len(category_threats)
                
                improvement = {
                    'area': category.title(),
                    'description': f"Systematic improvement of {category} security controls",
                    'affected_threats': len(category_threats),
                    'average_risk_score': round(avg_risk, 1),
                    'strategic_value': 'High',
                    'timeline': '3-6 months',
                    'investment_required': 'Medium to High',
                    'expected_outcome': f"Comprehensive {category} protection across all components"
                }
                strategic_improvements.append(improvement)
        
        # Adicionar melhorias arquiteturais gerais
        if len(threats) > 10:
            strategic_improvements.append({
                'area': 'Security Architecture',
                'description': 'Implement comprehensive security architecture review and enhancement',
                'affected_threats': len(threats),
                'average_risk_score': sum(t.risk_score for t in threats) / len(threats),
                'strategic_value': 'Very High',
                'timeline': '6-12 months',
                'investment_required': 'High',
                'expected_outcome': 'Systematic reduction of security risks across entire architecture'
            })
        
        return strategic_improvements
    
    def _get_architecture_recommendations(self, architecture_type: ArchitectureType, 
                                        threats: List[STRIDEThreat]) -> List[Dict]:
        """Obtém recomendações específicas por tipo de arquitetura"""
        recommendations = []
        
        if architecture_type == ArchitectureType.API_GATEWAY:
            recommendations.extend([
                {
                    'category': 'API Security',
                    'recommendation': 'Implement comprehensive API security framework',
                    'details': 'Deploy API gateway with OAuth 2.0, rate limiting, and input validation',
                    'priority': 'HIGH',
                    'timeline': '30-60 days'
                },
                {
                    'category': 'Monitoring',
                    'recommendation': 'Establish API monitoring and analytics',
                    'details': 'Real-time API usage monitoring, anomaly detection, and security analytics',
                    'priority': 'MEDIUM',
                    'timeline': '60-90 days'
                }
            ])
        
        elif architecture_type == ArchitectureType.MICROSERVICES:
            recommendations.extend([
                {
                    'category': 'Service Mesh',
                    'recommendation': 'Deploy service mesh for secure service-to-service communication',
                    'details': 'Implement Istio or Linkerd for mTLS, traffic management, and observability',
                    'priority': 'HIGH',
                    'timeline': '45-90 days'
                },
                {
                    'category': 'Container Security',
                    'recommendation': 'Implement comprehensive container security',
                    'details': 'Image scanning, runtime protection, and Kubernetes security policies',
                    'priority': 'HIGH',
                    'timeline': '30-60 days'
                }
            ])
        
        elif architecture_type == ArchitectureType.HYBRID_CLOUD:
            recommendations.extend([
                {
                    'category': 'Identity Federation',
                    'recommendation': 'Establish unified identity and access management',
                    'details': 'Single sign-on (SSO) and identity federation across cloud providers',
                    'priority': 'CRITICAL',
                    'timeline': '60-120 days'
                },
                {
                    'category': 'Data Governance',
                    'recommendation': 'Implement cross-cloud data governance',
                    'details': 'Consistent data classification, encryption, and compliance policies',
                    'priority': 'HIGH',
                    'timeline': '90-180 days'
                }
            ])
        
        # Adicionar recomendações baseadas em ameaças específicas
        high_risk_threats = [t for t in threats if t.risk_score >= 7.0]
        if len(high_risk_threats) > 5:
            recommendations.append({
                'category': 'Risk Management',
                'recommendation': 'Establish formal risk management program',
                'details': 'Regular threat assessments, risk monitoring, and incident response procedures',
                'priority': 'HIGH',
                'timeline': '90-180 days'
            })
        
        return recommendations