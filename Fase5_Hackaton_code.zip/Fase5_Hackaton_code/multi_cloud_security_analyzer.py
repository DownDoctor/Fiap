#!/usr/bin/env python3
"""
Multi-Cloud Security Analyzer
Analisa diagramas de arquitetura de múltiplos provedores de nuvem
Suporta: AWS, Azure, Google Cloud, Kubernetes, APIs, Microserviços
"""

import cv2
import pytesseract
import re
import json
import logging
from PIL import Image
import numpy as np
from dataclasses import dataclass, asdict
from typing import List, Dict, Tuple, Set, Optional
from pathlib import Path
import argparse
from datetime import datetime
from enum import Enum
from abc import ABC, abstractmethod

# Configuração de logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

class CloudProvider(Enum):
    """Enum para provedores de nuvem"""
    AWS = "aws"
    AZURE = "azure"
    GCP = "gcp"
    KUBERNETES = "kubernetes"
    GENERIC = "generic"
    API_MANAGEMENT = "api"
    MICROSERVICES = "microservices"

class ArchitectureType(Enum):
    """Enum para tipos de arquitetura"""
    CLOUD_NATIVE = "cloud_native"
    MICROSERVICES = "microservices"
    API_GATEWAY = "api_gateway"
    SERVERLESS = "serverless"
    CONTAINER_ORCHESTRATION = "container_orchestration"
    HYBRID_CLOUD = "hybrid_cloud"
    DATA_PLATFORM = "data_platform"

@dataclass
class SecurityGap:
    """Representa um gap de segurança identificado"""
    service: str
    provider: CloudProvider
    gap_type: str
    severity: str  # CRITICAL, HIGH, MEDIUM, LOW
    description: str
    recommendation: str
    compliance_impact: List[str]
    architecture_type: Optional[ArchitectureType] = None

@dataclass
class CloudComponent:
    """Representa um componente de nuvem detectado"""
    name: str
    service_type: str
    provider: CloudProvider
    location: Tuple[int, int]
    confidence: float
    properties: Dict[str, str]
    category: str  # compute, storage, networking, security, etc.

class ServiceDetectorBase(ABC):
    """Classe base para detectores de serviços"""
    
    @abstractmethod
    def detect_services(self, text: str) -> List[CloudComponent]:
        """Detecta serviços no texto extraído"""
        pass
    
    @abstractmethod
    def get_provider(self) -> CloudProvider:
        """Retorna o provedor de nuvem"""
        pass

class AWSServiceDetector(ServiceDetectorBase):
    """Detector específico para serviços AWS"""
    
    def __init__(self):
        self.aws_services = {
            # Compute
            'EC2': ['ec2', 'elastic compute', 'instance'],
            'Lambda': ['lambda', 'serverless'],
            'ECS': ['ecs', 'container service'],
            'EKS': ['eks', 'kubernetes'],
            'Fargate': ['fargate'],
            
            # Storage
            'S3': ['s3', 'simple storage'],
            'EBS': ['ebs', 'elastic block'],
            'EFS': ['efs', 'elastic file'],
            'FSx': ['fsx'],
            
            # Database
            'RDS': ['rds', 'relational database'],
            'DynamoDB': ['dynamodb', 'dynamo'],
            'ElastiCache': ['elasticache', 'redis', 'memcached'],
            'DocumentDB': ['documentdb'],
            'Neptune': ['neptune'],
            
            # Networking
            'VPC': ['vpc', 'virtual private cloud'],
            'ALB': ['alb', 'application load balancer'],
            'NLB': ['nlb', 'network load balancer'],
            'CloudFront': ['cloudfront', 'cdn'],
            'Route53': ['route53', 'dns'],
            'API Gateway': ['api gateway', 'api gw'],
            'Direct Connect': ['direct connect', 'dx'],
            
            # Security
            'IAM': ['iam', 'identity access'],
            'WAF': ['waf', 'web application firewall'],
            'Shield': ['shield', 'ddos'],
            'KMS': ['kms', 'key management'],
            'CloudTrail': ['cloudtrail', 'audit'],
            'GuardDuty': ['guardduty', 'threat detection'],
            'Security Hub': ['security hub'],
            'Cognito': ['cognito', 'authentication'],
            
            # Monitoring
            'CloudWatch': ['cloudwatch', 'monitoring'],
            'Config': ['config', 'compliance'],
            'X-Ray': ['x-ray', 'tracing'],
            
            # Application Services
            'SQS': ['sqs', 'simple queue'],
            'SNS': ['sns', 'notification'],
            'SES': ['ses', 'email service'],
            'EventBridge': ['eventbridge', 'event'],
            
            # Others
            'Auto Scaling': ['auto scaling', 'asg'],
            'Backup': ['backup', 'aws backup'],
            'CodePipeline': ['codepipeline', 'ci/cd'],
            'CodeBuild': ['codebuild'],
            'CodeDeploy': ['codedeploy']
        }
    
    def get_provider(self) -> CloudProvider:
        return CloudProvider.AWS
    
    def detect_services(self, text: str) -> List[CloudComponent]:
        """Detecta serviços AWS no texto"""
        return self._detect_services_generic(text, self.aws_services, CloudProvider.AWS)
    
    def _detect_services_generic(self, text: str, services_dict: Dict, provider: CloudProvider) -> List[CloudComponent]:
        """Método genérico para detecção de serviços"""
        detected = []
        text_lower = text.lower()
        
        for service, keywords in services_dict.items():
            for keyword in keywords:
                if keyword in text_lower:
                    location = (0, 0)  # Em implementação real, usar coordenadas OCR
                    confidence = 0.9 if keyword == service.lower() else 0.7
                    
                    component = CloudComponent(
                        name=service,
                        service_type=self._categorize_service(service),
                        provider=provider,
                        location=location,
                        confidence=confidence,
                        properties={},
                        category=self._get_service_category(service)
                    )
                    detected.append(component)
                    break
        
        return self._deduplicate_components(detected)
    
    def _categorize_service(self, service: str) -> str:
        """Categoriza o serviço"""
        categories = {
            'compute': ['EC2', 'Lambda', 'ECS', 'EKS', 'Fargate'],
            'storage': ['S3', 'EBS', 'EFS', 'FSx'],
            'database': ['RDS', 'DynamoDB', 'ElastiCache', 'DocumentDB', 'Neptune'],
            'networking': ['VPC', 'ALB', 'NLB', 'CloudFront', 'Route53', 'API Gateway', 'Direct Connect'],
            'security': ['IAM', 'WAF', 'Shield', 'KMS', 'CloudTrail', 'GuardDuty', 'Security Hub', 'Cognito'],
            'monitoring': ['CloudWatch', 'Config', 'X-Ray'],
            'application': ['SQS', 'SNS', 'SES', 'EventBridge', 'Auto Scaling', 'Backup'],
            'devops': ['CodePipeline', 'CodeBuild', 'CodeDeploy']
        }
        
        for category, services in categories.items():
            if service in services:
                return category
        return 'other'
    
    def _get_service_category(self, service: str) -> str:
        """Retorna categoria do serviço para análise"""
        return self._categorize_service(service)
    
    def _deduplicate_components(self, components: List[CloudComponent]) -> List[CloudComponent]:
        """Remove componentes duplicados"""
        seen = set()
        unique_components = []
        
        for component in components:
            key = (component.name, component.provider)
            if key not in seen:
                seen.add(key)
                unique_components.append(component)
        
        return unique_components

class AzureServiceDetector(ServiceDetectorBase):
    """Detector específico para serviços Azure"""
    
    def __init__(self):
        self.azure_services = {
            # Compute
            'Virtual Machines': ['virtual machines', 'vm', 'azure vm'],
            'App Service': ['app service', 'web app'],
            'Functions': ['azure functions', 'functions'],
            'Container Instances': ['container instances', 'aci'],
            'Kubernetes Service': ['aks', 'kubernetes service'],
            'Service Fabric': ['service fabric'],
            
            # Storage
            'Storage Account': ['storage account', 'blob storage'],
            'Files': ['azure files'],
            'Data Lake': ['data lake'],
            'Managed Disks': ['managed disks'],
            
            # Database
            'SQL Database': ['sql database', 'azure sql'],
            'Cosmos DB': ['cosmos db', 'cosmosdb'],
            'Redis Cache': ['redis cache'],
            'MySQL': ['azure mysql'],
            'PostgreSQL': ['azure postgresql'],
            
            # Networking
            'Virtual Network': ['virtual network', 'vnet'],
            'Load Balancer': ['load balancer', 'azure lb'],
            'Application Gateway': ['application gateway', 'app gateway'],
            'VPN Gateway': ['vpn gateway'],
            'ExpressRoute': ['expressroute'],
            'CDN': ['azure cdn'],
            'DNS': ['azure dns'],
            'API Management': ['api management', 'apim'],
            
            # Security
            'Active Directory': ['active directory', 'azure ad', 'aad'],
            'Key Vault': ['key vault'],
            'Security Center': ['security center'],
            'Sentinel': ['azure sentinel'],
            'Firewall': ['azure firewall'],
            
            # Monitoring
            'Monitor': ['azure monitor'],
            'Log Analytics': ['log analytics'],
            'Application Insights': ['application insights'],
            
            # Integration
            'Logic Apps': ['logic apps'],
            'Service Bus': ['service bus'],
            'Event Grid': ['event grid'],
            'Event Hubs': ['event hubs'],
            
            # DevOps
            'DevOps': ['azure devops'],
            'Pipelines': ['azure pipelines'],
            'Repos': ['azure repos']
        }
    
    def get_provider(self) -> CloudProvider:
        return CloudProvider.AZURE
    
    def detect_services(self, text: str) -> List[CloudComponent]:
        """Detecta serviços Azure no texto"""
        detected = []
        text_lower = text.lower()
        
        for service, keywords in self.azure_services.items():
            for keyword in keywords:
                if keyword in text_lower:
                    location = (0, 0)
                    confidence = 0.9 if keyword == service.lower() else 0.7
                    
                    component = CloudComponent(
                        name=service,
                        service_type=self._categorize_azure_service(service),
                        provider=CloudProvider.AZURE,
                        location=location,
                        confidence=confidence,
                        properties={},
                        category=self._get_azure_category(service)
                    )
                    detected.append(component)
                    break
        
        return self._deduplicate_components(detected)
    
    def _categorize_azure_service(self, service: str) -> str:
        """Categoriza serviços Azure"""
        categories = {
            'compute': ['Virtual Machines', 'App Service', 'Functions', 'Container Instances', 'Kubernetes Service', 'Service Fabric'],
            'storage': ['Storage Account', 'Files', 'Data Lake', 'Managed Disks'],
            'database': ['SQL Database', 'Cosmos DB', 'Redis Cache', 'MySQL', 'PostgreSQL'],
            'networking': ['Virtual Network', 'Load Balancer', 'Application Gateway', 'VPN Gateway', 'ExpressRoute', 'CDN', 'DNS', 'API Management'],
            'security': ['Active Directory', 'Key Vault', 'Security Center', 'Sentinel', 'Firewall'],
            'monitoring': ['Monitor', 'Log Analytics', 'Application Insights'],
            'integration': ['Logic Apps', 'Service Bus', 'Event Grid', 'Event Hubs'],
            'devops': ['DevOps', 'Pipelines', 'Repos']
        }
        
        for category, services in categories.items():
            if service in services:
                return category
        return 'other'
    
    def _get_azure_category(self, service: str) -> str:
        return self._categorize_azure_service(service)
    
    def _deduplicate_components(self, components: List[CloudComponent]) -> List[CloudComponent]:
        """Remove componentes duplicados"""
        seen = set()
        unique_components = []
        
        for component in components:
            key = (component.name, component.provider)
            if key not in seen:
                seen.add(key)
                unique_components.append(component)
        
        return unique_components

class APIServiceDetector(ServiceDetectorBase):
    """Detector para arquiteturas de API e microserviços"""
    
    def __init__(self):
        self.api_services = {
            # API Management
            'API Gateway': ['api gateway', 'gateway'],
            'API Management': ['api management', 'apim'],
            'Developer Portal': ['developer portal', 'dev portal'],
            'OAuth': ['oauth', 'authentication', 'auth'],
            'JWT': ['jwt', 'token'],
            
            # Microservices
            'Microservice': ['microservice', 'micro service'],
            'Service Mesh': ['service mesh', 'istio', 'linkerd'],
            'Load Balancer': ['load balancer', 'lb'],
            'Reverse Proxy': ['reverse proxy', 'nginx', 'envoy'],
            
            # Containers
            'Docker': ['docker', 'container'],
            'Kubernetes': ['kubernetes', 'k8s'],
            'Pod': ['pod'],
            'Service': ['service', 'svc'],
            'Ingress': ['ingress'],
            'ConfigMap': ['configmap'],
            'Secret': ['secret'],
            
            # Communication
            'REST API': ['rest api', 'rest', 'restful'],
            'GraphQL': ['graphql', 'gql'],
            'gRPC': ['grpc'],
            'WebSocket': ['websocket', 'ws'],
            'Message Queue': ['message queue', 'mq', 'queue'],
            'Event Bus': ['event bus', 'event'],
            
            # Data
            'Database': ['database', 'db'],
            'Cache': ['cache', 'redis', 'memcached'],
            'Data Store': ['data store', 'datastore'],
            
            # Security
            'TLS/SSL': ['tls', 'ssl', 'https'],
            'CORS': ['cors'],
            'Rate Limiting': ['rate limiting', 'throttling'],
            'Circuit Breaker': ['circuit breaker'],
            
            # Monitoring
            'Logging': ['logging', 'logs'],
            'Monitoring': ['monitoring', 'metrics'],
            'Tracing': ['tracing', 'trace'],
            'Health Check': ['health check', 'healthcheck']
        }
    
    def get_provider(self) -> CloudProvider:
        return CloudProvider.API_MANAGEMENT
    
    def detect_services(self, text: str) -> List[CloudComponent]:
        """Detecta componentes de API/microserviços"""
        detected = []
        text_lower = text.lower()
        
        for service, keywords in self.api_services.items():
            for keyword in keywords:
                if keyword in text_lower:
                    location = (0, 0)
                    confidence = 0.8
                    
                    component = CloudComponent(
                        name=service,
                        service_type=self._categorize_api_service(service),
                        provider=CloudProvider.API_MANAGEMENT,
                        location=location,
                        confidence=confidence,
                        properties={},
                        category=self._get_api_category(service)
                    )
                    detected.append(component)
                    break
        
        return self._deduplicate_components(detected)
    
    def _categorize_api_service(self, service: str) -> str:
        """Categoriza serviços de API"""
        categories = {
            'api_management': ['API Gateway', 'API Management', 'Developer Portal'],
            'authentication': ['OAuth', 'JWT'],
            'microservices': ['Microservice', 'Service Mesh'],
            'networking': ['Load Balancer', 'Reverse Proxy'],
            'containers': ['Docker', 'Kubernetes', 'Pod', 'Service', 'Ingress', 'ConfigMap', 'Secret'],
            'communication': ['REST API', 'GraphQL', 'gRPC', 'WebSocket', 'Message Queue', 'Event Bus'],
            'data': ['Database', 'Cache', 'Data Store'],
            'security': ['TLS/SSL', 'CORS', 'Rate Limiting', 'Circuit Breaker'],
            'monitoring': ['Logging', 'Monitoring', 'Tracing', 'Health Check']
        }
        
        for category, services in categories.items():
            if service in services:
                return category
        return 'other'
    
    def _get_api_category(self, service: str) -> str:
        return self._categorize_api_service(service)
    
    def _deduplicate_components(self, components: List[CloudComponent]) -> List[CloudComponent]:
        """Remove componentes duplicados"""
        seen = set()
        unique_components = []
        
        for component in components:
            key = (component.name, component.provider)
            if key not in seen:
                seen.add(key)
                unique_components.append(component)
        
        return unique_components

class MultiCloudServiceDetector:
    """Detector que combina múltiplos provedores"""
    
    def __init__(self):
        self.detectors = [
            AWSServiceDetector(),
            AzureServiceDetector(),
            APIServiceDetector()
        ]
    
    def detect_all_services(self, text: str) -> List[CloudComponent]:
        """Detecta serviços de todos os provedores"""
        all_components = []
        
        for detector in self.detectors:
            components = detector.detect_services(text)
            all_components.extend(components)
        
        return all_components
    
    def identify_architecture_type(self, components: List[CloudComponent]) -> ArchitectureType:
        """Identifica o tipo de arquitetura baseado nos componentes"""
        providers = set(comp.provider for comp in components)
        service_types = set(comp.service_type for comp in components)
        
        # Lógica para identificar tipo de arquitetura
        if CloudProvider.API_MANAGEMENT in providers:
            return ArchitectureType.API_GATEWAY
        
        if len(providers) > 1:
            return ArchitectureType.HYBRID_CLOUD
        
        if 'containers' in service_types or 'microservices' in service_types:
            return ArchitectureType.MICROSERVICES
        
        if 'serverless' in service_types:
            return ArchitectureType.SERVERLESS
        
        return ArchitectureType.CLOUD_NATIVE

class SecurityRulesEngineMultiCloud:
    """Motor de regras de segurança para múltiplas nuvens"""
    
    def __init__(self):
        self.aws_rules = self._get_aws_rules()
        self.azure_rules = self._get_azure_rules()
        self.api_rules = self._get_api_rules()
        self.general_rules = self._get_general_rules()
    
    def _get_aws_rules(self) -> Dict:
        """Regras específicas para AWS"""
        return {
            'ALB': {
                'subnet_type': 'public',
                'encryption': 'TLS 1.2+',
                'access_logs': True
            },
            'RDS': {
                'encryption_at_rest': True,
                'multi_az': True,
                'backup_retention': '>=7_days'
            },
            'S3': {
                'encryption': True,
                'versioning': True,
                'public_access_block': True
            }
        }
    
    def _get_azure_rules(self) -> Dict:
        """Regras específicas para Azure"""
        return {
            'Application Gateway': {
                'ssl_termination': True,
                'waf_enabled': True,
                'https_only': True
            },
            'SQL Database': {
                'transparent_encryption': True,
                'firewall_rules': True,
                'threat_detection': True
            },
            'Storage Account': {
                'secure_transfer': True,
                'encryption_at_rest': True,
                'access_tier_optimization': True
            },
            'Active Directory': {
                'mfa_enabled': True,
                'conditional_access': True,
                'privileged_access': True
            }
        }
    
    def _get_api_rules(self) -> Dict:
        """Regras para arquiteturas de API"""
        return {
            'API Gateway': {
                'authentication': True,
                'rate_limiting': True,
                'input_validation': True,
                'https_only': True
            },
            'REST API': {
                'authentication': True,
                'authorization': True,
                'input_validation': True,
                'output_encoding': True
            },
            'Microservice': {
                'service_mesh': True,
                'circuit_breaker': True,
                'health_checks': True,
                'logging': True
            },
            'OAuth': {
                'token_validation': True,
                'scope_limitation': True,
                'refresh_token_rotation': True
            }
        }
    
    def _get_general_rules(self) -> Dict:
        """Regras gerais aplicáveis a qualquer arquitetura"""
        return {
            'encryption_in_transit': True,
            'encryption_at_rest': True,
            'access_control': True,
            'monitoring_logging': True,
            'backup_strategy': True,
            'incident_response': True,
            'compliance_framework': True
        }
    
    def analyze_security_gaps(self, components: List[CloudComponent], 
                            architecture_type: ArchitectureType) -> List[SecurityGap]:
        """Analisa gaps de segurança para múltiplas nuvens"""
        gaps = []
        
        # Analisar por provedor
        aws_components = [c for c in components if c.provider == CloudProvider.AWS]
        azure_components = [c for c in components if c.provider == CloudProvider.AZURE]
        api_components = [c for c in components if c.provider == CloudProvider.API_MANAGEMENT]
        
        # Gaps AWS
        gaps.extend(self._analyze_aws_gaps(aws_components, architecture_type))
        
        # Gaps Azure
        gaps.extend(self._analyze_azure_gaps(azure_components, architecture_type))
        
        # Gaps API/Microserviços
        gaps.extend(self._analyze_api_gaps(api_components, architecture_type))
        
        # Gaps arquiteturais gerais
        gaps.extend(self._analyze_architectural_gaps(components, architecture_type))
        
        return gaps
    
    def _analyze_aws_gaps(self, components: List[CloudComponent], 
                         arch_type: ArchitectureType) -> List[SecurityGap]:
        """Analisa gaps específicos do AWS"""
        gaps = []
        service_names = [c.name for c in components]
        
        if 'ALB' in service_names:
            gaps.append(SecurityGap(
                service='ALB',
                provider=CloudProvider.AWS,
                gap_type='network_configuration',
                severity='CRITICAL',
                description='ALB pode estar em subnet privada',
                recommendation='Verificar se ALB está em subnet pública',
                compliance_impact=['SOC 2', 'AWS Well-Architected'],
                architecture_type=arch_type
            ))
        
        if 'API Gateway' in service_names and 'WAF' not in service_names:
            gaps.append(SecurityGap(
                service='API Gateway',
                provider=CloudProvider.AWS,
                gap_type='ddos_protection',
                severity='HIGH',
                description='API Gateway sem proteção WAF',
                recommendation='Implementar AWS WAF no API Gateway',
                compliance_impact=['PCI DSS', 'SOC 2'],
                architecture_type=arch_type
            ))
        
        return gaps
    
    def _analyze_azure_gaps(self, components: List[CloudComponent], 
                           arch_type: ArchitectureType) -> List[SecurityGap]:
        """Analisa gaps específicos do Azure"""
        gaps = []
        service_names = [c.name for c in components]
        
        if 'API Management' in service_names:
            gaps.append(SecurityGap(
                service='API Management',
                provider=CloudProvider.AZURE,
                gap_type='authentication',
                severity='HIGH',
                description='Azure API Management requer configuração de autenticação robusta',
                recommendation='Implementar Azure AD B2C ou OAuth 2.0 com políticas de acesso',
                compliance_impact=['GDPR', 'SOC 2', 'ISO 27001'],
                architecture_type=arch_type
            ))
        
        if 'Logic Apps' in service_names:
            gaps.append(SecurityGap(
                service='Logic Apps',
                provider=CloudProvider.AZURE,
                gap_type='workflow_security',
                severity='MEDIUM',
                description='Logic Apps requer controle de acesso e auditoria',
                recommendation='Configurar RBAC e logging detalhado para workflows',
                compliance_impact=['SOC 2', 'ISO 27001'],
                architecture_type=arch_type
            ))
        
        return gaps
    
    def _analyze_api_gaps(self, components: List[CloudComponent], 
                         arch_type: ArchitectureType) -> List[SecurityGap]:
        """Analisa gaps em arquiteturas de API"""
        gaps = []
        service_names = [c.name for c in components]
        
        if 'API Gateway' in service_names:
            if 'Rate Limiting' not in service_names:
                gaps.append(SecurityGap(
                    service='API Gateway',
                    provider=CloudProvider.API_MANAGEMENT,
                    gap_type='rate_limiting',
                    severity='HIGH',
                    description='API Gateway sem rate limiting configurado',
                    recommendation='Implementar rate limiting para prevenir ataques DDoS',
                    compliance_impact=['OWASP API Security', 'PCI DSS'],
                    architecture_type=arch_type
                ))
        
        if 'REST API' in service_names:
            if 'OAuth' not in service_names and 'JWT' not in service_names:
                gaps.append(SecurityGap(
                    service='REST API',
                    provider=CloudProvider.API_MANAGEMENT,
                    gap_type='authentication',
                    severity='CRITICAL',
                    description='APIs REST sem autenticação adequada',
                    recommendation='Implementar OAuth 2.0 ou JWT para autenticação de APIs',
                    compliance_impact=['OWASP API Security', 'GDPR', 'PCI DSS'],
                    architecture_type=arch_type
                ))
        
        if 'Microservice' in service_names:
            if 'Service Mesh' not in service_names:
                gaps.append(SecurityGap(
                    service='Microservice',
                    provider=CloudProvider.MICROSERVICES,
                    gap_type='service_communication',
                    severity='MEDIUM',
                    description='Microserviços sem service mesh para comunicação segura',
                    recommendation='Implementar service mesh (Istio/Linkerd) para mTLS automático',
                    compliance_impact=['Zero Trust Architecture'],
                    architecture_type=arch_type
                ))
        
        return gaps
    
    def _analyze_architectural_gaps(self, components: List[CloudComponent], 
                                  arch_type: ArchitectureType) -> List[SecurityGap]:
        """Analisa gaps arquiteturais gerais"""
        gaps = []
        providers = set(c.provider for c in components)
        
        # Multi-cloud sem governança
        if len(providers) > 1:
            gaps.append(SecurityGap(
                service='Multi-Cloud Architecture',
                provider=CloudProvider.GENERIC,
                gap_type='governance',
                severity='HIGH',
                description='Arquitetura multi-cloud sem governança unificada',
                recommendation='Implementar ferramentas de governança centralizada e políticas consistentes',
                compliance_impact=['SOC 2', 'ISO 27001', 'NIST'],
                architecture_type=arch_type
            ))
        
        # API Gateway sem monitoramento adequado
        if arch_type == ArchitectureType.API_GATEWAY:
            monitoring_services = ['Monitoring', 'CloudWatch', 'Application Insights']
            if not any(c.name in monitoring_services for c in components):
                gaps.append(SecurityGap(
                    service='Monitoring',
                    provider=CloudProvider.GENERIC,
                    gap_type='observability',
                    severity='MEDIUM',
                    description='Arquitetura de API sem monitoramento abrangente',
                    recommendation='Implementar APM, logging centralizado e alertas proativos',
                    compliance_impact=['SOC 2', 'ITIL'],
                    architecture_type=arch_type
                ))
        
        return gaps

class MultiCloudImageProcessor:
    """Processador de imagens para múltiplas arquiteturas"""
    
    def __init__(self):
        self.detector = MultiCloudServiceDetector()
    
    def extract_text_from_image(self, image_path: str) -> str:
        """Extrai texto da imagem com OCR otimizado"""
        try:
            image = cv2.imread(image_path)
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Pré-processamento otimizado para diagramas
            denoised = cv2.fastNlMeansDenoising(gray)
            
            # Detectar texto em diferentes orientações
            configs = [
                '--psm 6',  # Bloco uniforme de texto
                '--psm 8',  # Palavra única
                '--psm 13'  # Linha de texto crua
            ]
            
            extracted_texts = []
            for config in configs:
                try:
                    text = pytesseract.image_to_string(denoised, config=config)
                    if text.strip():
                        extracted_texts.append(text)
                except:
                    continue
            
            # Combinar textos extraídos
            combined_text = ' '.join(extracted_texts)
            
            logger.info(f"Texto extraído da imagem: {len(combined_text)} caracteres")
            return combined_text
            
        except Exception as e:
            logger.error(f"Erro ao processar imagem: {e}")
            return ""
    
    def detect_cloud_components(self, image_path: str) -> Tuple[List[CloudComponent], ArchitectureType]:
        """Detecta componentes de nuvem na imagem"""
        text = self.extract_text_from_image(image_path)
        components = self.detector.detect_all_services(text)
        architecture_type = self.detector.identify_architecture_type(components)
        
        logger.info(f"Componentes detectados: {[(c.name, c.provider.value) for c in components]}")
        logger.info(f"Tipo de arquitetura identificado: {architecture_type.value}")
        
        return components, architecture_type

class MultiCloudReportGenerator:
    """Gerador de relatórios para múltiplas arquiteturas"""
    
    def generate_security_report(self, components: List[CloudComponent], 
                               gaps: List[SecurityGap], 
                               architecture_type: ArchitectureType) -> Dict:
        """Gera relatório completo multi-cloud"""
        
        # Calcular score de segurança
        security_score = self._calculate_security_score(gaps)
        
        # Agrupar por provedor e severidade
        gaps_by_provider = self._group_gaps_by_provider(gaps)
        gaps_by_severity = self._group_gaps_by_severity(gaps)
        components_by_provider = self._group_components_by_provider(components)
        
        # Estatísticas detalhadas
        stats = {
            'total_components': len(components),
            'total_gaps': len(gaps),
            'critical_gaps': len(gaps_by_severity.get('CRITICAL', [])),
            'high_gaps': len(gaps_by_severity.get('HIGH', [])),
            'medium_gaps': len(gaps_by_severity.get('MEDIUM', [])),
            'low_gaps': len(gaps_by_severity.get('LOW', [])),
            'security_score': security_score,
            'architecture_type': architecture_type.value,
            'providers_detected': list(set(comp.provider.value for comp in components)),
            'provider_distribution': {
                provider.value: len(comps) 
                for provider, comps in components_by_provider.items()
            }
        }
        
        # Análise de maturidade por provedor
        maturity_analysis = self._analyze_security_maturity(gaps_by_provider)
        
        # Recomendações por arquitetura
        architecture_recommendations = self._get_architecture_specific_recommendations(
            architecture_type, components, gaps
        )
        
        # Roadmap de implementação
        implementation_roadmap = self._create_implementation_roadmap(gaps)
        
        report = {
            'timestamp': datetime.now().isoformat(),
            'architecture_analysis': {
                'type': architecture_type.value,
                'description': self._get_architecture_description(architecture_type),
                'complexity_score': self._calculate_complexity_score(components),
                'multi_cloud': len(set(comp.provider for comp in components)) > 1
            },
            'summary': stats,
            'components_detected': [asdict(comp) for comp in components],
            'components_by_provider': {
                provider.value: [asdict(comp) for comp in comps]
                for provider, comps in components_by_provider.items()
            },
            'security_gaps': [asdict(gap) for gap in gaps],
            'gaps_by_provider': {
                provider.value: [asdict(gap) for gap in gap_list]
                for provider, gap_list in gaps_by_provider.items()
            },
            'gaps_by_severity': {
                severity: [asdict(gap) for gap in gap_list]
                for severity, gap_list in gaps_by_severity.items()
            },
            'security_maturity': maturity_analysis,
            'architecture_recommendations': architecture_recommendations,
            'implementation_roadmap': implementation_roadmap,
            'compliance_impact': self._analyze_compliance_impact(gaps),
            'cost_impact_estimation': self._estimate_cost_impact(gaps, components)
        }
        
        return report
    
    def _calculate_security_score(self, gaps: List[SecurityGap]) -> int:
        """Calcula score de segurança considerando diferentes tipos de arquitetura"""
        if not gaps:
            return 100
        
        severity_weights = {'CRITICAL': 30, 'HIGH': 20, 'MEDIUM': 10, 'LOW': 5}
        
        # Peso adicional por tipo de gap
        gap_type_weights = {
            'authentication': 1.5,
            'encryption': 1.4,
            'network_configuration': 1.3,
            'access_control': 1.2,
            'monitoring': 1.1
        }
        
        total_penalty = 0
        for gap in gaps:
            base_penalty = severity_weights.get(gap.severity, 0)
            type_multiplier = gap_type_weights.get(gap.gap_type, 1.0)
            total_penalty += base_penalty * type_multiplier
        
        score = max(0, 100 - total_penalty)
        return min(100, int(score))
    
    def _group_gaps_by_provider(self, gaps: List[SecurityGap]) -> Dict[CloudProvider, List[SecurityGap]]:
        """Agrupa gaps por provedor de nuvem"""
        grouped = {}
        for gap in gaps:
            if gap.provider not in grouped:
                grouped[gap.provider] = []
            grouped[gap.provider].append(gap)
        return grouped
    
    def _group_gaps_by_severity(self, gaps: List[SecurityGap]) -> Dict[str, List[SecurityGap]]:
        """Agrupa gaps por severidade"""
        grouped = {}
        for gap in gaps:
            if gap.severity not in grouped:
                grouped[gap.severity] = []
            grouped[gap.severity].append(gap)
        return grouped
    
    def _group_components_by_provider(self, components: List[CloudComponent]) -> Dict[CloudProvider, List[CloudComponent]]:
        """Agrupa componentes por provedor"""
        grouped = {}
        for comp in components:
            if comp.provider not in grouped:
                grouped[comp.provider] = []
            grouped[comp.provider].append(comp)
        return grouped
    
    def _analyze_security_maturity(self, gaps_by_provider: Dict[CloudProvider, List[SecurityGap]]) -> Dict:
        """Analisa maturidade de segurança por provedor"""
        maturity = {}
        
        for provider, gaps in gaps_by_provider.items():
            critical_count = len([g for g in gaps if g.severity == 'CRITICAL'])
            high_count = len([g for g in gaps if g.severity == 'HIGH'])
            total_gaps = len(gaps)
            
            if total_gaps == 0:
                maturity_level = "OPTIMIZED"
                score = 95
            elif critical_count > 0:
                maturity_level = "BASIC"
                score = 40
            elif high_count > 2:
                maturity_level = "DEVELOPING"
                score = 60
            elif total_gaps <= 3:
                maturity_level = "DEFINED"
                score = 80
            else:
                maturity_level = "MANAGED"
                score = 70
            
            maturity[provider.value] = {
                'level': maturity_level,
                'score': score,
                'total_gaps': total_gaps,
                'critical_gaps': critical_count,
                'high_gaps': high_count,
                'recommendations': self._get_maturity_recommendations(maturity_level)
            }
        
        return maturity
    
    def _get_maturity_recommendations(self, level: str) -> List[str]:
        """Retorna recomendações baseadas no nível de maturidade"""
        recommendations = {
            'BASIC': [
                'Implementar controles fundamentais de segurança',
                'Estabelecer políticas básicas de acesso',
                'Configurar logging e monitoramento essencial'
            ],
            'DEVELOPING': [
                'Automatizar controles de segurança',
                'Implementar testes de segurança automatizados',
                'Estabelecer processos de resposta a incidentes'
            ],
            'DEFINED': [
                'Otimizar controles existentes',
                'Implementar análise avançada de ameaças',
                'Estabelecer métricas de segurança'
            ],
            'MANAGED': [
                'Implementar inteligência artificial para detecção',
                'Estabelecer programa de melhoria contínua',
                'Integrar segurança em toda a organização'
            ],
            'OPTIMIZED': [
                'Manter excelência operacional',
                'Compartilhar melhores práticas',
                'Inovar em novas tecnologias de segurança'
            ]
        }
        return recommendations.get(level, [])
    
    def _get_architecture_description(self, arch_type: ArchitectureType) -> str:
        """Retorna descrição da arquitetura"""
        descriptions = {
            ArchitectureType.API_GATEWAY: "Arquitetura centrada em API Gateway para gerenciamento de APIs e microserviços",
            ArchitectureType.MICROSERVICES: "Arquitetura de microserviços com serviços distribuídos e comunicação inter-serviços",
            ArchitectureType.CLOUD_NATIVE: "Arquitetura nativa da nuvem aproveitando serviços gerenciados",
            ArchitectureType.SERVERLESS: "Arquitetura serverless com funções como serviço",
            ArchitectureType.HYBRID_CLOUD: "Arquitetura híbrida combinando múltiplos provedores de nuvem",
            ArchitectureType.CONTAINER_ORCHESTRATION: "Arquitetura baseada em containers com orquestração",
            ArchitectureType.DATA_PLATFORM: "Plataforma de dados com pipelines e analytics"
        }
        return descriptions.get(arch_type, "Arquitetura não classificada")
    
    def _calculate_complexity_score(self, components: List[CloudComponent]) -> int:
        """Calcula score de complexidade da arquitetura"""
        base_score = len(components) * 2
        provider_count = len(set(comp.provider for comp in components))
        category_count = len(set(comp.category for comp in components))
        
        complexity = base_score + (provider_count * 5) + (category_count * 3)
        return min(100, complexity)
    
    def _get_architecture_specific_recommendations(self, arch_type: ArchitectureType, 
                                                 components: List[CloudComponent], 
                                                 gaps: List[SecurityGap]) -> List[Dict]:
        """Retorna recomendações específicas por tipo de arquitetura"""
        recommendations = []
        
        if arch_type == ArchitectureType.API_GATEWAY:
            recommendations.extend([
                {
                    'category': 'API Security',
                    'priority': 'HIGH',
                    'recommendation': 'Implementar OWASP API Security Top 10',
                    'details': 'Focar em autenticação, autorização, rate limiting e validação de entrada'
                },
                {
                    'category': 'API Monitoring',
                    'priority': 'MEDIUM',
                    'recommendation': 'Implementar observabilidade completa de APIs',
                    'details': 'Logs estruturados, métricas de performance e distributed tracing'
                }
            ])
        
        if arch_type == ArchitectureType.MICROSERVICES:
            recommendations.extend([
                {
                    'category': 'Service Mesh',
                    'priority': 'HIGH',
                    'recommendation': 'Implementar service mesh para comunicação segura',
                    'details': 'mTLS automático, políticas de rede e observabilidade entre serviços'
                },
                {
                    'category': 'Container Security',
                    'priority': 'HIGH',
                    'recommendation': 'Implementar security scanning de containers',
                    'details': 'Scan de vulnerabilidades, políticas de segurança e runtime protection'
                }
            ])
        
        if arch_type == ArchitectureType.HYBRID_CLOUD:
            recommendations.extend([
                {
                    'category': 'Multi-Cloud Governance',
                    'priority': 'CRITICAL',
                    'recommendation': 'Estabelecer governança unificada',
                    'details': 'Políticas consistentes, identidade federada e monitoramento centralizado'
                }
            ])
        
        return recommendations
    
    def _create_implementation_roadmap(self, gaps: List[SecurityGap]) -> Dict:
        """Cria roadmap de implementação baseado em gaps"""
        roadmap = {
            'phase_1_immediate': {'duration': '0-30 days', 'items': []},
            'phase_2_short_term': {'duration': '30-90 days', 'items': []},
            'phase_3_medium_term': {'duration': '90-180 days', 'items': []},
            'phase_4_long_term': {'duration': '180+ days', 'items': []}
        }
        
        for gap in gaps:
            item = {
                'service': gap.service,
                'provider': gap.provider.value,
                'description': gap.description,
                'recommendation': gap.recommendation,
                'effort': self._estimate_implementation_effort(gap),
                'cost_estimate': self._estimate_implementation_cost(gap)
            }
            
            # Priorização baseada em severidade
            if gap.severity == 'CRITICAL':
                roadmap['phase_1_immediate']['items'].append(item)
            elif gap.severity == 'HIGH':
                roadmap['phase_2_short_term']['items'].append(item)
            elif gap.severity == 'MEDIUM':
                roadmap['phase_3_medium_term']['items'].append(item)
            else:
                roadmap['phase_4_long_term']['items'].append(item)
        
        return roadmap
    
    def _estimate_implementation_effort(self, gap: SecurityGap) -> str:
        """Estima esforço de implementação"""
        effort_map = {
            'CRITICAL': 'HIGH',
            'HIGH': 'MEDIUM',
            'MEDIUM': 'LOW',
            'LOW': 'MINIMAL'
        }
        return effort_map.get(gap.severity, 'MEDIUM')
    
    def _estimate_implementation_cost(self, gap: SecurityGap) -> str:
        """Estima custo de implementação"""
        if gap.gap_type in ['authentication', 'encryption']:
            return 'MEDIUM'
        elif gap.gap_type in ['monitoring', 'logging']:
            return 'LOW'
        elif gap.gap_type in ['network_configuration', 'governance']:
            return 'HIGH'
        else:
            return 'MEDIUM'
    
    def _analyze_compliance_impact(self, gaps: List[SecurityGap]) -> Dict:
        """Analisa impacto em frameworks de compliance"""
        compliance_count = {}
        compliance_severity = {}
        
        for gap in gaps:
            for framework in gap.compliance_impact:
                if framework not in compliance_count:
                    compliance_count[framework] = 0
                    compliance_severity[framework] = []
                
                compliance_count[framework] += 1
                compliance_severity[framework].append(gap.severity)
        
        # Calcular risk score por framework
        compliance_analysis = {}
        for framework, count in compliance_count.items():
            severities = compliance_severity[framework]
            critical_count = severities.count('CRITICAL')
            high_count = severities.count('HIGH')
            
            risk_score = (critical_count * 4) + (high_count * 2) + count
            
            compliance_analysis[framework] = {
                'affected_controls': count,
                'critical_gaps': critical_count,
                'high_gaps': high_count,
                'risk_score': risk_score,
                'compliance_status': self._get_compliance_status(risk_score)
            }
        
        return dict(sorted(compliance_analysis.items(), 
                          key=lambda x: x[1]['risk_score'], reverse=True))
    
    def _get_compliance_status(self, risk_score: int) -> str:
        """Determina status de compliance baseado no risk score"""
        if risk_score >= 10:
            return 'NON_COMPLIANT'
        elif risk_score >= 6:
            return 'PARTIALLY_COMPLIANT'
        elif risk_score >= 3:
            return 'MOSTLY_COMPLIANT'
        else:
            return 'COMPLIANT'
    
    def _estimate_cost_impact(self, gaps: List[SecurityGap], 
                            components: List[CloudComponent]) -> Dict:
        """Estima impacto de custo das implementações"""
        monthly_cost_estimate = 0
        one_time_cost = 0
        
        for gap in gaps:
            if gap.gap_type == 'monitoring':
                monthly_cost_estimate += 200
            elif gap.gap_type == 'encryption':
                monthly_cost_estimate += 100
                one_time_cost += 2000
            elif gap.gap_type == 'authentication':
                monthly_cost_estimate += 300
                one_time_cost += 5000
            elif gap.gap_type == 'governance':
                monthly_cost_estimate += 500
                one_time_cost += 10000
        
        # Fator de complexidade baseado no número de componentes
        complexity_factor = min(2.0, 1 + (len(components) / 20))
        
        return {
            'monthly_operational_cost': int(monthly_cost_estimate * complexity_factor),
            'one_time_implementation_cost': int(one_time_cost * complexity_factor),
            'annual_cost_estimate': int((monthly_cost_estimate * 12 + one_time_cost) * complexity_factor),
            'roi_timeframe_months': 12,
            'cost_breakdown': {
                'tooling_and_services': '40%',
                'professional_services': '35%',
                'training_and_certification': '15%',
                'ongoing_operations': '10%'
            }
        }

class MultiCloudSecurityAnalyzer:
    """Analisador principal multi-cloud"""
    
    def __init__(self):
        self.image_processor = MultiCloudImageProcessor()
        self.rules_engine = SecurityRulesEngineMultiCloud()
        self.report_generator = MultiCloudReportGenerator()
    
    def analyze_architecture_diagram(self, image_path: str) -> Dict:
        """Analisa diagrama de arquitetura multi-cloud"""
        logger.info(f"Iniciando análise multi-cloud de: {image_path}")
        
        try:
            # 1. Detectar componentes e identificar arquitetura
            components, architecture_type = self.image_processor.detect_cloud_components(image_path)
            
            if not components:
                logger.warning("Nenhum componente detectado na imagem")
                return {"error": "Nenhum componente detectado"}
            
            # 2. Analisar gaps de segurança
            security_gaps = self.rules_engine.analyze_security_gaps(components, architecture_type)
            
            # 3. Gerar relatório completo
            report = self.report_generator.generate_security_report(
                components, security_gaps, architecture_type
            )
            
            logger.info(f"Análise concluída. Score de segurança: {report['summary']['security_score']}")
            logger.info(f"Arquitetura: {architecture_type.value}")
            logger.info(f"Provedores detectados: {report['summary']['providers_detected']}")
            
            return report
            
        except Exception as e:
            logger.error(f"Erro durante análise: {e}")
            return {"error": str(e)}
    
    def save_report(self, report: Dict, output_path: str):
        """Salva relatório em arquivo JSON"""
        try:
            with open(output_path, 'w', encoding='utf-8') as f:
                json.dump(report, f, indent=2, ensure_ascii=False)
            logger.info(f"Relatório salvo em: {output_path}")
        except Exception as e:
            logger.error(f"Erro ao salvar relatório: {e}")

def main():
    """Função principal do programa"""
    parser = argparse.ArgumentParser(
        description='Multi-Cloud Security Analyzer - Análise de Arquiteturas AWS, Azure, APIs'
    )
    parser.add_argument('image_path', help='Caminho para a imagem do diagrama')
    parser.add_argument('-o', '--output', help='Arquivo de saída para o relatório JSON')
    parser.add_argument('-v', '--verbose', action='store_true', help='Modo verboso')
    parser.add_argument('--format', choices=['json', 'html'], default='json', 
                       help='Formato do relatório (padrão: json)')
    
    args = parser.parse_args()
    
    if args.verbose:
        logging.getLogger().setLevel(logging.DEBUG)
    
    # Verificar se arquivo existe
    if not Path(args.image_path).exists():
        print(f"Erro: Arquivo não encontrado: {args.image_path}")
        return 1
    
    # Inicializar analisador
    analyzer = MultiCloudSecurityAnalyzer()
    
    # Executar análise
    report = analyzer.analyze_architecture_diagram(args.image_path)
    
    if "error" in report:
        print(f"Erro na análise: {report['error']}")
        return 1
    
    # Exibir resumo detalhado
    arch_analysis = report['architecture_analysis']
    summary = report['summary']
    
    print(f"\n{'='*80}")
    print(f"RELATÓRIO DE ANÁLISE DE SEGURANÇA MULTI-CLOUD")
    print(f"{'='*80}")
    print(f"Tipo de Arquitetura: {arch_analysis['type'].upper()}")
    print(f"Descrição: {arch_analysis['description']}")
    print(f"Multi-Cloud: {'Sim' if arch_analysis['multi_cloud'] else 'Não'}")
    print(f"Score de Complexidade: {arch_analysis['complexity_score']}/100")
    print(f"Score de Segurança: {summary['security_score']}/100")
    print(f"\nProvedores Detectados: {', '.join(summary['providers_detected'])}")
    print(f"Componentes Detectados: {summary['total_components']}")
    
    # Distribuição por provedor
    print(f"\nDistribuição por Provedor:")
    for provider, count in summary['provider_distribution'].items():
        print(f"  - {provider.upper()}: {count} componentes")
    
    print(f"\nGaps de Segurança: {summary['total_gaps']}")
    print(f"  - Críticos: {summary['critical_gaps']}")
    print(f"  - Altos: {summary['high_gaps']}")
    print(f"  - Médios: {summary['medium_gaps']}")
    print(f"  - Baixos: {summary['low_gaps']}")
    
    # Análise de maturidade
    if 'security_maturity' in report:
        print(f"\nMaturidade de Segurança por Provedor:")
        for provider, maturity in report['security_maturity'].items():
            print(f"  - {provider.upper()}: {maturity['level']} (Score: {maturity['score']}/100)")
    
    # Top recomendações
    if 'implementation_roadmap' in report:
        phase1_items = report['implementation_roadmap']['phase_1_immediate']['items']
        if phase1_items:
            print(f"\nTOP 5 AÇÕES IMEDIATAS (0-30 dias):")
            print(f"-" * 50)
            for i, item in enumerate(phase1_items[:5], 1):
                print(f"{i}. [{item['service']}] {item['description']}")
                print(f"   Solução: {item['recommendation']}")
                print(f"   Esforço: {item['effort']} | Custo: {item['cost_estimate']}")
                print()
    
    # Compliance mais impactado
    if 'compliance_impact' in report and report['compliance_impact']:
        print(f"FRAMEWORKS DE COMPLIANCE MAIS IMPACTADOS:")
        print(f"-" * 50)
        for framework, impact in list(report['compliance_impact'].items())[:3]:
            print(f"• {framework}: {impact['affected_controls']} controles afetados "
                  f"({impact['compliance_status']})")
    
    # Estimativa de custos
    if 'cost_impact_estimation' in report:
        costs = report['cost_impact_estimation']
        print(f"\nESTIMATIVA DE CUSTOS DE IMPLEMENTAÇÃO:")
        print(f"-" * 50)
        print(f"Custo único: ${costs['one_time_implementation_cost']:,}")
        print(f"Custo mensal: ${costs['monthly_operational_cost']:,}")
        print(f"Custo anual estimado: ${costs['annual_cost_estimate']:,}")
        print(f"ROI esperado em: {costs['roi_timeframe_months']} meses")
    
    # Salvar relatório
    if args.output:
        analyzer.save_report(report, args.output)
    else:
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        arch_type = arch_analysis['type']
        default_output = f"multicloud_security_report_{arch_type}_{timestamp}.json"
        analyzer.save_report(report, default_output)
    
    return 0

if __name__ == "__main__":
    exit(main())