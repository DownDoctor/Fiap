#!/usr/bin/env python3
"""
Enhanced Image Analyzer - Versão com suporte a thumbnail e informações da imagem
Adiciona thumbnail da imagem original e metadados no relatório
"""

import cv2
import base64
import os
from pathlib import Path
from PIL import Image
import io
from typing import Dict, Tuple, Optional

class ImageMetadataExtractor:
    """Extrator de metadados e thumbnail de imagens"""
    
    def __init__(self):
        self.supported_formats = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp']
    
    def extract_image_metadata(self, image_path: str) -> Dict:
        """
        Extrai metadados completos da imagem incluindo thumbnail
        """
        if not os.path.exists(image_path):
            return {"error": "Arquivo não encontrado"}
        
        try:
            path_obj = Path(image_path)
            
            # Informações básicas do arquivo
            file_stats = path_obj.stat()
            file_size_mb = file_stats.st_size / (1024 * 1024)
            
            # Carregar imagem com OpenCV para dimensões
            image = cv2.imread(image_path)
            if image is None:
                return {"error": "Não foi possível carregar a imagem"}
            
            height, width, channels = image.shape
            
            # Gerar thumbnail
            thumbnail_b64 = self._create_thumbnail_base64(image_path)
            
            # Detectar tipo de diagrama baseado no conteúdo
            diagram_type = self._detect_diagram_type(image)
            
            metadata = {
                "file_info": {
                    "filename": path_obj.name,
                    "full_path": str(path_obj.absolute()),
                    "file_size_mb": round(file_size_mb, 2),
                    "format": path_obj.suffix.lower(),
                    "modified_date": file_stats.st_mtime
                },
                "image_properties": {
                    "width": width,
                    "height": height,
                    "channels": channels,
                    "resolution": f"{width}x{height}",
                    "aspect_ratio": round(width/height, 2),
                    "total_pixels": width * height
                },
                "thumbnail": {
                    "base64_data": thumbnail_b64,
                    "format": "JPEG",
                    "size": "150x150"
                },
                "analysis_info": {
                    "diagram_type": diagram_type,
                    "complexity_score": self._calculate_complexity_score(image),
                    "text_density": self._estimate_text_density(image),
                    "color_profile": self._analyze_color_profile(image)
                }
            }
            
            return metadata
            
        except Exception as e:
            return {"error": f"Erro ao processar imagem: {str(e)}"}
    
    def _create_thumbnail_base64(self, image_path: str, size: Tuple[int, int] = (150, 150)) -> str:
        """Cria thumbnail em base64 para embedding no HTML"""
        try:
            # Usar PIL para melhor qualidade de thumbnail
            with Image.open(image_path) as img:
                # Converter para RGB se necessário
                if img.mode in ('RGBA', 'LA'):
                    background = Image.new('RGB', img.size, (255, 255, 255))
                    background.paste(img, mask=img.split()[-1] if img.mode == 'RGBA' else None)
                    img = background
                elif img.mode not in ('RGB', 'L'):
                    img = img.convert('RGB')
                
                # Criar thumbnail mantendo aspect ratio
                img.thumbnail(size, Image.Resampling.LANCZOS)
                
                # Criar nova imagem com fundo branco no tamanho exato
                thumbnail = Image.new('RGB', size, (255, 255, 255))
                
                # Centralizar a imagem no thumbnail
                x = (size[0] - img.width) // 2
                y = (size[1] - img.height) // 2
                thumbnail.paste(img, (x, y))
                
                # Converter para base64
                buffer = io.BytesIO()
                thumbnail.save(buffer, format='JPEG', quality=85, optimize=True)
                img_b64 = base64.b64encode(buffer.getvalue()).decode('utf-8')
                
                return img_b64
                
        except Exception as e:
            # Fallback: usar OpenCV se PIL falhar
            try:
                img = cv2.imread(image_path)
                img_resized = cv2.resize(img, size)
                
                # Converter para base64
                _, buffer = cv2.imencode('.jpg', img_resized)
                img_b64 = base64.b64encode(buffer).decode('utf-8')
                
                return img_b64
            except:
                return ""
    
    def _detect_diagram_type(self, image) -> str:
        """Detecta o tipo de diagrama baseado em características visuais"""
        try:
            # Converter para grayscale para análise
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Detectar linhas (indicativo de diagramas)
            edges = cv2.Canny(gray, 50, 150)
            lines = cv2.HoughLinesP(edges, 1, 3.14159/180, threshold=100, minLineLength=50, maxLineGap=10)
            
            # Detectar formas retangulares (caixas de componentes)
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            rectangles = 0
            for contour in contours:
                approx = cv2.approxPolyDP(contour, 0.02 * cv2.arcLength(contour, True), True)
                if len(approx) == 4:
                    rectangles += 1
            
            # Analisar densidade de texto
            text_pixels = cv2.countNonZero(cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY)[1])
            total_pixels = gray.shape[0] * gray.shape[1]
            text_ratio = text_pixels / total_pixels
            
            # Classificar tipo de diagrama
            if lines is not None and len(lines) > 20 and rectangles > 5:
                if text_ratio > 0.7:
                    return "Arquitetura de Software"
                elif rectangles > 15:
                    return "Diagrama de Rede"
                else:
                    return "Arquitetura de Sistema"
            elif rectangles > 10:
                return "Diagrama de Componentes"
            elif lines is not None and len(lines) > 10:
                return "Fluxograma"
            else:
                return "Diagrama Técnico"
                
        except:
            return "Diagrama Não Identificado"
    
    def _calculate_complexity_score(self, image) -> int:
        """Calcula score de complexidade do diagrama (0-100)"""
        try:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Número de contornos (componentes)
            edges = cv2.Canny(gray, 50, 150)
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # Número de linhas (conexões)
            lines = cv2.HoughLinesP(edges, 1, 3.14159/180, threshold=50, minLineLength=30, maxLineGap=10)
            line_count = len(lines) if lines is not None else 0
            
            # Variância de intensidade (complexidade visual)
            variance = cv2.Laplacian(gray, cv2.CV_64F).var()
            
            # Calcular score baseado nos fatores
            complexity = min(100, (len(contours) * 2) + (line_count * 1.5) + (variance / 100))
            
            return int(complexity)
            
        except:
            return 50  # Score médio se houver erro
    
    def _estimate_text_density(self, image) -> str:
        """Estima densidade de texto na imagem"""
        try:
            gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
            
            # Threshold para destacar texto
            _, thresh = cv2.threshold(gray, 240, 255, cv2.THRESH_BINARY)
            text_pixels = cv2.countNonZero(thresh)
            total_pixels = gray.shape[0] * gray.shape[1]
            
            text_ratio = text_pixels / total_pixels
            
            if text_ratio > 0.8:
                return "Muito Alta"
            elif text_ratio > 0.6:
                return "Alta"
            elif text_ratio > 0.4:
                return "Média"
            elif text_ratio > 0.2:
                return "Baixa"
            else:
                return "Muito Baixa"
                
        except:
            return "Não Determinada"
    
    def _analyze_color_profile(self, image) -> str:
        """Analisa perfil de cores da imagem"""
        try:
            # Converter para HSV para melhor análise de cores
            hsv = cv2.cvtColor(image, cv2.COLOR_BGR2HSV)
            
            # Calcular histograma de saturação
            hist_s = cv2.calcHist([hsv], [1], None, [256], [0, 256])
            
            # Analisar distribuição de cores
            low_sat = sum(hist_s[:50])  # Baixa saturação (tons de cinza)
            high_sat = sum(hist_s[100:])  # Alta saturação (cores vivas)
            
            total_pixels = image.shape[0] * image.shape[1]
            
            if low_sat / total_pixels > 0.8:
                return "Monocromático/Grayscale"
            elif high_sat / total_pixels > 0.3:
                return "Colorido"
            else:
                return "Tons Suaves"
                
        except:
            return "Perfil Não Determinado"

class EnhancedMultiCloudAnalyzerWithThumbnail:
    """Analisador aprimorado com suporte a thumbnail e metadados de imagem"""
    
    def __init__(self):
        # Importar classes necessárias evitando circular imports
        from multi_cloud_security_analyzer import MultiCloudSecurityAnalyzer
        from stride_analyzer import STRIDEThreatModeler, STRIDEReportGenerator
        
        self.base_analyzer = MultiCloudSecurityAnalyzer()
        self.stride_modeler = STRIDEThreatModeler()
        self.stride_reporter = STRIDEReportGenerator()
        self.image_extractor = ImageMetadataExtractor()
        self.reports_dir = Path("reports")
        self.reports_dir.mkdir(exist_ok=True)
    
    def analyze_architecture_with_thumbnail(self, image_path: str, generate_html: bool = True) -> Dict:
        """
        Análise completa com extração de thumbnail e metadados da imagem
        """
        print(f"🔄 Iniciando análise com thumbnail: {image_path}")
        
        try:
            # 1. Extrair metadados da imagem
            print("📸 Extraindo metadados da imagem...")
            image_metadata = self.image_extractor.extract_image_metadata(image_path)
            
            if "error" in image_metadata:
                return {"error": f"Erro nos metadados: {image_metadata['error']}"}
            
            print(f"✅ Imagem: {image_metadata['file_info']['filename']}")
            print(f"📊 Resolução: {image_metadata['image_properties']['resolution']}")
            print(f"🎨 Tipo: {image_metadata['analysis_info']['diagram_type']}")
            
            # 2. Executar análise tradicional
            print("🔍 Executando análise STRIDE...")
            traditional_report = self.base_analyzer.analyze_architecture_diagram(image_path)
            
            if "error" in traditional_report:
                return traditional_report
            
            # 3. Extrair componentes e executar STRIDE
            components = self._extract_components_from_report(traditional_report)
            architecture_type = self._get_architecture_type(traditional_report)
            
            stride_threats = self.stride_modeler.analyze_threats(components, architecture_type)
            stride_report = self.stride_reporter.generate_stride_report(
                stride_threats, components, architecture_type
            )
            
            # 4. Combinar todos os dados
            enhanced_report = self._create_enhanced_report(
                traditional_report, stride_report, image_metadata
            )
            
            # 5. Gerar HTML com thumbnail
            if generate_html:
                html_files = self._generate_enhanced_html(enhanced_report, image_path)
                enhanced_report['generated_files'] = html_files
                
                print(f"📊 JSON: {html_files['json_report']}")
                print(f"🌐 HTML: {html_files['html_report']}")
                print(f"📋 Resumo: {html_files['executive_summary']}")
            
            print(f"✅ Análise concluída: {len(stride_threats)} ameaças identificadas")
            
            return enhanced_report
            
        except Exception as e:
            return {"error": f"Erro durante análise: {str(e)}"}
    
    def _extract_components_from_report(self, report: Dict) -> list:
        """Extrai componentes do relatório tradicional"""
        from multi_cloud_security_analyzer import CloudComponent, CloudProvider
        
        components = []
        for comp_data in report.get('components_detected', []):
            component = CloudComponent(
                name=comp_data['name'],
                service_type=comp_data['service_type'],
                provider=CloudProvider(comp_data['provider']),
                location=tuple(comp_data['location']),
                confidence=comp_data['confidence'],
                properties=comp_data['properties'],
                category=comp_data['category']
            )
            components.append(component)
        return components
    
    def _get_architecture_type(self, report: Dict):
        """Obtém tipo de arquitetura do relatório"""
        from multi_cloud_security_analyzer import ArchitectureType
        return ArchitectureType(report['architecture_analysis']['type'])
    
    def _create_enhanced_report(self, traditional_report: Dict, stride_report: Dict, image_metadata: Dict) -> Dict:
        """Cria relatório aprimorado com metadados da imagem"""
        
        enhanced_report = {
            "analysis_metadata": {
                "timestamp": stride_report.get('timestamp'),
                "methodology": "Microsoft STRIDE Multi-Cloud Analysis with Image Metadata",
                "version": "2.1",
                "has_thumbnail": True
            },
            
            # Metadados da imagem original
            "source_image": image_metadata,
            
            # Análise arquitetural combinada
            "architecture_analysis": stride_report.get('architecture_analysis', {}),
            "components_detected": traditional_report.get('components_detected', []),
            "components_by_provider": traditional_report.get('components_by_provider', {}),
            
            # Análise STRIDE completa
            "stride_analysis": stride_report.get('stride_analysis', {}),
            "stride_threats": stride_report.get('detailed_threats', []),
            "risk_assessment": stride_report.get('risk_assessment', {}),
            "attack_surface_analysis": stride_report.get('attack_surface_analysis', {}),
            
            # Análise de compliance
            "compliance_impact": stride_report.get('compliance_impact', {}),
            
            # Recomendações
            "recommendations": stride_report.get('recommendations', {}),
            "mitigation_analysis": stride_report.get('mitigation_analysis', {}),
            
            # Controles de segurança
            "security_controls": stride_report.get('security_controls', {}),
            
            # Gaps tradicionais (mantido para compatibilidade)
            "traditional_gaps": traditional_report.get('security_gaps', [])
        }
        
        return enhanced_report
    
    def _generate_enhanced_html(self, report: Dict, original_image_path: str) -> Dict:
        """Gera HTML aprimorado com thumbnail da imagem"""
        from datetime import datetime
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        filename_base = Path(original_image_path).stem
        
        # Salvar JSON
        json_filename = self.reports_dir / f"stride_analysis_{filename_base}_{timestamp}.json"
        with open(json_filename, 'w', encoding='utf-8') as f:
            import json
            json.dump(report, f, indent=2, ensure_ascii=False, default=str)
        
        # Gerar HTML com thumbnail
        html_filename = self.reports_dir / f"stride_report_{filename_base}_{timestamp}.html"
        html_content = self._create_enhanced_html_content(report)
        
        with open(html_filename, 'w', encoding='utf-8') as f:
            f.write(html_content)
        
        # Gerar resumo executivo
        summary_filename = self.reports_dir / f"executive_summary_{filename_base}_{timestamp}.txt"
        summary_content = self._generate_executive_summary_with_image(report)
        
        with open(summary_filename, 'w', encoding='utf-8') as f:
            f.write(summary_content)
        
        return {
            'json_report': str(json_filename),
            'html_report': str(html_filename),
            'executive_summary': str(summary_filename)
        }
    
    def _create_enhanced_html_content(self, report: Dict) -> str:
        """Cria conteúdo HTML aprimorado com thumbnail"""
        
        # Extrair dados
        image_metadata = report.get('source_image', {})
        arch_analysis = report.get('architecture_analysis', {})
        risk_assessment = report.get('risk_assessment', {})
        threats = report.get('stride_threats', [])
        
        # Informações da imagem
        file_info = image_metadata.get('file_info', {})
        image_props = image_metadata.get('image_properties', {})
        thumbnail = image_metadata.get('thumbnail', {})
        analysis_info = image_metadata.get('analysis_info', {})
        
        # Dados da análise
        arch_type = arch_analysis.get('type', 'Unknown')
        total_threats = len(threats)
        risk_score = risk_assessment.get('overall_risk_score', 0)
        risk_level = arch_analysis.get('risk_level', 'Unknown')
        
        html = f"""
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório STRIDE - {file_info.get('filename', 'Análise')}</title>
    <style>
        {self._get_enhanced_css_styles()}
    </style>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container">
        <!-- Header com informações da imagem -->
        <div class="header">
            <h1>🔒 Relatório STRIDE Security Analysis</h1>
            <div class="subtitle">
                Análise de: <strong>{file_info.get('filename', 'Imagem não identificada')}</strong><br>
                Metodologia: Microsoft STRIDE | Gerado em: {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}
            </div>
        </div>
        
        <!-- Seção da imagem original -->
        <div class="section image-section">
            <h2>📸 Imagem Original Analisada</h2>
            <div class="image-info-grid">
                <div class="thumbnail-container">
                    <img src="data:image/jpeg;base64,{thumbnail.get('base64_data', '')}" 
                         alt="Thumbnail do diagrama" class="thumbnail-image">
                    <div class="thumbnail-caption">
                        {analysis_info.get('diagram_type', 'Diagrama')}
                    </div>
                </div>
                <div class="image-metadata">
                    <h3>📋 Informações do Arquivo</h3>
                    <div class="metadata-grid">
                        <div class="metadata-item">
                            <span class="label">Nome:</span>
                            <span class="value">{file_info.get('filename', 'N/A')}</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Tamanho:</span>
                            <span class="value">{file_info.get('file_size_mb', 0)} MB</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Resolução:</span>
                            <span class="value">{image_props.get('resolution', 'N/A')}</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Formato:</span>
                            <span class="value">{file_info.get('format', 'N/A').upper()}</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Tipo de Diagrama:</span>
                            <span class="value">{analysis_info.get('diagram_type', 'N/A')}</span>
                        </div>
                        <div class="metadata-item">
                            <span class="label">Complexidade:</span>
                            <span class="value">{analysis_info.get('complexity_score', 0)}/100</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Resumo Executivo -->
        <div class="section">
            <h2>📊 Resumo Executivo</h2>
            <div class="dashboard">
                <div class="metric-card">
                    <h3>Tipo de Arquitetura</h3>
                    <div class="metric-value" style="font-size: 1.5em;">{arch_type.replace('_', ' ').title()}</div>
                    <div class="metric-description">Detectado automaticamente</div>
                </div>
                <div class="metric-card {self._get_risk_class(risk_score)}">
                    <h3>Score de Risco</h3>
                    <div class="metric-value">{risk_score}/10</div>
                    <div class="metric-description">Nível: {risk_level}</div>
                </div>
                <div class="metric-card">
                    <h3>Total de Ameaças</h3>
                    <div class="metric-value">{total_threats}</div>
                    <div class="metric-description">Identificadas via STRIDE</div>
                </div>
                <div class="metric-card">
                    <h3>Status da Análise</h3>
                    <div class="metric-value" style="font-size: 1.2em;">
                        {self._get_status_emoji(risk_score)}
                    </div>
                    <div class="metric-description">{self._get_status_text(risk_score)}</div>
                </div>
            </div>
        </div>
        
        {self._create_stride_dashboard_html(report)}
        {self._create_threats_summary_html(threats)}
        {self._create_recommendations_html(report)}
        
        <!-- Footer -->
        <div class="footer">
            <p>🔒 Relatório gerado pelo <strong>Multi-Cloud Security Analyzer</strong> com metodologia <strong>Microsoft STRIDE</strong></p>
            <p>Imagem analisada: <strong>{file_info.get('filename', 'N/A')}</strong> | 
               Resolução: {image_props.get('resolution', 'N/A')} | 
               Tipo: {analysis_info.get('diagram_type', 'N/A')}</p>
            <p style="font-size: 0.8em; color: #adb5bd;">
                Relatório com thumbnail e metadados da imagem original
            </p>
        </div>
    </div>
    
    <script>
        {self._get_interactive_scripts(threats)}
    </script>
</body>
</html>
        """
        
        return html
    
    def _get_enhanced_css_styles(self) -> str:
        """CSS aprimorado com estilos para thumbnail e metadados"""
        return """
        * { margin: 0; padding: 0; box-sizing: border-box; }
        
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            line-height: 1.6; color: #333;
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }
        
        .container {
            max-width: 1200px; margin: 20px auto; padding: 20px;
            background: white; box-shadow: 0 0 20px rgba(0,0,0,0.1);
            border-radius: 10px;
        }
        
        .header {
            text-align: center; padding: 30px 0;
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
            color: white; border-radius: 10px; margin-bottom: 30px;
        }
        
        .header h1 { font-size: 2.5em; margin-bottom: 10px; }
        .header .subtitle { font-size: 1.2em; opacity: 0.9; }
        
        .section {
            margin-bottom: 40px; padding: 25px;
            background: #f8f9fa; border-radius: 10px;
            border-left: 5px solid #007bff;
        }
        
        .section h2 {
            color: #2c3e50; margin-bottom: 20px; font-size: 1.8em;
            display: flex; align-items: center;
        }
        
        .image-section {
            border-left-color: #28a745;
        }
        
        .image-info-grid {
            display: grid;
            grid-template-columns: 200px 1fr;
            gap: 30px;
            align-items: start;
        }
        
        .thumbnail-container {
            text-align: center;
            background: white;
            padding: 15px;
            border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        }
        
        .thumbnail-image {
            width: 150px;
            height: 150px;
            border-radius: 8px;
            border: 2px solid #dee2e6;
            object-fit: cover;
        }
        
        .thumbnail-caption {
            margin-top: 10px;
            font-size: 0.9em;
            color: #6c757d;
            font-weight: 500;
        }
        
        .image-metadata {
            background: white;
            padding: 20px;
            border-radius: 10px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.05);
        }
        
        .image-metadata h3 {
            color: #2c3e50;
            margin-bottom: 15px;
            font-size: 1.2em;
        }
        
        .metadata-grid {
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 12px;
        }
        
        .metadata-item {
            display: flex;
            justify-content: space-between;
            padding: 8px 0;
            border-bottom: 1px solid #f1f3f4;
        }
        
        .metadata-item .label {
            font-weight: 600;
            color: #495057;
        }
        
        .metadata-item .value {
            color: #6c757d;
            text-align: right;
        }
        
        .dashboard {
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px; margin-bottom: 30px;
        }
        
        .metric-card {
            background: white; padding: 25px; border-radius: 10px;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-align: center;
            transition: transform 0.3s ease; border-top: 4px solid #007bff;
        }
        
        .metric-card:hover { transform: translateY(-5px); }
        
        .metric-card h3 {
            color: #6c757d; font-size: 0.9em; text-transform: uppercase;
            letter-spacing: 1px; margin-bottom: 10px;
        }
        
        .metric-value {
            font-size: 2.5em; font-weight: bold;
            color: #2c3e50; margin-bottom: 5px;
        }
        
        .metric-description { color: #6c757d; font-size: 0.9em; }
        
        .critical { border-top-color: #dc3545; }
        .high { border-top-color: #fd7e14; }
        .medium { border-top-color: #ffc107; }
        .low { border-top-color: #28a745; }
        
        .footer {
            text-align: center; padding: 20px; margin-top: 40px;
            border-top: 1px solid #dee2e6; color: #6c757d;
        }
        
        @media (max-width: 768px) {
            .image-info-grid {
                grid-template-columns: 1fr;
                gap: 20px;
            }
            .metadata-grid {
                grid-template-columns: 1fr;
            }
            .container { margin: 10px; padding: 15px; }
            .dashboard { grid-template-columns: 1fr; }
        }
        """
    
    def _create_stride_dashboard_html(self, report: Dict) -> str:
        """Cria dashboard STRIDE em HTML"""
        stride_analysis = report.get('stride_analysis', {})
        statistics = stride_analysis.get('statistics', {})
        
        html = """
        <div class="section">
            <h2>🎭 Análise por Categoria STRIDE</h2>
            <div class="dashboard">
        """
        
        stride_categories = {
            'spoofing': {'emoji': '🎭', 'name': 'Spoofing', 'description': 'Falsificação de Identidade'},
            'tampering': {'emoji': '🔧', 'name': 'Tampering', 'description': 'Violação de Integridade'},
            'repudiation': {'emoji': '📝', 'name': 'Repudiation', 'description': 'Não-Repúdio'},
            'information_disclosure': {'emoji': '🔍', 'name': 'Information Disclosure', 'description': 'Vazamento de Dados'},
            'denial_of_service': {'emoji': '⚡', 'name': 'Denial of Service', 'description': 'Negação de Serviço'},
            'elevation_of_privilege': {'emoji': '⬆️', 'name': 'Elevation of Privilege', 'description': 'Escalação de Privilégios'}
        }
        
        for category_key, category_info in stride_categories.items():
            stats = statistics.get(category_key, {})
            total_count = stats.get('total_count', 0)
            avg_risk = stats.get('avg_risk_score', 0)
            critical_count = stats.get('critical_count', 0)
            
            risk_class = self._get_risk_class(avg_risk)
            
            html += f"""
                <div class="metric-card {risk_class}">
                    <h3>{category_info['emoji']} {category_info['name']}</h3>
                    <div class="metric-value">{total_count}</div>
                    <div class="metric-description">
                        Risk Score: {avg_risk}/10<br>
                        {category_info['description']}
                        {f'<br>🚨 {critical_count} Críticas' if critical_count > 0 else ''}
                    </div>
                </div>
            """
        
        html += """
            </div>
        </div>
        """
        
        return html
    
    def _create_threats_summary_html(self, threats: list) -> str:
        """Cria resumo de ameaças em HTML"""
        if not threats:
            return ""
        
        # Contar por severidade
        severity_count = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
        for threat in threats:
            severity = threat.get('severity', 'medium')
            if severity in severity_count:
                severity_count[severity] += 1
        
        # Top 5 ameaças
        sorted_threats = sorted(threats, key=lambda x: x.get('risk_score', 0), reverse=True)
        
        html = f"""
        <div class="section">
            <h2>📈 Distribuição de Ameaças</h2>
            <div class="dashboard">
                <div class="metric-card critical">
                    <h3>Críticas</h3>
                    <div class="metric-value">{severity_count['critical']}</div>
                    <div class="metric-description">Requerem ação imediata</div>
                </div>
                <div class="metric-card high">
                    <h3>Altas</h3>
                    <div class="metric-value">{severity_count['high']}</div>
                    <div class="metric-description">Atenção prioritária</div>
                </div>
                <div class="metric-card medium">
                    <h3>Médias</h3>
                    <div class="metric-value">{severity_count['medium']}</div>
                    <div class="metric-description">Monitoramento necessário</div>
                </div>
                <div class="metric-card low">
                    <h3>Baixas</h3>
                    <div class="metric-value">{severity_count['low']}</div>
                    <div class="metric-description">Melhorias graduais</div>
                </div>
            </div>
            
            <h3>🔥 Top 5 Ameaças por Risk Score</h3>
            <div style="background: white; border-radius: 10px; padding: 20px; margin-top: 20px;">
        """
        
        for i, threat in enumerate(sorted_threats[:5], 1):
            threat_type = threat.get('threat_type', 'unknown').replace('_', ' ').title()
            component = threat.get('component', 'N/A')
            severity = threat.get('severity', 'medium')
            risk_score = threat.get('risk_score', 0)
            description = threat.get('description', 'N/A')[:100] + "..." if len(threat.get('description', '')) > 100 else threat.get('description', 'N/A')
            
            severity_colors = {
                'critical': '#dc3545',
                'high': '#fd7e14', 
                'medium': '#ffc107',
                'low': '#28a745'
            }
            
            html += f"""
                <div style="border-left: 4px solid {severity_colors.get(severity, '#6c757d')}; 
                           padding: 15px; margin: 10px 0; background: #f8f9fa; border-radius: 0 8px 8px 0;">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 8px;">
                        <strong style="color: #2c3e50;">{i}. {threat_type} | {component}</strong>
                        <span style="background: {severity_colors.get(severity, '#6c757d')}; color: white; 
                                   padding: 4px 8px; border-radius: 12px; font-size: 0.8em; font-weight: bold;">
                            {severity.upper()} - {risk_score}/10
                        </span>
                    </div>
                    <p style="color: #6c757d; margin: 0; font-size: 0.9em;">{description}</p>
                </div>
            """
        
        html += """
            </div>
        </div>
        """
        
        return html
    
    def _create_recommendations_html(self, report: Dict) -> str:
        """Cria seção de recomendações em HTML"""
        recommendations = report.get('recommendations', {})
        immediate_actions = recommendations.get('immediate_actions', [])
        
        if not immediate_actions:
            return ""
        
        html = """
        <div class="section">
            <h2>💡 Ações Imediatas Recomendadas</h2>
            <div style="background: white; border-radius: 10px; padding: 20px;">
        """
        
        for i, action in enumerate(immediate_actions[:5], 1):
            priority = action.get('priority', 'MEDIUM')
            component = action.get('component', 'N/A')
            description = action.get('description', 'Ação não especificada')
            timeline = action.get('timeline', 'N/A')
            risk_score = action.get('risk_score', 0)
            
            priority_colors = {
                'CRITICAL': '#dc3545',
                'HIGH': '#fd7e14',
                'MEDIUM': '#ffc107',
                'LOW': '#28a745'
            }
            
            html += f"""
                <div style="border: 1px solid #dee2e6; border-radius: 8px; padding: 20px; margin: 15px 0;
                           border-left: 5px solid {priority_colors.get(priority, '#6c757d')};">
                    <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: 10px;">
                        <h4 style="margin: 0; color: #2c3e50;">{i}. {description}</h4>
                        <span style="background: {priority_colors.get(priority, '#6c757d')}; color: white;
                                   padding: 4px 12px; border-radius: 20px; font-size: 0.8em; font-weight: bold;">
                            {priority}
                        </span>
                    </div>
                    <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 15px;">
                        <div>
                            <strong style="color: #495057;">Componente:</strong>
                            <span style="color: #6c757d;">{component}</span>
                        </div>
                        <div>
                            <strong style="color: #495057;">Timeline:</strong>
                            <span style="color: #6c757d;">{timeline}</span>
                        </div>
                        <div>
                            <strong style="color: #495057;">Risk Score:</strong>
                            <span style="color: #6c757d;">{risk_score}/10</span>
                        </div>
                    </div>
                </div>
            """
        
        html += """
            </div>
        </div>
        """
        
        return html
    
    def _generate_executive_summary_with_image(self, report: Dict) -> str:
        """Gera resumo executivo incluindo informações da imagem"""
        from datetime import datetime
        
        image_metadata = report.get('source_image', {})
        file_info = image_metadata.get('file_info', {})
        analysis_info = image_metadata.get('analysis_info', {})
        
        arch_analysis = report.get('architecture_analysis', {})
        risk_assessment = report.get('risk_assessment', {})
        threats = report.get('stride_threats', [])
        
        summary = f"""
RESUMO EXECUTIVO - ANÁLISE DE SEGURANÇA STRIDE COM IMAGEM
{'=' * 70}

📅 Data da Análise: {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}
🔬 Metodologia: Microsoft STRIDE Threat Modeling with Image Analysis

📸 IMAGEM ANALISADA
{'-' * 30}
Arquivo: {file_info.get('filename', 'Não identificado')}
Tamanho: {file_info.get('file_size_mb', 0)} MB
Resolução: {image_metadata.get('image_properties', {}).get('resolution', 'N/A')}
Formato: {file_info.get('format', 'N/A').upper()}
Tipo de Diagrama: {analysis_info.get('diagram_type', 'Não identificado')}
Complexidade Visual: {analysis_info.get('complexity_score', 0)}/100

🏗️ ARQUITETURA DETECTADA
{'-' * 30}
Tipo: {arch_analysis.get('type', 'Unknown').replace('_', ' ').title()}
Componentes: {arch_analysis.get('total_components', 0)}
Provedores: {len(report.get('components_by_provider', {}))}

🎯 RESULTADOS DA ANÁLISE STRIDE
{'-' * 30}
Total de Ameaças: {len(threats)}
Risk Score Geral: {risk_assessment.get('overall_risk_score', 0)}/10
Nível de Risco: {arch_analysis.get('risk_level', 'Unknown')}

📊 DISTRIBUIÇÃO POR SEVERIDADE
{'-' * 30}"""
        
        # Contar por severidade
        severity_count = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0, 'info': 0}
        for threat in threats:
            severity = threat.get('severity', 'medium')
            if severity in severity_count:
                severity_count[severity] += 1
        
        for severity, count in severity_count.items():
            if count > 0:
                summary += f"\n{severity.upper()}: {count} ameaças"
        
        # Top 3 ameaças
        sorted_threats = sorted(threats, key=lambda x: x.get('risk_score', 0), reverse=True)
        if sorted_threats:
            summary += f"\n\n🚨 TOP 3 AMEAÇAS CRÍTICAS\n{'-' * 30}"
            for i, threat in enumerate(sorted_threats[:3], 1):
                threat_type = threat.get('threat_type', 'unknown').replace('_', ' ').title()
                component = threat.get('component', 'unknown')
                risk_score = threat.get('risk_score', 0)
                summary += f"\n{i}. {threat_type} em {component} (Risk: {risk_score}/10)"
        
        # Conclusão
        summary += f"\n\n🎯 CONCLUSÃO\n{'-' * 30}"
        overall_risk = risk_assessment.get('overall_risk_score', 0)
        
        if overall_risk >= 8.0:
            summary += f"\nA arquitetura apresenta RISCOS CRÍTICOS que requerem ação imediata."
        elif overall_risk >= 6.0:
            summary += f"\nA arquitetura apresenta riscos ALTOS que necessitam atenção prioritária."
        elif overall_risk >= 4.0:
            summary += f"\nA arquitetura apresenta riscos MÉDIOS que devem ser monitorados."
        else:
            summary += f"\nA arquitetura apresenta nível de risco ACEITÁVEL."
        
        summary += f"\n\nO diagrama '{file_info.get('filename', 'analisado')}' foi processado com sucesso,"
        summary += f"\nidentificando {len(threats)} ameaças de segurança usando a metodologia STRIDE."
        summary += f"\nO tipo de diagrama detectado foi: {analysis_info.get('diagram_type', 'Não identificado')}."
        
        return summary
    
    # Métodos utilitários
    def _get_risk_class(self, risk_score: float) -> str:
        """Retorna classe CSS baseada no risk score"""
        if risk_score >= 8.0:
            return 'critical'
        elif risk_score >= 6.0:
            return 'high'
        elif risk_score >= 4.0:
            return 'medium'
        else:
            return 'low'
    
    def _get_status_emoji(self, risk_score: float) -> str:
        """Retorna emoji baseado no risk score"""
        if risk_score >= 8.0:
            return '🚨'
        elif risk_score >= 6.0:
            return '⚠️'
        elif risk_score >= 4.0:
            return '🟡'
        else:
            return '✅'
    
    def _get_status_text(self, risk_score: float) -> str:
        """Retorna texto de status"""
        if risk_score >= 8.0:
            return 'Ação Imediata Necessária'
        elif risk_score >= 6.0:
            return 'Atenção Requerida'
        elif risk_score >= 4.0:
            return 'Monitoramento Necessário'
        else:
            return 'Status Aceitável'
    
    def _get_interactive_scripts(self, threats: list) -> str:
        """Scripts JavaScript para interatividade"""
        return """
        // Animações de entrada
        const observerOptions = {
            threshold: 0.1,
            rootMargin: '0px 0px -50px 0px'
        };
        
        const observer = new IntersectionObserver((entries) => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    entry.target.style.opacity = '1';
                    entry.target.style.transform = 'translateY(0)';
                }
            });
        }, observerOptions);
        
        // Aplicar animações
        document.querySelectorAll('.metric-card, .section').forEach(element => {
            element.style.opacity = '0';
            element.style.transform = 'translateY(20px)';
            element.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
            observer.observe(element);
        });
        
        // Hover effect no thumbnail
        const thumbnail = document.querySelector('.thumbnail-image');
        if (thumbnail) {
            thumbnail.addEventListener('mouseenter', function() {
                this.style.transform = 'scale(1.05)';
                this.style.transition = 'transform 0.3s ease';
            });
            
            thumbnail.addEventListener('mouseleave', function() {
                this.style.transform = 'scale(1)';
            });
        }
        """

def test_enhanced_analyzer():
    """Função para testar o analisador aprimorado"""
    print("🧪 TESTE DO ANALISADOR APRIMORADO COM THUMBNAIL")
    print("=" * 55)
    
    # Verificar se há imagens disponíveis para teste
    image_extensions = ['.png', '.jpg', '.jpeg', '.bmp', '.tiff']
    test_images = []
    
    for ext in image_extensions:
        test_images.extend(Path(".").glob(f"*{ext}"))
    
    if not test_images:
        print("⚠️ Nenhuma imagem encontrada para teste")
        print("💡 Coloque uma imagem de diagrama no diretório atual")
        print(f"   Formatos suportados: {', '.join(image_extensions)}")
        return False
    
    # Usar a primeira imagem encontrada
    test_image = test_images[0]
    print(f"📸 Usando imagem: {test_image}")
    
    try:
        # Criar analisador aprimorado
        analyzer = EnhancedMultiCloudAnalyzerWithThumbnail()
        
        # Executar análise com thumbnail
        result = analyzer.analyze_architecture_with_thumbnail(str(test_image))
        
        if "error" in result:
            print(f"❌ Erro na análise: {result['error']}")
            return False
        
        # Mostrar resultados
        image_info = result.get('source_image', {})
        file_info = image_info.get('file_info', {})
        
        print(f"✅ Análise concluída!")
        print(f"📁 Arquivo: {file_info.get('filename')}")
        print(f"📊 Resolução: {image_info.get('image_properties', {}).get('resolution')}")
        print(f"🎨 Tipo: {image_info.get('analysis_info', {}).get('diagram_type')}")
        
        # Verificar arquivos gerados
        files = result.get('generated_files', {})
        if files:
            print(f"\n📁 ARQUIVOS GERADOS:")
            for file_type, file_path in files.items():
                if os.path.exists(file_path):
                    size_kb = os.path.getsize(file_path) / 1024
                    print(f"  ✅ {file_type}: {file_path} ({size_kb:.1f} KB)")
                else:
                    print(f"  ❌ {file_type}: {file_path} (não encontrado)")
            
            # Verificar thumbnail no HTML
            html_file = files.get('html_report')
            if html_file and os.path.exists(html_file):
                with open(html_file, 'r', encoding='utf-8') as f:
                    html_content = f.read()
                
                has_thumbnail = 'data:image/jpeg;base64,' in html_content
                has_metadata = 'image-metadata' in html_content
                
                print(f"\n🌐 VERIFICAÇÃO DO HTML:")
                print(f"  {'✅' if has_thumbnail else '❌'} Thumbnail integrado")
                print(f"  {'✅' if has_metadata else '❌'} Metadados da imagem")
        
        return True
        
    except Exception as e:
        print(f"❌ Erro durante teste: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    # Executar teste
    success = test_enhanced_analyzer()
    
    if success:
        print(f"\n🎉 TESTE CONCLUÍDO COM SUCESSO!")
        print("🌐 Abra o arquivo HTML gerado para ver o thumbnail!")
        print("📸 O relatório agora inclui:")
        print("  ✅ Thumbnail da imagem original")
        print("  ✅ Nome e metadados do arquivo")
        print("  ✅ Tipo de diagrama detectado")
        print("  ✅ Informações de resolução e tamanho")
        print("  ✅ Score de complexidade visual")
    else:
        print(f"\n❌ TESTE FALHOU")
        print("🔧 Verifique se há imagens no diretório atual")
