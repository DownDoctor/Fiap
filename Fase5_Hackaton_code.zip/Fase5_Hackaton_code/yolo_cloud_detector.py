# yolo_cloud_detector.py
"""
Módulo de detecção de ícones de cloud providers usando YOLO treinado
Este módulo integra o modelo best_cloud_icons.pt com o sistema de análise STRIDE
"""

import os
import sys
from pathlib import Path
from typing import Dict, List, Optional, Tuple, Any
import numpy as np
from PIL import Image
import json

# Tentativa de importar YOLOv5 ou YOLOv8
try:
    import torch
    TORCH_AVAILABLE = True
except ImportError:
    TORCH_AVAILABLE = False

try:
    # Tentativa para YOLOv8 (ultralytics)
    from ultralytics import YOLO
    YOLOV8_AVAILABLE = True
except ImportError:
    YOLOV8_AVAILABLE = False

# Se YOLOv8 não está disponível, tenta YOLOv5
if not YOLOV8_AVAILABLE:
    try:
        import yolov5
        YOLOV5_AVAILABLE = True
    except ImportError:
        YOLOV5_AVAILABLE = False
else:
    YOLOV5_AVAILABLE = False


class YOLOCloudDetector:
    """
    Detector especializado para ícones de cloud providers usando modelo YOLO treinado.
    Esta classe encapsula toda a lógica de detecção YOLO, tornando-a facilmente
    integrável com o RealImageAnalyzer existente.
    """
    
    def __init__(self, model_path: str = "./cloud_icons_training/best.pt"):
        """
        Inicializa o detector YOLO com o modelo treinado.
        
        O modelo deve estar treinado para detectar classes como:
        - aws_ec2, aws_s3, aws_lambda, aws_rds, aws_vpc, etc.
        - azure_vm, azure_storage, azure_functions, azure_sql, etc.
        - gcp_compute, gcp_storage, gcp_functions, gcp_bigquery, etc.
        """
        self.model_path = Path(model_path)
        self.model = None
        self.device = None
        self.class_names = []
        self.provider_mapping = {}
        
        # Inicializar o modelo se disponível
        self._initialize_model()
        
        # Configurar mapeamento de classes para providers
        self._setup_provider_mapping()
    
    def _initialize_model(self):
        """
        Carrega o modelo YOLO treinado, detectando automaticamente
        se devemos usar YOLOv5 ou YOLOv8 baseado na disponibilidade.
        """
       
        if not self.model_path.exists():
            print(f"⚠️ Modelo YOLO não encontrado em: {self.model_path}")
            return False
        
        if not TORCH_AVAILABLE:
            print("⚠️ PyTorch não está instalado. YOLO detection desabilitado.")
            return False
        
        try:
            # Detectar dispositivo (GPU se disponível, senão CPU)
            self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
            print(f"🔧 Usando dispositivo: {self.device}")
            
            if YOLOV8_AVAILABLE:
                # Carregar com YOLOv8 (preferencial por ser mais recente)
                print("📦 Carregando modelo com YOLOv8...")
                self.model = YOLO(str(self.model_path))
                
                # Extrair nomes das classes do modelo
                if hasattr(self.model, 'names'):
                    self.class_names = self.model.names
                    
            elif YOLOV5_AVAILABLE:
                # Carregar com YOLOv5
                print("📦 Carregando modelo com YOLOv5...")
                self.model = torch.hub.load('ultralytics/yolov5', 'custom', 
                                           path=str(self.model_path), 
                                           device=self.device)
                self.model.conf = 0.45  # Threshold de confiança
                
                # Extrair nomes das classes
                if hasattr(self.model, 'names'):
                    self.class_names = self.model.names
            else:
                # Tentativa de carregar modelo PyTorch puro como fallback
                print("📦 Tentando carregar modelo PyTorch diretamente...")
                self.model = torch.load(str(self.model_path), map_location=self.device)
                
                # Tentar extrair classes do checkpoint
                if isinstance(self.model, dict) and 'names' in self.model:
                    self.class_names = self.model['names']
            
            print(f"✅ Modelo YOLO carregado com sucesso!")
            print(f"📋 Classes detectadas: {len(self.class_names)} classes")
            
            # Mostrar algumas classes como exemplo
            if self.class_names:
                sample_classes = list(self.class_names.values() if isinstance(self.class_names, dict) 
                                     else self.class_names)[:5]
                print(f"   Exemplos: {sample_classes}")
            
            return True
            
        except Exception as e:
            print(f"❌ Erro ao carregar modelo YOLO: {str(e)}")
            import traceback
            traceback.print_exc()
            return False
    
    def _setup_provider_mapping(self):
        """
        Configura o mapeamento entre classes do YOLO e providers de cloud.
        Este mapeamento permite identificar rapidamente qual provider
        cada ícone detectado pertence.
        """
        self.provider_mapping = {
            # AWS Services
            'aws_ec2': {'provider': 'aws', 'service': 'EC2', 'type': 'compute'},
            'aws_s3': {'provider': 'aws', 'service': 'S3', 'type': 'storage'},
            'aws_lambda': {'provider': 'aws', 'service': 'Lambda', 'type': 'compute'},
            'aws_rds': {'provider': 'aws', 'service': 'RDS', 'type': 'storage'},
            'aws_vpc': {'provider': 'aws', 'service': 'VPC', 'type': 'networking'},
            'aws_elb': {'provider': 'aws', 'service': 'ELB', 'type': 'networking'},
            'aws_cloudfront': {'provider': 'aws', 'service': 'CloudFront', 'type': 'networking'},
            'aws_dynamodb': {'provider': 'aws', 'service': 'DynamoDB', 'type': 'storage'},
            'aws_sqs': {'provider': 'aws', 'service': 'SQS', 'type': 'service'},
            'aws_sns': {'provider': 'aws', 'service': 'SNS', 'type': 'service'},
            
            # Azure Services
            'azure_vm': {'provider': 'azure', 'service': 'Virtual Machine', 'type': 'compute'},
            'azure_storage': {'provider': 'azure', 'service': 'Storage Account', 'type': 'storage'},
            'azure_functions': {'provider': 'azure', 'service': 'Functions', 'type': 'compute'},
            'azure_sql': {'provider': 'azure', 'service': 'SQL Database', 'type': 'storage'},
            'azure_vnet': {'provider': 'azure', 'service': 'Virtual Network', 'type': 'networking'},
            'azure_lb': {'provider': 'azure', 'service': 'Load Balancer', 'type': 'networking'},
            'azure_cosmos': {'provider': 'azure', 'service': 'Cosmos DB', 'type': 'storage'},
            
            # GCP Services
            'gcp_compute': {'provider': 'gcp', 'service': 'Compute Engine', 'type': 'compute'},
            'gcp_storage': {'provider': 'gcp', 'service': 'Cloud Storage', 'type': 'storage'},
            'gcp_functions': {'provider': 'gcp', 'service': 'Cloud Functions', 'type': 'compute'},
            'gcp_sql': {'provider': 'gcp', 'service': 'Cloud SQL', 'type': 'storage'},
            'gcp_vpc': {'provider': 'gcp', 'service': 'VPC', 'type': 'networking'},
            'gcp_bigquery': {'provider': 'gcp', 'service': 'BigQuery', 'type': 'storage'},
            'gcp_pubsub': {'provider': 'gcp', 'service': 'Pub/Sub', 'type': 'service'},
            
            # Generic Components
            'generic_database': {'provider': 'generic', 'service': 'Database', 'type': 'storage'},
            'generic_server': {'provider': 'generic', 'service': 'Server', 'type': 'compute'},
            'generic_network': {'provider': 'generic', 'service': 'Network', 'type': 'networking'},
            'generic_user': {'provider': 'generic', 'service': 'User', 'type': 'identity'},
        }
    
    def detect(self, image: Any, confidence_threshold: float = 0.45) -> Dict:
        """
        Executa detecção YOLO na imagem fornecida.
        
        Args:
            image: Pode ser um path, PIL Image, ou numpy array
            confidence_threshold: Threshold mínimo de confiança para detecções
            
        Returns:
            Dict contendo as detecções processadas e metadados
        """
        if self.model is None:
            return {
                'success': False,
                'error': 'Modelo YOLO não carregado',
                'detections': []
            }
        
        try:
            # Preparar imagem para inferência
            if isinstance(image, str) or isinstance(image, Path):
                image = Image.open(image)
            elif isinstance(image, np.ndarray):
                image = Image.fromarray(image)
            
            # Executar inferência baseada na versão do YOLO
            if YOLOV8_AVAILABLE:
                results = self.model(image, conf=confidence_threshold)
                detections = self._process_yolov8_results(results)
            elif YOLOV5_AVAILABLE:
                self.model.conf = confidence_threshold
                results = self.model(image)
                detections = self._process_yolov5_results(results)
            else:
                return {
                    'success': False,
                    'error': 'Nenhuma implementação YOLO disponível',
                    'detections': []
                }
            
            # Enriquecer detecções com informações de provider
            enriched_detections = self._enrich_detections(detections)
            
            # Calcular estatísticas
            stats = self._calculate_detection_stats(enriched_detections)
            
            return {
                'success': True,
                'detections': enriched_detections,
                'total_detections': len(enriched_detections),
                'stats': stats,
                'model_info': {
                    'path': str(self.model_path),
                    'device': str(self.device),
                    'threshold': confidence_threshold
                }
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': f'Erro durante detecção: {str(e)}',
                'detections': []
            }
    
    def _process_yolov8_results(self, results) -> List[Dict]:
        """
        Processa resultados do YOLOv8 para formato padronizado.
        YOLOv8 retorna resultados em um formato ligeiramente diferente do v5.
        """
        detections = []
        
        for r in results:
            boxes = r.boxes
            if boxes is not None:
                for box in boxes:
                    # Extrair coordenadas da bounding box
                    x1, y1, x2, y2 = box.xyxy[0].tolist()
                    
                    # Extrair confiança e classe
                    confidence = float(box.conf[0])
                    class_id = int(box.cls[0])
                    
                    # Obter nome da classe
                    class_name = self.class_names[class_id] if class_id < len(self.class_names) else f'class_{class_id}'
                    
                    detections.append({
                        'class_name': class_name,
                        'class_id': class_id,
                        'confidence': confidence,
                        'bbox': {
                            'x1': int(x1),
                            'y1': int(y1),
                            'x2': int(x2),
                            'y2': int(y2),
                            'width': int(x2 - x1),
                            'height': int(y2 - y1),
                            'center_x': int((x1 + x2) / 2),
                            'center_y': int((y1 + y2) / 2)
                        }
                    })
        
        return detections
    
    def _process_yolov5_results(self, results) -> List[Dict]:
        """
        Processa resultados do YOLOv5 para formato padronizado.
        """
        detections = []
        
        # YOLOv5 retorna resultados em results.xyxy[0]
        for detection in results.xyxy[0]:
            x1, y1, x2, y2, conf, cls = detection.tolist()
            
            class_id = int(cls)
            class_name = self.model.names[class_id] if hasattr(self.model, 'names') else f'class_{class_id}'
            
            detections.append({
                'class_name': class_name,
                'class_id': class_id,
                'confidence': float(conf),
                'bbox': {
                    'x1': int(x1),
                    'y1': int(y1),
                    'x2': int(x2),
                    'y2': int(y2),
                    'width': int(x2 - x1),
                    'height': int(y2 - y1),
                    'center_x': int((x1 + x2) / 2),
                    'center_y': int((y1 + y2) / 2)
                }
            })
        
        return detections
    
    def _enrich_detections(self, detections: List[Dict]) -> List[Dict]:
        """
        Enriquece as detecções com informações sobre provider, serviço e tipo.
        Este método mapeia as classes detectadas para informações úteis sobre
        o serviço de cloud correspondente.
        """
        enriched = []
        
        for detection in detections:
            class_name = detection['class_name']
            
            # Buscar informações no mapeamento
            if class_name in self.provider_mapping:
                info = self.provider_mapping[class_name]
                detection['provider'] = info['provider']
                detection['service'] = info['service']
                detection['component_type'] = info['type']
                detection['full_name'] = f"{info['provider'].upper()} {info['service']}"
            else:
                # Tentar inferir provider do nome da classe
                if 'aws' in class_name.lower():
                    detection['provider'] = 'aws'
                elif 'azure' in class_name.lower():
                    detection['provider'] = 'azure'
                elif 'gcp' in class_name.lower() or 'google' in class_name.lower():
                    detection['provider'] = 'gcp'
                else:
                    detection['provider'] = 'generic'
                
                # Extrair nome do serviço
                parts = class_name.split('_')
                detection['service'] = parts[-1].title() if len(parts) > 1 else class_name
                detection['component_type'] = self._infer_component_type(class_name)
                detection['full_name'] = detection['service']
            
            enriched.append(detection)
        
        return enriched
    
    def _infer_component_type(self, class_name: str) -> str:
        """
        Infere o tipo de componente baseado no nome da classe quando
        não há mapeamento explícito disponível.
        """
        class_lower = class_name.lower()
        
        # Palavras-chave para cada tipo
        storage_keywords = ['storage', 's3', 'database', 'db', 'rds', 'cosmos', 'bigquery', 'dynamodb']
        compute_keywords = ['compute', 'vm', 'ec2', 'lambda', 'function', 'container', 'kubernetes']
        network_keywords = ['network', 'vpc', 'vnet', 'load', 'balancer', 'gateway', 'firewall', 'cdn']
        
        for keyword in storage_keywords:
            if keyword in class_lower:
                return 'storage'
        
        for keyword in compute_keywords:
            if keyword in class_lower:
                return 'compute'
        
        for keyword in network_keywords:
            if keyword in class_lower:
                return 'networking'
        
        return 'service'  # Default
    
    def _calculate_detection_stats(self, detections: List[Dict]) -> Dict:
        """
        Calcula estatísticas sobre as detecções para fornecer
        insights sobre a arquitetura detectada.
        """
        if not detections:
            return {}
        
        stats = {
            'providers': {},
            'component_types': {},
            'confidence': {
                'mean': 0,
                'min': 1.0,
                'max': 0,
                'high_confidence_count': 0  # Detecções com > 0.8 de confiança
            }
        }
        
        confidences = []
        
        for detection in detections:
            # Contabilizar providers
            provider = detection.get('provider', 'unknown')
            stats['providers'][provider] = stats['providers'].get(provider, 0) + 1
            
            # Contabilizar tipos de componentes
            comp_type = detection.get('component_type', 'unknown')
            stats['component_types'][comp_type] = stats['component_types'].get(comp_type, 0) + 1
            
            # Coletar confidências
            conf = detection['confidence']
            confidences.append(conf)
            
            if conf > 0.8:
                stats['confidence']['high_confidence_count'] += 1
        
        # Calcular estatísticas de confiança
        stats['confidence']['mean'] = np.mean(confidences)
        stats['confidence']['min'] = min(confidences)
        stats['confidence']['max'] = max(confidences)
        
        # Identificar provider dominante
        if stats['providers']:
            stats['dominant_provider'] = max(stats['providers'], key=stats['providers'].get)
        
        # Identificar se é arquitetura multi-cloud
        stats['is_multi_cloud'] = len(stats['providers']) > 1
        
        return stats