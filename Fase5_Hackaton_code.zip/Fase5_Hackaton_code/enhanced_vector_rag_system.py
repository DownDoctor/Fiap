#!/usr/bin/env python3
"""
Enhanced Vector RAG System FIXED - Chat RAG Especializado 
✅ Combina análise atual + Knowledge Base local
✅ Respostas contextuais específicas da arquitetura
✅ KB OWASP/NIST/STRIDE integrada
✅ Fallback inteligente sem OpenAI
"""

import json
import os
import hashlib
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
import re

# Tentar importar dependências opcionais
try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

try:
    import numpy as np
    NUMPY_AVAILABLE = True
except ImportError:
    NUMPY_AVAILABLE = False

# Vector database simples usando arquivos JSON (fallback se não tiver bibliotecas avançadas)
try:
    import chromadb
    from sentence_transformers import SentenceTransformer
    ADVANCED_RAG_AVAILABLE = True
except ImportError:
    ADVANCED_RAG_AVAILABLE = False


class SimpleVectorDB:
    """Vector database simples usando similaridade de texto básica"""
    
    def __init__(self, persist_path: str = "./simple_vector_db"):
        self.persist_path = Path(persist_path)
        self.persist_path.mkdir(exist_ok=True)
        
        self.documents_file = self.persist_path / "documents.json"
        self.index_file = self.persist_path / "index.json"
        
        # Carregar documentos existentes
        self.documents = self._load_documents()
        self.index = self._load_index()
    
    def _load_documents(self) -> List[Dict]:
        """Carrega documentos salvos"""
        if self.documents_file.exists():
            try:
                with open(self.documents_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return []
        return []
    
    def _load_index(self) -> Dict:
        """Carrega índice de busca"""
        if self.index_file.exists():
            try:
                with open(self.index_file, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}
    
    def _save_documents(self):
        """Salva documentos"""
        with open(self.documents_file, 'w', encoding='utf-8') as f:
            json.dump(self.documents, f, ensure_ascii=False, indent=2)
    
    def _save_index(self):
        """Salva índice"""
        with open(self.index_file, 'w', encoding='utf-8') as f:
            json.dump(self.index, f, ensure_ascii=False, indent=2)
    
    def add_document(self, content: str, metadata: Dict = None) -> str:
        """Adiciona documento ao banco vetorial"""
        doc_id = hashlib.md5(content.encode()).hexdigest()[:12]
        
        document = {
            'id': doc_id,
            'content': content,
            'metadata': metadata or {},
            'timestamp': datetime.now().isoformat(),
            'keywords': self._extract_keywords(content)
        }
        
        # Verificar se já existe
        existing_ids = [doc['id'] for doc in self.documents]
        if doc_id not in existing_ids:
            self.documents.append(document)
            self._update_index(document)
            self._save_documents()
            self._save_index()
        
        return doc_id
    
    def _extract_keywords(self, text: str) -> List[str]:
        """Extrai palavras-chave do texto"""
        # Limpeza básica
        text = re.sub(r'[^\w\s]', ' ', text.lower())
        words = text.split()
        
        # Filtrar palavras relevantes (>= 3 caracteres, não números)
        keywords = [word for word in words if len(word) >= 3 and not word.isdigit()]
        
        # Remover duplicatas mantendo ordem
        return list(dict.fromkeys(keywords))
    
    def _update_index(self, document: Dict):
        """Atualiza índice de busca"""
        doc_id = document['id']
        keywords = document['keywords']
        
        for keyword in keywords:
            if keyword not in self.index:
                self.index[keyword] = []
            
            if doc_id not in self.index[keyword]:
                self.index[keyword].append(doc_id)
    
    def search(self, query: str, top_k: int = 5) -> List[Dict]:
        """Busca documentos relevantes"""
        query_keywords = self._extract_keywords(query)
        
        # Score de documentos baseado em keywords matching
        doc_scores = {}
        
        for keyword in query_keywords:
            if keyword in self.index:
                for doc_id in self.index[keyword]:
                    if doc_id not in doc_scores:
                        doc_scores[doc_id] = 0
                    doc_scores[doc_id] += 1
        
        # Ordenar por relevância
        sorted_docs = sorted(doc_scores.items(), key=lambda x: x[1], reverse=True)
        
        # Buscar documentos completos
        results = []
        for doc_id, score in sorted_docs[:top_k]:
            doc = next((d for d in self.documents if d['id'] == doc_id), None)
            if doc:
                results.append({
                    'document': doc['content'],
                    'metadata': doc['metadata'],
                    'score': score,
                    'id': doc_id
                })
        
        return results
    
    def get_stats(self) -> Dict:
        """Retorna estatísticas do banco"""
        return {
            'total_documents': len(self.documents),
            'total_keywords': len(self.index),
            'avg_keywords_per_doc': round(sum(len(doc['keywords']) for doc in self.documents) / max(1, len(self.documents)), 1)
        }


class EnhancedVectorDB:
    """Vector database avançado (quando bibliotecas estão disponíveis)"""
    
    def __init__(self, persist_path: str = "./chroma_db_enhanced"):
        self.persist_path = Path(persist_path)
        self.persist_path.mkdir(exist_ok=True)
        
        if ADVANCED_RAG_AVAILABLE:
            self.client = chromadb.PersistentClient(path=str(self.persist_path))
            self.collection = self.client.get_or_create_collection(
                name="stride_knowledge",
                metadata={"description": "STRIDE Security Knowledge Base"}
            )
            
            # Encoder para embeddings
            self.encoder = SentenceTransformer('all-MiniLM-L6-v2')
            self.advanced_mode = True
        else:
            # Fallback para modo simples
            self.simple_db = SimpleVectorDB(persist_path)
            self.advanced_mode = False
    
    def add_document(self, content: str, metadata: Dict = None) -> str:
        """Adiciona documento ao banco vetorial"""
        if self.advanced_mode:
            return self._add_document_advanced(content, metadata)
        else:
            return self.simple_db.add_document(content, metadata)
    
    def _add_document_advanced(self, content: str, metadata: Dict = None) -> str:
        """Adiciona documento usando ChromaDB + embeddings"""
        doc_id = hashlib.md5(content.encode()).hexdigest()[:12]
        
        # Gerar embedding
        embedding = self.encoder.encode([content])[0].tolist()
        
        # Adicionar à coleção
        self.collection.add(
            embeddings=[embedding],
            documents=[content],
            metadatas=[metadata or {}],
            ids=[doc_id]
        )
        
        return doc_id
    
    def search(self, query: str, top_k: int = 5) -> List[Dict]:
        """Busca documentos relevantes"""
        if self.advanced_mode:
            return self._search_advanced(query, top_k)
        else:
            return self.simple_db.search(query, top_k)
    
    def _search_advanced(self, query: str, top_k: int) -> List[Dict]:
        """Busca avançada com embeddings"""
        # Gerar embedding da query
        query_embedding = self.encoder.encode([query])[0].tolist()
        
        # Buscar documentos similares
        results = self.collection.query(
            query_embeddings=[query_embedding],
            n_results=top_k,
            include=['documents', 'metadatas', 'distances']
        )
        
        # Formatar resultados
        formatted_results = []
        if results['documents'] and results['documents'][0]:
            for i, doc in enumerate(results['documents'][0]):
                formatted_results.append({
                    'document': doc,
                    'metadata': results['metadatas'][0][i] if results['metadatas'][0] else {},
                    'score': 1.0 - results['distances'][0][i],  # Converter distância para score
                    'id': f"doc_{i}"
                })
        
        return formatted_results
    
    def get_stats(self) -> Dict:
        """Retorna estatísticas do banco"""
        if self.advanced_mode:
            count = self.collection.count()
            return {
                'total_documents': count,
                'mode': 'advanced',
                'encoder': 'all-MiniLM-L6-v2'
            }
        else:
            stats = self.simple_db.get_stats()
            stats['mode'] = 'simple'
            return stats


class SecurityKnowledgeBase:
    """Knowledge Base especializada em segurança"""
    
    def __init__(self):
        # Knowledge base integrada
        self.owasp_knowledge = self._load_owasp_knowledge()
        self.stride_knowledge = self._load_stride_knowledge()
        self.nist_knowledge = self._load_nist_knowledge()
        self.cloud_security_knowledge = self._load_cloud_security_knowledge()
        
        # Combinar todas as bases
        self.combined_knowledge = {
            **self.owasp_knowledge,
            **self.stride_knowledge, 
            **self.nist_knowledge,
            **self.cloud_security_knowledge
        }
    
    def _load_owasp_knowledge(self) -> Dict:
        """Carrega conhecimento OWASP Top 10"""
        return {
            'owasp_a01_broken_access_control': {
                'title': 'A01:2021 – Broken Access Control',
                'description': 'Falhas no controle de acesso que permitem que atacantes acessem funcionalidades ou dados não autorizados',
                'examples': [
                    'Violation of the principle of least privilege',
                    'Bypassing access control checks by modifying the URL',
                    'Elevation of privilege'
                ],
                'prevention': [
                    'Implement proper access controls',
                    'Deny by default',
                    'Log access control failures',
                    'Rate limit API and controller access'
                ],
                'stride_mapping': ['Spoofing', 'Elevation of Privilege']
            },
            'owasp_a02_cryptographic_failures': {
                'title': 'A02:2021 – Cryptographic Failures',
                'description': 'Falhas relacionadas à criptografia que podem levar à exposição de dados sensíveis',
                'examples': [
                    'Data transmitted in clear text',
                    'Old or weak cryptographic algorithms',
                    'Default crypto keys in use'
                ],
                'prevention': [
                    'Encrypt all data in transit',
                    'Encrypt all sensitive data at rest', 
                    'Use up to date and strong standard algorithms',
                    'Proper key management'
                ],
                'stride_mapping': ['Information Disclosure', 'Tampering']
            },
            'owasp_a03_injection': {
                'title': 'A03:2021 – Injection',
                'description': 'Falhas de injeção como SQL, NoSQL, OS, e LDAP injection',
                'examples': [
                    'SQL injection',
                    'NoSQL injection',
                    'Command injection',
                    'LDAP injection'
                ],
                'prevention': [
                    'Use parameterized queries',
                    'Validate input',
                    'Escape special characters',
                    'Use LIMIT and other SQL controls'
                ],
                'stride_mapping': ['Tampering', 'Information Disclosure', 'Elevation of Privilege']
            },
            'owasp_a04_insecure_design': {
                'title': 'A04:2021 – Insecure Design',
                'description': 'Falhas no design de segurança, diferente de implementação insegura',
                'examples': [
                    'Missing threat modeling',
                    'Insecure design patterns',
                    'Business logic flaws'
                ],
                'prevention': [
                    'Secure development lifecycle',
                    'Threat modeling',
                    'Security architecture review',
                    'Unit and integration tests for authorization'
                ],
                'stride_mapping': ['All STRIDE categories']
            }
        }
    
    def _load_stride_knowledge(self) -> Dict:
        """Carrega conhecimento específico STRIDE"""
        return {
            'stride_spoofing': {
                'title': 'STRIDE: Spoofing Identity',
                'description': 'Ameaças de falsificação de identidade onde atacantes se fazem passar por usuários legítimos',
                'attack_examples': [
                    'IP spoofing',
                    'Email spoofing', 
                    'User identity spoofing',
                    'Website spoofing'
                ],
                'mitigations': [
                    'Strong authentication (MFA)',
                    'Digital certificates',
                    'Kerberos authentication',
                    'PKI infrastructure'
                ],
                'cloud_specific': {
                    'azure': ['Azure AD', 'Managed Identity', 'Conditional Access'],
                    'aws': ['IAM', 'Cognito', 'STS'],
                    'gcp': ['Cloud IAM', 'Identity-Aware Proxy']
                }
            },
            'stride_tampering': {
                'title': 'STRIDE: Tampering with Data',
                'description': 'Modificação maliciosa de dados em trânsito ou em repouso',
                'attack_examples': [
                    'Man-in-the-middle attacks',
                    'Data modification in transit',
                    'File tampering',
                    'Database tampering'
                ],
                'mitigations': [
                    'Data integrity checks',
                    'Digital signatures',
                    'HMAC',
                    'Code signing',
                    'File integrity monitoring'
                ],
                'cloud_specific': {
                    'azure': ['Azure Key Vault', 'Storage encryption'],
                    'aws': ['KMS', 'S3 encryption', 'CloudHSM'],
                    'gcp': ['Cloud KMS', 'Encryption at rest']
                }
            },
            'stride_repudiation': {
                'title': 'STRIDE: Repudiation',
                'description': 'Negação de ações realizadas, falta de não-repúdio',
                'attack_examples': [
                    'Denying actions taken',
                    'Log tampering',
                    'Audit trail manipulation'
                ],
                'mitigations': [
                    'Strong audit logs',
                    'Digital signatures',
                    'Time stamping',
                    'Secure logging',
                    'Log integrity protection'
                ],
                'cloud_specific': {
                    'azure': ['Azure Monitor', 'Log Analytics'],
                    'aws': ['CloudTrail', 'CloudWatch'],
                    'gcp': ['Cloud Logging', 'Cloud Audit Logs']
                }
            },
            'stride_information_disclosure': {
                'title': 'STRIDE: Information Disclosure',
                'description': 'Exposição não autorizada de informações',
                'attack_examples': [
                    'Data breaches',
                    'Information leakage',
                    'Privilege escalation to read data',
                    'Metadata exposure'
                ],
                'mitigations': [
                    'Data encryption',
                    'Access controls',
                    'Data Loss Prevention (DLP)',
                    'Data classification',
                    'Least privilege access'
                ],
                'cloud_specific': {
                    'azure': ['Azure Information Protection', 'Data Classification'],
                    'aws': ['Macie', 'S3 bucket policies'],
                    'gcp': ['Cloud DLP', 'Data Classification']
                }
            },
            'stride_denial_of_service': {
                'title': 'STRIDE: Denial of Service',
                'description': 'Negação ou degradação de serviços para usuários legítimos',
                'attack_examples': [
                    'DDoS attacks',
                    'Resource exhaustion',
                    'Application-level DoS',
                    'Infrastructure attacks'
                ],
                'mitigations': [
                    'Rate limiting',
                    'Load balancing',
                    'Auto-scaling',
                    'DDoS protection',
                    'Resource monitoring'
                ],
                'cloud_specific': {
                    'azure': ['Azure DDoS Protection', 'Application Gateway'],
                    'aws': ['Shield', 'CloudFront', 'Auto Scaling'],
                    'gcp': ['Cloud Armor', 'Load Balancing']
                }
            },
            'stride_elevation_of_privilege': {
                'title': 'STRIDE: Elevation of Privilege',
                'description': 'Obtenção não autorizada de privilégios elevados',
                'attack_examples': [
                    'Privilege escalation bugs',
                    'Admin account compromise',
                    'Lateral movement',
                    'Container escape'
                ],
                'mitigations': [
                    'Principle of least privilege',
                    'Role-based access control (RBAC)',
                    'Privilege access management (PAM)',
                    'Regular access reviews',
                    'Container security'
                ],
                'cloud_specific': {
                    'azure': ['Privileged Identity Management', 'RBAC'],
                    'aws': ['IAM Roles', 'SCP', 'Access Analyzer'], 
                    'gcp': ['Cloud IAM', 'Organization Policy']
                }
            }
        }
    
    def _load_nist_knowledge(self) -> Dict:
        """Carrega conhecimento NIST Framework"""
        return {
            'nist_identify': {
                'title': 'NIST: Identify (ID)',
                'description': 'Desenvolver compreensão organizacional para gerenciar risco de cibersegurança',
                'categories': [
                    'Asset Management (ID.AM)',
                    'Business Environment (ID.BE)', 
                    'Governance (ID.GV)',
                    'Risk Assessment (ID.RA)',
                    'Risk Management Strategy (ID.RM)'
                ],
                'stride_relevance': 'Foundation for all STRIDE analysis'
            },
            'nist_protect': {
                'title': 'NIST: Protect (PR)',
                'description': 'Desenvolver e implementar salvaguardas apropriadas',
                'categories': [
                    'Identity Management (PR.AC)',
                    'Awareness and Training (PR.AT)',
                    'Data Security (PR.DS)',
                    'Information Protection (PR.IP)',
                    'Maintenance (PR.MA)',
                    'Protective Technology (PR.PT)'
                ],
                'stride_relevance': 'Primary mitigation for Spoofing, Tampering, Information Disclosure'
            },
            'nist_detect': {
                'title': 'NIST: Detect (DE)',
                'description': 'Desenvolver e implementar atividades apropriadas para identificar ocorrência de evento de cibersegurança',
                'categories': [
                    'Anomalies and Events (DE.AE)',
                    'Security Continuous Monitoring (DE.CM)',
                    'Detection Processes (DE.DP)'
                ],
                'stride_relevance': 'Essential for Repudiation and early threat detection'
            }
        }
    
    def _load_cloud_security_knowledge(self) -> Dict:
        """Carrega conhecimento específico de segurança cloud"""
        return {
            'cloud_shared_responsibility': {
                'title': 'Cloud Shared Responsibility Model',
                'description': 'Modelo de responsabilidade compartilhada entre provedor e cliente',
                'aws_model': {
                    'aws_responsibility': 'Security OF the cloud (infrastructure, hardware, software)',
                    'customer_responsibility': 'Security IN the cloud (data, configurations, access management)'
                },
                'azure_model': {
                    'microsoft_responsibility': 'Physical security, network controls, host OS patching',
                    'customer_responsibility': 'Data classification, identity management, network security'
                },
                'gcp_model': {
                    'google_responsibility': 'Infrastructure security, encryption at rest',
                    'customer_responsibility': 'Access policies, network security, data encryption'
                }
            },
            'cloud_identity_management': {
                'title': 'Cloud Identity and Access Management',
                'description': 'Melhores práticas para IAM em ambiente cloud',
                'best_practices': [
                    'Implement least privilege access',
                    'Use multi-factor authentication', 
                    'Regular access reviews',
                    'Centralized identity management',
                    'Just-in-time access'
                ],
                'tools': {
                    'azure': 'Azure Active Directory',
                    'aws': 'AWS IAM + Organizations',
                    'gcp': 'Google Cloud Identity'
                }
            }
        }
    
    def search_knowledge(self, query: str, categories: List[str] = None) -> List[Dict]:
        """Busca conhecimento específico"""
        query_lower = query.lower()
        results = []
        
        # Buscar em todas as categorias ou nas especificadas
        knowledge_sources = {
            'owasp': self.owasp_knowledge,
            'stride': self.stride_knowledge,
            'nist': self.nist_knowledge,
            'cloud': self.cloud_security_knowledge
        }
        
        if categories:
            knowledge_sources = {k: v for k, v in knowledge_sources.items() if k in categories}
        
        for source_name, knowledge in knowledge_sources.items():
            for key, item in knowledge.items():
                # Calcular relevância baseada em palavras-chave
                relevance_score = 0
                
                # Buscar no título
                if any(word in item.get('title', '').lower() for word in query_lower.split()):
                    relevance_score += 3
                
                # Buscar na descrição
                if any(word in item.get('description', '').lower() for word in query_lower.split()):
                    relevance_score += 2
                
                # Buscar em exemplos
                examples = item.get('examples', []) + item.get('attack_examples', [])
                if any(any(word in example.lower() for word in query_lower.split()) for example in examples):
                    relevance_score += 1
                
                # Buscar em mitigações
                mitigations = item.get('prevention', []) + item.get('mitigations', [])
                if any(any(word in mitigation.lower() for word in query_lower.split()) for mitigation in mitigations):
                    relevance_score += 1
                
                if relevance_score > 0:
                    results.append({
                        'source': source_name,
                        'key': key,
                        'content': item,
                        'relevance_score': relevance_score
                    })
        
        # Ordenar por relevância
        return sorted(results, key=lambda x: x['relevance_score'], reverse=True)


class RAGChatEngine:
    """Motor de chat RAG especializado para STRIDE"""
    
    def __init__(self, vector_db: EnhancedVectorDB = None):
        self.vector_db = vector_db or EnhancedVectorDB()
        self.security_kb = SecurityKnowledgeBase()
        
        # OpenAI client se disponível
        self.openai_available = OPENAI_AVAILABLE and os.getenv('OPENAI_API_KEY')
        if self.openai_available:
            self.client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
        
        # Histórico de conversas
        self.conversation_history = []
        self.max_history = 10
        
        # Inicializar KB no vector database
        self._initialize_knowledge_base()
        
        print(f"🤖 RAG Chat Engine inicializado")
        print(f"   Vector DB: {'✅ Avançado' if self.vector_db.advanced_mode else '⚙️ Simples'}")
        print(f"   OpenAI: {'✅ Disponível' if self.openai_available else '❌ Local apenas'}")
        print(f"   Knowledge Base: ✅ {len(self.security_kb.combined_knowledge)} itens")
    
    def _initialize_knowledge_base(self):
        """Inicializa knowledge base no vector database"""
        print("📚 Inicializando Knowledge Base...")
        
        # Adicionar conhecimento ao vector database
        for key, item in self.security_kb.combined_knowledge.items():
            content = f"""
            Title: {item.get('title', key)}
            Description: {item.get('description', '')}
            
            Examples: {'; '.join(item.get('examples', []) + item.get('attack_examples', []))}
            
            Prevention/Mitigations: {'; '.join(item.get('prevention', []) + item.get('mitigations', []))}
            
            STRIDE Mapping: {item.get('stride_mapping', 'N/A')}
            """
            
            metadata = {
                'source': 'security_kb',
                'key': key,
                'title': item.get('title', key),
                'type': 'knowledge_base'
            }
            
            self.vector_db.add_document(content.strip(), metadata)
        
        stats = self.vector_db.get_stats()
        print(f"✅ Knowledge Base carregada: {stats.get('total_documents', 0)} documentos")
    
    def enhanced_chat(self, query: str, analysis_result: Dict = None, max_tokens: int = 800) -> str:
        """
        Chat principal com contexto enriquecido
        
        Args:
            query: Pergunta do usuário
            analysis_result: Resultado da análise STRIDE atual (opcional)
            max_tokens: Máximo de tokens para resposta OpenAI
            
        Returns:
            Resposta contextualizada
        """
        
        print(f"💬 Processando query: {query[:50]}{'...' if len(query) > 50 else ''}")
        
        # 1. Extrair contexto da análise atual
        analysis_context = self._build_analysis_context(analysis_result)
        
        # 2. Buscar conhecimento relevante no vector DB
        vector_context = self._search_vector_knowledge(query)
        
        # 3. Buscar conhecimento específico na KB
        kb_context = self._search_security_knowledge(query)
        
        # 4. Gerar resposta
        if self.openai_available:
            response = self._generate_openai_response(query, analysis_context, vector_context, kb_context, max_tokens)
        else:
            response = self._generate_local_response(query, analysis_context, vector_context, kb_context)
        
        # 5. Adicionar ao histórico
        self._add_to_history(query, response, analysis_result)
        
        return response
    
    def _build_analysis_context(self, analysis_result: Dict = None) -> str:
        """Constrói contexto da análise atual"""
        if not analysis_result:
            return "Nenhuma análise STRIDE ativa no momento."
        
        # Extrair informações principais
        components = analysis_result.get('detected_components', [])
        threats = analysis_result.get('stride_threats', [])
        risk_metrics = analysis_result.get('risk_metrics', {})
        cloud_providers = analysis_result.get('cloud_providers', {})
        
        # Construir contexto estruturado
        context_parts = ["=== ANÁLISE STRIDE ATUAL ==="]
        
        # Componentes
        if components:
            context_parts.append("COMPONENTES DETECTADOS:")
            for comp in components[:5]:  # Top 5 componentes
                provider_info = f" ({comp.get('provider', 'unknown')})" if comp.get('provider') else ""
                context_parts.append(f"• {comp.get('name', 'Unknown')}{provider_info} - {comp.get('type', 'unknown')} - Criticidade: {comp.get('security_criticality', 'medium')}")
        
        # Provedores cloud
        if cloud_providers:
            providers_list = ', '.join([f"{k.upper()}({v.get('count', 0)})" for k, v in cloud_providers.items()])
            context_parts.append(f"PROVEDORES: {providers_list}")
        
        # Métricas de risco
        overall_risk = risk_metrics.get('overall_risk_score', 0)
        risk_level = risk_metrics.get('risk_level', 'unknown')
        total_threats = len(threats)
        
        context_parts.extend([
            f"RISK SCORE: {overall_risk}/10 ({risk_level.upper()})",
            f"TOTAL DE AMEAÇAS: {total_threats}"
        ])
        
        # Top 3 ameaças
        if threats:
            context_parts.append("PRINCIPAIS AMEAÇAS:")
            top_threats = sorted(threats, key=lambda x: x.get('risk_score', 0), reverse=True)[:3]
            for i, threat in enumerate(top_threats, 1):
                context_parts.append(f"{i}. {threat.get('category', 'Unknown')}: {threat.get('description', 'N/A')} (Risk: {threat.get('risk_score', 0)}/10)")
        
        return '\n'.join(context_parts)
    
    def _search_vector_knowledge(self, query: str) -> str:
        """Busca conhecimento no vector database"""
        try:
            results = self.vector_db.search(query, top_k=3)
            
            if not results:
                return "Nenhum conhecimento específico encontrado no banco vetorial."
            
            context_parts = ["=== CONHECIMENTO VETORIAL RELEVANTE ==="]
            
            for i, result in enumerate(results, 1):
                doc = result.get('document', '')
                metadata = result.get('metadata', {})
                score = result.get('score', 0)
                
                context_parts.append(f"[Conhecimento {i} - Score: {score:.2f}]")
                context_parts.append(f"Fonte: {metadata.get('title', 'Unknown')}")
                context_parts.append(doc[:300] + ('...' if len(doc) > 300 else ''))
                context_parts.append("")
            
            return '\n'.join(context_parts)
            
        except Exception as e:
            return f"Erro na busca vetorial: {str(e)}"
    
    def _search_security_knowledge(self, query: str) -> str:
        """Busca conhecimento na KB de segurança"""
        try:
            results = self.security_kb.search_knowledge(query)
            
            if not results:
                return "Nenhum conhecimento específico de segurança encontrado."
            
            context_parts = ["=== KNOWLEDGE BASE DE SEGURANÇA ==="]
            
            # Top 3 resultados mais relevantes
            for i, result in enumerate(results[:3], 1):
                source = result.get('source', '').upper()
                content = result.get('content', {})
                relevance = result.get('relevance_score', 0)
                
                context_parts.append(f"[{source} {i} - Relevância: {relevance}]")
                context_parts.append(f"Título: {content.get('title', 'N/A')}")
                context_parts.append(f"Descrição: {content.get('description', 'N/A')}")
                
                # Adicionar mitigações se existirem
                mitigations = content.get('prevention', []) + content.get('mitigations', [])
                if mitigations:
                    context_parts.append(f"Mitigações: {'; '.join(mitigations[:3])}")
                
                # Cloud-specific se existir
                if 'cloud_specific' in content:
                    cloud_info = []
                    for provider, tools in content['cloud_specific'].items():
                        cloud_info.append(f"{provider.upper()}: {', '.join(tools[:2])}")
                    context_parts.append(f"Cloud: {'; '.join(cloud_info)}")
                
                context_parts.append("")
            
            return '\n'.join(context_parts)
            
        except Exception as e:
            return f"Erro na busca de KB: {str(e)}"
    
    def _generate_openai_response(self, query: str, analysis_context: str, 
                                  vector_context: str, kb_context: str, max_tokens: int) -> str:
        """Gera resposta usando OpenAI"""
        try:
            # Construir prompt estruturado
            system_prompt = """Você é um especialista em segurança cibernética especializado em análise STRIDE e arquiteturas cloud.

Instruções:
1. Responda baseado PRIMEIRO na análise atual quando disponível
2. Use o conhecimento de segurança (OWASP, NIST, STRIDE) para enriquecer a resposta
3. Seja específico sobre componentes e ameaças identificados
4. Forneça recomendações práticas e acionáveis
5. Cite referências quando apropriado (OWASP, NIST, Microsoft STRIDE)
6. Mantenha resposta concisa mas informativa
7. Use emojis para melhor organização visual
8. Se não houver análise atual, foque no conhecimento de segurança geral"""

            user_prompt = f"""
{analysis_context}

{vector_context}

{kb_context}

PERGUNTA DO USUÁRIO: {query}

Responda de forma clara, específica e acionável baseado no contexto fornecido."""

            response = self.client.chat.completions.create(
                model="gpt-4o-mini",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {"role": "user", "content": user_prompt}
                ],
                max_tokens=max_tokens,
                temperature=0.1
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            print(f"❌ Erro OpenAI: {e}")
            # Fallback para resposta local
            return self._generate_local_response(query, analysis_context, vector_context, kb_context)
    
    def _generate_local_response(self, query: str, analysis_context: str, 
                                 vector_context: str, kb_context: str) -> str:
        """Gera resposta local inteligente sem OpenAI"""
        
        query_lower = query.lower()
        
        # Detectar tipo de pergunta e gerar resposta contextual
        
        # 1. Perguntas sobre melhoria de risk score
        if any(term in query_lower for term in ['melhorar', 'reduzir', 'diminuir', 'risk score', 'risco']):
            return self._generate_risk_improvement_response(analysis_context, kb_context)
        
        # 2. Perguntas sobre categorias STRIDE específicas
        stride_categories = ['spoofing', 'tampering', 'repudiation', 'information disclosure', 'denial of service', 'elevation of privilege']
        for category in stride_categories:
            if category.replace(' ', '') in query_lower.replace(' ', ''):
                return self._generate_stride_category_response(category, analysis_context, kb_context)
        
        # 3. Perguntas sobre componentes
        if any(term in query_lower for term in ['componentes', 'detectados', 'arquitetura', 'detectou']):
            return self._generate_components_response(analysis_context, kb_context)
        
        # 4. Perguntas sobre recomendações
        if any(term in query_lower for term in ['recomend', 'sugest', 'como', 'o que fazer', 'implementar']):
            return self._generate_recommendations_response(analysis_context, kb_context)
        
        # 5. Perguntas sobre compliance
        if any(term in query_lower for term in ['compliance', 'conformidade', 'nist', 'iso', 'soc2']):
            return self._generate_compliance_response(analysis_context, kb_context)
        
        # 6. Resposta genérica contextual
        return self._generate_generic_contextual_response(query, analysis_context, vector_context, kb_context)
    
    def _generate_risk_improvement_response(self, analysis_context: str, kb_context: str) -> str:
        """Resposta específica para melhoria de risk score"""
        return f"""🎯 **Como melhorar o risk score da sua arquitetura:**

{analysis_context}

**🚀 Ações Prioritárias Recomendadas:**

1. **🔐 Fortalecer Autenticação**
   - Implementar Multi-Factor Authentication (MFA)
   - Usar Azure AD / AWS IAM com políticas rigorosas
   - Configurar Conditional Access

2. **🛡️ Implementar Controles de Segurança**
   - Criptografia end-to-end para dados em trânsito
   - Encryption at rest para dados armazenados
   - Network Security Groups / VPC Security

3. **📊 Monitoramento e Alertas**
   - SIEM/SOAR para detecção de ameaças
   - Logging abrangente (CloudTrail, Azure Monitor)
   - Alertas automatizados para atividades suspeitas

4. **🔒 Principle of Least Privilege**
   - Revisar e reduzir permissões excessivas
   - Implementar Just-In-Time Access
   - Role-Based Access Control (RBAC)

5. **🔍 Auditorias Regulares**
   - Penetration testing trimestral
   - Vulnerability assessments
   - Access reviews mensais

**📚 Referências aplicáveis:**
{self._extract_relevant_references(kb_context)}

💡 **Dica:** Configure a OpenAI API para recomendações mais específicas baseadas nos componentes detectados!"""

    def _generate_stride_category_response(self, category: str, analysis_context: str, kb_context: str) -> str:
        """Resposta específica para categoria STRIDE"""
        
        category_icons = {
            'spoofing': '🎭',
            'tampering': '🔧',
            'repudiation': '📝',
            'information disclosure': '🔍',
            'denial of service': '⚡',
            'elevation of privilege': '⬆️'
        }
        
        icon = category_icons.get(category, '🔒')
        category_title = category.replace('_', ' ').title()
        
        return f"""{icon} **Análise de {category_title} na sua arquitetura:**

{analysis_context}

**🎯 {category_title.upper()} IDENTIFICADO:**

• **Definição:** {self._get_stride_definition(category)}
• **Riscos na arquitetura:** Baseado nos componentes detectados
• **Impacto potencial:** Comprometimento da segurança arquitetural

**🛡️ Mitigações Específicas:**

{self._get_stride_mitigations(category)}

**☁️ Soluções Cloud Específicas:**

• **Azure:** {self._get_cloud_solutions(category, 'azure')}
• **AWS:** {self._get_cloud_solutions(category, 'aws')}
• **GCP:** {self._get_cloud_solutions(category, 'gcp')}

**📚 Referências:**
• Microsoft STRIDE Framework - {category_title}
• OWASP Security Controls
• NIST Cybersecurity Framework

💡 Configure a OpenAI API para análise mais detalhada dos componentes específicos!"""

    def _generate_components_response(self, analysis_context: str, kb_context: str) -> str:
        """Resposta sobre componentes detectados"""
        return f"""🏗️ **Componentes detectados na sua arquitetura:**

{analysis_context}

**🔍 Análise dos Componentes:**

• **Detecção:** Cada componente foi avaliado quanto a ameaças STRIDE específicas
• **Risk Assessment:** Risk score calculado baseado nas vulnerabilidades identificadas
• **Criticidade:** Classificação por nível de importância de segurança

**⚙️ Recomendações por Tipo:**

• **Networking Components:** Implementar Network Security Groups, firewalls, VPN
• **Compute Components:** Hardening, patch management, monitoring
• **Storage Components:** Encryption, access controls, backup security

**☁️ Melhores Práticas:**

• **Multi-Cloud:** Governança unificada, controles consistentes
• **Hybrid:** Conectividade segura, identity federation
• **On-Premises:** Integration security, compliance alignment

**📊 Próximos Passos:**

1. Implementar controles específicos por componente
2. Configurar monitoramento adequado
3. Estabelecer políticas de segurança
4. Realizar assessments regulares

💡 Configure a OpenAI API para análise mais específica de cada componente!"""

    def _generate_recommendations_response(self, analysis_context: str, kb_context: str) -> str:
        """Resposta com recomendações gerais"""
        return f"""🎯 **Recomendações de Segurança para sua Arquitetura:**

{analysis_context}

**🚀 Recomendações Prioritárias:**

**1. 🔴 CRÍTICO - Implementação Imediata (1-2 semanas)**
   • Multi-Factor Authentication em todos os pontos de acesso
   • Encryption para dados em trânsito e repouso
   • Network segmentation e micro-segmentation

**2. 🟠 ALTO - Implementação Rápida (1 mês)**
   • Centralized logging e SIEM
   • Vulnerability management program
   • Backup e disaster recovery testing

**3. 🟡 MÉDIO - Implementação Programada (2-3 meses)**
   • Security awareness training
   • Penetration testing regular
   • Compliance framework implementation

**🛠️ Framework de Implementação:**

• **NIST Framework:** Identify → Protect → Detect → Respond → Recover
• **OWASP:** Focus em Top 10 vulnerabilities
• **Cloud Security:** Shared responsibility model

**📈 Métricas de Sucesso:**
• Redução do risk score para < 6.0
• Zero incidentes críticos
• 100% compliance com frameworks escolhidos

**💰 ROI Esperado:**
• Redução de 60-80% em incidentes de segurança
• Compliance automática com regulamentações
• Redução de custos operacionais de segurança

💡 Para recomendações específicas por componente, configure a OpenAI API!"""

    def _generate_compliance_response(self, analysis_context: str, kb_context: str) -> str:
        """Resposta sobre compliance"""
        return f"""⚖️ **Análise de Compliance para sua Arquitetura:**

{analysis_context}

**📋 Frameworks de Compliance Relevantes:**

**🔹 SOC 2 (System and Organization Controls)**
• Trust Service Criteria: Security, Availability, Confidentiality
• Controles aplicáveis aos componentes cloud detectados
• Auditoria anual recomendada

**🔹 ISO 27001 (Information Security Management)**
• Annex A controls mapeados para ameaças STRIDE
• ISMS (Information Security Management System)
• Continuous improvement process

**🔹 NIST Cybersecurity Framework**
• Identify: Asset management, risk assessment
• Protect: Access controls, data security
• Detect: Monitoring, anomaly detection

**📊 Compliance Score Atual:**
• Baseado no risk score da arquitetura
• Gap analysis automática
• Roadmap de implementação

**🎯 Ações para Compliance:**

1. **Data Classification & Protection**
   • Identify sensitive data flows
   • Implement appropriate controls
   • Regular access reviews

2. **Incident Response Plan**
   • Define response procedures
   • Regular tabletop exercises
   • Integration com SIEM/SOAR

3. **Vendor Management**
   • Third-party risk assessment
   • SLA requirements
   • Regular vendor reviews

**📈 Compliance Roadmap:**
• **Phase 1 (3 months):** Quick wins, basic controls
• **Phase 2 (6 months):** Advanced controls, monitoring
• **Phase 3 (12 months):** Audit readiness, certification

💡 Configure OpenAI para mapeamento detalhado de controles específicos!"""

    def _generate_generic_contextual_response(self, query: str, analysis_context: str, 
                                             vector_context: str, kb_context: str) -> str:
        """Resposta genérica contextual"""
        return f"""🤖 **Resposta baseada no contexto disponível:**

{analysis_context}

**🧠 Knowledge Base Relevante:**
{self._extract_key_points(kb_context)}

**💡 Informações Contextuais:**
{self._extract_key_points(vector_context) if vector_context else 'Nenhum contexto vetorial específico encontrado.'}

**🎯 Para sua pergunta específica:**
{self._generate_query_specific_guidance(query)}

**📚 Recursos Adicionais:**
• **OWASP Top 10:** Vulnerabilidades mais comuns
• **Microsoft STRIDE:** Framework de modelagem de ameaças
• **NIST Framework:** Controles de cibersegurança
• **Cloud Security Alliance:** Melhores práticas cloud

**🔧 Próximos Passos Sugeridos:**

1. **Configurar OpenAI API** para respostas mais específicas e contextuais
2. **Executar análise STRIDE** se ainda não foi feita
3. **Implementar controles básicos** baseados nas recomendações
4. **Estabelecer monitoramento** para detectar ameaças

💡 **Dica:** Para respostas mais inteligentes e específicas, configure a chave da OpenAI API!

**📞 Perguntas Sugeridas:**
• "Como melhorar o risk score da minha arquitetura?"
• "Explique spoofing na minha arquitetura"
• "Quais são as principais recomendações?"
• "Como implementar compliance NIST?""""

    def _get_stride_definition(self, category: str) -> str:
        """Retorna definição da categoria STRIDE"""
        definitions = {
            'spoofing': 'Falsificação de identidade onde atacantes se fazem passar por entidades legítimas',
            'tampering': 'Modificação maliciosa de dados em trânsito ou armazenados',
            'repudiation': 'Negação de ações realizadas, falta de auditoria adequada',
            'information disclosure': 'Exposição não autorizada de informações sensíveis',
            'denial of service': 'Negação ou degradação de serviços para usuários legítimos',
            'elevation of privilege': 'Obtenção não autorizada de privilégios elevados no sistema'
        }
        return definitions.get(category, 'Categoria de ameaça STRIDE')
    
    def _get_stride_mitigations(self, category: str) -> str:
        """Retorna mitigações para categoria STRIDE"""
        mitigations = {
            'spoofing': '• Strong authentication (MFA)\n• Digital certificates\n• Identity verification\n• PKI infrastructure',
            'tampering': '• Data integrity checks (HMAC)\n• Digital signatures\n• File integrity monitoring\n• Code signing',
            'repudiation': '• Comprehensive audit logs\n• Digital signatures\n• Time stamping\n• Non-repudiation protocols',
            'information disclosure': '• Data encryption at rest and in transit\n• Access controls (RBAC)\n• Data loss prevention (DLP)\n• Secure data classification',
            'denial of service': '• Rate limiting and throttling\n• Load balancing\n• DDoS protection\n• Resource monitoring',
            'elevation of privilege': '• Principle of least privilege\n• Regular access reviews\n• Privilege access management (PAM)\n• Security hardening'
        }
        return mitigations.get(category, '• Implementar controles de segurança adequados')
    
    def _get_cloud_solutions(self, category: str, provider: str) -> str:
        """Retorna soluções cloud específicas"""
        solutions = {
            'spoofing': {
                'azure': 'Azure AD, Conditional Access, Managed Identity',
                'aws': 'IAM Roles, Cognito, AWS SSO',
                'gcp': 'Cloud Identity, Identity-Aware Proxy'
            },
            'tampering': {
                'azure': 'Azure Key Vault, Storage encryption',
                'aws': 'AWS KMS, S3 encryption, CloudHSM',
                'gcp': 'Cloud KMS, Encryption at rest'
            },
            'repudiation': {
                'azure': 'Azure Monitor, Log Analytics, Sentinel',
                'aws': 'CloudTrail, CloudWatch, Security Hub',
                'gcp': 'Cloud Logging, Security Command Center'
            },
            'information disclosure': {
                'azure': 'Azure Information Protection, Data Classification',
                'aws': 'Amazon Macie, S3 bucket policies',
                'gcp': 'Cloud DLP, Data Classification'
            },
            'denial of service': {
                'azure': 'Azure DDoS Protection, Application Gateway',
                'aws': 'AWS Shield, CloudFront, Auto Scaling',
                'gcp': 'Cloud Armor, Load Balancing'
            },
            'elevation of privilege': {
                'azure': 'Privileged Identity Management, Azure RBAC',
                'aws': 'IAM Access Analyzer, Service Control Policies',
                'gcp': 'Cloud IAM, Organization Policy Service'
            }
        }
        
        return solutions.get(category, {}).get(provider, f'{provider.upper()} security services')
    
    def _extract_relevant_references(self, kb_context: str) -> str:
        """Extrai referências relevantes do contexto KB"""
        if not kb_context or len(kb_context) < 50:
            return "• OWASP Top 10\n• Microsoft STRIDE Framework\n• NIST Cybersecurity Framework"
        
        # Buscar por padrões de referência no contexto
        references = []
        if 'owasp' in kb_context.lower():
            references.append('• OWASP Top 10 Security Controls')
        if 'nist' in kb_context.lower():
            references.append('• NIST Cybersecurity Framework')
        if 'stride' in kb_context.lower():
            references.append('• Microsoft STRIDE Threat Modeling')
        if 'iso' in kb_context.lower():
            references.append('• ISO 27001 Information Security Management')
        
        return '\n'.join(references) if references else "• Frameworks de segurança padrão da indústria"
    
    def _extract_key_points(self, context: str, max_points: int = 3) -> str:
        """Extrai pontos-chave do contexto"""
        if not context or len(context) < 50:
            return "Nenhuma informação específica disponível."
        
        # Buscar por seções estruturadas
        lines = context.split('\n')
        key_points = []
        
        for line in lines:
            line = line.strip()
            if line and (line.startswith('•') or line.startswith('-') or line.startswith('*')):
                key_points.append(line)
            elif len(line) > 30 and len(line) < 150:  # Frases informativas
                key_points.append(f"• {line}")
            
            if len(key_points) >= max_points:
                break
        
        return '\n'.join(key_points[:max_points]) if key_points else "Informações contextuais disponíveis no knowledge base."
    
    def _generate_query_specific_guidance(self, query: str) -> str:
        """Gera orientação específica para a query"""
        query_lower = query.lower()
        
        if any(term in query_lower for term in ['como', 'how to', 'implementar', 'configure']):
            return "Baseado na sua pergunta sobre implementação, recomendo começar com controles básicos e evoluir gradualmente."
        
        elif any(term in query_lower for term in ['o que é', 'what is', 'explique', 'explain']):
            return "Para explicações detalhadas, consulte a documentação oficial dos frameworks mencionados."
        
        elif any(term in query_lower for term in ['melhor', 'best', 'recomenda', 'suggest']):
            return "As melhores práticas dependem do contexto específico da sua arquitetura e requisitos de compliance."
        
        else:
            return "Para perguntas específicas, tente reformular com mais detalhes ou use termos como 'como implementar', 'o que é', ou 'recomendações para'."
    
    def _add_to_history(self, query: str, response: str, analysis_result: Dict = None):
        """Adiciona interação ao histórico"""
        self.conversation_history.append({
            'timestamp': datetime.now().isoformat(),
            'query': query,
            'response': response,
            'has_analysis': analysis_result is not None,
            'analysis_id': analysis_result.get('analysis_id') if analysis_result else None
        })
        
        # Manter apenas as últimas N conversas
        if len(self.conversation_history) > self.max_history:
            self.conversation_history.pop(0)
    
    def get_chat_history(self) -> List[Dict]:
        """Retorna histórico de conversas"""
        return self.conversation_history.copy()
    
    def clear_history(self):
        """Limpa histórico de conversas"""
        self.conversation_history.clear()
    
    def get_stats(self) -> Dict:
        """Retorna estatísticas do chat engine"""
        return {
            'total_conversations': len(self.conversation_history),
            'openai_available': self.openai_available,
            'vector_db_stats': self.vector_db.get_stats(),
            'knowledge_base_items': len(self.security_kb.combined_knowledge),
            'advanced_mode': self.vector_db.advanced_mode if hasattr(self.vector_db, 'advanced_mode') else False
        }


# Exemplo de uso standalone
def test_rag_chat_engine():
    """Teste do sistema RAG"""
    print("🧪 Testando RAG Chat Engine...")
    
    # Inicializar chat engine
    chat_engine = RAGChatEngine()
    
    # Exemplo de análise simulada
    mock_analysis = {
        'analysis_id': 'test_001',
        'detected_components': [
            {'name': 'ExpressRoute Gateway', 'provider': 'azure', 'type': 'networking', 'security_criticality': 'high'},
            {'name': 'API Gateway', 'provider': 'aws', 'type': 'networking', 'security_criticality': 'critical'}
        ],
        'stride_threats': [
            {'category': 'Spoofing', 'risk_score': 8.5, 'description': 'API Gateway authentication bypass'},
            {'category': 'Information Disclosure', 'risk_score': 9.0, 'description': 'Data exposure through ExpressRoute'}
        ],
        'risk_metrics': {
            'overall_risk_score': 8.7,
            'risk_level': 'high'
        },
        'cloud_providers': {
            'azure': {'count': 1},
            'aws': {'count': 1}
        }
    }
    
    # Teste de perguntas
    test_queries = [
        "Como melhorar o risk score da minha arquitetura?",
        "Explique spoofing na minha arquitetura",
        "Quais componentes foram detectados?",
        "Recomendações de segurança"
    ]
    
    for query in test_queries:
        print(f"\n💬 Pergunta: {query}")
        print("=" * 60)
        
        response = chat_engine.enhanced_chat(query, mock_analysis)
        print(response)
        
        print("\n" + "=" * 60)
    
    # Estatísticas
    stats = chat_engine.get_stats()
    print(f"\n📊 Estatísticas do Chat Engine:")
    for key, value in stats.items():
        print(f"   {key}: {value}")


if __name__ == "__main__":
    test_rag_chat_engine()