"""
html_import_fallback.py
-----------------------
Utilitário para fazer import *robusto* do gerador de relatório HTML.
Tenta, na ordem:
  1) html_report_generator_with_cloud_stamp
  2) html_report_generator_with_refs
  3) html_report_generator    (base)

Expõe dois símbolos compatíveis:
  - generate_html_report(json_report, output_path)
  - STRIDEHTMLReportGenerator  (classe)

Uso no seu stride_integration_llm.py (substitua o import antigo):
    from html_import_fallback import generate_html_report, STRIDEHTMLReportGenerator

Assim você mantém a mesma API sem alterar o resto do código.
"""
from importlib import import_module

def _load_html_gen_module():
    last_exc = None
    for mod in (
        "html_report_generator_with_cloud_stamp",
        "html_report_generator_with_refs",
        "html_report_generator",
    ):
        try:
            return import_module(mod)
        except Exception as e:
            last_exc = e
    raise ImportError("Nenhum gerador de HTML disponível (verifique se html_report_generator.py existe).") from last_exc

_htmlgen = _load_html_gen_module()

# Preferência por função direta (se existir)
_generate_func = getattr(_htmlgen, "generate_html_report", None)
_GenClass = getattr(_htmlgen, "STRIDEHTMLReportGenerator", None)

if _generate_func is None and _GenClass is None:
    raise ImportError("O módulo de relatório não expõe generate_html_report() nem STRIDEHTMLReportGenerator.")

def generate_html_report(json_report, output_path):
    if _generate_func is not None:
        return _generate_func(json_report, output_path)
    # Fallback para classe
    gen = _GenClass()
    return gen.generate_html_report(json_report, output_path)

# Expor a classe também, para compatibilidade
if _GenClass is None:
    # Criar uma classe proxy mínima
    class STRIDEHTMLReportGenerator:
        def generate_html_report(self, json_report, output_path):
            return generate_html_report(json_report, output_path)
else:
    STRIDEHTMLReportGenerator = _GenClass
