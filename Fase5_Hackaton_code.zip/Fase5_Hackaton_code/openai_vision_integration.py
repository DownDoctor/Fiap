# openai_vision_integration.py
"""
Sistema avançado de integração com OpenAI Vision API
Análise detalhada de diagramas de arquitetura com prompts otimizados
"""

from openai import OpenAI
import base64
import json
from typing import Dict, List, Optional, Tuple, Any
import cv2
import numpy as np
from pathlib import Path
import asyncio
import aiohttp
from dataclasses import dataclass, asdict
from enum import Enum
import logging
from datetime import datetime
import hashlib

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class AnalysisDepth(Enum):
    """Níveis de profundidade de análise"""
    BASIC = "basic"
    STANDARD = "standard"
    DETAILED = "detailed"
    COMPREHENSIVE = "comprehensive"


@dataclass
class VisionAnalysisRequest:
    """Requisição de análise estruturada"""
    image_path: str
    analysis_depth: AnalysisDepth
    focus_areas: List[str]
    include_ocr: bool = True
    include_icons: bool = True
    include_flows: bool = True
    include_security: bool = True
    include_cost: bool = True
    max_tokens: int = 4096
    temperature: float = 0.1


class PromptEngineering:
    """Motor de engenharia de prompts otimizados"""
    
    @staticmethod
    def create_system_prompt(depth: AnalysisDepth) -> str:
        """Cria system prompt baseado na profundidade"""
        base_prompt = """You are an expert cloud architect and security analyst with deep expertise in:
- AWS, Azure, GCP, Kubernetes, and hybrid cloud architectures
- STRIDE threat modeling and security analysis
- Compliance frameworks (SOC2, GDPR, HIPAA, PCI-DSS, ISO 27001)
- Cost optimization and performance engineering
- Architecture patterns and anti-patterns
- DevOps and CI/CD practices
- Microservices, serverless, and container orchestration

Your analysis should be:
1. Precise and technically accurate
2. Comprehensive within the requested scope
3. Actionable with specific recommendations
4. Risk-aware with security considerations
5. Cost-conscious with optimization opportunities"""
        
        depth_additions = {
            AnalysisDepth.BASIC: "\n\nProvide a concise analysis focusing on key components and critical issues.",
            AnalysisDepth.STANDARD: "\n\nProvide a balanced analysis covering all major aspects with moderate detail.",
            AnalysisDepth.DETAILED: "\n\nProvide detailed analysis with specific recommendations and risk assessments.",
            AnalysisDepth.COMPREHENSIVE: "\n\nProvide exhaustive analysis covering every aspect with maximum detail, including edge cases and long-term considerations."
        }
        
        return base_prompt + depth_additions[depth]
    
    @staticmethod
    def create_analysis_prompt(request: VisionAnalysisRequest, 
                              context: Optional[Dict] = None) -> str:
        """Cria prompt de análise otimizado"""
        
        # Estrutura JSON esperada
        json_structure = {
            "architecture_overview": {
                "type": "string",
                "description": "microservices|serverless|monolithic|hybrid|event-driven|data-pipeline|ml-platform",
                "confidence": "float (0-1)"
            },
            "cloud_providers": {
                "primary": "string",
                "secondary": ["list of strings"],
                "multi_cloud": "boolean",
                "hybrid_cloud": "boolean"
            },
            "components": [
                {
                    "id": "unique_identifier",
                    "name": "component_name",
                    "type": "compute|storage|database|networking|security|monitoring|ml|analytics",
                    "provider": "AWS|Azure|GCP|Kubernetes|Generic",
                    "service": "specific_service_name",
                    "position": {"x": "float", "y": "float"},
                    "configuration": {},
                    "dependencies": ["list of component_ids"],
                    "security_posture": "exposed|protected|unknown",
                    "estimated_cost": "USD/month range"
                }
            ],
            "connections": [
                {
                    "source": "component_id",
                    "target": "component_id",
                    "type": "data|control|management",
                    "protocol": "HTTPS|TCP|UDP|gRPC|AMQP|WebSocket|Custom",
                    "port": "number or range",
                    "direction": "unidirectional|bidirectional",
                    "encryption": "TLS|mTLS|IPSec|None|Unknown",
                    "authentication": "OAuth|JWT|APIKey|Certificate|None",
                    "data_classification": "public|internal|confidential|restricted"
                }
            ],
            "security_analysis": {
                "overall_score": "1-10",
                "stride_threats": [
                    {
                        "category": "Spoofing|Tampering|Repudiation|InformationDisclosure|DenialOfService|ElevationOfPrivilege",
                        "component": "component_id",
                        "severity": "critical|high|medium|low",
                        "likelihood": "high|medium|low",
                        "impact": "high|medium|low",
                        "description": "detailed threat description",
                        "mitigation": "specific mitigation strategy",
                        "references": ["CVE-IDs or documentation links"]
                    }
                ],
                "vulnerabilities": [],
                "missing_controls": [],
                "compliance_gaps": {}
            },
            "performance_analysis": {
                "bottlenecks": [],
                "scalability_issues": [],
                "single_points_of_failure": [],
                "latency_concerns": []
            },
            "cost_analysis": {
                "estimated_monthly_cost": "USD range",
                "cost_breakdown": {},
                "optimization_opportunities": [],
                "potential_savings": "percentage"
            },
            "recommendations": {
                "immediate": [],
                "short_term": [],
                "long_term": [],
                "best_practices": []
            },
            "patterns_detected": {
                "architectural_patterns": [],
                "anti_patterns": [],
                "security_patterns": []
            }
        }
        
        prompt = f"""Analyze this cloud architecture diagram with {request.analysis_depth.value} depth.

FOCUS AREAS: {', '.join(request.focus_areas)}

{f"CONTEXT: {json.dumps(context, indent=2)}" if context else ""}

Return a comprehensive JSON analysis with this exact structure:
{json.dumps(json_structure, indent=2)}

ANALYSIS REQUIREMENTS:
1. Identify EVERY visible component with high accuracy
2. Map ALL connections and data flows
3. Detect security vulnerabilities using STRIDE methodology
4. Assess compliance with major frameworks
5. Estimate costs based on typical configurations
6. Provide actionable recommendations
7. Identify patterns and anti-patterns
8. Consider performance and scalability

Be specific, technical, and thorough. Include confidence scores where uncertain."""
        
        return prompt


class EnhancedVisionAnalyzer:
    """Analisador avançado usando OpenAI Vision"""
    
    def __init__(self, api_key: Optional[str] = None):
        self.client = OpenAI(api_key=api_key)
        self.prompt_engine = PromptEngineering()
        self.cache = {}
        self.analysis_history = []
    
    def analyze(self, request: VisionAnalysisRequest) -> Dict:
        """Executa análise completa da arquitetura"""
        
        # Verificar cache
        cache_key = self._get_cache_key(request)
        if cache_key in self.cache:
            logger.info("Retornando resultado do cache")
            return self.cache[cache_key]
        
        try:
            # Preparar imagem
            base64_image = self._encode_image(request.image_path)
            
            # Preprocessar imagem se necessário
            enhanced_image = self._preprocess_image(request.image_path)
            
            # Executar análise paralela
            result = asyncio.run(self._parallel_analysis(
                base64_image, enhanced_image, request
            ))
            
            # Pós-processar resultado
            result = self._postprocess_result(result, request)
            
            # Cachear resultado
            self.cache[cache_key] = result
            
            # Adicionar ao histórico
            self.analysis_history.append({
                'timestamp': datetime.now().isoformat(),
                'request': asdict(request),
                'result_summary': self._create_summary(result)
            })
            
            return result
            
        except Exception as e:
            logger.error(f"Erro na análise: {str(e)}")
            return {"error": str(e)}
    
    async def _parallel_analysis(self, base64_image: str, 
                                enhanced_image: Optional[str],
                                request: VisionAnalysisRequest) -> Dict:
        """Executa análises em paralelo para maior eficiência"""
        
        tasks = []
        
        # Análise principal
        tasks.append(self._vision_analysis(base64_image, request))
        
        # Análises complementares opcionais
        if request.include_ocr:
            tasks.append(self._ocr_analysis(request.image_path))
        
        if request.include_icons:
            tasks.append(self._icon_detection(request.image_path))
        
        if enhanced_image and request.analysis_depth in [AnalysisDepth.DETAILED, AnalysisDepth.COMPREHENSIVE]:
            tasks.append(self._enhanced_analysis(enhanced_image, request))
        
        # Executar todas as tarefas em paralelo
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Combinar resultados
        combined = {}
        for result in results:
            if isinstance(result, dict) and not isinstance(result, Exception):
                combined = self._merge_results(combined, result)
        
        return combined
    
    async def _vision_analysis(self, base64_image: str, 
                              request: VisionAnalysisRequest) -> Dict:
        """Análise principal com Vision API"""
        
        system_prompt = self.prompt_engine.create_system_prompt(request.analysis_depth)
        user_prompt = self.prompt_engine.create_analysis_prompt(request)
        
        try:
            response = await asyncio.to_thread(
                self.client.chat.completions.create,
                model="gpt-4o",
                messages=[
                    {"role": "system", "content": system_prompt},
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": user_prompt},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{base64_image}",
                                    "detail": "high"
                                }
                            }
                        ]
                    }
                ],
                max_tokens=request.max_tokens,
                temperature=request.temperature,
                response_format={"type": "json_object"}
            )
            
            result = json.loads(response.choices[0].message.content)
            result['_metadata'] = {
                'model': response.model,
                'tokens': response.usage.total_tokens if hasattr(response, 'usage') else None,
                'analysis_type': 'vision_primary'
            }
            
            return result
            
        except Exception as e:
            logger.error(f"Erro na análise Vision: {str(e)}")
            return {"error": str(e), "analysis_type": "vision_primary"}
    
    async def _ocr_analysis(self, image_path: str) -> Dict:
        """Análise OCR complementar"""
        try:
            # Usar OCR engine melhorado
            from enhanced_ocr_engine import MultiEngineOCR
            
            ocr = MultiEngineOCR()
            ocr_results = await asyncio.to_thread(
                ocr.extract_comprehensive_text,
                image_path
            )
            
            return {
                'ocr_results': ocr_results,
                '_metadata': {'analysis_type': 'ocr'}
            }
        except Exception as e:
            logger.warning(f"OCR falhou: {str(e)}")
            return {}
    
    async def _icon_detection(self, image_path: str) -> Dict:
        """Detecção de ícones com YOLO"""
        try:
            from yolo_icon_training_system import IconDetectionEngine
            
            # Usar modelo treinado
            model_path = "models/cloud_icons_best.pt"
            if not Path(model_path).exists():
                return {}
            
            engine = IconDetectionEngine(model_path)
            detections = await asyncio.to_thread(
                engine.detect_icons,
                image_path
            )
            
            analysis = await asyncio.to_thread(
                engine.analyze_architecture_composition,
                detections
            )
            
            return {
                'icon_detections': detections,
                'icon_analysis': analysis,
                '_metadata': {'analysis_type': 'yolo_icons'}
            }
        except Exception as e:
            logger.warning(f"Detecção de ícones falhou: {str(e)}")
            return {}
    
    async def _enhanced_analysis(self, enhanced_image: str,
                                request: VisionAnalysisRequest) -> Dict:
        """Análise adicional com imagem processada"""
        
        # Prompt focado em detalhes perdidos
        detail_prompt = """Focus on:
        1. Small text and labels
        2. Connection details and protocols
        3. Security boundaries and zones
        4. Version numbers and configurations
        5. Hidden or subtle components"""
        
        try:
            response = await asyncio.to_thread(
                self.client.chat.completions.create,
                model="gpt-4o",
                messages=[
                    {
                        "role": "user",
                        "content": [
                            {"type": "text", "text": detail_prompt},
                            {
                                "type": "image_url",
                                "image_url": {
                                    "url": f"data:image/jpeg;base64,{enhanced_image}",
                                    "detail": "high"
                                }
                            }
                        ]
                    }
                ],
                max_tokens=2000,
                temperature=0.1
            )
            
            return {
                'enhanced_details': response.choices[0].message.content,
                '_metadata': {'analysis_type': 'enhanced_vision'}
            }
            
        except Exception as e:
            logger.warning(f"Análise enhanced falhou: {str(e)}")
            return {}
    
    def _preprocess_image(self, image_path: str) -> Optional[str]:
        """Preprocessa imagem para melhor análise"""
        try:
            img = cv2.imread(image_path)
            
            # Aplicar melhorias
            # 1. Aumentar contraste
            lab = cv2.cvtColor(img, cv2.COLOR_BGR2LAB)
            l, a, b = cv2.split(lab)
            clahe = cv2.createCLAHE(clipLimit=3.0, tileGridSize=(8,8))
            l = clahe.apply(l)
            enhanced = cv2.merge([l, a, b])
            enhanced = cv2.cvtColor(enhanced, cv2.COLOR_LAB2BGR)
            
            # 2. Sharpen
            kernel = np.array([[-1,-1,-1],
                              [-1, 9,-1],
                              [-1,-1,-1]])
            enhanced = cv2.filter2D(enhanced, -1, kernel)
            
            # 3. Denoise
            enhanced = cv2.fastNlMeansDenoisingColored(enhanced, None, 10, 10, 7, 21)
            
            # Codificar
            _, buffer = cv2.imencode('.jpg', enhanced)
            return base64.b64encode(buffer).decode('utf-8')
            
        except Exception as e:
            logger.warning(f"Preprocessamento falhou: {str(e)}")
            return None
    
    def _merge_results(self, base: Dict, new: Dict) -> Dict:
        """Mescla resultados de múltiplas análises"""
        merged = base.copy()
        
        for key, value in new.items():
            if key.startswith('_'):
                continue
                
            if key not in merged:
                merged[key] = value
            elif isinstance(value, dict) and isinstance(merged[key], dict):
                merged[key] = self._merge_results(merged[key], value)
            elif isinstance(value, list) and isinstance(merged[key], list):
                # Combinar listas removendo duplicatas
                merged[key].extend(value)
                merged[key] = list({json.dumps(item, sort_keys=True): item 
                                   for item in merged[key]}.values())
        
        return merged
    
    def _postprocess_result(self, result: Dict, 
                          request: VisionAnalysisRequest) -> Dict:
        """Pós-processa e enriquece resultado"""
        
        # Adicionar metadados
        result['metadata'] = {
            'timestamp': datetime.now().isoformat(),
            'analysis_depth': request.analysis_depth.value,
            'focus_areas': request.focus_areas,
            'version': '2.0'
        }
        
        # Calcular métricas derivadas
        if 'components' in result:
            result['statistics'] = self._calculate_statistics(result)
        
        # Adicionar scoring
        if 'security_analysis' in result:
            result['risk_score'] = self._calculate_risk_score(result['security_analysis'])
        
        # Gerar recomendações priorizadas
        if 'recommendations' in result:
            result['prioritized_actions'] = self._prioritize_recommendations(result)
        
        return result
    
    def _calculate_statistics(self, result: Dict) -> Dict:
        """Calcula estatísticas da arquitetura"""
        components = result.get('components', [])
        connections = result.get('connections', [])
        
        # Estatísticas por provider
        providers = {}
        categories = {}
        
        for comp in components:
            provider = comp.get('provider', 'unknown')
            category = comp.get('type', 'unknown')
            
            providers[provider] = providers.get(provider, 0) + 1
            categories[category] = categories.get(category, 0) + 1
        
        # Análise de conectividade
        connectivity = {}
        for conn in connections:
            source = conn.get('source')
            target = conn.get('target')
            
            connectivity[source] = connectivity.get(source, {'in': 0, 'out': 0})
            connectivity[target] = connectivity.get(target, {'in': 0, 'out': 0})
            
            connectivity[source]['out'] += 1
            connectivity[target]['in'] += 1
        
        # Identificar componentes críticos
        critical_components = [
            comp_id for comp_id, stats in connectivity.items()
            if stats['in'] + stats['out'] > len(connections) * 0.3
        ]
        
        return {
            'total_components': len(components),
            'total_connections': len(connections),
            'providers_distribution': providers,
            'categories_distribution': categories,
            'average_connectivity': len(connections) / len(components) if components else 0,
            'critical_components': critical_components,
            'multi_cloud': len(providers) > 1,
            'complexity_score': self._calculate_complexity(components, connections)
        }
    
    def _calculate_complexity(self, components: List, connections: List) -> int:
        """Calcula score de complexidade"""
        base_score = len(components) + len(connections)
        
        # Fatores de complexidade
        providers = len(set(c.get('provider') for c in components))
        categories = len(set(c.get('type') for c in components))
        
        complexity = min(100, base_score + (providers * 10) + (categories * 5))
        
        return complexity
    
    def _calculate_risk_score(self, security_analysis: Dict) -> float:
        """Calcula score de risco consolidado"""
        threats = security_analysis.get('stride_threats', [])
        
        if not threats:
            return 0.0
        
        severity_weights = {
            'critical': 10,
            'high': 7,
            'medium': 4,
            'low': 1
        }
        
        likelihood_multipliers = {
            'high': 1.5,
            'medium': 1.0,
            'low': 0.5
        }
        
        total_score = 0
        for threat in threats:
            severity = threat.get('severity', 'medium')
            likelihood = threat.get('likelihood', 'medium')
            
            base_score = severity_weights.get(severity, 4)
            multiplier = likelihood_multipliers.get(likelihood, 1.0)
            
            total_score += base_score * multiplier
        
        # Normalizar para escala 0-10
        max_possible = len(threats) * 15  # Critical * High likelihood
        normalized = min(10, (total_score / max_possible) * 10) if max_possible > 0 else 0
        
        return round(normalized, 1)
    
    def _prioritize_recommendations(self, result: Dict) -> List[Dict]:
        """Prioriza recomendações baseado em impacto e esforço"""
        all_recommendations = []
        
        # Coletar todas as recomendações
        for timeframe in ['immediate', 'short_term', 'long_term']:
            recs = result.get('recommendations', {}).get(timeframe, [])
            for rec in recs:
                if isinstance(rec, str):
                    rec = {'description': rec}
                rec['timeframe'] = timeframe
                all_recommendations.append(rec)
        
        # Calcular prioridade
        for rec in all_recommendations:
            # Heurística simples - pode ser melhorada
            impact = rec.get('impact', 5)
            effort = rec.get('effort', 5)
            
            # Prioridade = Impacto / Esforço
            rec['priority_score'] = impact / max(effort, 1)
            
            # Classificar prioridade
            if rec['priority_score'] > 1.5:
                rec['priority'] = 'high'
            elif rec['priority_score'] > 0.7:
                rec['priority'] = 'medium'
            else:
                rec['priority'] = 'low'
        
        # Ordenar por prioridade
        all_recommendations.sort(key=lambda x: x['priority_score'], reverse=True)
        
        return all_recommendations[:10]  # Top 10
    
    def _get_cache_key(self, request: VisionAnalysisRequest) -> str:
        """Gera chave de cache para requisição"""
        # Ler primeiros bytes da imagem para hash
        with open(request.image_path, 'rb') as f:
            image_hash = hashlib.md5(f.read(1024)).hexdigest()
        
        key_data = f"{image_hash}_{request.analysis_depth.value}_{','.join(request.focus_areas)}"
        return hashlib.md5(key_data.encode()).hexdigest()
    
    def _create_summary(self, result: Dict) -> Dict:
        """Cria resumo executivo do resultado"""
        return {
            'components_detected': len(result.get('components', [])),
            'threats_identified': len(result.get('security_analysis', {}).get('stride_threats', [])),
            'risk_score': result.get('risk_score', 0),
            'architecture_type': result.get('architecture_overview', {}).get('type', 'unknown'),
            'providers': list(result.get('statistics', {}).get('providers_distribution', {}).keys())
        }
    
    def export_analysis(self, result: Dict, format: str = 'json') -> str:
        """Exporta análise em diferentes formatos"""
        if format == 'json':
            return json.dumps(result, indent=2, default=str)
        elif format == 'markdown':
            return self._export_markdown(result)
        elif format == 'html':
            return self._export_html(result)
        else:
            raise ValueError(f"Formato não suportado: {format}")
    
    def _export_markdown(self, result: Dict) -> str:
        """Exporta resultado em Markdown"""
        md = f"""# Cloud Architecture Analysis Report

**Date**: {result.get('metadata', {}).get('timestamp', 'N/A')}
**Analysis Depth**: {result.get('metadata', {}).get('analysis_depth', 'N/A')}

## Executive Summary

- **Architecture Type**: {result.get('architecture_overview', {}).get('type', 'N/A')}
- **Risk Score**: {result.get('risk_score', 'N/A')}/10
- **Total Components**: {len(result.get('components', []))}
- **Total Threats**: {len(result.get('security_analysis', {}).get('stride_threats', []))}

## Components Detected

"""
        
        for comp in result.get('components', []):
            md += f"- **{comp.get('name', 'Unknown')}** ({comp.get('provider', 'N/A')}): {comp.get('type', 'N/A')}\n"
        
        md += "\n## Security Analysis\n\n"
        
        for threat in result.get('security_analysis', {}).get('stride_threats', [])[:5]:
            md += f"""### {threat.get('category', 'Unknown')} - {threat.get('severity', 'N/A').upper()}
**Component**: {threat.get('component', 'N/A')}
**Description**: {threat.get('description', 'N/A')}
**Mitigation**: {threat.get('mitigation', 'N/A')}

"""
        
        md += "\n## Recommendations\n\n"
        
        for rec in result.get('prioritized_actions', [])[:5]:
            md += f"- **[{rec.get('priority', 'N/A').upper()}]** {rec.get('description', 'N/A')}\n"
        
        return md
    
    def _export_html(self, result: Dict) -> str:
        """Exporta resultado em HTML"""
        risk_color = '#28a745' if result.get('risk_score', 0) < 4 else '#ffc107' if result.get('risk_score', 0) < 7 else '#dc3545'
        
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>Architecture Analysis Report</title>
    <style>
        body {{ font-family: 'Segoe UI', sans-serif; margin: 20px; background: #f5f5f5; }}
        .container {{ max-width: 1200px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }}
        .header {{ background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; padding: 30px; border-radius: 10px; margin-bottom: 30px; text-align: center; }}
        .metric-card {{ display: inline-block; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); margin: 10px; min-width: 200px; text-align: center; }}
        .risk-score {{ font-size: 2em; font-weight: bold; color: {risk_color}; }}
        .threat {{ border-left: 4px solid #dc3545; padding: 15px; margin: 10px 0; background: #f8f9fa; }}
        .recommendation {{ border-left: 4px solid #28a745; padding: 15px; margin: 10px 0; background: #f8f9fa; }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>Cloud Architecture Analysis Report</h1>
            <p>{result.get('metadata', {}).get('timestamp', 'N/A')}</p>
        </div>
        
        <div class="metrics">
            <div class="metric-card">
                <h3>Risk Score</h3>
                <div class="risk-score">{result.get('risk_score', 'N/A')}/10</div>
            </div>
            <div class="metric-card">
                <h3>Components</h3>
                <div style="font-size: 2em;">{len(result.get('components', []))}</div>
            </div>
            <div class="metric-card">
                <h3>Threats</h3>
                <div style="font-size: 2em;">{len(result.get('security_analysis', {}).get('stride_threats', []))}</div>
            </div>
        </div>
        
        <h2>Top Security Threats</h2>
        {"".join([f'<div class="threat"><strong>{t.get("category", "N/A")}</strong> - {t.get("description", "N/A")}</div>' 
                  for t in result.get('security_analysis', {}).get('stride_threats', [])[:5]])}
        
        <h2>Priority Recommendations</h2>
        {"".join([f'<div class="recommendation">{r.get("description", "N/A")}</div>' 
                  for r in result.get('prioritized_actions', [])[:5]])}
    </div>
</body>
</html>"""
        
        return html


# Exemplo de uso
if __name__ == "__main__":
    # Configurar análise
    request = VisionAnalysisRequest(
        image_path="architecture_diagram.png",
        analysis_depth=AnalysisDepth.COMPREHENSIVE,
        focus_areas=["security", "cost", "performance", "compliance"],
        include_ocr=True,
        include_icons=True,
        include_flows=True,
        include_security=True,
        include_cost=True,
        max_tokens=4096,
        temperature=0.1
    )
    
    # Executar análise
    analyzer = EnhancedVisionAnalyzer()
    result = analyzer.analyze(request)
    
    # Exibir resultados
    print(f"Risk Score: {result.get('risk_score', 'N/A')}/10")
    print(f"Components: {len(result.get('components', []))}")
    print(f"Threats: {len(result.get('security_analysis', {}).get('stride_threats', []))}")
    
    # Exportar
    with open("analysis_report.json", "w") as f:
        f.write(analyzer.export_analysis(result, format='json'))
    
    with open("analysis_report.md", "w") as f:
        f.write(analyzer.export_analysis(result, format='markdown'))
    
    with open("analysis_report.html", "w") as f:
        f.write(analyzer.export_analysis(result, format='html'))