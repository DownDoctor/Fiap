# ui_threats_table.py
# Helpers para renderizar tabelas no Streamlit para o app STRIDE
# Inclui parsing numérico robusto nas estatísticas (strings, dicts, numpy, etc.).

from typing import List, Dict, Any, Tuple, Optional
import streamlit as st
import re
from numbers import Number

# ----------------------------- Top Ameaças -----------------------------
def render_top_threats_table(top_threats: List[Dict[str, Any]]):
    st.markdown("### 🔝 Top Ameaças")
    if not isinstance(top_threats, list) or not top_threats:
        st.info("Sem ameaças no rascunho do LLM ou análise.")
        return

    try:
        import pandas as pd  # type: ignore
    except Exception:
        pd = None  # type: ignore

    def _to_str(v):
        try:
            if v is None:
                return ""
            return str(v)
        except Exception:
            return ""

    rows = []
    for t in top_threats:
        if not isinstance(t, dict):
            continue
        sev = _to_str(t.get("severity", ""))
        typ = _to_str(t.get("threat_type", t.get("type", "")))
        comp = _to_str(t.get("component", ""))
        title = _to_str(t.get("title", t.get("name", "")))
        desc = _to_str(t.get("description", ""))
        rec = _to_str(t.get("recommendation", t.get("mitigation", "")))
        likelihood = _to_str(t.get("likelihood", ""))
        impact = _to_str(t.get("impact", ""))
        risk = _to_str(t.get("risk", t.get("risk_score", "")))
        rows.append({
            "Severidade": sev,
            "STRIDE": typ,
            "Componente": comp,
            "Título": title,
            "Descrição": desc,
            "Recomendação": rec,
            "Prob.": likelihood,
            "Impacto": impact,
            "Risco": risk,
        })

    if rows and pd is not None:
        df = pd.DataFrame(rows)

        # Ordenar por severidade (heurística)
        sev_order = {"critical": 0, "alta": 1, "high": 1, "média": 2, "medium": 2, "baixa": 3, "low": 3}
        df["__sev_rank"] = df["Severidade"].str.lower().map(sev_order).fillna(9)

        cols = ["Severidade", "STRIDE", "Componente", "Título", "Descrição", "Recomendação", "Prob.", "Impacto", "Risco"]
        df = df[cols + ["__sev_rank"]].sort_values("__sev_rank").drop(columns=["__sev_rank"])

        try:
            st.dataframe(df, use_container_width=True)
        except Exception:
            st.markdown(df.to_markdown(index=False))
    else:
        for i, r in enumerate(rows, start=1):
            st.markdown(
                f"**{i}.** [{r.get('Severidade','')}] ({r.get('STRIDE','')}) — "
                f"**{r.get('Título','')}** em *{r.get('Componente','')}*  \n"
                f"{r.get('Descrição','')}\n\n**Mitigação:** {r.get('Recomendação','')}"
            )

# ------------------------ STRIDE (estatísticas) ------------------------
_STRIDE_KEYS = [
    "spoofing",
    "tampering",
    "repudiation",
    "information_disclosure",
    "denial_of_service",
    "elevation_of_privilege",
]

def _normalize_key(k: str) -> str:
    k = (k or "").strip().lower()
    k = k.replace(" ", "_").replace("-", "_")
    aliases = {
        "info_disclosure": "information_disclosure",
        "informationdisclosure": "information_disclosure",
        "dos": "denial_of_service",
        "denialofservice": "denial_of_service",
        "eop": "elevation_of_privilege",
        "elevationofprivilege": "elevation_of_privilege",
    }
    return aliases.get(k, k)

def _label_for_stride(k: str) -> str:
    labels = {
        "spoofing": "Spoofing",
        "tampering": "Tampering",
        "repudiation": "Repudiation",
        "information_disclosure": "Information Disclosure",
        "denial_of_service": "Denial of Service",
        "elevation_of_privilege": "Elevation of Privilege",
    }
    return labels.get(k, k.title().replace("_", " "))

def _as_int(value: Any) -> Optional[int]:
    # números reais (inclui numpy)
    if isinstance(value, Number):
        try:
            return int(value)
        except Exception:
            return None
    # strings com dígitos (ex.: "3", "  4  ", "5 itens")
    if isinstance(value, str):
        m = re.search(r"-?\d+", value)
        if m:
            try:
                return int(m.group(0))
            except Exception:
                return None
        return None
    # dicionários com chaves comuns (count, total, value, n, qty, quantity)
    if isinstance(value, dict):
        for key in ("count", "total", "value", "n", "qty", "quantity"):
            if key in value:
                return _as_int(value[key])
    # outros objetos → tentar str()
    try:
        return _as_int(str(value))
    except Exception:
        return None

def _collect_stats_rows(stats: Dict[str, Any]) -> Tuple[list, int]:
    rows, total = [], 0
    if not isinstance(stats, dict):
        return rows, total

    for raw_k, v in stats.items():
        k = _normalize_key(str(raw_k))
        n = _as_int(v)
        if n is None:
            # Se não conseguimos converter, ignore a chave
            continue
        rows.append((k, n))
        total += n

    return rows, total

def render_stride_stats_table(stats: Dict[str, Any]):
    st.markdown("### 📊 STRIDE (estatísticas)")

    rows, total = _collect_stats_rows(stats)
    if not rows:
        st.info("Sem estatísticas disponíveis.")
        return

    try:
        import pandas as pd  # type: ignore
    except Exception:
        pd = None  # type: ignore

    # separar categorias STRIDE clássicas de outras
    stride_rows = [(k, n) for (k, n) in rows if k in _STRIDE_KEYS]
    other_rows = [(k, n) for (k, n) in rows if k not in _STRIDE_KEYS]

    def _rows_to_table(rs):
        table = []
        for k, n in rs:
            label = _label_for_stride(k) if k in _STRIDE_KEYS else k.title().replace("_", " ")
            pct = (n / total * 100.0) if total else 0.0
            table.append({"Categoria": label, "Quantidade": n, "%": round(pct, 2)})
        return table

    table = _rows_to_table(stride_rows) + _rows_to_table(other_rows)

    if pd is not None and table:
        df = pd.DataFrame(table).sort_values("Quantidade", ascending=False).reset_index(drop=True)
        try:
            st.dataframe(df, use_container_width=True)
        except Exception:
            st.markdown(df.to_markdown(index=False))
    else:
        for r in sorted(table, key=lambda x: x["Quantidade"], reverse=True):
            st.write(f"- {r['Categoria']}: {r['Quantidade']} ({r['%']}%)")
