# cloud_icon_trainer.py
"""
Sistema de treinamento para reconhecimento de ícones cloud
"""

import torch
import torch.nn as nn
from ultralytics import YOLO
import cv2
import numpy as np
from pathlib import Path
import json
from typing import Dict, List, Tuple
import albumentations as A
from albumentations.pytorch import ToTensorV2

class CloudIconDataset:
    """Dataset customizado para ícones de cloud providers"""
    
    def __init__(self, annotations_path: str, images_dir: str):
        self.images_dir = Path(images_dir)
        self.annotations = self._load_annotations(annotations_path)
        self.transform = self._get_transforms()
        
        # Mapeamento completo de ícones cloud
        self.icon_classes = {
            # AWS Services (0-29)
            'aws_ec2': 0, 'aws_s3': 1, 'aws_lambda': 2, 'aws_rds': 3,
            'aws_dynamodb': 4, 'aws_api_gateway': 5, 'aws_cloudfront': 6,
            'aws_vpc': 7, 'aws_iam': 8, 'aws_route53': 9,
            'aws_elb': 10, 'aws_ecs': 11, 'aws_eks': 12, 'aws_fargate': 13,
            'aws_sqs': 14, 'aws_sns': 15, 'aws_kinesis': 16, 'aws_glue': 17,
            'aws_athena': 18, 'aws_redshift': 19, 'aws_emr': 20,
            'aws_cloudwatch': 21, 'aws_cloudtrail': 22, 'aws_config': 23,
            'aws_guardduty': 24, 'aws_shield': 25, 'aws_waf': 26,
            'aws_cognito': 27, 'aws_kms': 28, 'aws_secrets_manager': 29,
            
            # Azure Services (30-59)
            'azure_vm': 30, 'azure_storage': 31, 'azure_functions': 32,
            'azure_sql_database': 33, 'azure_cosmos_db': 34,
            'azure_api_management': 35, 'azure_app_service': 36,
            'azure_vnet': 37, 'azure_ad': 38, 'azure_dns': 39,
            'azure_load_balancer': 40, 'azure_aks': 41, 'azure_container_instances': 42,
            'azure_service_bus': 43, 'azure_event_hubs': 44, 'azure_logic_apps': 45,
            'azure_data_factory': 46, 'azure_databricks': 47, 'azure_synapse': 48,
            'azure_monitor': 49, 'azure_log_analytics': 50, 'azure_sentinel': 51,
            'azure_key_vault': 52, 'azure_security_center': 53, 'azure_firewall': 54,
            'azure_front_door': 55, 'azure_cdn': 56, 'azure_traffic_manager': 57,
            'azure_express_route': 58, 'azure_vpn_gateway': 59,
            
            # GCP Services (60-89)
            'gcp_compute_engine': 60, 'gcp_cloud_storage': 61, 'gcp_cloud_functions': 62,
            'gcp_cloud_sql': 63, 'gcp_bigtable': 64, 'gcp_spanner': 65,
            'gcp_api_gateway': 66, 'gcp_app_engine': 67, 'gcp_vpc': 68,
            'gcp_iam': 69, 'gcp_cloud_dns': 70, 'gcp_load_balancer': 71,
            'gcp_gke': 72, 'gcp_cloud_run': 73, 'gcp_pub_sub': 74,
            'gcp_dataflow': 75, 'gcp_dataproc': 76, 'gcp_bigquery': 77,
            'gcp_cloud_monitoring': 78, 'gcp_cloud_logging': 79,
            'gcp_cloud_trace': 80, 'gcp_kms': 81, 'gcp_secret_manager': 82,
            'gcp_cloud_armor': 83, 'gcp_cloud_cdn': 84, 'gcp_cloud_nat': 85,
            'gcp_cloud_vpn': 86, 'gcp_cloud_interconnect': 87,
            'gcp_cloud_router': 88, 'gcp_cloud_firewall': 89,
            
            # Kubernetes (90-99)
            'k8s_pod': 90, 'k8s_service': 91, 'k8s_ingress': 92,
            'k8s_deployment': 93, 'k8s_statefulset': 94, 'k8s_daemonset': 95,
            'k8s_configmap': 96, 'k8s_secret': 97, 'k8s_pv': 98, 'k8s_pvc': 99
        }
        
    def _load_annotations(self, annotations_path: str) -> Dict:
        """Carrega anotações em formato COCO ou YOLO"""
        with open(annotations_path, 'r') as f:
            return json.load(f)
    
    def _get_transforms(self):
        """Define augmentações para treino"""
        return A.Compose([
            A.RandomResizedCrop(640, 640),
            A.HorizontalFlip(p=0.5),
            A.RandomBrightnessContrast(p=0.2),
            A.RandomGamma(p=0.2),
            A.Blur(blur_limit=3, p=0.1),
            A.MotionBlur(p=0.1),
            A.MedianBlur(blur_limit=3, p=0.1),
            A.GaussNoise(p=0.1),
            A.Normalize(mean=[0.485, 0.456, 0.406], std=[0.229, 0.224, 0.225]),
            ToTensorV2()
        ], bbox_params=A.BboxParams(format='yolo', label_fields=['class_labels']))
    
    def prepare_training_data(self) -> Tuple[str, str]:
        """Prepara dados para treinamento YOLO"""
        train_path = self.images_dir / 'train'
        val_path = self.images_dir / 'val'
        
        # Criar estrutura de diretórios
        for path in [train_path / 'images', train_path / 'labels',
                     val_path / 'images', val_path / 'labels']:
            path.mkdir(parents=True, exist_ok=True)
        
        # Criar arquivo data.yaml
        data_yaml = {
            'train': str(train_path / 'images'),
            'val': str(val_path / 'images'),
            'nc': len(self.icon_classes),
            'names': list(self.icon_classes.keys())
        }
        
        yaml_path = self.images_dir / 'data.yaml'
        with open(yaml_path, 'w') as f:
            import yaml
            yaml.dump(data_yaml, f)
        
        return str(yaml_path), str(self.images_dir / 'runs')

class CloudIconYOLOTrainer:
    """Treinador especializado para detecção de ícones cloud"""
    
    def __init__(self, base_model: str = 'yolov8x.pt'):
        self.model = YOLO(base_model)
        self.training_history = []
        
    def train_cloud_detector(self, data_yaml: str, epochs: int = 300):
        """Treina modelo específico para ícones cloud"""
        
        results = self.model.train(
            data=data_yaml,
            epochs=epochs,
            imgsz=640,
            batch=16,
            name='cloud_icons_detector',
            patience=50,
            save=True,
            device='0',  # GPU
            workers=8,
            cos_lr=True,
            lr0=0.01,
            lrf=0.01,
            momentum=0.937,
            weight_decay=0.0005,
            warmup_epochs=3,
            warmup_momentum=0.8,
            warmup_bias_lr=0.1,
            box=0.05,
            cls=0.5,
            dfl=1.5,
            hsv_h=0.015,
            hsv_s=0.7,
            hsv_v=0.4,
            degrees=0.0,
            translate=0.1,
            scale=0.5,
            shear=0.0,
            perspective=0.0,
            flipud=0.0,
            fliplr=0.5,
            mosaic=1.0,
            mixup=0.1,
            copy_paste=0.1,
            plots=True,
            save_period=10
        )
        
        self.training_history.append(results)
        return results
    
    def export_optimized_model(self, export_path: str):
        """Exporta modelo otimizado para produção"""
        
        # Exportar para diferentes formatos
        exports = {
            'torchscript': self.model.export(format='torchscript'),
            'onnx': self.model.export(format='onnx', dynamic=True, simplify=True),
            'tflite': self.model.export(format='tflite', int8=True),
            'engine': self.model.export(format='engine', device=0)  # TensorRT
        }
        
        # Salvar modelo PyTorch
        torch.save({
            'model_state_dict': self.model.model.state_dict(),
            'icon_classes': CloudIconDataset.icon_classes,
            'training_history': self.training_history
        }, export_path)
        
        return exports