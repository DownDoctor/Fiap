#!/usr/bin/env python3
"""
Archer AI - STRIDE Security Analyzer  - Análise Visual Automatizada com Sistema de Login e Reconhecimento Facial
✅ Interface web completa mantida
✅ Análise real de imagens implementada
✅ Detecção dinâmica de componentes baseada no conteúdo visual
✅ Relatórios HTML dinâmicos com links
✅ RAG híbrido com busca vetorial corrigido
✅ Sistema de login com SQLite para persistência
✅ Autenticação por reconhecimento facial
✅ NOVO: Aba Config para gerenciamento de reconhecimento facial
"""

import streamlit as st
import json
import time
import base64
from pathlib import Path
from datetime import datetime
from typing import Dict, List, Optional, Any, Tuple
import hashlib
import os
import sys
import re
from collections import Counter
import sqlite3
import bcrypt
import io

# Configuração da página
st.set_page_config(
    page_title="STRIDE Security Analyzer Enhanced",
    page_icon="🔒",
    layout="wide",
    initial_sidebar_state="expanded"
)

# Importações opcionais
try:
    from dotenv import load_dotenv
    load_dotenv()
    ENV_LOADED = True
except ImportError:
    ENV_LOADED = False

try:
    from openai import OpenAI
    OPENAI_AVAILABLE = True
except ImportError:
    OPENAI_AVAILABLE = False

try:
    import plotly.graph_objects as go
    import plotly.express as px
    PLOTLY_AVAILABLE = True
except ImportError:
    PLOTLY_AVAILABLE = False

try:
    import cv2
    import numpy as np
    CV2_AVAILABLE = True
except ImportError:
    CV2_AVAILABLE = False

try:
    import pandas as pd
    PANDAS_AVAILABLE = True
except ImportError:
    PANDAS_AVAILABLE = False

try:
    import pytesseract
    from PIL import Image
    OCR_AVAILABLE = True
except ImportError:
    OCR_AVAILABLE = False

try:
    from sklearn.feature_extraction.text import TfidfVectorizer
    from sklearn.metrics.pairwise import cosine_similarity
    SKLEARN_AVAILABLE = True
except ImportError:
    SKLEARN_AVAILABLE = False

# NOVO: Importação para reconhecimento facial
try:
    import face_recognition
    FACE_RECOGNITION_AVAILABLE = True
except ImportError:
    FACE_RECOGNITION_AVAILABLE = False

try:
    import weasyprint
    from weasyprint import HTML, CSS
    WEASYPRINT_AVAILABLE = True
except (ImportError, OSError) as e:
    # Captura tanto ImportError quanto OSError (problema de DLL no Windows)
    WEASYPRINT_AVAILABLE = False
    WEASYPRINT_ERROR = str(e)

try:
    import pdfkit
    PDFKIT_AVAILABLE = True
except ImportError:
    PDFKIT_AVAILABLE = False

# NOVA OPÇÃO: Usar xhtml2pdf que funciona bem no Windows
try:
    from xhtml2pdf import pisa
    import io
    XHTML2PDF_AVAILABLE = True
except ImportError:
    XHTML2PDF_AVAILABLE = False

# NOVA OPÇÃO: Usar reportlab com platypus
try:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, letter
    from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
    from reportlab.platypus import Image as ReportLabImage
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.pdfgen import canvas
    from reportlab.lib.enums import TA_CENTER, TA_LEFT
    import io
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False

# Import do AI Provider Manager
from ai_provider_manager import (
    AIProviderManager, 
    get_ai_provider_manager, 
    ProviderMode,
    show_ai_provider_status,
    configure_ai_provider_mode
)

# Sistema de Autenticação com SQLite e Reconhecimento Facial
class FacialAuthSystem:
    """Sistema de autenticação com SQLite e reconhecimento facial"""
    
    def __init__(self, db_path: str = "stride_users.db", auth_img_path: str = "authimg"):
        self.db_path = db_path
        self.auth_img_path = Path(auth_img_path)
        self.auth_img_path.mkdir(exist_ok=True)
        self.init_database()
        self.create_default_user()
    
    def init_database(self):
        """Inicializa o banco de dados com suporte a reconhecimento facial"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Tabela de usuários com campos para reconhecimento facial
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password_hash TEXT NOT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                last_login TIMESTAMP,
                must_change_password BOOLEAN DEFAULT FALSE,
                is_active BOOLEAN DEFAULT TRUE,
                face_encoding TEXT,
                face_image_path TEXT,
                facial_auth_enabled BOOLEAN DEFAULT FALSE
            )
        ''')
        
        # Tabela de conversas
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS conversations (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER NOT NULL,
                conversation_id TEXT NOT NULL,
                timestamp TEXT NOT NULL,
                messages TEXT NOT NULL,
                analysis_context TEXT,
                message_count INTEGER,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        # Tabela de histórico de login
        cursor.execute('''
            CREATE TABLE IF NOT EXISTS login_history (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                user_id INTEGER,
                timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                auth_method TEXT,
                face_confidence REAL,
                success BOOLEAN,
                FOREIGN KEY (user_id) REFERENCES users (id)
            )
        ''')
        
        conn.commit()
        conn.close()
    
    def create_default_user(self):
        """Cria usuário padrão archer2025"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Verificar se usuário já existe
        cursor.execute("SELECT id FROM users WHERE username = ?", ("archer2025",))
        if not cursor.fetchone():
            # Criar hash da senha
            password_hash = bcrypt.hashpw("87654321".encode('utf-8'), bcrypt.gensalt())
            
            cursor.execute('''
                INSERT INTO users (username, password_hash, must_change_password)
                VALUES (?, ?, ?)
            ''', ("archer2025", password_hash.decode('utf-8'), True))
            
            conn.commit()
        
        conn.close()
    
    def authenticate(self, username: str, password: str) -> Dict:
        """Autentica usuário com credenciais"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT id, username, password_hash, must_change_password, is_active
            FROM users WHERE username = ?
        ''', (username,))
        
        user = cursor.fetchone()
        
        if user and bcrypt.checkpw(password.encode('utf-8'), user[2].encode('utf-8')):
            # Atualizar último login
            cursor.execute('''
                UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?
            ''', (user[0],))
            
            # Registrar no histórico
            cursor.execute('''
                INSERT INTO login_history (user_id, auth_method, success)
                VALUES (?, 'credentials', TRUE)
            ''', (user[0],))
            
            conn.commit()
            conn.close()
            
            return {
                'success': True,
                'user_id': user[0],
                'username': user[1],
                'must_change_password': user[3],
                'is_active': user[4],
                'auth_method': 'credentials'
            }
        
        conn.close()
        return {'success': False, 'message': 'Usuário ou senha incorretos'}
    
    def register_face(self, user_id: int, image_data: bytes) -> Dict:
        """Registra face do usuário para autenticação"""
        if not FACE_RECOGNITION_AVAILABLE:
            return {'success': False, 'message': 'face_recognition não instalado'}
        
        try:
            # Converter bytes para imagem
            image = Image.open(io.BytesIO(image_data))
            image_np = np.array(image)
            
            # Detectar faces
            face_locations = face_recognition.face_locations(image_np)
            
            if len(face_locations) == 0:
                return {'success': False, 'message': 'Nenhuma face detectada na imagem'}
            
            if len(face_locations) > 1:
                return {'success': False, 'message': 'Múltiplas faces detectadas. Use uma foto com apenas uma pessoa'}
            
            # Gerar encoding facial
            face_encodings = face_recognition.face_encodings(image_np, face_locations)
            
            if len(face_encodings) == 0:
                return {'success': False, 'message': 'Não foi possível processar a face'}
            
            face_encoding = face_encodings[0]
            
            # Salvar imagem de referência
            username = self.get_username_by_id(user_id)
            image_filename = f"{username}_face.jpg"
            image_path = self.auth_img_path / image_filename
            image.save(image_path, 'JPEG')
            
            # Converter encoding para string base64 para armazenar no banco
            encoding_str = base64.b64encode(face_encoding.tobytes()).decode('utf-8')
            
            # Atualizar banco de dados
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                UPDATE users 
                SET face_encoding = ?, face_image_path = ?, facial_auth_enabled = TRUE
                WHERE id = ?
            ''', (encoding_str, str(image_path), user_id))
            
            conn.commit()
            conn.close()
            
            return {'success': True, 'message': 'Face registrada com sucesso'}
            
        except Exception as e:
            return {'success': False, 'message': f'Erro ao registrar face: {str(e)}'}
    
    def authenticate_face(self, image_data: bytes) -> Dict:
        """Autentica usuário por reconhecimento facial"""
        if not FACE_RECOGNITION_AVAILABLE:
            return {'success': False, 'message': 'face_recognition não instalado'}
        
        try:
            # Converter bytes para imagem
            image = Image.open(io.BytesIO(image_data))
            image_np = np.array(image)
            
            # Detectar faces na imagem de login
            face_locations = face_recognition.face_locations(image_np)
            
            if len(face_locations) == 0:
                return {'success': False, 'message': 'Nenhuma face detectada'}
            
            if len(face_locations) > 1:
                return {'success': False, 'message': 'Múltiplas faces detectadas'}
            
            # Gerar encoding da face detectada
            face_encodings = face_recognition.face_encodings(image_np, face_locations)
            
            if len(face_encodings) == 0:
                return {'success': False, 'message': 'Não foi possível processar a face'}
            
            unknown_encoding = face_encodings[0]
            
            # Buscar todos os usuários com facial auth habilitado
            conn = sqlite3.connect(self.db_path)
            cursor = conn.cursor()
            
            cursor.execute('''
                SELECT id, username, face_encoding, is_active
                FROM users 
                WHERE facial_auth_enabled = TRUE AND face_encoding IS NOT NULL
            ''')
            
            users_with_faces = cursor.fetchall()
            
            # Comparar com cada face registrada
            for user in users_with_faces:
                user_id, username, encoding_str, is_active = user
                
                if not is_active:
                    continue
                
                # Converter encoding do banco de volta para numpy array
                stored_encoding = np.frombuffer(base64.b64decode(encoding_str), dtype=np.float64)
                
                # Comparar faces (tolerância padrão de 0.6)
                matches = face_recognition.compare_faces([stored_encoding], unknown_encoding, tolerance=0.6)
                
                if matches[0]:
                    # Face reconhecida!
                    # Calcular distância para mostrar confiança
                    face_distance = face_recognition.face_distance([stored_encoding], unknown_encoding)[0]
                    confidence = (1 - face_distance) * 100
                    
                    # Atualizar último login
                    cursor.execute('''
                        UPDATE users SET last_login = CURRENT_TIMESTAMP WHERE id = ?
                    ''', (user_id,))
                    
                    # Registrar no histórico
                    cursor.execute('''
                        INSERT INTO login_history (user_id, auth_method, face_confidence, success)
                        VALUES (?, 'facial', ?, TRUE)
                    ''', (user_id, confidence))
                    
                    conn.commit()
                    conn.close()
                    
                    return {
                        'success': True,
                        'user_id': user_id,
                        'username': username,
                        'confidence': confidence,
                        'must_change_password': False,
                        'is_active': True,
                        'auth_method': 'facial'
                    }
            
            conn.close()
            return {'success': False, 'message': 'Face não reconhecida'}
            
        except Exception as e:
            return {'success': False, 'message': f'Erro na autenticação facial: {str(e)}'}
    
    def get_username_by_id(self, user_id: int) -> str:
        """Obtém username pelo ID"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute("SELECT username FROM users WHERE id = ?", (user_id,))
        result = cursor.fetchone()
        conn.close()
        return result[0] if result else None
    
    def has_facial_auth(self, username: str) -> bool:
        """Verifica se usuário tem autenticação facial configurada"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        cursor.execute('''
            SELECT facial_auth_enabled FROM users WHERE username = ?
        ''', (username,))
        result = cursor.fetchone()
        conn.close()
        return result[0] if result else False
    
    def change_password(self, user_id: int, new_password: str) -> bool:
        """Altera senha do usuário"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        password_hash = bcrypt.hashpw(new_password.encode('utf-8'), bcrypt.gensalt())
        
        cursor.execute('''
            UPDATE users SET password_hash = ?, must_change_password = FALSE
            WHERE id = ?
        ''', (password_hash.decode('utf-8'), user_id))
        
        conn.commit()
        conn.close()
        return True
    
    def save_conversation(self, user_id: int, conversation_data: Dict):
        """Salva conversa no banco"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            INSERT INTO conversations 
            (user_id, conversation_id, timestamp, messages, analysis_context, message_count)
            VALUES (?, ?, ?, ?, ?, ?)
        ''', (
            user_id,
            conversation_data['id'],
            conversation_data['timestamp'],
            json.dumps(conversation_data['messages']),
            conversation_data['analysis_context'],
            conversation_data['message_count']
        ))
        
        conn.commit()
        conn.close()
    
    def load_conversations(self, user_id: int) -> List[Dict]:
        """Carrega conversas do usuário"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT conversation_id, timestamp, messages, analysis_context, message_count
            FROM conversations WHERE user_id = ?
            ORDER BY created_at DESC
        ''', (user_id,))
        
        conversations = []
        for row in cursor.fetchall():
            conversations.append({
                'id': row[0],
                'timestamp': row[1],
                'messages': json.loads(row[2]),
                'analysis_context': row[3],
                'message_count': row[4]
            })
        
        conn.close()
        return conversations
    
    def delete_conversation(self, user_id: int, conversation_id: str):
        """Apaga conversa específica"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        cursor.execute('''
            DELETE FROM conversations 
            WHERE user_id = ? AND conversation_id = ?
        ''', (user_id, conversation_id))
        
        conn.commit()
        conn.close()
    
    def get_login_stats(self, user_id: int) -> Dict:
        """Obtém estatísticas de login do usuário"""
        conn = sqlite3.connect(self.db_path)
        cursor = conn.cursor()
        
        # Total de logins
        cursor.execute('''
            SELECT COUNT(*) FROM login_history WHERE user_id = ? AND success = TRUE
        ''', (user_id,))
        total_logins = cursor.fetchone()[0]
        
        # Logins por método
        cursor.execute('''
            SELECT auth_method, COUNT(*) 
            FROM login_history 
            WHERE user_id = ? AND success = TRUE
            GROUP BY auth_method
        ''', (user_id,))
        logins_by_method = dict(cursor.fetchall())
        
        # Último login facial com confiança
        cursor.execute('''
            SELECT face_confidence, timestamp
            FROM login_history 
            WHERE user_id = ? AND auth_method = 'facial' AND success = TRUE
            ORDER BY timestamp DESC
            LIMIT 1
        ''', (user_id,))
        last_facial = cursor.fetchone()
        
        conn.close()
        
        return {
            'total': total_logins,
            'by_method': logins_by_method,
            'last_facial': last_facial
        }

# Instância global do sistema de auth
auth_system = FacialAuthSystem()


def create_login_page():
    """Tela de login com opção de reconhecimento facial"""
    st.markdown("""
    <div style="max-width: 450px; margin: 80px auto; padding: 2rem; 
                background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); 
                border-radius: 15px; box-shadow: 0 8px 32px rgba(0,0,0,0.3);">
        <h1 style="color: white; text-align: center; margin-bottom: 0rem;">
            🔒 Archer - AI 
        </h1>
                <h1 style="color: white; text-align: center; margin-bottom: 2rem;">
            STRIDE Security Analyzer
        </h1>
        <p style="color: white; text-align: center; opacity: 0.9;">
            Sistema de Análise de Segurança com IA
        </p>
    </div>
    """, unsafe_allow_html=True)
    
    # Verificar dependências
    if not FACE_RECOGNITION_AVAILABLE:
        st.sidebar.warning("""
        ⚠️ **Reconhecimento facial não disponível**
        
        Para habilitar, instale:
        ```bash
        pip install face-recognition
        pip install dlib
        ```
        
        **Nota:** Requer cmake e compilador C++
        """)
    
    # Centralizar form de login
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        # Seletor de método de autenticação
        auth_method = st.radio(
            "🔐 Método de Autenticação",
            ["Login Tradicional", "Reconhecimento Facial"],
            horizontal=True,
            help="Escolha como deseja fazer login"
        )
        
        if auth_method == "Login Tradicional":
            # Login tradicional
            st.markdown("### 👤 Login com Credenciais")
            
            with st.form("login_form"):
                username = st.text_input("Usuário", placeholder="Digite seu usuário")
                password = st.text_input("Senha", type="password", placeholder="Digite sua senha")
                submit = st.form_submit_button("🚀 Entrar", use_container_width=True, type="primary")
                
                if submit:
                    if username and password:
                        result = auth_system.authenticate(username, password)
                        
                        if result['success']:
                            # Salvar dados do usuário na sessão
                            st.session_state['authenticated'] = True
                            st.session_state['user_id'] = result['user_id']
                            st.session_state['username'] = result['username']
                            st.session_state['must_change_password'] = result['must_change_password']
                            st.session_state['auth_method'] = 'credentials'
                            
                            if result['must_change_password']:
                                st.session_state['show_change_password'] = True
                            
                            st.rerun()
                        else:
                            st.error(result['message'])
                    else:
                        st.error("Por favor, preencha usuário e senha")
        
        else:
            # Login com reconhecimento facial
            st.markdown("### 📸 Login com Reconhecimento Facial")
            
            if FACE_RECOGNITION_AVAILABLE:
                # Opções de captura
                capture_method = st.radio(
                    "Método de captura",
                    ["Upload de Foto", "Captura por Webcam"],
                    horizontal=True
                )
                
                if capture_method == "Upload de Foto":
                    uploaded_photo = st.file_uploader(
                        "Selecione uma foto sua",
                        type=['jpg', 'jpeg', 'png'],
                        help="A foto deve mostrar claramente seu rosto"
                    )
                    
                    if uploaded_photo:
                        # Mostrar preview
                        st.image(uploaded_photo, caption="Foto para autenticação", use_container_width=True)
                        
                        if st.button("🔓 Autenticar com Face", use_container_width=True, type="primary"):
                            with st.spinner("🔍 Analisando face..."):
                                result = auth_system.authenticate_face(uploaded_photo.getvalue())
                                
                                if result['success']:
                                    st.success(f"✅ Face reconhecida! Confiança: {result['confidence']:.1f}%")
                                    
                                    # Salvar dados na sessão
                                    st.session_state['authenticated'] = True
                                    st.session_state['user_id'] = result['user_id']
                                    st.session_state['username'] = result['username']
                                    st.session_state['must_change_password'] = False
                                    st.session_state['auth_method'] = 'facial'
                                    
                                    st.snow()
                                    time.sleep(1)
                                    st.rerun()
                                else:
                                    st.error(f"❌ {result['message']}")
                
                else:
                    # Captura por webcam
                    st.info("📷 Captura por webcam")
                    
                    # Verificar suporte para camera_input no Streamlit
                    try:
                        picture = st.camera_input("Tire uma foto para autenticação")
                        
                        if picture:
                            if st.button("🔓 Autenticar com Face", use_container_width=True, type="primary"):
                                with st.spinner("🔍 Analisando face..."):
                                    result = auth_system.authenticate_face(picture.getvalue())
                                    
                                    if result['success']:
                                        st.success(f"✅ Face reconhecida! Confiança: {result['confidence']:.1f}%")
                                        
                                        # Salvar dados na sessão
                                        st.session_state['authenticated'] = True
                                        st.session_state['user_id'] = result['user_id']
                                        st.session_state['username'] = result['username']
                                        st.session_state['must_change_password'] = False
                                        st.session_state['auth_method'] = 'facial'
                                        
                                        st.snow()
                                        time.sleep(1)
                                        st.rerun()
                                    else:
                                        st.error(f"❌ {result['message']}")
                    except:
                        st.warning("Esta funcionalidade requer Streamlit >= 1.28.0")
            
            else:
                st.error("❌ Reconhecimento facial não disponível. Instale as dependências necessárias.")
                st.code("pip install face-recognition dlib")
        
        # Informações de acesso
        st.markdown("---")
        
        if auth_method == "Login Tradicional":
            st.info("""
            **Acesso Inicial:**
            - Usuário: `archer2025`
            - Senha: `87654321`
            - Será solicitada alteração da senha no primeiro login
            """)
        else:
            st.info("""
            **Reconhecimento Facial:**
            - Faça login tradicional primeiro para cadastrar sua face
            - Depois use reconhecimento facial para logins futuros
            - Sistema com alta segurança e privacidade
            """)


def create_change_password_page():
    """Tela para alterar senha obrigatória"""
    st.warning("⚠️ É necessário alterar sua senha no primeiro acesso")
    
    col1, col2, col3 = st.columns([1, 2, 1])
    
    with col2:
        st.markdown("### 🔑 Alterar Senha")
        
        with st.form("change_password_form"):
            new_password = st.text_input("Nova Senha", type="password", placeholder="Digite a nova senha")
            confirm_password = st.text_input("Confirmar Senha", type="password", placeholder="Confirme a nova senha")
            submit = st.form_submit_button("🔄 Alterar Senha", use_container_width=True, type="primary")
            
            if submit:
                if new_password and confirm_password:
                    if new_password == confirm_password:
                        if len(new_password) >= 6:
                            auth_system.change_password(st.session_state['user_id'], new_password)
                            st.session_state['must_change_password'] = False
                            st.session_state['show_change_password'] = False
                            st.success("Senha alterada com sucesso!")
                            time.sleep(2)
                            st.rerun()
                        else:
                            st.error("A senha deve ter pelo menos 6 caracteres")
                    else:
                        st.error("As senhas não coincidem")
                else:
                    st.error("Por favor, preencha todos os campos")


def check_authentication():
    """Verifica se usuário está autenticado"""
    if not st.session_state.get('authenticated', False):
        create_login_page()
        return False
    
    if st.session_state.get('show_change_password', False):
        create_change_password_page()
        return False
    
    return True


# Função para converter tipos numpy para serializáveis
def convert_numpy_types(obj):
    """Converte tipos numpy para tipos Python serializáveis para JSON"""
    if isinstance(obj, dict):
        return {key: convert_numpy_types(value) for key, value in obj.items()}
    elif isinstance(obj, list):
        return [convert_numpy_types(item) for item in obj]
    elif hasattr(obj, 'dtype'):  # numpy arrays
        if obj.dtype.kind in 'iufc':  # int, uint, float, complex
            return obj.tolist()
        else:
            return str(obj)
    elif hasattr(obj, 'item'):  # numpy scalars
        return obj.item()
    elif CV2_AVAILABLE and isinstance(obj, (np.integer, np.floating)):
        return obj.item()
    else:
        return obj


# CSS Customizado
def inject_custom_css():
    st.markdown("""
    <style>
    /* Tema geral */
    .main {
        padding: 0rem 1rem;
    }
    
    /* Header gradient */
    .main-header {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 2rem;
        border-radius: 10px;
        margin-bottom: 2rem;
        color: white;
        text-align: center;
    }
    
    /* Cards */
    .metric-card {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        border-left: 4px solid #007bff;
        margin: 1rem 0;
    }
    
    .threat-critical { 
        color: #dc3545 !important; 
        font-weight: bold; 
    }
    .threat-high { 
        color: #fd7e14 !important; 
        font-weight: bold; 
    }
    .threat-medium { 
        color: #ffc107 !important; 
        font-weight: bold; 
    }
    .threat-low { 
        color: #28a745 !important; 
        font-weight: bold; 
    }
    
    /* Buttons */
    .stButton > button {
        border-radius: 8px;
        border: none;
        background: linear-gradient(45deg, #667eea, #764ba2);
        color: white;
        font-weight: 600;
        transition: all 0.3s ease;
    }
    
    .stButton > button:hover {
        transform: translateY(-2px);
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.4);
    }
    </style>
    """, unsafe_allow_html=True)


# Sistema de Referências Automatizado
class ThreatReferenceManager:
    """Gerencia referências e links para ameaças STRIDE"""
    
    def __init__(self):
        self.reference_database = self._build_reference_database()
    
    def _build_reference_database(self) -> Dict:
        """Constrói banco de referências com URLs reais"""
        return {
            'owasp': {
                'base_url': 'https://owasp.org/Top10',
                'categories': {
                    'Broken Access Control': 'A01_2021-Broken_Access_Control/',
                    'Cryptographic Failures': 'A02_2021-Cryptographic_Failures/',
                    'Injection': 'A03_2021-Injection/',
                    'Insecure Design': 'A04_2021-Insecure_Design/',
                    'Security Misconfiguration': 'A05_2021-Security_Misconfiguration/',
                    'Vulnerable Components': 'A06_2021-Vulnerable_and_Outdated_Components/',
                    'Authentication Failures': 'A07_2021-Identification_and_Authentication_Failures/',
                    'Software Integrity': 'A08_2021-Software_and_Data_Integrity_Failures/',
                    'Logging Failures': 'A09_2021-Security_Logging_and_Monitoring_Failures/',
                    'SSRF': 'A10_2021-Server-Side_Request_Forgery_%28SSRF%29/'
                }
            },
            'nist': {
                'base_url': 'https://csrc.nist.gov/publications/detail/sp/800-53/rev-5/final',
                'controls': {
                    'Access Control': '#ac',
                    'Audit and Accountability': '#au',
                    'Identification and Authentication': '#ia',
                    'System and Communications Protection': '#sc',
                    'System and Information Integrity': '#si'
                }
            },
            'microsoft_stride': {
                'base_url': 'https://docs.microsoft.com/en-us/azure/security/develop/threat-modeling-tool-threats',
                'categories': {
                    'Spoofing': '#spoofing',
                    'Tampering': '#tampering', 
                    'Repudiation': '#repudiation',
                    'Information Disclosure': '#information-disclosure',
                    'Denial of Service': '#denial-of-service',
                    'Elevation of Privilege': '#elevation-of-privilege'
                }
            },
            'cloud_providers': {
                'azure': {
                    'base_url': 'https://docs.microsoft.com/en-us/azure/security',
                    'services': {
                        'networking': '/fundamentals/network-security',
                        'compute': '/fundamentals/compute',
                        'storage': '/fundamentals/encryption-overview'
                    }
                },
                'aws': {
                    'base_url': 'https://docs.aws.amazon.com/security',
                    'services': {
                        'networking': '/vpc/latest/userguide/security.html',
                        'compute': '/ec2/latest/userguide/ec2-security.html',
                        'storage': '/s3/latest/userguide/security.html'
                    }
                },
                'gcp': {
                    'base_url': 'https://cloud.google.com/security',
                    'services': {
                        'networking': '/vpc/docs/security',
                        'compute': '/compute/docs/security',
                        'storage': '/storage/docs/security'
                    }
                }
            }
        }
    
    def get_threat_references(self, threat: Dict, detected_providers: List[str] = None) -> List[Dict]:
        """Gera referências específicas para uma ameaça"""
        category = threat.get('category', '')
        component_type = threat.get('component_type', 'generic')
        references = []
        
        # OWASP Reference
        owasp_mapping = self._map_stride_to_owasp(category)
        if owasp_mapping:
            owasp_url = f"{self.reference_database['owasp']['base_url']}/{self.reference_database['owasp']['categories'].get(owasp_mapping, '')}"
            references.append({
                'type': 'owasp',
                'title': f'OWASP - {owasp_mapping}',
                'url': owasp_url,
                'description': f'OWASP guidance for {owasp_mapping.lower()}'
            })
        
        # NIST Reference
        nist_control = self._map_stride_to_nist(category)
        if nist_control:
            nist_url = f"{self.reference_database['nist']['base_url']}{self.reference_database['nist']['controls'].get(nist_control, '')}"
            references.append({
                'type': 'nist',
                'title': f'NIST - {nist_control}',
                'url': nist_url,
                'description': f'NIST controls for {nist_control.lower()}'
            })
        
        # Microsoft STRIDE Reference
        stride_url = f"{self.reference_database['microsoft_stride']['base_url']}{self.reference_database['microsoft_stride']['categories'].get(category, '')}"
        references.append({
            'type': 'microsoft',
            'title': f'Microsoft STRIDE - {category}',
            'url': stride_url,
            'description': f'Microsoft guidance for {category.lower()}'
        })
        
        return references
    
    def _map_stride_to_owasp(self, stride_category: str) -> Optional[str]:
        mapping = {
            'Spoofing': 'Broken Access Control',
            'Tampering': 'Software Integrity', 
            'Repudiation': 'Logging Failures',
            'Information Disclosure': 'Cryptographic Failures',
            'Denial of Service': 'Security Misconfiguration',
            'Elevation of Privilege': 'Broken Access Control'
        }
        return mapping.get(stride_category)
    
    def _map_stride_to_nist(self, stride_category: str) -> Optional[str]:
        mapping = {
            'Spoofing': 'Identification and Authentication',
            'Tampering': 'System and Information Integrity',
            'Repudiation': 'Audit and Accountability', 
            'Information Disclosure': 'System and Communications Protection',
            'Denial of Service': 'System and Communications Protection',
            'Elevation of Privilege': 'Access Control'
        }
        return mapping.get(stride_category)

# Instância global
threat_reference_manager = ThreatReferenceManager()


# Analisador Real de Imagens
class RealImageAnalyzer:
    """Analisador real de imagens de arquitetura"""
    
    def __init__(self):
        # Usar AI Provider Manager ao invés de cliente OpenAI direto
        self.ai_manager = get_ai_provider_manager()
        
        # Configurar pytesseract (mantém igual)
        if OCR_AVAILABLE:
            try:
                if os.name == 'nt':  # Windows
                    possible_paths = [
                        r'C:\Program Files\Tesseract-OCR\tesseract.exe',
                        r'C:\Users\*\AppData\Local\Tesseract-OCR\tesseract.exe'
                    ]
                    for path in possible_paths:
                        if os.path.exists(path):
                            pytesseract.pytesseract.tesseract_cmd = path
                            break
            except:
                pass

    def analyze_image_content(self, image_file) -> Dict:
        """Analisa o conteúdo real da imagem"""
        try:
            # Converter para array numpy
            image = Image.open(image_file)
            img_array = np.array(image) if CV2_AVAILABLE else None
            
            # Análise com múltiplas abordagens
            results = {
                'cv_analysis': self._analyze_with_opencv(img_array) if CV2_AVAILABLE and img_array is not None else {},
                'ocr_analysis': self._analyze_with_ocr(image) if OCR_AVAILABLE else {},
                'color_analysis': self._analyze_colors(img_array) if CV2_AVAILABLE and img_array is not None else {},
                'openai_analysis': self._analyze_with_openai(image_file) if self.openai_client else None
            }
            
            # Combinar resultados
            components = self._combine_detection_results(results)
            
            return {
                'success': True,
                'detected_components': components,
                'analysis_details': results,
                'component_count': len(components)
            }
            
        except Exception as e:
            return {
                'success': False,
                'error': str(e),
                'detected_components': [],
                'component_count': 0
            }
    
    def _analyze_with_opencv(self, img_array: np.ndarray) -> Dict:
        """Análise usando OpenCV"""
        try:
            # Converter para grayscale
            if len(img_array.shape) == 3:
                gray = cv2.cvtColor(img_array, cv2.COLOR_RGB2GRAY)
            else:
                gray = img_array
            
            # Detectar bordas
            edges = cv2.Canny(gray, 50, 150)
            
            # Encontrar contornos
            contours, _ = cv2.findContours(edges, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
            
            # Filtrar contornos por tamanho
            min_area = 1000
            significant_contours = [c for c in contours if cv2.contourArea(c) > min_area]
            
            # Classificar formas
            shapes = []
            for contour in significant_contours:
                epsilon = 0.02 * cv2.arcLength(contour, True)
                approx = cv2.approxPolyDP(contour, epsilon, True)
                vertices = len(approx)
                area = cv2.contourArea(contour)
                x, y, w, h = cv2.boundingRect(contour)
                
                shape_type = 'rectangle' if vertices == 4 else 'circle' if vertices > 8 else 'polygon'
                
                shapes.append({
                    'type': shape_type,
                    'vertices': vertices,
                    'area': int(area),
                    'position': {'x': int(x), 'y': int(y), 'w': int(w), 'h': int(h)}
                })
            
            return {
                'total_contours': len(significant_contours),
                'shapes': shapes,
                'image_dimensions': {'width': img_array.shape[1], 'height': img_array.shape[0]}
            }
            
        except Exception as e:
            return {'error': str(e), 'shapes': [], 'total_contours': 0}
    
    def _analyze_with_ocr(self, image: Image) -> Dict:
        """Análise usando OCR"""
        try:
            # Extrair texto
            data = pytesseract.image_to_data(image, output_type=pytesseract.Output.DICT)
            
            text_elements = []
            for i in range(len(data['text'])):
                text = data['text'][i].strip()
                if text and len(text) > 2:
                    confidence = int(data['conf'][i])
                    if confidence > 30:
                        text_elements.append({
                            'text': text,
                            'confidence': confidence,
                            'position': {
                                'x': data['left'][i],
                                'y': data['top'][i],
                                'width': data['width'][i],
                                'height': data['height'][i]
                            }
                        })
            
            # Identificar tecnologias
            known_techs = self._identify_technologies(text_elements)
            
            return {
                'text_elements': text_elements,
                'total_text_regions': len(text_elements),
                'identified_technologies': known_techs
            }
            
        except Exception as e:
            return {'error': str(e), 'text_elements': [], 'identified_technologies': []}
    
    def _identify_technologies(self, text_elements: List[Dict]) -> List[Dict]:
        """Identifica tecnologias no texto"""
        tech_patterns = {
            'aws': ['aws', 'amazon', 'ec2', 'lambda', 's3', 'rds', 'vpc', 'cloudfront', 'waf', 'shield'],
            'azure': ['azure', 'microsoft', 'vnet', 'vm', 'storage', 'functions', 'sql', 'expressroute'],
            'gcp': ['google', 'gcp', 'gce', 'gcs', 'cloud', 'kubernetes', 'pubsub', 'bigquery'],
            'generic': ['database', 'server', 'api', 'gateway', 'load', 'balancer', 'firewall', 'router']
        }
        
        identified = []
        all_text = ' '.join([elem['text'].lower() for elem in text_elements])
        
        for provider, keywords in tech_patterns.items():
            for keyword in keywords:
                if keyword in all_text:
                    matching_elements = [elem for elem in text_elements if keyword in elem['text'].lower()]
                    for elem in matching_elements:
                        identified.append({
                            'technology': keyword,
                            'provider': provider,
                            'text': elem['text'],
                            'position': elem['position'],
                            'confidence': elem['confidence']
                        })
        
        return identified
    
    def _analyze_colors(self, img_array: np.ndarray) -> Dict:
        """Análise de cores para identificar providers"""
        try:
            # Redimensionar para análise
            height, width = img_array.shape[:2]
            if height > 500 or width > 500:
                scale = 500 / max(height, width)
                new_width = int(width * scale)
                new_height = int(height * scale)
                img_array = cv2.resize(img_array, (new_width, new_height))
            
            # Cores características
            provider_colors = {
                'aws': {'orange': [255, 153, 0], 'blue': [35, 47, 62]},
                'azure': {'blue': [0, 120, 212], 'dark_blue': [0, 78, 137]},
                'gcp': {'blue': [66, 133, 244], 'red': [234, 67, 53]}
            }
            
            # Contar matches
            color_matches = {}
            for provider, colors in provider_colors.items():
                total_matches = 0
                for color_name, target_color in colors.items():
                    if len(img_array.shape) == 3:
                        diff = np.linalg.norm(img_array - target_color, axis=2)
                        matches = np.sum(diff < 50)
                        total_matches += matches
                color_matches[provider] = total_matches
            
            # Provider dominante
            total_pixels = img_array.shape[0] * img_array.shape[1]
            dominant_provider = max(color_matches.keys(), key=lambda x: color_matches[x])
            confidence = min(color_matches[dominant_provider] / total_pixels * 10, 1.0)
            
            return {
                'dominant_provider': dominant_provider,
                'confidence': confidence,
                'color_matches': color_matches
            }
            
        except Exception as e:
            return {'error': str(e), 'dominant_provider': 'unknown', 'confidence': 0.0}

    def _analyze_with_openai(self, image_file) -> Optional[Dict]:
        """Análise usando AI Provider (OpenAI/Anthropic com fallback/redundância)"""
        try:
            image = Image.open(image_file)
            buffer = io.BytesIO()
            image.save(buffer, format='PNG')
            image_bytes = buffer.getvalue()
            
            # Prompt para análise
            prompt = """Analyze this architecture diagram. Count components and identify cloud provider. 
            Return JSON with: component_count, provider, components (list of component names), 
            confidence (0-1), detected_technologies (list)."""
            
            # Usar AI Provider Manager
            ai_response = self.ai_manager.analyze_image(image_bytes, prompt)
            
            if ai_response.success:
                try:
                    # Tentar parse JSON
                    result = json.loads(ai_response.content)
                    
                    # Adicionar metadata do provider
                    result['ai_provider'] = ai_response.provider
                    result['ai_model'] = ai_response.model
                    
                    # Se foi consolidação, adicionar insights extras
                    if ai_response.provider == "consolidated":
                        result['analysis_type'] = 'redundant'
                        result['sources'] = ai_response.metadata.get('sources', 1)
                        
                        # Extrair insights consolidados
                        if 'metadata' in ai_response.metadata:
                            result['provider_insights'] = ai_response.metadata['metadata']
                    
                    return result
                    
                except json.JSONDecodeError:
                    # Se não for JSON, retornar resposta bruta
                    return {
                        'raw_response': ai_response.content,
                        'ai_provider': ai_response.provider,
                        'ai_model': ai_response.model
                    }
            else:
                return {'error': ai_response.error, 'ai_provider': ai_response.provider}
                
        except Exception as e:
            return {'error': str(e)}
  
    def _combine_detection_results(self, results: Dict) -> List[Dict]:
        """Combina resultados de detecção"""
        components = []
        component_id = 1
        
        # OpenAI results first
        if results.get('openai_analysis') and not results['openai_analysis'].get('error'):
            openai_data = results['openai_analysis']
            if 'components' in openai_data:
                for comp in openai_data['components']:
                    components.append({
                        'id': f'C{component_id:03d}',
                        'name': comp if isinstance(comp, str) else comp.get('name', f'Component {component_id}'),
                        'type': 'detected',
                        'provider': results.get('color_analysis', {}).get('dominant_provider', 'generic'),
                        'confidence': 0.8,
                        'detection_method': 'openai_vision',
                        'position': {'x': 0, 'y': 0}
                    })
                    component_id += 1
        
        # OCR identified technologies
        if results.get('ocr_analysis', {}).get('identified_technologies'):
            for tech in results['ocr_analysis']['identified_technologies']:
                components.append({
                    'id': f'C{component_id:03d}',
                    'name': tech['text'],
                    'type': self._classify_component_type(tech['technology']),
                    'provider': tech['provider'],
                    'confidence': tech['confidence'] / 100.0,
                    'detection_method': 'ocr',
                    'position': tech['position']
                })
                component_id += 1
        
        # OpenCV shapes as fallback
        cv_analysis = results.get('cv_analysis', {})
        if cv_analysis.get('shapes') and len(components) < 3:
            for shape in cv_analysis['shapes'][:8]:
                if shape['area'] > 2000:
                    components.append({
                        'id': f'C{component_id:03d}',
                        'name': f'{shape["type"].title()} Component {component_id}',
                        'type': self._infer_type_from_shape(shape),
                        'provider': results.get('color_analysis', {}).get('dominant_provider', 'generic'),
                        'confidence': 0.5,
                        'detection_method': 'opencv_shape',
                        'position': shape['position']
                    })
                    component_id += 1
        
        return self._remove_duplicate_components(components)
    
    def _classify_component_type(self, technology: str) -> str:
        """Classifica tipo do componente"""
        tech_lower = technology.lower()
        if any(db in tech_lower for db in ['database', 'sql', 'rds', 'storage']):
            return 'storage'
        elif any(compute in tech_lower for compute in ['server', 'vm', 'ec2', 'lambda', 'function']):
            return 'compute'
        elif any(net in tech_lower for net in ['gateway', 'load', 'balancer', 'vpc', 'network']):
            return 'networking'
        else:
            return 'service'
    
    def _infer_type_from_shape(self, shape: Dict) -> str:
        """Infere tipo pela forma"""
        if shape['type'] == 'rectangle':
            aspect_ratio = shape['position']['w'] / shape['position']['h']
            return 'networking' if aspect_ratio > 2 else 'compute'
        elif shape['type'] == 'circle':
            return 'storage'
        else:
            return 'service'
    
    def _remove_duplicate_components(self, components: List[Dict]) -> List[Dict]:
        """Remove duplicatas"""
        if len(components) <= 1:
            return components
        
        unique_components = []
        threshold = 50
        
        for comp in components:
            pos = comp['position']
            is_duplicate = False
            
            for existing in unique_components:
                existing_pos = existing['position']
                distance = ((pos['x'] - existing_pos['x'])**2 + (pos['y'] - existing_pos['y'])**2)**0.5
                
                if distance < threshold:
                    if comp['confidence'] > existing['confidence']:
                        unique_components.remove(existing)
                        unique_components.append(comp)
                    is_duplicate = True
                    break
            
            if not is_duplicate:
                unique_components.append(comp)
        
        return unique_components

# Sistema RAG Híbrido com Busca Vetorial
# Sistema RAG Híbrido com Busca Vetorial
class VectorRAG:
    """Sistema RAG com busca vetorial usando AI Provider Manager"""
    
    def __init__(self):
        self.ai_manager = get_ai_provider_manager()
        self.tfidf_vectorizer = None
        self.embedding_matrix = None
        self.document_chunks = []
        self.openai_client = None  # Para compatibilidade
        
        # Verificar se OpenAI está disponível (para compatibilidade)
        if OPENAI_AVAILABLE and os.getenv('OPENAI_API_KEY'):
            try:
                from openai import OpenAI
                self.openai_client = OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
            except:
                pass
    
    def create_embeddings_from_frameworks(self, compliance_frameworks: Dict) -> bool:
        """Cria embeddings a partir dos frameworks de compliance"""
        try:
            # Preparar chunks de documentos
            self.document_chunks = []
            
            for framework_name, framework_data in compliance_frameworks.items():
                # Processar controles
                for control_name, control_content in framework_data.get('controls', {}).items():
                    self.document_chunks.append({
                        'text': control_content,
                        'framework': framework_name,
                        'control': control_name,
                        'type': 'control'
                    })
                
                # Processar seções
                for section_name, section_content in framework_data.get('sections', {}).items():
                    self.document_chunks.append({
                        'text': section_content,
                        'framework': framework_name,
                        'control': section_name,
                        'type': 'section'
                    })
            
            if not self.document_chunks:
                return False
            
            # Tentar criar embeddings OpenAI primeiro
            success = self._create_openai_embeddings()
            
            if not success:
                # Fallback para TF-IDF
                success = self._create_tfidf_embeddings()
            
            return success
            
        except Exception as e:
            st.warning(f"Erro ao criar embeddings: {e}")
            return False
    
    def _create_openai_embeddings(self) -> bool:
        """Cria embeddings usando AI Provider Manager"""
        try:
            texts = [chunk['text'] for chunk in self.document_chunks]
            
            # Usar AI Provider Manager para embeddings
            embeddings = self.ai_manager.create_embeddings(texts)
            
            if embeddings is not None:
                self.embedding_matrix = embeddings
                return True
            else:
                # Fallback para TF-IDF se embeddings não disponíveis
                st.warning("Embeddings não disponíveis, usando TF-IDF...")
                return self._create_tfidf_embeddings()
                
        except Exception as e:
            st.warning(f"Falha nos embeddings: {e}. Usando TF-IDF...")
            return self._create_tfidf_embeddings()
    
    def _create_tfidf_embeddings(self) -> bool:
        """Cria embeddings usando TF-IDF como fallback"""
        if not SKLEARN_AVAILABLE:
            st.error("Scikit-learn não disponível para TF-IDF")
            return False
        
        try:
            texts = [chunk['text'] for chunk in self.document_chunks]
            
            # Criar vetorizador TF-IDF
            self.tfidf_vectorizer = TfidfVectorizer(
                max_features=768,  # Similar à dimensão do Ada-002
                stop_words='english',
                ngram_range=(1, 2)
            )
            
            # Criar matriz de embeddings
            self.embedding_matrix = self.tfidf_vectorizer.fit_transform(texts).toarray()
            
            return True
            
        except Exception as e:
            st.error(f"Erro ao criar embeddings TF-IDF: {e}")
            return False
    
    def semantic_search(self, query: str, top_k: int = 5) -> List[Dict]:
        """Busca semântica nos chunks de documentos"""
        if self.embedding_matrix is None or len(self.document_chunks) == 0:
            return []
        
        try:
            # Criar embedding da query
            if self.tfidf_vectorizer is not None:
                # Usar TF-IDF
                query_embedding = self.tfidf_vectorizer.transform([query]).toarray()[0]
            else:
                # Usar AI Provider Manager
                query_embeddings = self.ai_manager.create_embeddings([query])
                if query_embeddings is None:
                    return []
                query_embedding = query_embeddings[0]
            
            # Calcular similaridades
            if CV2_AVAILABLE:
                # Usar numpy se disponível
                import numpy as np
                similarities = np.dot(self.embedding_matrix, query_embedding)
                # Normalizar
                norm_matrix = np.linalg.norm(self.embedding_matrix, axis=1)
                norm_query = np.linalg.norm(query_embedding)
                similarities = similarities / (norm_matrix * norm_query + 1e-8)
            elif SKLEARN_AVAILABLE:
                # Usar sklearn
                from sklearn.metrics.pairwise import cosine_similarity
                query_embedding_reshaped = query_embedding.reshape(1, -1)
                similarities = cosine_similarity(self.embedding_matrix, query_embedding_reshaped).flatten()
            else:
                # Fallback para cálculo manual
                similarities = []
                for i, doc_embedding in enumerate(self.embedding_matrix):
                    # Produto escalar manual
                    dot_product = sum(a * b for a, b in zip(doc_embedding, query_embedding))
                    # Normas
                    norm_doc = sum(a**2 for a in doc_embedding) ** 0.5
                    norm_query = sum(a**2 for a in query_embedding) ** 0.5
                    # Similaridade coseno
                    similarity = dot_product / (norm_doc * norm_query + 1e-8)
                    similarities.append(similarity)
            
            # Obter top-k índices
            if CV2_AVAILABLE:
                import numpy as np
                top_indices = np.argsort(similarities)[-top_k:][::-1]
            else:
                # Ordenação manual
                indexed_similarities = [(i, sim) for i, sim in enumerate(similarities)]
                indexed_similarities.sort(key=lambda x: x[1], reverse=True)
                top_indices = [i for i, _ in indexed_similarities[:top_k]]
            
            # Preparar resultados
            results = []
            for idx in top_indices:
                chunk = self.document_chunks[idx].copy()
                chunk['similarity_score'] = float(similarities[idx])
                # Limitar o conteúdo retornado
                chunk['content'] = chunk['text'][:500] + '...' if len(chunk['text']) > 500 else chunk['text']
                results.append(chunk)
            
            return results
            
        except Exception as e:
            st.error(f"Erro na busca semântica: {e}")
            return []
    
    def get_relevant_chunks(self, query: str, k: int = 3) -> List[Dict]:
        """Método de compatibilidade - chama semantic_search"""
        return self.semantic_search(query, top_k=k)
        
# Analisador STRIDE Real
class RealSTRIDEAnalyzer:
    """Analisador STRIDE real baseado em análise visual"""
    
    def __init__(self):
        from enhanced_image_analyzer_yolo_integration import RealImageAnalyzerWithYOLO
        self.image_analyzer = RealImageAnalyzerWithYOLO()
        
        # OWASP Risk Rating Methodology Tables
        # Baseado em: https://owasp.org/www-community/OWASP_Risk_Rating_Methodology
        
        # Likelihood Matrix (0.0 a 1.0) - Probabilidade de exploração
        self.likelihood_matrix = {
            'storage': {
                'Information Disclosure': 0.8,  # Dados são alvo primário
                'Tampering': 0.6,               # Requer acesso mas comum
                'Repudiation': 0.4,             # Menos comum em storage
                'Denial of Service': 0.5,        # Ataques de disponibilidade
                'Spoofing': 0.3,                # Menos aplicável a storage
                'Elevation of Privilege': 0.4    # Possível mas não primário
            },
            'networking': {
                'Spoofing': 0.7,                # Alto em redes
                'Denial of Service': 0.8,        # DDoS muito comum
                'Tampering': 0.5,               # Man-in-the-middle
                'Information Disclosure': 0.6,   # Sniffing de rede
                'Repudiation': 0.3,             # Menos relevante
                'Elevation of Privilege': 0.4    # Lateral movement
            },
            'compute': {
                'Elevation of Privilege': 0.8,   # Principal vetor em compute
                'Tampering': 0.7,               # Code injection comum
                'Denial of Service': 0.6,        # Resource exhaustion
                'Information Disclosure': 0.5,   # Memory leaks
                'Spoofing': 0.4,                # Token hijacking
                'Repudiation': 0.3              # Audit bypass
            },
            'service': {
                'Repudiation': 0.6,             # Falta de logging
                'Information Disclosure': 0.5,   # API leaks
                'Tampering': 0.5,               # Parâmetros
                'Denial of Service': 0.6,        # Service flooding
                'Spoofing': 0.5,                # Service impersonation
                'Elevation of Privilege': 0.5    # Service account abuse
            }
        }
        
        # Impact Matrix (0.0 a 1.0) - Baseado em CIA Triad + Business Impact
        self.impact_matrix = {
            'Information Disclosure': {
                'confidentiality': 1.0,  # Impacto total
                'integrity': 0.0,        # Sem impacto
                'availability': 0.0,     # Sem impacto
                'business': 0.9          # Alto impacto no negócio (GDPR, reputação)
            },
            'Tampering': {
                'confidentiality': 0.2,  # Possível exposição
                'integrity': 1.0,        # Impacto total
                'availability': 0.3,     # Pode afetar
                'business': 0.8          # Dados corrompidos = problema sério
            },
            'Repudiation': {
                'confidentiality': 0.1,  # Mínimo
                'integrity': 0.6,        # Questiona integridade
                'availability': 0.0,     # Sem impacto
                'business': 0.7          # Compliance e auditoria
            },
            'Denial of Service': {
                'confidentiality': 0.0,  # Sem impacto
                'integrity': 0.0,        # Sem impacto
                'availability': 1.0,     # Impacto total
                'business': 0.8          # Perda de receita
            },
            'Spoofing': {
                'confidentiality': 0.7,  # Acesso não autorizado
                'integrity': 0.5,        # Ações falsas
                'availability': 0.1,     # Mínimo
                'business': 0.8          # Fraude, perda de confiança
            },
            'Elevation of Privilege': {
                'confidentiality': 0.9,  # Acesso amplo
                'integrity': 0.9,        # Controle total
                'availability': 0.5,     # Pode derrubar
                'business': 0.9          # Comprometimento total
            }
        }
        
        # Fatores de ajuste baseados em ambiente/contexto
        self.environmental_factors = {
            'multi_cloud': 1.2,      # Aumenta complexidade
            'public_exposure': 1.3,   # Internet-facing
            'data_sensitivity': 1.2,  # Dados sensíveis
            'regulatory': 1.15,       # Compliance requirements
            'legacy_systems': 1.25    # Sistemas antigos
        }
    
    def analyze_image(self, image_file, use_yolo: bool = True, 
                     use_vision: bool = True) -> Dict:
        """Análise completa com metodologia formal de risco"""
        start_time = time.time()
        
        # Detectar componentes reais
        detection_result = self.image_analyzer.analyze_image_content(image_file)
        
        if not detection_result['success']:
            return {'success': False, 'error': detection_result['error']}
        
        components = detection_result['detected_components']
        
        # Gerar ameaças com cálculo formal
        threats = self._generate_realistic_threats_formal(components)
        
        # Calcular risk score agregado
        risk_score = self._calculate_aggregated_risk_score(threats)
        
        # Análise STRIDE
        stride_analysis = self._generate_stride_analysis(threats)
        
        analysis_time = time.time() - start_time
        
        return {
            'success': True,
            'analysis_id': hashlib.md5(f"{image_file.name}{time.time()}".encode()).hexdigest()[:8],
            'timestamp': datetime.now().isoformat(),
            'analysis_time': analysis_time,
            'image_info': {
                'filename': image_file.name,
                'size': len(image_file.getvalue()) if hasattr(image_file, 'getvalue') else 0,
                'type': getattr(image_file, 'type', 'unknown')
            },
            'detected_components': components,
            'threats': threats,
            'risk_score': risk_score,
            'risk_methodology': 'OWASP Risk Rating + NIST SP 800-30',
            'stride_analysis': stride_analysis,
            'recommendations': self._generate_recommendations(threats),
            'cloud_providers': self._detect_cloud_providers(components),
            'compliance_score': self._calculate_compliance_score(threats),
            'detection_details': detection_result['analysis_details'],
            'environmental_context': self._analyze_environmental_context(components)
        }
    
    def _generate_realistic_threats(self, components: List[Dict]) -> List[Dict]:
        """Gera ameaças baseadas nos componentes detectados"""
        threats = []
        threat_id = 1
        
        for component in components:
            comp_type = component.get('type', 'service')
            comp_name = component.get('name', 'Unknown')
            
            templates = self.threat_templates.get(comp_type, self.threat_templates['service'])
            
            for template in templates:
                threat = {
                    'id': f'T{threat_id:03d}',
                    'category': template['category'],
                    'component': comp_name,
                    'component_type': comp_type,
                    'provider': component.get('provider', 'generic'),
                    'description': f"{template['base_description']} in {comp_name}",
                    'risk_score': template['risk_score'],
                    'severity': template['severity'],
                    'mitigation': template['mitigation'],
                    'detection_confidence': component.get('confidence', 0.5),
                    'references': self._get_references_for_threat(template['category'])
                }
                threats.append(threat)
                threat_id += 1
        
        # Ameaças arquiteturais
        if len(components) > 3:
            threats.extend(self._generate_architectural_threats_formal(components, threat_id))
        
        return threats

    def calculate_owasp_risk_score(self, threat_category: str, component_type: str, 
                                   detection_confidence: float, 
                                   environmental_context: Dict = None) -> Dict:
        """
        Calcula risk score usando OWASP Risk Rating Methodology
        
        Risk = Likelihood × Impact
        
        Onde:
        - Likelihood baseado em threat agent capability + vulnerability
        - Impact baseado em technical impact (CIA) + business impact
        """
        
        # 1. Calcular Likelihood (0-10)
        base_likelihood = self.likelihood_matrix.get(component_type, {}).get(
            threat_category, 0.5  # Default médio se não mapeado
        )
        
        # Ajustar likelihood baseado em fatores técnicos
        technical_factors = {
            'threat_agent_skill': 0.7,    # Assume atacantes skilled
            'threat_agent_motive': 0.8,   # Alto valor dos alvos
            'threat_agent_opportunity': 0.6,  # Depende da exposição
            'vulnerability_ease': 0.5     # Média dificuldade
        }
        
        avg_technical = sum(technical_factors.values()) / len(technical_factors)
        adjusted_likelihood = (base_likelihood + avg_technical) / 2
        
        # 2. Calcular Impact (0-10)
        impact_values = self.impact_matrix.get(threat_category, {})
        
        # CIA Triad Impact
        technical_impact = (
            impact_values.get('confidentiality', 0.5) * 0.4 +  # 40% peso
            impact_values.get('integrity', 0.5) * 0.3 +       # 30% peso
            impact_values.get('availability', 0.5) * 0.3       # 30% peso
        )
        
        # Business Impact
        business_impact = impact_values.get('business', 0.5)
        
        # Impact total (média ponderada)
        total_impact = (technical_impact * 0.6 + business_impact * 0.4)
        
        # 3. Calcular Risk Base (OWASP formula)
        base_risk = adjusted_likelihood * total_impact * 10  # Escala 0-10
        
        # 4. Aplicar fatores ambientais se fornecidos
        environmental_multiplier = 1.0
        if environmental_context:
            for factor, value in environmental_context.items():
                if value and factor in self.environmental_factors:
                    environmental_multiplier *= self.environmental_factors[factor]
        
        # Limitar multiplicador para não distorcer demais
        environmental_multiplier = min(environmental_multiplier, 1.5)
        
        adjusted_risk = base_risk * environmental_multiplier
        
        # 5. Ajuste por confiança de detecção (não reduz risco, apenas certeza)
        # Alta confiança = risco mais confiável
        # Baixa confiança = adicionar margem de incerteza
        confidence_adjustment = 0.5 + (detection_confidence * 0.5)  # 0.5 a 1.0
        
        final_risk = adjusted_risk * confidence_adjustment
        
        # Garantir que fica dentro da escala 0-10
        final_risk = min(10.0, max(0.0, final_risk))
        
        # 6. Classificar severidade baseada em NIST SP 800-30
        if final_risk >= 9.0:
            severity = 'critical'
            severity_label = 'Very High'
        elif final_risk >= 7.0:
            severity = 'high'
            severity_label = 'High'
        elif final_risk >= 4.0:
            severity = 'medium'
            severity_label = 'Moderate'
        elif final_risk >= 2.0:
            severity = 'low'
            severity_label = 'Low'
        else:
            severity = 'info'
            severity_label = 'Very Low'
        
        return {
            'risk_score': round(final_risk, 2),
            'severity': severity,
            'severity_label': severity_label,
            'likelihood': round(adjusted_likelihood * 10, 2),
            'impact': round(total_impact * 10, 2),
            'confidence': detection_confidence,
            'methodology': 'OWASP Risk Rating',
            'factors': {
                'base_likelihood': round(base_likelihood, 2),
                'technical_impact': round(technical_impact, 2),
                'business_impact': round(business_impact, 2),
                'environmental_multiplier': round(environmental_multiplier, 2),
                'confidence_adjustment': round(confidence_adjustment, 2)
            }
        }

    def _generate_realistic_threats_formal(self, components: List[Dict]) -> List[Dict]:
        """Gera ameaças com cálculo formal de risco"""
        threats = []
        threat_id = 1
        
        # Determinar contexto ambiental
        environmental_context = self._analyze_environmental_context(components)
        
        # Mapear ameaças STRIDE para cada componente
        stride_mappings = {
            'storage': ['Information Disclosure', 'Tampering', 'Repudiation'],
            'networking': ['Spoofing', 'Denial of Service', 'Tampering', 'Information Disclosure'],
            'compute': ['Elevation of Privilege', 'Tampering', 'Denial of Service'],
            'service': ['Repudiation', 'Information Disclosure', 'Tampering', 'Denial of Service']
        }
        
        for component in components:
            comp_type = component.get('type', 'service')
            comp_name = component.get('name', 'Unknown')
            detection_confidence = component.get('confidence', 0.5)
            
            # Obter categorias STRIDE aplicáveis
            applicable_threats = stride_mappings.get(comp_type, ['Repudiation'])
            
            for threat_category in applicable_threats:
                # Calcular risco usando metodologia formal
                risk_assessment = self.calculate_owasp_risk_score(
                    threat_category=threat_category,
                    component_type=comp_type,
                    detection_confidence=detection_confidence,
                    environmental_context=environmental_context
                )
                
                threat = {
                    'id': f'T{threat_id:03d}',
                    'category': threat_category,
                    'component': comp_name,
                    'component_type': comp_type,
                    'provider': component.get('provider', 'generic'),
                    'description': self._generate_threat_description(
                        threat_category, comp_name, risk_assessment
                    ),
                    'risk_score': risk_assessment['risk_score'],
                    'severity': risk_assessment['severity'],
                    'severity_label': risk_assessment['severity_label'],
                    'likelihood': risk_assessment['likelihood'],
                    'impact': risk_assessment['impact'],
                    'detection_confidence': detection_confidence,
                    'methodology': risk_assessment['methodology'],
                    'risk_factors': risk_assessment['factors'],
                    'mitigation': self._get_mitigation_for_threat(
                        threat_category, comp_type, risk_assessment['severity']
                    ),
                    'references': self._get_references_for_threat(threat_category)
                }
                
                threats.append(threat)
                threat_id += 1
        
        # Adicionar ameaças arquiteturais se aplicável
        if len(components) > 3:
            threats.extend(self._generate_architectural_threats_formal(
                components, threat_id, environmental_context
            ))
        
        return threats

    def _analyze_environmental_context(self, components: List[Dict]) -> Dict:
        """Analisa contexto ambiental para fatores de risco"""
        context = {}
        
        # Multi-cloud detection
        providers = set(comp.get('provider', 'generic') for comp in components)
        context['multi_cloud'] = len(providers) > 1
        
        # Assumir exposição pública se tem componentes de networking
        context['public_exposure'] = any(
            comp.get('type') == 'networking' for comp in components
        )
        
        # Assumir dados sensíveis se tem storage
        context['data_sensitivity'] = any(
            comp.get('type') == 'storage' for comp in components
        )
        
        # Outros fatores poderiam ser detectados via OCR ou metadata
        context['regulatory'] = False  # Poderia detectar menções a GDPR, HIPAA, etc
        context['legacy_systems'] = False  # Poderia detectar versões antigas
        
        return context

    def _generate_threat_description(self, category: str, component: str, 
                                    risk_assessment: Dict) -> str:
        """Gera descrição contextualizada da ameaça"""
        base_descriptions = {
            'Spoofing': f"Identity spoofing vulnerability in {component} could allow unauthorized access. Likelihood: {risk_assessment['likelihood']}/10, Impact: {risk_assessment['impact']}/10",
            'Tampering': f"Data tampering risk in {component} could compromise data integrity. Likelihood: {risk_assessment['likelihood']}/10, Impact: {risk_assessment['impact']}/10",
            'Repudiation': f"Insufficient audit logging in {component} prevents action tracking. Likelihood: {risk_assessment['likelihood']}/10, Impact: {risk_assessment['impact']}/10",
            'Information Disclosure': f"Data exposure vulnerability in {component} could leak sensitive information. Likelihood: {risk_assessment['likelihood']}/10, Impact: {risk_assessment['impact']}/10",
            'Denial of Service': f"DoS vulnerability in {component} could impact availability. Likelihood: {risk_assessment['likelihood']}/10, Impact: {risk_assessment['impact']}/10",
            'Elevation of Privilege': f"Privilege escalation risk in {component} could grant unauthorized access. Likelihood: {risk_assessment['likelihood']}/10, Impact: {risk_assessment['impact']}/10"
        }
        
        return base_descriptions.get(category, f"Security risk in {component}")

    def _get_mitigation_for_threat(self, category: str, comp_type: str, 
                                   severity: str) -> str:
        """Retorna mitigação baseada na severidade e tipo"""
        
        # Mitigações prioritárias por severidade
        priority_prefix = {
            'critical': "URGENT: ",
            'high': "HIGH PRIORITY: ",
            'medium': "RECOMMENDED: ",
            'low': "CONSIDER: ",
            'info': "OPTIONAL: "
        }
        
        mitigations = {
            'Spoofing': "Implement strong authentication (MFA), certificate validation, and mutual TLS",
            'Tampering': "Enable integrity monitoring, code signing, and input validation",
            'Repudiation': "Implement comprehensive audit logging with tamper protection",
            'Information Disclosure': "Apply encryption at rest and in transit, implement DLP",
            'Denial of Service': "Deploy rate limiting, DDoS protection, and auto-scaling",
            'Elevation of Privilege': "Apply least privilege principle, regular patching, and privilege access management"
        }
        
        base_mitigation = mitigations.get(category, "Review security controls")
        return f"{priority_prefix[severity]}{base_mitigation}"


    def _generate_architectural_threats_formal(self, components: List[Dict], 
                                              start_id: int,
                                              environmental_context: Dict) -> List[Dict]:
        """Gera ameaças arquiteturais com cálculo formal"""
        threats = []
        
        if environmental_context.get('multi_cloud'):
            # Multi-cloud tem riscos específicos
            risk_assessment = self.calculate_owasp_risk_score(
                threat_category='Information Disclosure',
                component_type='service',  # Genérico
                detection_confidence=0.9,  # Alta confiança na detecção
                environmental_context=environmental_context
            )
            
            threats.append({
                'id': f'T{start_id:03d}',
                'category': 'Information Disclosure',
                'component': 'Multi-cloud Architecture',
                'component_type': 'architecture',
                'provider': 'multi-cloud',
                'description': f"Multi-cloud complexity increases attack surface. Risk Score: {risk_assessment['risk_score']}/10",
                'risk_score': risk_assessment['risk_score'],
                'severity': risk_assessment['severity'],
                'severity_label': risk_assessment['severity_label'],
                'likelihood': risk_assessment['likelihood'],
                'impact': risk_assessment['impact'],
                'detection_confidence': 0.9,
                'methodology': risk_assessment['methodology'],
                'mitigation': 'Implement unified security controls across all cloud providers',
                'references': ['NIST-SP-800-146', 'CSA-Security-Guidance']
            })
        
        return threats
    
    def _get_references_for_threat(self, category: str) -> List[str]:
        """Referências atualizadas com frameworks formais"""
        references_map = {
            'Spoofing': ['OWASP-A07-2021', 'NIST-IA-2', 'CIS-Control-6'],
            'Tampering': ['OWASP-A08-2021', 'NIST-SI-7', 'CIS-Control-3'],
            'Repudiation': ['OWASP-A09-2021', 'NIST-AU-12', 'CIS-Control-8'],
            'Information Disclosure': ['OWASP-A01-2021', 'NIST-SC-8', 'CIS-Control-13'],
            'Denial of Service': ['NIST-SC-5', 'CIS-Control-7', 'ISO-27001-A.12.1.3'],
            'Elevation of Privilege': ['OWASP-A01-2021', 'NIST-AC-6', 'CIS-Control-5']
        }
        return references_map.get(category, ['OWASP-General', 'NIST-General'])
    
    def _calculate_aggregated_risk_score(self, threats: List[Dict]) -> float:
        """
        Calcula score agregado usando metodologia formal
        Usa NIST SP 800-30 approach: considera highest risks mais weight médio
        """
        if not threats:
            return 0.0
        
        # Separar por severidade
        critical_risks = [t['risk_score'] for t in threats if t['severity'] == 'critical']
        high_risks = [t['risk_score'] for t in threats if t['severity'] == 'high']
        medium_risks = [t['risk_score'] for t in threats if t['severity'] == 'medium']
        low_risks = [t['risk_score'] for t in threats if t['severity'] in ['low', 'info']]
        
        # Peso diferenciado por severidade (NIST approach)
        weighted_scores = []
        
        if critical_risks:
            weighted_scores.extend([score * 1.0 for score in critical_risks])
        if high_risks:
            weighted_scores.extend([score * 0.8 for score in high_risks])
        if medium_risks:
            weighted_scores.extend([score * 0.5 for score in medium_risks])
        if low_risks:
            weighted_scores.extend([score * 0.2 for score in low_risks])
        
        if weighted_scores:
            # Considera o máximo e a média ponderada
            max_risk = max(t['risk_score'] for t in threats)
            avg_weighted = sum(weighted_scores) / len(weighted_scores)
            
            # 70% máximo, 30% média (enfatiza riscos altos)
            final_score = (max_risk * 0.7) + (avg_weighted * 0.3)
        else:
            final_score = 0.0
        
        return round(min(10.0, max(0.0, final_score)), 1)
    
    def _generate_stride_analysis(self, threats: List[Dict]) -> Dict:
        """Análise STRIDE com métricas formais"""
        stride_categories = {
            'Spoofing': {'count': 0, 'avg_risk': 0, 'avg_likelihood': 0, 'avg_impact': 0, 'threats': []},
            'Tampering': {'count': 0, 'avg_risk': 0, 'avg_likelihood': 0, 'avg_impact': 0, 'threats': []},
            'Repudiation': {'count': 0, 'avg_risk': 0, 'avg_likelihood': 0, 'avg_impact': 0, 'threats': []},
            'Information Disclosure': {'count': 0, 'avg_risk': 0, 'avg_likelihood': 0, 'avg_impact': 0, 'threats': []},
            'Denial of Service': {'count': 0, 'avg_risk': 0, 'avg_likelihood': 0, 'avg_impact': 0, 'threats': []},
            'Elevation of Privilege': {'count': 0, 'avg_risk': 0, 'avg_likelihood': 0, 'avg_impact': 0, 'threats': []}
        }
        
        for threat in threats:
            category = threat.get('category', 'Unknown')
            if category in stride_categories:
                stride_categories[category]['count'] += 1
                stride_categories[category]['threats'].append(threat)
        
        # Calcular médias
        for category, data in stride_categories.items():
            if data['count'] > 0:
                total_risk = sum(t.get('risk_score', 0) for t in data['threats'])
                total_likelihood = sum(t.get('likelihood', 0) for t in data['threats'])
                total_impact = sum(t.get('impact', 0) for t in data['threats'])
                
                data['avg_risk'] = round(total_risk / data['count'], 2)
                data['avg_likelihood'] = round(total_likelihood / data['count'], 2)
                data['avg_impact'] = round(total_impact / data['count'], 2)
        
        return stride_categories
    
    def _generate_recommendations(self, threats: List[Dict]) -> List[Dict]:
        """Gera recomendações priorizadas por severidade"""
        recommendations = []
        
        # Agrupar por severidade
        threats_by_severity = {'critical': [], 'high': [], 'medium': [], 'low': [], 'info': []}
        
        for threat in threats:
            severity = threat.get('severity', 'medium')
            if severity in threats_by_severity:
                threats_by_severity[severity].append(threat)
        
        # Gerar recomendações priorizadas
        for severity in ['critical', 'high', 'medium', 'low', 'info']:
            for threat in threats_by_severity[severity]:
                recommendations.append({
                    'priority': severity,
                    'priority_label': threat.get('severity_label', severity.title()),
                    'category': threat.get('category', 'Unknown'),
                    'component': threat.get('component', 'Unknown'),
                    'recommendation': threat.get('mitigation', 'Review security controls'),
                    'references': threat.get('references', []),
                    'risk_score': threat.get('risk_score', 0),
                    'likelihood': threat.get('likelihood', 0),
                    'impact': threat.get('impact', 0)
                })
        
        return recommendations
    
    def _detect_cloud_providers(self, components: List[Dict]) -> Dict:
        """Detecta provedores"""
        providers = {}
        for component in components:
            provider = component.get('provider', 'unknown')
            providers[provider] = providers.get(provider, 0) + 1
        return providers
    
    def _calculate_compliance_score(self, threats: List[Dict]) -> float:
        """
        Calcula score de compliance baseado na distribuição de riscos
        Inversamente proporcional ao risco agregado
        """
        if not threats:
            return 10.0
        
        # Contar ameaças por severidade
        severity_weights = {
            'critical': 2.5,
            'high': 2.0,
            'medium': 1.0,
            'low': 0.5,
            'info': 0.1
        }
        
        total_weight = 0
        for threat in threats:
            severity = threat.get('severity', 'medium')
            total_weight += severity_weights.get(severity, 1.0)
        
        # Score inversamente proporcional ao peso total
        # Normalizado para escala 0-10
        max_possible_weight = len(threats) * severity_weights['critical']
        compliance_ratio = 1 - (total_weight / max_possible_weight)
        
        return round(compliance_ratio * 10, 1)


# Sistema RAG Inteligente
class IntelligentSTRIDERAG:
    """Sistema RAG inteligente para análise STRIDE com correlação de normas"""
    
    def __init__(self, knowledge_docs_path: str = "knowledge_base"):
        self.knowledge_base = self._build_knowledge_base()
        self.analysis_context = None
        self.compliance_frameworks = {}
        self.knowledge_docs_path = Path(knowledge_docs_path)
        self.vector_rag = VectorRAG()
        self.embeddings_ready = False
        self.ai_manager = get_ai_provider_manager()  # Adicionar AI Provider Manager
        
        # Carregar normas e frameworks de arquivos .md
        self._load_compliance_frameworks()
        
        # Criar embeddings se frameworks foram carregados
        if self.compliance_frameworks:
            self.embeddings_ready = self.vector_rag.create_embeddings_from_frameworks(self.compliance_frameworks)
            
    def _load_compliance_frameworks(self):
        """Carrega frameworks de compliance de arquivos .md"""
        if not self.knowledge_docs_path.exists():
            st.warning(f"Pasta {self.knowledge_docs_path} não encontrada. Criando estrutura de exemplo...")
            self._create_example_knowledge_base()
            return
            
        # Carregar todos os arquivos .md
        md_files = list(self.knowledge_docs_path.glob("*.md"))
        
        for md_file in md_files:
            try:
                framework_name = md_file.stem.lower()
                with open(md_file, 'r', encoding='utf-8') as f:
                    content = f.read()
                
                # Parse do conteúdo markdown
                parsed_content = self._parse_markdown_framework(content, framework_name)
                self.compliance_frameworks[framework_name] = parsed_content
                
            except Exception as e:
                st.warning(f"Erro ao carregar {md_file}: {e}")
    
    def _create_example_knowledge_base(self):
        """Cria estrutura de exemplo com frameworks de compliance"""
        self.knowledge_docs_path.mkdir(exist_ok=True)
        
        # Exemplo: NIST Framework
        nist_content = """# NIST Cybersecurity Framework

## Access Control (AC)
### AC-1: Access Control Policy and Procedures
- **Description**: Establish formal access control policies
- **Implementation**: Document access control procedures
- **STRIDE Relevance**: Mitigates Spoofing and Elevation of Privilege
- **Risk Level**: High if not implemented

### AC-2: Account Management  
- **Description**: Manage user accounts systematically
- **Implementation**: Regular account reviews and provisioning
- **STRIDE Relevance**: Prevents unauthorized access (Spoofing)
- **Risk Level**: Critical for multi-user systems

## Identification and Authentication (IA)
### IA-1: Identification and Authentication Policy
- **Description**: Establish identity verification procedures
- **Implementation**: Multi-factor authentication required
- **STRIDE Relevance**: Primary defense against Spoofing attacks
- **Risk Level**: Critical

### IA-2: User Identification and Authentication
- **Description**: Uniquely identify and authenticate users
- **Implementation**: Strong password policies + MFA
- **STRIDE Relevance**: Spoofing prevention
- **Risk Level**: High

## System and Information Integrity (SI)
### SI-1: System and Information Integrity Policy
- **Description**: Maintain data and system integrity
- **Implementation**: Integrity monitoring tools
- **STRIDE Relevance**: Detects and prevents Tampering
- **Risk Level**: High

### SI-7: Software and Information Integrity
- **Description**: Detect unauthorized changes
- **Implementation**: Digital signatures, checksums
- **STRIDE Relevance**: Anti-tampering controls
- **Risk Level**: Medium to High
"""
        
        # Exemplo: OWASP Top 10
        owasp_content = """# OWASP Top 10 2021

## A01 - Broken Access Control
- **Description**: Restrictions on authenticated users not properly enforced
- **Common Weaknesses**: Bypassing access control checks
- **STRIDE Relevance**: Elevation of Privilege, Spoofing
- **Mitigation**: Implement proper authorization checks
- **Testing**: Verify access controls in all user flows

## A02 - Cryptographic Failures
- **Description**: Failures related to cryptography leading to data exposure
- **Common Weaknesses**: Weak encryption, plain text storage
- **STRIDE Relevance**: Information Disclosure
- **Mitigation**: Use strong encryption standards (AES-256)
- **Testing**: Scan for weak cryptographic implementations

## A03 - Injection
- **Description**: Hostile data sent to interpreter as part of command/query
- **Common Weaknesses**: SQL, NoSQL, OS command injection
- **STRIDE Relevance**: Tampering, Elevation of Privilege
- **Mitigation**: Input validation, parameterized queries
- **Testing**: Automated and manual injection testing

## A08 - Software and Data Integrity Failures
- **Description**: Code and infrastructure without integrity protection
- **Common Weaknesses**: Unsigned updates, CI/CD vulnerabilities
- **STRIDE Relevance**: Tampering
- **Mitigation**: Digital signatures, secure CI/CD pipelines
- **Testing**: Verify software update mechanisms

## A09 - Security Logging and Monitoring Failures
- **Description**: Insufficient logging, detection, monitoring
- **Common Weaknesses**: Logs not monitored, inadequate incident response
- **STRIDE Relevance**: Repudiation
- **Mitigation**: Comprehensive logging strategy
- **Testing**: Verify log coverage and alerting
"""
        
        # Exemplo: ISO 27001
        iso_content = """# ISO 27001:2022 Controls

## A.5 Information Security Policies
### A.5.1 Management Direction for Information Security
- **Description**: Management commitment to information security
- **Implementation**: Formal security policy approved by management  
- **STRIDE Relevance**: Overall security posture
- **Applicability**: All organizations

## A.8 Asset Management
### A.8.1 Responsibility for Assets
- **Description**: Assets should be identified and appropriate protection responsibilities defined
- **Implementation**: Asset inventory and ownership
- **STRIDE Relevance**: Information Disclosure prevention
- **Risk Assessment**: Critical for data classification

### A.8.2 Information Classification
- **Description**: Information should be classified according to sensitivity
- **Implementation**: Data labeling and handling procedures
- **STRIDE Relevance**: Information Disclosure mitigation
- **Risk Assessment**: Essential for compliance

## A.9 Access Control
### A.9.1 Business Requirements of Access Control
- **Description**: Access control policy based on business requirements
- **Implementation**: Role-based access control (RBAC)
- **STRIDE Relevance**: Spoofing and Elevation of Privilege prevention
- **Risk Assessment**: High priority control

### A.9.2 User Access Management
- **Description**: Formal user access provisioning process
- **Implementation**: Regular access reviews and deprovisioning
- **STRIDE Relevance**: Prevents unauthorized access (Spoofing)
- **Risk Assessment**: Critical for user lifecycle management
"""
        
        # Salvar arquivos de exemplo
        (self.knowledge_docs_path / "nist_framework.md").write_text(nist_content, encoding='utf-8')
        (self.knowledge_docs_path / "owasp_top10.md").write_text(owasp_content, encoding='utf-8')
        (self.knowledge_docs_path / "iso27001.md").write_text(iso_content, encoding='utf-8')
        
        st.success(f"Criados arquivos de exemplo em {self.knowledge_docs_path}")
        
        # Carregar os arquivos criados
        self._load_compliance_frameworks()
    
    def _parse_markdown_framework(self, content: str, framework_name: str) -> Dict:
        """Parse de arquivo markdown de framework de compliance"""
        parsed = {
            'name': framework_name,
            'sections': {},
            'controls': {},
            'stride_mappings': {}
        }
        
        lines = content.split('\n')
        current_section = None
        current_control = None
        current_content = []
        
        for line in lines:
            line = line.strip()
            
            # Seções principais (## Title)
            if line.startswith('## '):
                if current_section and current_content:
                    parsed['sections'][current_section] = '\n'.join(current_content)
                current_section = line[3:].strip()
                current_content = []
                
            # Controles específicos (### Control)
            elif line.startswith('### '):
                if current_control and current_content:
                    parsed['controls'][current_control] = '\n'.join(current_content)
                current_control = line[4:].strip()
                current_content = []
                
            # Mapeamento STRIDE
            elif 'STRIDE Relevance:' in line:
                stride_info = line.split('STRIDE Relevance:')[1].strip()
                if current_control:
                    if current_control not in parsed['stride_mappings']:
                        parsed['stride_mappings'][current_control] = []
                    
                    # Extrair categorias STRIDE mencionadas
                    stride_categories = []
                    for category in ['Spoofing', 'Tampering', 'Repudiation', 'Information Disclosure', 'Denial of Service', 'Elevation of Privilege']:
                        if category in stride_info:
                            stride_categories.append(category)
                    
                    parsed['stride_mappings'][current_control] = stride_categories
                current_content.append(line)
                
            else:
                if line:  # Ignorar linhas vazias
                    current_content.append(line)
        
        # Adicionar último item
        if current_control and current_content:
            parsed['controls'][current_control] = '\n'.join(current_content)
        elif current_section and current_content:
            parsed['sections'][current_section] = '\n'.join(current_content)
        
        return parsed
    
    def _find_relevant_compliance_controls(self, threat_category: str, component_type: str = None) -> List[Dict]:
        """Busca controles de compliance relevantes para uma ameaça STRIDE"""
        relevant_controls = []
        
        for framework_name, framework_data in self.compliance_frameworks.items():
            stride_mappings = framework_data.get('stride_mappings', {})
            controls = framework_data.get('controls', {})
            
            for control_name, stride_categories in stride_mappings.items():
                if threat_category in stride_categories:
                    control_content = controls.get(control_name, '')
                    
                    relevant_controls.append({
                        'framework': framework_name.upper(),
                        'control': control_name,
                        'content': control_content,
                        'relevance_score': self._calculate_relevance_score(control_content, threat_category, component_type)
                    })
        
        # Ordenar por relevância
        relevant_controls.sort(key=lambda x: x['relevance_score'], reverse=True)
        
        return relevant_controls[:5]  # Top 5 mais relevantes
    
    def _calculate_relevance_score(self, control_content: str, threat_category: str, component_type: str = None) -> float:
        """Calcula score de relevância de um controle para uma ameaça"""
        score = 0.0
        content_lower = control_content.lower()
        
        # Score base por menção da categoria STRIDE
        if threat_category.lower() in content_lower:
            score += 1.0
        
        # Score adicional por tipo de componente
        if component_type:
            component_keywords = {
                'networking': ['network', 'communication', 'connection', 'traffic'],
                'storage': ['data', 'storage', 'database', 'information'],
                'compute': ['application', 'system', 'server', 'processing']
            }
            
            keywords = component_keywords.get(component_type, [])
            for keyword in keywords:
                if keyword in content_lower:
                    score += 0.2
        
        # Score por palavras-chave de criticidade
        critical_keywords = ['critical', 'high', 'essential', 'mandatory', 'required']
        for keyword in critical_keywords:
            if keyword in content_lower:
                score += 0.1
        
        return score
        
    def set_analysis_context(self, analysis_result: Dict):
        """Define o contexto da análise atual para RAG contextual"""
        self.analysis_context = analysis_result
        
    def _build_knowledge_base(self) -> Dict:
        """Constrói base de conhecimento especializada em STRIDE"""
        return {
            'stride_categories': {
                'spoofing': {
                    'definition': 'Ataques onde adversários se passam por entidades legítimas',
                    'techniques': ['credential theft', 'session hijacking', 'DNS spoofing', 'IP spoofing'],
                    'mitigations': ['strong authentication', 'MFA', 'certificate validation', 'mutual authentication'],
                    'examples': ['SQL injection em login', 'Falsificação de tokens JWT', 'ARP spoofing']
                },
                'tampering': {
                    'definition': 'Modificação não autorizada de dados ou código',
                    'techniques': ['data manipulation', 'code injection', 'configuration changes'],
                    'mitigations': ['input validation', 'code signing', 'integrity monitoring', 'checksums'],
                    'examples': ['Alteração de parâmetros HTTP', 'Modificação de arquivos de configuração']
                },
                'repudiation': {
                    'definition': 'Negação de ações realizadas sem evidências adequadas',
                    'techniques': ['log tampering', 'time manipulation', 'identity confusion'],
                    'mitigations': ['comprehensive logging', 'digital signatures', 'audit trails', 'timestamps'],
                    'examples': ['Usuário nega transação realizada', 'Admin nega mudanças de configuração']
                },
                'information_disclosure': {
                    'definition': 'Exposição não autorizada de informações confidenciais',
                    'techniques': ['data leakage', 'unauthorized access', 'side-channel attacks'],
                    'mitigations': ['encryption', 'access controls', 'data classification', 'DLP'],
                    'examples': ['Logs com dados sensíveis', 'APIs sem autenticação', 'Buckets S3 públicos']
                },
                'denial_of_service': {
                    'definition': 'Ataques que impedem acesso legítimo a recursos',
                    'techniques': ['resource exhaustion', 'network flooding', 'application crashes'],
                    'mitigations': ['rate limiting', 'load balancing', 'DDoS protection', 'resource monitoring'],
                    'examples': ['DDoS na camada 7', 'Spam de requests', 'Memory exhaustion']
                },
                'elevation_of_privilege': {
                    'definition': 'Obtenção de privilégios superiores aos autorizados',
                    'techniques': ['privilege escalation', 'buffer overflow', 'SQL injection'],
                    'mitigations': ['least privilege', 'input validation', 'security patching', 'sandboxing'],
                    'examples': ['Usuário comum vira admin', 'Container escape', 'Kernel exploits']
                }
            },
            'cloud_security': {
                'aws': {
                    'services': ['IAM', 'CloudTrail', 'GuardDuty', 'Security Hub', 'WAF', 'Shield'],
                    'best_practices': ['Enable MFA', 'Use IAM roles', 'Enable logging', 'Encrypt data'],
                    'common_risks': ['Open S3 buckets', 'Overprivileged IAM', 'Unencrypted data']
                },
                'azure': {
                    'services': ['Azure AD', 'Security Center', 'Sentinel', 'Key Vault', 'WAF'],
                    'best_practices': ['Enable conditional access', 'Use managed identities', 'Enable monitoring'],
                    'common_risks': ['Exposed storage accounts', 'Weak access controls', 'Unpatched VMs']
                },
                'gcp': {
                    'services': ['Cloud IAM', 'Security Command Center', 'Cloud Armor', 'KMS'],
                    'best_practices': ['Use service accounts', 'Enable audit logs', 'Implement VPC security'],
                    'common_risks': ['Open firewall rules', 'Public datasets', 'Weak IAM policies']
                }
            },
            'component_risks': {
                'networking': {
                    'common_threats': ['Man-in-the-middle', 'DDoS', 'Network sniffing', 'Spoofing'],
                    'security_controls': ['TLS/SSL', 'Network segmentation', 'Firewalls', 'IDS/IPS']
                },
                'storage': {
                    'common_threats': ['Data breaches', 'Unauthorized access', 'Data tampering'],
                    'security_controls': ['Encryption at rest', 'Access controls', 'Backup security', 'Audit logs']
                },
                'compute': {
                    'common_threats': ['Code injection', 'Privilege escalation', 'Malware'],
                    'security_controls': ['Input validation', 'Regular patching', 'Antivirus', 'Least privilege']
                }
            }
        }
    
    def process_query(self, user_query: str) -> str:
        """Processa pergunta do usuário com RAG contextual melhorado"""
        if not self.analysis_context:
            return self._general_response(user_query)
            
        # Usar busca vetorial se disponível
        if self.embeddings_ready:
            return self._process_with_vector_rag(user_query)
        # Usar OpenAI para análise semântica se disponível
        elif OPENAI_AVAILABLE and os.getenv('OPENAI_API_KEY'):
            return self._process_with_openai(user_query)
        else:
            return self._process_with_heuristics(user_query)
    
    def _process_with_vector_rag(self, user_query: str) -> str:
        """Processa pergunta usando RAG híbrido com busca vetorial e AI Provider Manager"""
        try:
            # Busca semântica
            relevant_chunks = self.vector_rag.semantic_search(user_query, top_k=5)
            
            # Preparar contexto da arquitetura
            arch_context = self._prepare_architecture_context()
            
            # Preparar contexto dos controles relevantes
            controls_context = ""
            if relevant_chunks:
                controls_context = "\n\nCONTROLES DE COMPLIANCE RELEVANTES:\n"
                for chunk in relevant_chunks:
                    controls_context += f"• {chunk['framework'].upper()} - {chunk['control']}\n"
                    controls_context += f"  {chunk['content'][:200]}...\n"
            
            # Usar AI Provider Manager para síntese final
            system_prompt = f"""Você é um especialista em segurança STRIDE analisando uma arquitetura específica.

CONTEXTO DA ARQUITETURA ANALISADA:
{arch_context}

{controls_context}

Responda de forma natural e conversacional, correlacionando os controles de compliance com as ameaças específicas da arquitetura.
Use os dados reais da análise e os controles encontrados na busca vetorial.
Seja específico e prático nas recomendações."""
            
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_query}
            ]
            
            ai_response = self.ai_manager.chat_completion(
                messages=messages,
                temperature=0.7,
                max_tokens=800
            )
            
            if ai_response.success:
                response_text = ai_response.content
                
                # Adicionar indicador do provider
                provider_info = f"\n\n---\n_RAG Híbrido: {ai_response.provider.title()}"
                if ai_response.provider == "consolidated":
                    provider_info += f" (Consolidação de múltiplos providers)"
                provider_info += f" + Busca Vetorial ({len(relevant_chunks)} controles)_"
                
                return response_text + provider_info
            else:
                # Fallback para processamento heurístico melhorado
                return self._process_with_heuristics_enhanced(user_query, relevant_chunks)
                
        except Exception as e:
            st.error(f"Erro no RAG híbrido: {e}")
            return self._process_with_heuristics(user_query)

    
    def _process_with_heuristics_enhanced(self, user_query: str, relevant_chunks: List[Dict]) -> str:
        """Processamento heurístico melhorado com controles de compliance"""
        # Usar heurística básica
        basic_response = self._process_with_heuristics(user_query)
        
        # Adicionar controles relevantes se encontrados
        if relevant_chunks:
            enhanced_response = basic_response + "\n\n**Controles de Compliance Relevantes encontrados na busca vetorial:**\n"
            for chunk in relevant_chunks[:3]:
                enhanced_response += f"\n• **{chunk['framework'].upper()} - {chunk['control']}**\n"
                enhanced_response += f"  Similaridade: {chunk['similarity_score']:.3f}\n"
                # Extrair descrição do conteúdo
                lines = chunk['content'].split('\n')
                for line in lines:
                    if 'Description:' in line:
                        desc = line.split('Description:')[1].strip()
                        enhanced_response += f"  {desc}\n"
                        break
            return enhanced_response
        
        return basic_response
    
    def _process_with_openai(self, user_query: str) -> str:
        """Processa pergunta usando AI Provider Manager"""
        try:
            # Preparar contexto da arquitetura
            context = self._prepare_architecture_context()
            
            # Prompt especializado para análise STRIDE
            system_prompt = f"""Você é um especialista em segurança STRIDE analisando uma arquitetura específica.

CONTEXTO DA ARQUITETURA ANALISADA:
{context}

FRAMEWORKS DE COMPLIANCE DISPONÍVEIS:
{', '.join([f.upper() for f in self.compliance_frameworks.keys()])}

Responda de forma natural e conversacional, como se fosse um consultor de segurança experiente. 
Use os dados reais da arquitetura analisada para dar respostas específicas e contextuais.
Se a pergunta mencionar componentes específicos, ameaças, ou pedir mitigações, seja específico usando os dados reais.
Correlacione com normas de compliance quando relevante.

IMPORTANTE: Seja natural, conversacional e específico. Evite respostas genéricas."""
            
            # Preparar mensagens
            messages = [
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_query}
            ]
            
            # Usar AI Provider Manager
            ai_response = self.ai_manager.chat_completion(
                messages=messages,
                temperature=0.7,
                max_tokens=800
            )
            
            if ai_response.success:
                response_text = ai_response.content
                
                # Adicionar indicador do provider usado
                provider_indicator = f"\n\n---\n_Análise por: {ai_response.provider.title()} ({ai_response.model})_"
                
                # Se foi consolidação, adicionar informação extra
                if ai_response.provider == "consolidated":
                    provider_indicator += f"\n_Consolidação de {ai_response.metadata.get('sources', 2)} providers_"
                
                # Enriquecer com informações de compliance
                enriched_response = self._enrich_with_compliance(response_text, user_query)
                
                return enriched_response + provider_indicator
            else:
                # Fallback para processamento heurístico
                st.warning(f"Erro na análise AI: {ai_response.error}. Usando heurísticas...")
                return self._process_with_heuristics(user_query)
                
        except Exception as e:
            st.error(f"Erro no processamento: {e}")
            return self._process_with_heuristics(user_query)
    
    def _prepare_architecture_context(self) -> str:
        """Prepara contexto estruturado da arquitetura para OpenAI"""
        if not self.analysis_context:
            return "Nenhuma análise disponível"
            
        components = self.analysis_context.get('detected_components', [])
        threats = self.analysis_context.get('threats', [])
        stride_analysis = self.analysis_context.get('stride_analysis', {})
        
        context = f"""
ARQUITETURA ANALISADA:
- Imagem: {self.analysis_context.get('image_info', {}).get('filename', 'N/A')}
- Risk Score: {self.analysis_context.get('risk_score', 0)}/10
- Total de componentes: {len(components)}
- Total de ameaças: {len(threats)}

COMPONENTES DETECTADOS:
"""
        
        for comp in components[:10]:  # Top 10 componentes
            context += f"- {comp.get('name', 'Unknown')}: {comp.get('type', 'unknown')} ({comp.get('provider', 'generic')}) - Confiança: {comp.get('confidence', 0):.0%}\n"
        
        context += "\nAMEAÇAS IDENTIFICADAS:\n"
        
        # Agrupar ameaças por categoria
        for category, data in stride_analysis.items():
            count = data.get('count', 0)
            if count > 0:
                context += f"- {category.replace('_', ' ')}: {count} ameaças (risco médio: {data.get('avg_risk', 0)}/10)\n"
        
        context += "\nPRINCIPAIS AMEAÇAS:\n"
        top_threats = sorted(threats, key=lambda x: x.get('risk_score', 0), reverse=True)[:5]
        for threat in top_threats:
            context += f"- {threat.get('component', 'Unknown')}: {threat.get('category', 'Unknown')} (Risk: {threat.get('risk_score', 0)}/10)\n"
            context += f"  Descrição: {threat.get('description', 'N/A')}\n"
        
        return context
    
    def _enrich_with_compliance(self, ai_response: str, user_query: str) -> str:
        """Enriquece resposta da OpenAI com informações de compliance quando relevante"""
        query_lower = user_query.lower()
        
        # Se a pergunta menciona compliance, normas ou como corrigir
        if any(word in query_lower for word in ['norma', 'compliance', 'iso', 'nist', 'owasp', 'como corrigir', 'mitigar']):
            
            # Extrair categorias STRIDE mencionadas na resposta ou pergunta
            stride_categories = []
            for category in ['Spoofing', 'Tampering', 'Repudiation', 'Information Disclosure', 'Denial of Service', 'Elevation of Privilege']:
                if category.lower() in query_lower or category.lower() in ai_response.lower():
                    stride_categories.append(category)
            
            if stride_categories:
                compliance_info = "\n\n**Controles de Compliance Relevantes:**\n"
                for category in stride_categories[:2]:  # Top 2 categorias
                    controls = self._find_relevant_compliance_controls(category)
                    if controls:
                        compliance_info += f"\n*{category}:*\n"
                        for control in controls[:2]:
                            compliance_info += f"• {control['framework']}: {control['control']}\n"
                
                return ai_response + compliance_info
        
        return ai_response
    
    def _process_with_heuristics(self, user_query: str) -> str:
        """Processa pergunta usando heurísticas quando OpenAI não está disponível"""
        # Análise semântica básica melhorada
        query_analysis = self._analyze_user_query_improved(user_query)
        
        # Buscar informações relevantes
        relevant_info = self._retrieve_relevant_information(query_analysis)
        
        # Gerar resposta contextual
        response = self._generate_contextual_response_improved(query_analysis, relevant_info, user_query)
        
        return response
    
    def _analyze_user_query_improved(self, query: str) -> Dict:
        """Análise semântica melhorada da pergunta"""
        query_lower = query.lower()
        
        # Analisar componentes mencionados na pergunta
        mentioned_components = []
        if self.analysis_context and 'detected_components' in self.analysis_context:
            for component in self.analysis_context['detected_components']:
                comp_name = component.get('name', '').lower()
                # Buscar por partes do nome também
                comp_words = comp_name.split()
                if any(word in query_lower for word in comp_words if len(word) > 3):
                    mentioned_components.append(component)
        
        # Analisar ameaças/categorias mencionadas
        mentioned_categories = []
        stride_keywords = {
            'spoofing': ['spoof', 'falsifica', 'personaliza', 'identidade', 'autenticação'],
            'tampering': ['tamper', 'modifica', 'altera', 'integridade', 'dados'],
            'repudiation': ['repudia', 'nega', 'auditoria', 'logs', 'rastrea'],
            'information_disclosure': ['disclosure', 'vaza', 'expõe', 'dados', 'confidencial', 'informação'],
            'denial_of_service': ['dos', 'ddos', 'nega', 'disponibilidade', 'indisponível', 'serviço'],
            'elevation_of_privilege': ['privilege', 'privilégio', 'escala', 'admin', 'root', 'acesso']
        }
        
        for category, keywords in stride_keywords.items():
            if any(keyword in query_lower for keyword in keywords):
                mentioned_categories.append(category)
        
        # Identificar intenção mais precisamente
        intent = 'general_inquiry'
        if any(word in query_lower for word in ['como', 'como corrigir', 'como resolver', 'como mitigar', 'o que fazer']):
            intent = 'mitigation_request'
        elif any(word in query_lower for word in ['por que', 'porque', 'explique', 'o que é', 'como funciona']):
            intent = 'explanation_request'
        elif any(word in query_lower for word in ['quais', 'que', 'lista', 'mostre']):
            intent = 'listing_request'
        elif any(word in query_lower for word in ['melhorar', 'reduzir', 'diminuir', 'score']):
            intent = 'improvement_request'
        
        # Classificar tipo da pergunta
        query_type = 'general'
        if any(word in query_lower for word in ['risco', 'score', 'pontuação']):
            query_type = 'risk_analysis'
        elif any(word in query_lower for word in ['componente', 'detecta', 'identifica']):
            query_type = 'component_analysis'
        elif any(word in query_lower for word in ['ameaça', 'vulnerabilidade', 'ataque']):
            query_type = 'threat_analysis'
        elif any(word in query_lower for word in ['stride', 'categoria']):
            query_type = 'stride_methodology'
        
        return {
            'original_query': query,
            'mentioned_components': mentioned_components,
            'mentioned_categories': mentioned_categories,
            'intent': intent,
            'query_type': query_type,
            'is_specific': len(mentioned_components) > 0 or len(mentioned_categories) > 0
        }
    
    def _retrieve_relevant_information(self, query_analysis: Dict) -> Dict:
        """Recupera informações relevantes baseado na análise da pergunta"""
        relevant_info = {
            'current_analysis': {},
            'knowledge_base_info': {},
            'specific_recommendations': []
        }
        
        # Informações da análise atual
        if self.analysis_context:
            relevant_info['current_analysis'] = {
                'total_components': len(self.analysis_context.get('detected_components', [])),
                'total_threats': len(self.analysis_context.get('threats', [])),
                'risk_score': self.analysis_context.get('risk_score', 0),
                'providers': list(self.analysis_context.get('cloud_providers', {}).keys()),
                'stride_distribution': self.analysis_context.get('stride_analysis', {}),
                'detection_methods': self._extract_detection_methods()
            }
        
        # Buscar informações específicas mencionadas
        for category in query_analysis['mentioned_categories']:
            if category in self.knowledge_base['stride_categories']:
                relevant_info['knowledge_base_info'][category] = self.knowledge_base['stride_categories'][category]
        
        return relevant_info
    
    def _extract_detection_methods(self) -> Dict:
        """Extrai informações sobre métodos de detecção utilizados"""
        if not self.analysis_context or 'detected_components' not in self.analysis_context:
            return {}
            
        methods = {}
        for component in self.analysis_context['detected_components']:
            method = component.get('detection_method', 'unknown')
            if method not in methods:
                methods[method] = []
            methods[method].append(component.get('name', 'Unknown'))
        
        return methods
    
    def _generate_contextual_response_improved(self, query_analysis: Dict, relevant_info: Dict, original_query: str) -> str:
        """Gera resposta contextual melhorada e mais natural"""
        
        # Se não há elementos específicos mencionados, dar uma resposta mais direcionada
        if not query_analysis['is_specific']:
            return self._generate_guided_response(original_query, relevant_info)
        
        intent = query_analysis['intent']
        query_type = query_analysis['query_type']
        
        # Roteamento melhorado baseado na intenção
        if intent == 'mitigation_request':
            return self._generate_mitigation_response_improved(query_analysis, relevant_info)
        elif intent == 'explanation_request':
            return self._generate_explanation_response_improved(query_analysis, relevant_info)
        elif intent == 'improvement_request':
            return self._generate_improvement_response(query_analysis, relevant_info)
        elif query_type == 'risk_analysis':
            return self._generate_risk_analysis_response_improved(query_analysis, relevant_info)
        elif query_type == 'component_analysis':
            return self._generate_component_analysis_response_improved(query_analysis, relevant_info)
        elif query_type == 'threat_analysis':
            return self._generate_threat_analysis_response_improved(query_analysis, relevant_info)
        else:
            return self._generate_specific_response(query_analysis, relevant_info)
    
    def _generate_guided_response(self, original_query: str, relevant_info: Dict) -> str:
        """Gera resposta direcionada quando pergunta não é específica"""
        current = relevant_info['current_analysis']
        query_lower = original_query.lower()
        
        if 'risco' in query_lower or 'score' in query_lower:
            risk_score = current.get('risk_score', 0)
            return f"Seu risk score atual é {risk_score}/10. Isso indica um nível {'crítico' if risk_score >= 8 else 'alto' if risk_score >= 6 else 'médio' if risk_score >= 4 else 'baixo'} de risco. " + \
                   f"As principais categorias de ameaças na sua arquitetura são: {', '.join([cat.replace('_', ' ') for cat, data in current.get('stride_distribution', {}).items() if data.get('count', 0) > 0])[:3]}. " + \
                   "Quer que eu explique alguma categoria específica ou como melhorar o score?"
        
        elif 'componente' in query_lower:
            components = current.get('total_components', 0)
            return f"Detectei {components} componentes na sua arquitetura usando análise visual multi-modal. " + \
                   f"Os principais são: {', '.join([comp.get('name', 'Unknown') for comp in self.analysis_context.get('detected_components', [])[:3]])}. " + \
                   "Quer saber mais sobre algum componente específico ou como foram detectados?"
        
        elif any(word in query_lower for word in ['melhor', 'corrig', 'mitiga']):
            high_risk_threats = [t for t in self.analysis_context.get('threats', []) if t.get('severity') in ['critical', 'high']]
            if high_risk_threats:
                return f"Para melhorar a segurança, foque primeiro nas ameaças críticas/altas. Por exemplo: " + \
                       f"{high_risk_threats[0].get('category', 'Unknown')} no {high_risk_threats[0].get('component', 'componente')}. " + \
                       "Quer que eu detalhe as mitigações específicas para esta ameaça?"
            else:
                return "Sua arquitetura está com riscos controlados. Posso sugerir melhorias preventivas se quiser."
        
        else:
            # Resposta mais inteligente e direcionada
            total_components = current.get('total_components', 0)
            total_threats = current.get('total_threats', 0)
            risk_score = current.get('risk_score', 0)
            
            main_categories = [cat.replace('_', ' ') for cat, data in current.get('stride_distribution', {}).items() 
                             if data.get('count', 0) > 0][:3]
            
            return f"Analisei sua arquitetura e encontrei {total_components} componentes com {total_threats} ameaças (risk score {risk_score}/10). " + \
                   f"As principais categorias de risco são: {', '.join(main_categories)}. " + \
                   "Posso explicar qualquer aspecto específico - por exemplo: 'Como corrigir spoofing?' ou 'Por que o ExpressRoute tem risco alto?'"
    
    def _generate_improvement_response(self, query_analysis: Dict, relevant_info: Dict) -> str:
        """Gera resposta para pedidos de melhoria"""
        current = relevant_info['current_analysis']
        risk_score = current.get('risk_score', 0)
        
        response = f"Para melhorar seu risk score atual de {risk_score}/10:\n\n"
        
        # Identificar ameaças de alta prioridade
        high_priority = [t for t in self.analysis_context.get('threats', []) if t.get('severity') in ['critical', 'high']]
        
        if high_priority:
            response += "**Prioridade 1 - Ameaças Críticas/Altas:**\n"
            for i, threat in enumerate(high_priority[:3]):
                response += f"{i+1}. {threat.get('component', 'Componente')}: {threat.get('category', 'Ameaça')}\n"
                response += f"   → {threat.get('mitigation', 'Implementar controles de segurança')}\n\n"
        
        # Sugestões baseadas na distribuição STRIDE
        stride_dist = current.get('stride_distribution', {})
        worst_category = max(stride_dist.keys(), key=lambda x: stride_dist[x].get('count', 0)) if stride_dist else None
        
        if worst_category and stride_dist[worst_category].get('count', 0) > 0:
            response += f"**Foco Principal:** {worst_category.replace('_', ' ')} ({stride_dist[worst_category]['count']} ameaças)\n"
            
            # Buscar controles de compliance
            controls = self._find_relevant_compliance_controls(worst_category.replace('_', ' '))
            if controls:
                response += f"Controles recomendados: {controls[0]['framework']} - {controls[0]['control']}\n"
        
        return response
    
    def _generate_mitigation_response_improved(self, query_analysis: Dict, relevant_info: Dict) -> str:
        """Gera resposta melhorada para mitigação"""
        return self._generate_improvement_response(query_analysis, relevant_info)
    
    def _generate_explanation_response_improved(self, query_analysis: Dict, relevant_info: Dict) -> str:
        """Gera resposta explicativa melhorada"""
        return self._generate_guided_response(query_analysis['original_query'], relevant_info)
    
    def _generate_risk_analysis_response_improved(self, query_analysis: Dict, relevant_info: Dict) -> str:
        """Gera análise de risco melhorada"""
        return self._generate_guided_response(query_analysis['original_query'], relevant_info)
    
    def _generate_component_analysis_response_improved(self, query_analysis: Dict, relevant_info: Dict) -> str:
        """Gera análise de componente melhorada"""
        return self._generate_guided_response(query_analysis['original_query'], relevant_info)
    
    def _generate_threat_analysis_response_improved(self, query_analysis: Dict, relevant_info: Dict) -> str:
        """Gera análise de ameaça melhorada"""
        return self._generate_guided_response(query_analysis['original_query'], relevant_info)
    
    def _generate_specific_response(self, query_analysis: Dict, relevant_info: Dict) -> str:
        """Gera resposta específica"""
        return self._generate_guided_response(query_analysis['original_query'], relevant_info)
        
    def _general_response(self, query: str) -> str:
        """Resposta quando não há contexto de análise"""
        return "Execute uma análise STRIDE primeiro para ter respostas contextualizadas sobre sua arquitetura específica. " + \
               "O chat ficará muito mais inteligente com os dados reais da sua imagem analisada!"


# Função para obter instância do RAG, criando se necessário
def get_stride_rag():
    """Função para obter instância do RAG, criando se necessário"""
    if 'stride_rag_instance' not in st.session_state:
        st.session_state.stride_rag_instance = IntelligentSTRIDERAG()
    return st.session_state.stride_rag_instance


# Funções auxiliares para relatórios
def get_risk_level_class(risk_score: float) -> str:
    if risk_score >= 9.0:
        return 'critical'
    elif risk_score >= 7.0:
        return 'high'
    elif risk_score >= 4.0:
        return 'medium'
    else:
        return 'low'


def get_stride_description(category: str) -> str:
    descriptions = {
        'Spoofing': 'Falsificação de Identidade',
        'Tampering': 'Modificação de Dados',
        'Repudiation': 'Não-Repúdio',
        'Information Disclosure': 'Vazamento de Dados',
        'Denial of Service': 'Negação de Serviço',
        'Elevation of Privilege': 'Escalação de Privilégios'
    }
    return descriptions.get(category, 'Categoria STRIDE')


# Gerador HTML Completo
def generate_enhanced_html_report(analysis_result: Dict) -> str:
    """Gera relatório HTML completo baseado no template original com dados da análise real"""
    
    # Extrair dados REAIS da análise
    threats = analysis_result.get('threats', [])
    components = analysis_result.get('detected_components', [])
    stride_analysis = analysis_result.get('stride_analysis', {})
    cloud_providers = analysis_result.get('cloud_providers', {})
    
    total_threats = len(threats)
    overall_risk = analysis_result.get('risk_score', 0)
    
    # Calcular distribuição de severidade REAL
    severity_count = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
    for threat in threats:
        severity = threat.get('severity', 'medium')
        if severity in severity_count:
            severity_count[severity] += 1
    
    # Calcular percentuais
    severity_percent = {}
    for severity, count in severity_count.items():
        if total_threats > 0:
            severity_percent[severity] = round((count / total_threats) * 100, 1)
        else:
            severity_percent[severity] = 0
    
    # Gerar badges de cloud providers DINAMICOS
    cloud_badges_html = ""
    for provider, count in cloud_providers.items():
        badge_class = {
            'aws': 'badge-aws',
            'azure': 'badge-azure', 
            'gcp': 'badge-gcp',
            'on-premises': 'badge-other',
            'generic': 'badge-other'
        }.get(provider, 'badge-other')
        
        cloud_badges_html += f'''
        <span class="badge-cloud {badge_class}">
            {provider.upper()} <span class="badge-count">{count}</span>
        </span>
        '''
    
    # Gerar cards de métricas DINAMICOS
    metric_cards_html = f'''
    <div class="metric-card">
        <h3>Total de Ameaças</h3>
        <div class="metric-value">{total_threats}</div>
        <div class="metric-description">Identificadas na arquitetura</div>
    </div>
    
    <div class="metric-card">
        <h3>Risk Score</h3>
        <div class="metric-value risk-score-{get_risk_level_class(overall_risk)}">{overall_risk}/10</div>
        <div class="metric-description">Nível de risco global</div>
    </div>
    
    <div class="metric-card">
        <h3>Componentes</h3>
        <div class="metric-value">{len(components)}</div>
        <div class="metric-description">Detectados automaticamente</div>
    </div>
    
    <div class="metric-card">
        <h3>Compliance</h3>
        <div class="metric-value">{analysis_result.get('compliance_score', 0)}/10</div>
        <div class="metric-description">Score de conformidade</div>
    </div>
    '''
    
    # Gerar categorias STRIDE DINAMICAS
    stride_cards_html = ""
    stride_icons = {
        'Spoofing': '🎭',
        'Tampering': '🔧',
        'Repudiation': '📝', 
        'Information Disclosure': '📋',
        'Denial of Service': '⚡',
        'Elevation of Privilege': '⬆️'
    }
    
    for category, data in stride_analysis.items():
        icon = stride_icons.get(category, '🔒')
        count = data.get('count', 0)
        avg_risk = data.get('avg_risk', 0)
        risk_class = get_risk_level_class(avg_risk)
        
        stride_cards_html += f'''
        <div class="stride-category">
            <h4>
                {icon} {category}
                <span class="threat-count">{count}</span>
            </h4>
            <div class="risk-score {risk_class}">{avg_risk}/10</div>
            <p style="color: #6c757d; font-size: 0.9em;">{get_stride_description(category)}</p>
        </div>
        '''
    
    # Gerar tabela de ameaças COM LINKS DE REFERENCIA
    threats_table_html = ""
    detected_providers = list(cloud_providers.keys())
    
    # Ordenar ameaças por risk score
    sorted_threats = sorted(threats, key=lambda x: x.get('risk_score', 0), reverse=True)
    
    for threat in sorted_threats:
        severity = threat.get('severity', 'medium')
        risk_score = threat.get('risk_score', 0)
        risk_class = get_risk_level_class(risk_score)
        
        # Gerar links de referência automáticos
        references = threat_reference_manager.get_threat_references(threat, detected_providers)
        references_html = ""
        
        for ref in references[:4]:  # Limitar a 4 referências por ameaça
            ref_icon = {
                'owasp': '🛡️',
                'nist': '📋', 
                'microsoft': '🏢',
                'cloud': '☁️'
            }.get(ref['type'], '🔗')
            
            references_html += f'''
            <a href="{ref['url']}" target="_blank" title="{ref['description']}" style="margin-right: 8px; text-decoration: none;">
                {ref_icon} {ref['title'][:20]}{'...' if len(ref['title']) > 20 else ''}
            </a><br>
            '''
        
        threats_table_html += f'''
        <tr class="threat-row">
            <td><strong>{threat.get('category', 'Unknown')}</strong></td>
            <td>{threat.get('component', 'Unknown')}</td>
            <td><span class="threat-{severity}">{severity.title()}</span></td>
            <td class="risk-score {risk_class}">{risk_score}/10</td>
            <td>{threat.get('description', 'N/A')}</td>
            <td style="font-size: 0.85em;">
                {references_html if references_html else 'N/A'}
            </td>
        </tr>
        '''
    
    # Template HTML COMPLETO
    html_content = f'''<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório Archer - AI STRIDE Security Analysis</title>
    
<style>
    * {{
        margin: 0;
        padding: 0;
        box-sizing: border-box;
    }}
    
    body {{
        font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
        line-height: 1.6;
        color: #333;
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        min-height: 100vh;
    }}
    
    .container {{
        max-width: 1200px;
        margin: 0 auto;
        padding: 20px;
        background: white;
        box-shadow: 0 0 20px rgba(0,0,0,0.1);
        border-radius: 10px;
        margin-top: 20px;
        margin-bottom: 20px;
    }}
    
    .header {{
        text-align: center;
        padding: 30px 0;
        background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%);
        color: white;
        border-radius: 10px;
        margin-bottom: 30px;
    }}
    
    .header h1 {{
        font-size: 2.5em;
        margin-bottom: 10px;
        text-shadow: 2px 2px 4px rgba(0,0,0,0.3);
    }}
    
    .header .subtitle {{
        font-size: 1.2em;
        opacity: 0.9;
    }}
    
    .section {{
        margin-bottom: 40px;
        padding: 25px;
        background: #f8f9fa;
        border-radius: 10px;
        border-left: 5px solid #007bff;
    }}
    
    .section h2 {{
        color: #2c3e50;
        margin-bottom: 20px;
        font-size: 1.8em;
        display: flex;
        align-items: center;
    }}
    
    .section h2::before {{
        content: "🔒";
        margin-right: 10px;
        font-size: 1.2em;
    }}
    
    .dashboard {{
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
        gap: 20px;
        margin-bottom: 30px;
    }}
    
    .metric-card {{
        background: white;
        padding: 25px;
        border-radius: 10px;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
        text-align: center;
        transition: transform 0.3s ease;
        border-top: 4px solid #007bff;
    }}
    
    .metric-card:hover {{
        transform: translateY(-5px);
    }}
    
    .metric-card h3 {{
        color: #6c757d;
        font-size: 0.9em;
        text-transform: uppercase;
        letter-spacing: 1px;
        margin-bottom: 10px;
    }}
    
    .metric-value {{
        font-size: 2.5em;
        font-weight: bold;
        color: #2c3e50;
        margin-bottom: 5px;
    }}
    
    .metric-description {{
        color: #6c757d;
        font-size: 0.9em;
    }}
    
    .stride-categories {{
        display: grid;
        grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
        gap: 20px;
    }}
    
    .stride-category {{
        background: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
        border-left: 5px solid #007bff;
    }}
    
    .stride-category h4 {{
        color: #2c3e50;
        margin-bottom: 15px;
        display: flex;
        justify-content: space-between;
        align-items: center;
    }}
    
    .threat-count {{
        background: #007bff;
        color: white;
        padding: 4px 12px;
        border-radius: 20px;
        font-size: 0.8em;
    }}
    
    .risk-score {{
        font-size: 1.5em;
        font-weight: bold;
        text-align: center;
        padding: 10px;
        border-radius: 5px;
        margin: 10px 0;
    }}
    
    .risk-score.critical, .risk-score-critical {{ background: #ffebee; color: #c62828; }}
    .risk-score.high, .risk-score-high {{ background: #fff3e0; color: #ef6c00; }}
    .risk-score.medium, .risk-score-medium {{ background: #fffde7; color: #f57f17; }}
    .risk-score.low, .risk-score-low {{ background: #e8f5e8; color: #2e7d32; }}
    
    .threats-table {{
        width: 100%;
        border-collapse: collapse;
        background: white;
        border-radius: 10px;
        overflow: hidden;
        box-shadow: 0 4px 6px rgba(0,0,0,0.1);
    }}
    
    .threats-table th {{
        background: #343a40;
        color: white;
        padding: 15px 10px;
        text-align: left;
        font-weight: 600;
    }}
    
    .threats-table td {{
        padding: 12px 10px;
        border-bottom: 1px solid #dee2e6;
    }}
    
    .threat-row:hover {{
        background: #f8f9fa;
    }}
    
    .threat-critical {{ color: #dc3545; font-weight: bold; }}
    .threat-high {{ color: #fd7e14; font-weight: bold; }}
    .threat-medium {{ color: #ffc107; font-weight: bold; }}
    .threat-low {{ color: #28a745; font-weight: bold; }}
    
    .badge-cloud {{
        display: inline-block;
        padding: 8px 16px;
        margin: 5px;
        border-radius: 20px;
        font-weight: bold;
        font-size: 0.9em;
        text-transform: uppercase;
    }}
    
    .badge-aws {{ background: #ff9900; color: white; }}
    .badge-azure {{ background: #0078d4; color: white; }}
    .badge-gcp {{ background: #4285f4; color: white; }}
    .badge-other {{ background: #6c757d; color: white; }}
    
    .badge-count {{
        background: rgba(255,255,255,0.3);
        padding: 2px 8px;
        border-radius: 10px;
        margin-left: 8px;
    }}
    
    .chart-container {{
        width: 100%;
        height: 300px;
        margin: 20px 0;
        background: white;
        border-radius: 10px;
        padding: 20px;
        box-shadow: 0 2px 10px rgba(0,0,0,0.1);
    }}
    
    .footer {{
        text-align: center;
        padding: 20px;
        margin-top: 40px;
        border-top: 1px solid #dee2e6;
        color: #6c757d;
    }}
    
    @media (max-width: 768px) {{
        .container {{
            margin: 10px;
            padding: 15px;
        }}
        
        .dashboard, .stride-categories {{
            grid-template-columns: 1fr;
        }}
        
        .threats-table {{
            font-size: 0.9em;
        }}
    }}
</style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔒 Archer - AI STRIDE Security Analysis</h1>
            <p class="subtitle">Análise de Segurança Arquitetural - {analysis_result.get('timestamp', datetime.now().strftime('%d/%m/%Y %H:%M'))}</p>
            <p style="font-size: 0.9em; margin-top: 10px;">Imagem analisada: {analysis_result.get('image_info', {}).get('filename', 'N/A')}</p>
            <div style="margin-top: 15px;">
                {cloud_badges_html}
            </div>
        </div>
        
        <div class="section">
            <h2>📊 Dashboard Executivo</h2>
            <div class="dashboard">
                {metric_cards_html}
            </div>
        </div>
        
        <div class="section">
            <h2>⚡ Análise STRIDE por Categoria</h2>
            <div class="stride-categories">
                {stride_cards_html}
            </div>
        </div>
        
        <div class="section">
            <h2>📈 Distribuição de Ameaças</h2>
            <div class="dashboard">
                <div class="metric-card critical">
                    <h3>Críticas</h3>
                    <div class="metric-value">{severity_count['critical']}</div>
                    <div class="metric-description">{severity_percent['critical']}% do total</div>
                </div>
                <div class="metric-card high">
                    <h3>Altas</h3>
                    <div class="metric-value">{severity_count['high']}</div>
                    <div class="metric-description">{severity_percent['high']}% do total</div>
                </div>
                <div class="metric-card medium">
                    <h3>Médias</h3>
                    <div class="metric-value">{severity_count['medium']}</div>
                    <div class="metric-description">{severity_percent['medium']}% do total</div>
                </div>
                <div class="metric-card low">
                    <h3>Baixas</h3>
                    <div class="metric-value">{severity_count['low']}</div>
                    <div class="metric-description">{severity_percent['low']}% do total</div>
                </div>
            </div>
            
            <div class="chart-container">
                <canvas id="threatChart"></canvas>
            </div>
        </div>
        
        <div class="section">
            <h2>🗃️ Componentes Detectados</h2>
            <div style="display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 15px;">
    '''
    
    # Componentes dinâmicos
    for component in components:
        provider_icon = {"aws": "🟧", "azure": "🔵", "gcp": "🟩", "on-premises": "🏢", "generic": "⚪"}.get(component.get('provider', 'generic'), "⚪")
        html_content += f'''
                <div style="background: white; padding: 15px; border-radius: 8px; border-left: 4px solid #28a745;">
                    <h4>{provider_icon} {component.get('name', 'Unknown')}</h4>
                    <p><strong>Tipo:</strong> {component.get('type', 'Unknown')}</p>
                    <p><strong>Provedor:</strong> {component.get('provider', 'Unknown')}</p>
                    <p><strong>Confiança:</strong> {component.get('confidence', 0):.0%}</p>
                    <p><strong>Método:</strong> {component.get('detection_method', 'unknown')}</p>
                </div>
        '''
    
    html_content += f'''
            </div>
        </div>
        
        <div class="section">
            <h2>🔍 Tabela Detalhada de Ameaças</h2>
            <table class="threats-table">
                <thead>
                    <tr>
                        <th>Tipo STRIDE</th>
                        <th>Componente</th>
                        <th>Severidade</th>
                        <th>Risk Score</th>
                        <th>Descrição</th>
                        <th>Referências & Links</th>
                    </tr>
                </thead>
                <tbody>
                    {threats_table_html}
                </tbody>
            </table>
        </div>
        
        <div class="footer">
            <p><strong>Archer - AI STRIDE Security Analysis Enhanced</strong> | Gerado automaticamente em {datetime.now().strftime('%d/%m/%Y às %H:%M:%S')}</p>
            <p>Análise ID: {analysis_result.get('analysis_id', 'N/A')} | Componentes detectados: {len(components)} | Tempo de análise: {analysis_result.get('analysis_time', 0):.2f}s</p>
            <p>🎯 Análise Visual | 🧠 Multi-Modal Detection | 📊 Template Dinâmico com Links</p>
        </div>
    </div>
    
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        // Gráfico com dados DINÂMICOS
        const ctx = document.getElementById('threatChart').getContext('2d');
        const threatChart = new Chart(ctx, {{
            type: 'doughnut',
            data: {{
                labels: ['Críticas', 'Altas', 'Médias', 'Baixas'],
                datasets: [{{
                    data: [{severity_count['critical']}, {severity_count['high']}, {severity_count['medium']}, {severity_count['low']}],
                    backgroundColor: ['#dc3545', '#fd7e14', '#ffc107', '#28a745'],
                    borderWidth: 2,
                    borderColor: '#fff'
                }}]
            }},
            options: {{
                responsive: true,
                maintainAspectRatio: false,
                plugins: {{
                    legend: {{
                        position: 'bottom',
                        labels: {{
                            padding: 20,
                            usePointStyle: true
                        }}
                    }},
                    title: {{
                        display: true,
                        text: 'Distribuição de Ameaças por Severidade',
                        font: {{
                            size: 16,
                            weight: 'bold'
                        }}
                    }}
                }}
            }}
        }});
    </script>
</body>
</html>'''
    
    return html_content

# Adicione este novo método logo após o método generate_enhanced_html_report existente

def generate_enhanced_html_report2(analysis_result: Dict) -> str:
    """
    Gera relatório HTML no estilo AWS Threat Composer Dashboard
    Baseado no padrão visual do anexo PDF
    """
    
    # Extrair dados da análise
    threats = analysis_result.get('threats', [])
    components = analysis_result.get('detected_components', [])
    stride_analysis = analysis_result.get('stride_analysis', {})
    
    # Calcular métricas do dashboard
    total_threats = len(threats)
    
    # Contar por severidade
    severity_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
    for threat in threats:
        severity = threat.get('severity', 'medium')
        if severity in severity_counts:
            severity_counts[severity] += 1
    
    # Calcular mitigações (assumindo 2-3 mitigações por ameaça para simulação)
    total_mitigations = total_threats * 2 + len(components)
    
    # Calcular progresso
    threats_addressed = 0  # Começando em 0 como no dashboard
    mitigations_implemented = 0
    
    # HTML no estilo AWS Threat Composer
    html_content = f'''<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Threat Composer Dashboard - STRIDE Analysis</title>
    
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: 'Amazon Ember', 'Helvetica Neue', Roboto, Arial, sans-serif;
            background-color: #232f3e;
            color: #232f3e;
            line-height: 1.5;
        }}
        
        /* Header estilo AWS */
        .aws-header {{
            background: #232f3e;
            color: white;
            padding: 12px 20px;
            display: flex;
            align-items: center;
            border-bottom: 1px solid #37475a;
        }}
        
        .aws-header h1 {{
            font-size: 18px;
            font-weight: 400;
            margin-left: 10px;
        }}
        
        .workspace-selector {{
            background: #37475a;
            border: 1px solid #545b64;
            color: white;
            padding: 6px 12px;
            border-radius: 4px;
            margin-right: 20px;
            cursor: pointer;
        }}
        
        /* Alertas estilo AWS */
        .alert-banner {{
            padding: 12px 20px;
            display: flex;
            align-items: center;
            gap: 10px;
            border-left: 4px solid;
            margin: 0;
            font-size: 14px;
        }}
        
        .alert-success {{
            background: #d4f4dd;
            border-left-color: #067d68;
            color: #067d68;
        }}
        
        .alert-info {{
            background: #e1f5fe;
            border-left-color: #0972d3;
            color: #0972d3;
        }}
        
        .close-alert {{
            margin-left: auto;
            cursor: pointer;
            color: inherit;
            font-size: 20px;
            background: none;
            border: none;
        }}
        
        /* Container principal */
        .main-container {{
            background: #fafafa;
            min-height: calc(100vh - 60px);
            padding: 20px;
        }}
        
        /* Card de threat summary */
        .threat-summary-card {{
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.12);
            padding: 20px;
            margin-bottom: 20px;
        }}
        
        .card-header {{
            display: flex;
            align-items: center;
            gap: 8px;
            margin-bottom: 20px;
            font-size: 18px;
            font-weight: 600;
            color: #232f3e;
        }}
        
        /* Grid de métricas */
        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(140px, 1fr));
            gap: 1px;
            background: #e1e4e8;
            border: 1px solid #e1e4e8;
            border-radius: 4px;
            overflow: hidden;
        }}
        
        .metric-box {{
            background: white;
            padding: 16px;
            text-align: center;
        }}
        
        .metric-label {{
            font-size: 12px;
            color: #545b64;
            margin-bottom: 8px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        
        .metric-value {{
            font-size: 36px;
            font-weight: 300;
            color: #16191f;
            line-height: 1;
        }}
        
        .metric-value.blue {{
            color: #0972d3;
        }}
        
        /* Progress section */
        .progress-section {{
            display: grid;
            grid-template-columns: 1fr 1fr;
            gap: 1px;
            background: #e1e4e8;
            border: 1px solid #e1e4e8;
            border-radius: 4px;
            margin-top: 20px;
            overflow: hidden;
        }}
        
        .progress-box {{
            background: white;
            padding: 16px;
        }}
        
        .progress-label {{
            font-size: 14px;
            color: #545b64;
            margin-bottom: 12px;
            font-weight: 600;
        }}
        
        .progress-value {{
            font-size: 32px;
            color: #0972d3;
            font-weight: 300;
        }}
        
        /* Badges de prioridade */
        .priority-badge {{
            display: inline-block;
            padding: 2px 8px;
            border-radius: 3px;
            font-size: 11px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
            margin-bottom: 8px;
        }}
        
        .priority-high {{
            background: #d13212;
            color: white;
        }}
        
        .priority-med {{
            background: #0972d3;
            color: white;
        }}
        
        .priority-low {{
            background: #037f0c;
            color: white;
        }}
        
        /* Tabela de detalhes */
        .details-section {{
            background: white;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.12);
            padding: 20px;
            margin-top: 20px;
        }}
        
        .data-table {{
            width: 100%;
            border-collapse: collapse;
            margin-top: 16px;
        }}
        
        .data-table th {{
            background: #fafafa;
            border-bottom: 2px solid #e1e4e8;
            padding: 12px;
            text-align: left;
            font-weight: 600;
            font-size: 12px;
            text-transform: uppercase;
            color: #545b64;
            letter-spacing: 0.5px;
        }}
        
        .data-table td {{
            padding: 12px;
            border-bottom: 1px solid #e1e4e8;
            font-size: 14px;
            color: #16191f;
        }}
        
        .data-table tr:hover {{
            background: #f5f7fa;
        }}
        
        /* Footer */
        .dashboard-footer {{
            text-align: center;
            padding: 20px;
            color: #545b64;
            font-size: 12px;
            background: white;
            margin-top: 20px;
            border-radius: 8px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.12);
        }}
        
        /* Responsive */
        @media (max-width: 768px) {{
            .metrics-grid {{
                grid-template-columns: repeat(2, 1fr);
            }}
            
            .progress-section {{
                grid-template-columns: 1fr;
            }}
        }}
    </style>
</head>
<body>
    <!-- Header AWS Style -->
    <div class="aws-header">
        <select class="workspace-selector">
            <option>Workspace: {analysis_result.get('image_info', {}).get('filename', 'STRIDE Analysis')}</option>
        </select>
        <h1>Insights dashboard | {analysis_result.get('image_info', {}).get('filename', 'Architecture Security Analysis')}</h1>
    </div>
    
    <!-- Alert Banners -->
    <div class="alert-banner alert-success">
        <span>✓</span>
        <span>You can now create, view and edit Threat Composer files directly within Visual Studio Code using the AWS Toolkit extension.</span>
        <button class="close-alert">×</button>
    </div>
    
    <div class="alert-banner alert-info">
        <span>ⓘ</span>
        <span>This analysis was generated on {datetime.now().strftime('%Y-%m-%d %H:%M')}. Risk Score: {analysis_result.get('risk_score', 0)}/10</span>
        <button class="close-alert">×</button>
    </div>
    
    <!-- Main Container -->
    <div class="main-container">
        
        <!-- Threat Summary Card -->
        <div class="threat-summary-card">
            <div class="card-header">
                <span>::</span>
                <span>Threat summary</span>
            </div>
            
            <!-- Metrics Grid -->
            <div class="metrics-grid">
                <div class="metric-box">
                    <div class="metric-label">Total</div>
                    <div class="metric-value blue">{total_threats}</div>
                </div>
                
                <div class="metric-box">
                    <div class="metric-label">No mitigation<br>and assumption</div>
                    <div class="metric-value blue">0</div>
                </div>
                
                <div class="metric-box">
                    <div class="metric-label">No mitigation</div>
                    <div class="metric-value blue">0</div>
                </div>
                
                <div class="metric-box">
                    <div class="metric-label">
                        <span class="priority-badge priority-high">High</span>
                    </div>
                    <div class="metric-value blue">{severity_counts['high'] + severity_counts['critical']}</div>
                </div>
                
                <div class="metric-box">
                    <div class="metric-label">
                        <span class="priority-badge priority-med">Med</span>
                    </div>
                    <div class="metric-value blue">{severity_counts['medium']}</div>
                </div>
                
                <div class="metric-box">
                    <div class="metric-label">
                        <span class="priority-badge priority-low">Low</span>
                    </div>
                    <div class="metric-value blue">{severity_counts['low']}</div>
                </div>
                
                <div class="metric-box">
                    <div class="metric-label">Missing<br>priority</div>
                    <div class="metric-value blue">0</div>
                </div>
            </div>
            
            <!-- Progress Section -->
            <div class="progress-section">
                <div class="progress-box">
                    <div class="progress-label">Threat progress</div>
                    <div class="progress-value">{threats_addressed}/{total_threats}</div>
                </div>
                
                <div class="progress-box">
                    <div class="progress-label">Mitigation progress</div>
                    <div class="progress-value">{mitigations_implemented}/{total_mitigations}</div>
                </div>
            </div>
        </div>
        
        <!-- Threat Details -->
        <div class="details-section">
            <div class="card-header">
                <span>::</span>
                <span>Threat Details by STRIDE Category</span>
            </div>
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Category</th>
                        <th>Count</th>
                        <th>Avg Risk</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
    '''
    
    # Adicionar categorias STRIDE
    for category, data in stride_analysis.items():
        if data.get('count', 0) > 0:
            avg_risk = data.get('avg_risk', 0)
            status_badge = 'priority-high' if avg_risk >= 7 else 'priority-med' if avg_risk >= 4 else 'priority-low'
            status_text = 'HIGH' if avg_risk >= 7 else 'MEDIUM' if avg_risk >= 4 else 'LOW'
            
            html_content += f'''
                    <tr>
                        <td>{category.replace('_', ' ').title()}</td>
                        <td>{data['count']}</td>
                        <td>{avg_risk}/10</td>
                        <td><span class="priority-badge {status_badge}">{status_text}</span></td>
                    </tr>
            '''
    
    html_content += '''
                </tbody>
            </table>
        </div>
        
        <!-- Component Summary -->
        <div class="details-section">
            <div class="card-header">
                <span>::</span>
                <span>Component Analysis Summary</span>
            </div>
            
            <table class="data-table">
                <thead>
                    <tr>
                        <th>Component</th>
                        <th>Type</th>
                        <th>Provider</th>
                        <th>Confidence</th>
                        <th>Detection Method</th>
                    </tr>
                </thead>
                <tbody>
    '''
    
    # Adicionar componentes
    for comp in components[:10]:  # Limitar a 10 componentes
        confidence_percent = f"{comp.get('confidence', 0):.0%}"
        html_content += f'''
                    <tr>
                        <td>{comp.get('name', 'Unknown')}</td>
                        <td>{comp.get('type', 'unknown')}</td>
                        <td>{comp.get('provider', 'generic').upper()}</td>
                        <td>{confidence_percent}</td>
                        <td>{comp.get('detection_method', 'unknown')}</td>
                    </tr>
        '''
    
    html_content += f'''
                </tbody>
            </table>
        </div>
        
        <!-- Footer -->
        <div class="dashboard-footer">
            <p><strong>Archer AI - STRIDE Security Analysis</strong></p>
            <p>AWS Threat Composer Style Dashboard | Generated: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}</p>
            <p>Analysis ID: {analysis_result.get('analysis_id', 'N/A')} | Components: {len(components)} | Analysis Time: {analysis_result.get('analysis_time', 0):.2f}s</p>
        </div>
    </div>
</body>
</html>'''
    
    return html_content

def generate_enhanced_html_report3(analysis_result: Dict) -> str:
    """
    Gera relatório HTML com matriz de Attack Feasibility (Risk Matrix)
    Correlaciona com dados da análise e knowledge base
    """
    
    # Extrair dados da análise
    threats = analysis_result.get('threats', [])
    components = analysis_result.get('detected_components', [])
    stride_analysis = analysis_result.get('stride_analysis', {})
    
    # Obter instância do RAG para buscar controles
    stride_rag = get_stride_rag()
    
    # Classificar ameaças por impacto e probabilidade
    threat_matrix = {
        'critical': {'count': 0, 'threats': []},
        'high': {'count': 0, 'threats': []},
        'medium': {'count': 0, 'threats': []},
        'low': {'count': 0, 'threats': []},
        'none': {'count': 0, 'threats': []}
    }
    
    for threat in threats:
        severity = threat.get('severity', 'medium')
        risk_score = threat.get('risk_score', 5.0)
        
        # Mapear para células da matriz
        if risk_score >= 8.5:
            cell = 'critical'
        elif risk_score >= 7.0:
            cell = 'high'
        elif risk_score >= 5.0:
            cell = 'medium'
        elif risk_score >= 3.0:
            cell = 'low'
        else:
            cell = 'none'
        
        threat_matrix[cell]['count'] += 1
        threat_matrix[cell]['threats'].append(threat)
    
    # Buscar controles relevantes via RAG se disponível
    compliance_controls = {}
    if stride_rag.embeddings_ready:
        for category in ['Spoofing', 'Tampering', 'Information Disclosure']:
            relevant_chunks = stride_rag.vector_rag.semantic_search(f"controls for {category}", top_k=2)
            if relevant_chunks:
                compliance_controls[category] = relevant_chunks[0]
    
    # HTML da matriz de risco
    html_content = f'''<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attack Feasibility Matrix - STRIDE Analysis</title>
    
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
            background: #f5f7fa;
            color: #2c3e50;
            padding: 20px;
            line-height: 1.6;
        }}
        
        .header {{
            background: white;
            padding: 25px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }}
        
        .header h1 {{
            font-size: 24px;
            color: #2c3e50;
            margin-bottom: 10px;
        }}
        
        .header p {{
            color: #7f8c8d;
            font-size: 14px;
        }}
        
        .matrix-container {{
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }}
        
        .matrix-title {{
            font-size: 18px;
            font-weight: 600;
            margin-bottom: 20px;
            color: #2c3e50;
        }}
        
        .risk-matrix {{
            display: grid;
            grid-template-columns: 100px repeat(5, 1fr);
            grid-template-rows: auto repeat(5, 80px);
            gap: 2px;
            background: #e0e0e0;
            border: 2px solid #bdbdbd;
            border-radius: 8px;
            overflow: hidden;
        }}
        
        .matrix-cell {{
            background: white;
            display: flex;
            flex-direction: column;
            align-items: center;
            justify-content: center;
            padding: 10px;
            font-size: 13px;
            font-weight: 500;
            position: relative;
            cursor: pointer;
            transition: all 0.3s ease;
        }}
        
        .matrix-cell:hover {{
            transform: scale(1.05);
            z-index: 10;
            box-shadow: 0 4px 12px rgba(0,0,0,0.2);
        }}
        
        .axis-label {{
            background: #f8f9fa;
            font-weight: 600;
            font-size: 12px;
            color: #495057;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        
        .axis-value {{
            background: #f1f3f5;
            font-size: 12px;
            color: #495057;
        }}
        
        /* Risk colors matching the original image */
        .cell-none {{ background: #e8f5e9; color: #2e7d32; }}
        .cell-low {{ background: #fff9c4; color: #f57f17; }}
        .cell-medium {{ background: #ffecb3; color: #ef6c00; }}
        .cell-high {{ background: #ffe0b2; color: #e65100; }}
        .cell-critical {{ background: #ffcdd2; color: #c62828; }}
        
        .cell-value {{
            font-size: 24px;
            font-weight: bold;
            margin-bottom: 5px;
        }}
        
        .cell-label {{
            font-size: 10px;
            text-transform: uppercase;
            opacity: 0.8;
        }}
        
        /* Legend */
        .legend {{
            display: flex;
            gap: 20px;
            margin-top: 20px;
            padding: 15px;
            background: #f8f9fa;
            border-radius: 8px;
        }}
        
        .legend-item {{
            display: flex;
            align-items: center;
            gap: 8px;
        }}
        
        .legend-color {{
            width: 24px;
            height: 24px;
            border-radius: 4px;
            border: 1px solid #dee2e6;
        }}
        
        /* Details section */
        .details-container {{
            background: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }}
        
        .threat-list {{
            margin-top: 20px;
        }}
        
        .threat-item {{
            padding: 12px;
            margin-bottom: 10px;
            border-left: 4px solid;
            background: #f8f9fa;
            border-radius: 4px;
        }}
        
        .threat-critical {{ border-left-color: #c62828; }}
        .threat-high {{ border-left-color: #e65100; }}
        .threat-medium {{ border-left-color: #ef6c00; }}
        .threat-low {{ border-left-color: #f57f17; }}
        
        /* Compliance controls */
        .controls-section {{
            background: #e3f2fd;
            padding: 20px;
            border-radius: 8px;
            margin-top: 20px;
        }}
        
        .control-item {{
            background: white;
            padding: 15px;
            margin-bottom: 10px;
            border-radius: 4px;
            border-left: 3px solid #1976d2;
        }}
        
        .control-framework {{
            font-weight: 600;
            color: #1976d2;
            font-size: 12px;
            text-transform: uppercase;
        }}
        
        .control-name {{
            font-size: 14px;
            color: #424242;
            margin-top: 5px;
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🎯 Attack Feasibility Matrix - Risk Assessment</h1>
        <p>Analysis: {analysis_result.get('image_info', {}).get('filename', 'N/A')} | 
           Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')} | 
           Total Threats: {len(threats)}</p>
    </div>
    
    <div class="matrix-container">
        <div class="matrix-title">Risk Matrix - Impact vs Likelihood</div>
        
        <div class="risk-matrix">
            <!-- Headers -->
            <div class="matrix-cell axis-label">Impact →<br>Likelihood ↓</div>
            <div class="matrix-cell axis-value">None<br>(1)</div>
            <div class="matrix-cell axis-value">Low<br>(2)</div>
            <div class="matrix-cell axis-value">Medium<br>(3)</div>
            <div class="matrix-cell axis-value">High<br>(4)</div>
            <div class="matrix-cell axis-value">Critical<br>(5)</div>
            
            <!-- Row: None -->
            <div class="matrix-cell axis-value">None<br>(1)</div>
            <div class="matrix-cell cell-none" data-risk="1,1">
                <div class="cell-value">cell(1,1)</div>
                <div class="cell-label">Low risk<br>1</div>
            </div>
            <div class="matrix-cell cell-none" data-risk="1,2">
                <div class="cell-value">cell(1,2)</div>
                <div class="cell-label">Low risk<br>1</div>
            </div>
            <div class="matrix-cell cell-none" data-risk="1,3">
                <div class="cell-value">cell(1,3)</div>
                <div class="cell-label">Low risk<br>1</div>
            </div>
            <div class="matrix-cell cell-low" data-risk="1,4">
                <div class="cell-value">cell(1,4)</div>
                <div class="cell-label">Medium risk<br>3</div>
            </div>
            <div class="matrix-cell cell-low" data-risk="1,5">
                <div class="cell-value">cell(1,5)</div>
                <div class="cell-label">Medium risk<br>3</div>
            </div>
            
            <!-- Row: Low -->
            <div class="matrix-cell axis-value">Low<br>(2)</div>
            <div class="matrix-cell cell-none" data-risk="2,1">
                <div class="cell-value">cell(2,1)</div>
                <div class="cell-label">Low risk<br>2</div>
            </div>
            <div class="matrix-cell cell-none" data-risk="2,2">
                <div class="cell-value">cell(2,2)</div>
                <div class="cell-label">Low risk<br>4</div>
            </div>
            <div class="matrix-cell cell-none" data-risk="2,3">
                <div class="cell-value">cell(2,3)</div>
                <div class="cell-label">Low risk<br>6</div>
            </div>
            <div class="matrix-cell cell-low" data-risk="2,4">
                <div class="cell-value">cell(2,4)</div>
                <div class="cell-label">Medium risk<br>8</div>
            </div>
            <div class="matrix-cell cell-medium" data-risk="2,5">
                <div class="cell-value">cell(2,5)</div>
                <div class="cell-label">Medium risk<br>10</div>
            </div>
            
            <!-- Row: Medium -->
            <div class="matrix-cell axis-value">Medium<br>(3)</div>
            <div class="matrix-cell cell-none" data-risk="3,1">
                <div class="cell-value">cell(3,1)</div>
                <div class="cell-label">Low risk<br>3</div>
            </div>
            <div class="matrix-cell cell-low" data-risk="3,2">
                <div class="cell-value">cell(3,2)</div>
                <div class="cell-label">Medium risk<br>6</div>
            </div>
            <div class="matrix-cell cell-low" data-risk="3,3">
                <div class="cell-value">cell(3,3)</div>
                <div class="cell-label">Medium risk<br>9</div>
            </div>
            <div class="matrix-cell cell-medium" data-risk="3,4">
                <div class="cell-value">cell(3,4)</div>
                <div class="cell-label">High risk<br>12</div>
            </div>
            <div class="matrix-cell cell-high" data-risk="3,5">
                <div class="cell-value">cell(3,5)</div>
                <div class="cell-label">High risk<br>15</div>
            </div>
            
            <!-- Row: High -->
            <div class="matrix-cell axis-value">High<br>(4)</div>
            <div class="matrix-cell cell-low" data-risk="4,1">
                <div class="cell-value">cell(4,1)</div>
                <div class="cell-label">Medium risk<br>4</div>
            </div>
            <div class="matrix-cell cell-medium" data-risk="4,2">
                <div class="cell-value">cell(4,2)</div>
                <div class="cell-label">Medium risk<br>8</div>
            </div>
            <div class="matrix-cell cell-medium" data-risk="4,3">
                <div class="cell-value">cell(4,3)</div>
                <div class="cell-label">High risk<br>12</div>
            </div>
            <div class="matrix-cell cell-high" data-risk="4,4">
                <div class="cell-value">cell(4,4)</div>
                <div class="cell-label">High risk<br>16</div>
            </div>
            <div class="matrix-cell cell-critical" data-risk="4,5">
                <div class="cell-value">cell(4,5)</div>
                <div class="cell-label">Extreme risk<br>20</div>
            </div>
            
            <!-- Row: Critical -->
            <div class="matrix-cell axis-value">Critical<br>(5)</div>
            <div class="matrix-cell cell-medium" data-risk="5,1">
                <div class="cell-value">cell(5,1)</div>
                <div class="cell-label">Medium risk<br>5</div>
            </div>
            <div class="matrix-cell cell-high" data-risk="5,2">
                <div class="cell-value">cell(5,2)</div>
                <div class="cell-label">High risk<br>10</div>
            </div>
            <div class="matrix-cell cell-high" data-risk="5,3">
                <div class="cell-value">cell(5,3)</div>
                <div class="cell-label">High risk<br>15</div>
            </div>
            <div class="matrix-cell cell-critical" data-risk="5,4">
                <div class="cell-value">cell(5,4)</div>
                <div class="cell-label">Extreme risk<br>20</div>
            </div>
            <div class="matrix-cell cell-critical" data-risk="5,5">
                <div class="cell-value">cell(5,5)</div>
                <div class="cell-label">Extreme risk<br>25</div>
            </div>
        </div>
        
        <div class="legend">
            <div class="legend-item">
                <div class="legend-color cell-none"></div>
                <span>None ({threat_matrix['none']['count']} threats)</span>
            </div>
            <div class="legend-item">
                <div class="legend-color cell-low"></div>
                <span>Low ({threat_matrix['low']['count']} threats)</span>
            </div>
            <div class="legend-item">
                <div class="legend-color cell-medium"></div>
                <span>Medium ({threat_matrix['medium']['count']} threats)</span>
            </div>
            <div class="legend-item">
                <div class="legend-color cell-high"></div>
                <span>High ({threat_matrix['high']['count']} threats)</span>
            </div>
            <div class="legend-item">
                <div class="legend-color cell-critical"></div>
                <span>Critical ({threat_matrix['critical']['count']} threats)</span>
            </div>
        </div>
    </div>
    
    <div class="details-container">
        <div class="matrix-title">Threats by Risk Level</div>
        
        <div class="threat-list">
    '''
    
    # Adicionar ameaças por nível
    for level in ['critical', 'high', 'medium', 'low']:
        if threat_matrix[level]['count'] > 0:
            html_content += f'<h4>{level.title()} Risk Threats ({threat_matrix[level]["count"]})</h4>'
            for threat in threat_matrix[level]['threats'][:5]:  # Top 5 por nível
                html_content += f'''
            <div class="threat-item threat-{level}">
                <strong>{threat.get('category', 'Unknown')}</strong> - {threat.get('component', 'Unknown')}<br>
                <small>{threat.get('description', 'N/A')}</small><br>
                <small>Risk Score: {threat.get('risk_score', 0)}/10</small>
            </div>
                '''
    
    # Adicionar controles de compliance se disponível
    if compliance_controls:
        html_content += '''
        </div>
        
        <div class="controls-section">
            <h3>📚 Relevant Compliance Controls (from Knowledge Base)</h3>
        '''
        for category, control in compliance_controls.items():
            html_content += f'''
            <div class="control-item">
                <div class="control-framework">{control.get('framework', 'Unknown').upper()}</div>
                <div class="control-name">{control.get('control', 'Unknown')}</div>
                <small>Similarity: {control.get('similarity_score', 0):.2%}</small>
            </div>
            '''
        html_content += '</div>'
    
    html_content += '''
        </div>
    </div>
    
    <script>
        // Atualizar células com contagem real de ameaças
        document.querySelectorAll('.matrix-cell[data-risk]').forEach(cell => {
            const value = cell.querySelector('.cell-value');
            if (value) {
                const risk = cell.dataset.risk;
                // Aqui você pode mapear as ameaças reais para cada célula
                value.textContent = '0'; // Default
            }
        });
    </script>
</body>
</html>'''
    
    return html_content


def generate_enhanced_html_report4(analysis_result: Dict) -> str:
    """
    Gera relatório HTML com Threat Matrix (Threats vs Assets)
    Correlaciona ameaças STRIDE com tipos de componentes/assets
    """
    
    # Extrair dados da análise
    threats = analysis_result.get('threats', [])
    components = analysis_result.get('detected_components', [])
    stride_analysis = analysis_result.get('stride_analysis', {})
    
    # Obter instância do RAG
    stride_rag = get_stride_rag()
    
    # Mapear componentes para categorias de assets
    asset_categories = {
        'Users': [],
        'Intellectual Data': [],
        'Workstations': [],
        'Servers': [],
        'Security Devices': [],
        'Facilities': []
    }
    
    # Classificar componentes detectados
    for comp in components:
        comp_type = comp.get('type', 'unknown')
        comp_name = comp.get('name', 'Unknown')
        
        if 'user' in comp_name.lower() or 'auth' in comp_name.lower():
            asset_categories['Users'].append(comp)
        elif 'data' in comp_name.lower() or 'storage' in comp_type:
            asset_categories['Intellectual Data'].append(comp)
        elif 'workstation' in comp_name.lower() or 'client' in comp_name.lower():
            asset_categories['Workstations'].append(comp)
        elif 'server' in comp_name.lower() or 'compute' in comp_type:
            asset_categories['Servers'].append(comp)
        elif 'security' in comp_name.lower() or 'firewall' in comp_name.lower():
            asset_categories['Security Devices'].append(comp)
        else:
            asset_categories['Facilities'].append(comp)
    
    # Mapear ameaças para eventos
    threat_events = {
        'Social engineering': {'threats': [], 'assets': {}},
        'Unauthorized access': {'threats': [], 'assets': {}},
        'Unauthorized use': {'threats': [], 'assets': {}},
        'Unauthorized disclosure': {'threats': [], 'assets': {}},
        'Disruption': {'threats': [], 'assets': {}},
        'Unauthorized modification': {'threats': [], 'assets': {}}
    }
    
    # Classificar ameaças por tipo de evento
    for threat in threats:
        category = threat.get('category', '')
        comp_type = threat.get('component_type', '')
        
        if category == 'Spoofing':
            threat_events['Social engineering']['threats'].append(threat)
        elif category == 'Elevation of Privilege':
            threat_events['Unauthorized access']['threats'].append(threat)
        elif category == 'Tampering':
            threat_events['Unauthorized modification']['threats'].append(threat)
        elif category == 'Information Disclosure':
            threat_events['Unauthorized disclosure']['threats'].append(threat)
        elif category == 'Denial of Service':
            threat_events['Disruption']['threats'].append(threat)
        elif category == 'Repudiation':
            threat_events['Unauthorized use']['threats'].append(threat)
    
    # Calcular níveis de risco por célula
    def calculate_risk_level(threat_count, asset_count):
        if threat_count == 0 or asset_count == 0:
            return 'N/A', '#e0e0e0'
        score = (threat_count * asset_count) / 2
        if score >= 3:
            return 'High', '#ff5252'
        elif score >= 1.5:
            return 'Moderate', '#ffa726'
        elif score > 0:
            return 'Low', '#66bb6a'
        return 'N/A', '#e0e0e0'
    
    # HTML da Threat Matrix
    html_content = f'''<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Threat Matrix - STRIDE vs Assets</title>
    
    <style>
        * {{
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }}
        
        body {{
            font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Arial, sans-serif;
            background: #f0f2f5;
            color: #1a1a1a;
            padding: 20px;
            line-height: 1.6;
        }}
        
        .header {{
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            color: white;
            padding: 30px;
            border-radius: 10px;
            margin-bottom: 30px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.15);
        }}
        
        .header h1 {{
            font-size: 28px;
            margin-bottom: 10px;
        }}
        
        .header p {{
            opacity: 0.95;
            font-size: 14px;
        }}
        
        .matrix-wrapper {{
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 2px 10px rgba(0,0,0,0.1);
            margin-bottom: 30px;
            overflow-x: auto;
        }}
        
        .section-title {{
            font-size: 20px;
            font-weight: 600;
            margin-bottom: 20px;
            color: #2c3e50;
            display: flex;
            align-items: center;
            gap: 10px;
        }}
        
        .threat-matrix-table {{
            width: 100%;
            border-collapse: collapse;
            border: 2px solid #34495e;
        }}
        
        .threat-matrix-table th,
        .threat-matrix-table td {{
            border: 1px solid #95a5a6;
            padding: 12px;
            text-align: center;
            font-size: 13px;
        }}
        
        .threat-matrix-table th {{
            background: #2c3e50;
            color: white;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }}
        
        .matrix-header-primary {{
            background: #27ae60 !important;
            font-size: 16px !important;
            padding: 15px !important;
        }}
        
        .matrix-header-secondary {{
            background: #66bb6a !important;
        }}
        
        .threat-event-label {{
            background: #ecf0f1;
            font-weight: 600;
            text-align: left !important;
            color: #2c3e50;
        }}
        
        .risk-cell {{
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            position: relative;
        }}
        
        .risk-cell:hover {{
            transform: scale(1.1);
            box-shadow: 0 4px 8px rgba(0,0,0,0.2);
            z-index: 10;
        }}
        
        .risk-high {{
            background: #ff5252 !important;
            color: white;
        }}
        
        .risk-moderate {{
            background: #ffa726 !important;
            color: #333;
        }}
        
        .risk-low {{
            background: #66bb6a !important;
            color: white;
        }}
        
        .risk-na {{
            background: #e0e0e0 !important;
            color: #757575;
        }}
        
        /* Statistics section */
        .stats-container {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
            gap: 20px;
            margin-bottom: 30px;
        }}
        
        .stat-card {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 8px rgba(0,0,0,0.1);
            text-align: center;
        }}
        
        .stat-value {{
            font-size: 32px;
            font-weight: bold;
            color: #667eea;
        }}
        
        .stat-label {{
            font-size: 14px;
            color: #7f8c8d;
            margin-top: 5px;
        }}
        
        /* Compliance section */
        .compliance-container {{
            background: #f8f9fa;
            padding: 25px;
            border-radius: 10px;
            margin-top: 30px;
        }}
        
        .compliance-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(300px, 1fr));
            gap: 15px;
            margin-top: 15px;
        }}
        
        .compliance-card {{
            background: white;
            padding: 15px;
            border-radius: 6px;
            border-left: 4px solid #667eea;
        }}
        
        .compliance-framework {{
            font-size: 12px;
            color: #667eea;
            font-weight: 600;
            text-transform: uppercase;
        }}
        
        .compliance-control {{
            font-size: 14px;
            color: #2c3e50;
            margin-top: 8px;
        }}
        
        /* Tooltip */
        .tooltip {{
            position: absolute;
            background: #333;
            color: white;
            padding: 8px;
            border-radius: 4px;
            font-size: 12px;
            display: none;
            z-index: 1000;
            white-space: nowrap;
        }}
        
        .risk-cell:hover .tooltip {{
            display: block;
            top: -30px;
            left: 50%;
            transform: translateX(-50%);
        }}
    </style>
</head>
<body>
    <div class="header">
        <h1>🔐 Threat Matrix Analysis - Threats vs Assets</h1>
        <p>Architecture: {analysis_result.get('image_info', {}).get('filename', 'N/A')} | 
           Generated: {datetime.now().strftime('%Y-%m-%d %H:%M')} | 
           Components: {len(components)} | Threats: {len(threats)}</p>
    </div>
    
    <div class="stats-container">
        <div class="stat-card">
            <div class="stat-value">{len(components)}</div>
            <div class="stat-label">Total Assets</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">{len(threats)}</div>
            <div class="stat-label">Total Threats</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">{sum(1 for cat in asset_categories.values() if cat)}</div>
            <div class="stat-label">Asset Categories</div>
        </div>
        <div class="stat-card">
            <div class="stat-value">{sum(1 for event in threat_events.values() if event['threats'])}</div>
            <div class="stat-label">Active Threat Events</div>
        </div>
    </div>
    
    <div class="matrix-wrapper">
        <h2 class="section-title">
            <span style="color: #27ae60;">THREAT</span>
            <span style="color: #2c3e50;">MATRIX</span>
            <span style="margin-left: auto; font-size: 14px; color: #7f8c8d;">
                STRIDE Events vs Asset Categories
            </span>
        </h2>
        
        <table class="threat-matrix-table">
            <thead>
                <tr>
                    <th colspan="2" rowspan="2" class="matrix-header-primary">THREAT<br>MATRIX</th>
                    <th colspan="6" class="matrix-header-secondary">ASSETS</th>
                </tr>
                <tr>
                    <th>Users</th>
                    <th>Intellectual<br>Data</th>
                    <th>Workstations</th>
                    <th>Servers</th>
                    <th>Security<br>Devices</th>
                    <th>Facilities</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td rowspan="6" class="matrix-header-secondary" style="writing-mode: vertical-lr; text-orientation: mixed;">
                        THREAT EVENT
                    </td>
                    <td class="threat-event-label">Social<br>engineering</td>
    '''
    
    # Preencher células da matriz
    for event_name, event_data in threat_events.items():
        if event_name != 'Social engineering':
            html_content += f'''
                <tr>
                    <td class="threat-event-label">{event_name.replace('Unauthorized ', 'Unauthorized<br>')}</td>
            '''
        
        for asset_name in ['Users', 'Intellectual Data', 'Workstations', 'Servers', 'Security Devices', 'Facilities']:
            # Calcular risco para esta célula
            threat_count = len(event_data['threats'])
            asset_count = len(asset_categories[asset_name])
            risk_level, risk_color = calculate_risk_level(threat_count, asset_count)
            
            # Determinar classe CSS
            if risk_level == 'High':
                risk_class = 'risk-high'
            elif risk_level == 'Moderate':
                risk_class = 'risk-moderate'
            elif risk_level == 'Low':
                risk_class = 'risk-low'
            else:
                risk_class = 'risk-na'
            
            html_content += f'''
                    <td class="risk-cell {risk_class}">
                        {risk_level}
                        <div class="tooltip">
                            Threats: {threat_count}<br>
                            Assets: {asset_count}
                        </div>
                    </td>
            '''
        
        html_content += '</tr>'
    
    html_content += '''
            </tbody>
        </table>
    </div>
    '''
    
    # Adicionar seção de controles de compliance se disponível
    if stride_rag.embeddings_ready:
        html_content += '''
    <div class="compliance-container">
        <h2 class="section-title">📚 Relevant Compliance Controls from Knowledge Base</h2>
        <div class="compliance-grid">
        '''
        
        # Buscar controles para principais categorias de ameaças
        for category in ['Spoofing', 'Tampering', 'Information Disclosure']:
            if stride_analysis.get(category, {}).get('count', 0) > 0:
                relevant_chunks = stride_rag.vector_rag.semantic_search(f"mitigation for {category}", top_k=1)
                if relevant_chunks:
                    control = relevant_chunks[0]
                    html_content += f'''
            <div class="compliance-card">
                <div class="compliance-framework">{control.get('framework', 'Unknown').upper()}</div>
                <div class="compliance-control">
                    <strong>{control.get('control', 'Unknown')}</strong><br>
                    <small>Relevance: {control.get('similarity_score', 0):.1%}</small>
                </div>
            </div>
                    '''
        
        html_content += '''
        </div>
    </div>
        '''
    
    html_content += '''
    <script>
        // Adicionar interatividade às células
        document.querySelectorAll('.risk-cell').forEach(cell => {
            cell.addEventListener('click', function() {
                alert(`Risk Level: ${this.textContent.trim()}\\n${this.querySelector('.tooltip').textContent}`);
            });
        });
    </script>
</body>
</html>'''
    
    return html_content

# SUBSTITUA A FUNÇÃO generate_pdf_from_html() POR ESTA VERSÃO:
def generate_pdf_from_html(html_content: str, css_for_pdf: bool = True) -> bytes:
    """
    Gera PDF a partir do HTML do relatório com múltiplas opções de bibliotecas
    Prioriza bibliotecas que funcionam bem no Windows
    
    Args:
        html_content: String HTML do relatório
        css_for_pdf: Se True, adiciona CSS otimizado para PDF
    
    Returns:
        Bytes do PDF gerado ou None se houver erro
    """
    
    # Opção 1: xhtml2pdf (funciona bem no Windows)
    if XHTML2PDF_AVAILABLE:
        try:
            # Criar buffer para o PDF
            pdf_buffer = io.BytesIO()
            
            # Converter HTML para PDF
            pisa_status = pisa.CreatePDF(
                html_content,
                dest=pdf_buffer,
                encoding='UTF-8'
            )
            
            # Verificar se conversão foi bem sucedida
            if not pisa_status.err:
                pdf_buffer.seek(0)
                return pdf_buffer.read()
            else:
                st.warning("Erro na conversão com xhtml2pdf, tentando outra biblioteca...")
                
        except Exception as e:
            st.warning(f"xhtml2pdf falhou: {str(e)[:100]}")
    
    # Opção 2: pdfkit (requer wkhtmltopdf mas funciona no Windows)
    if PDFKIT_AVAILABLE:
        try:
            import pdfkit
            
            # Configurações otimizadas para Windows
            config = None
            # Tentar detectar wkhtmltopdf no Windows
            import os
            possible_paths = [
                r'C:\Program Files\wkhtmltopdf\bin\wkhtmltopdf.exe',
                r'C:\Program Files (x86)\wkhtmltopdf\bin\wkhtmltopdf.exe',
                r'C:\wkhtmltopdf\bin\wkhtmltopdf.exe',
            ]
            
            for path in possible_paths:
                if os.path.exists(path):
                    config = pdfkit.configuration(wkhtmltopdf=path)
                    break
            
            options = {
                'page-size': 'A4',
                'margin-top': '0.75in',
                'margin-right': '0.75in',
                'margin-bottom': '0.75in',
                'margin-left': '0.75in',
                'encoding': "UTF-8",
                'enable-local-file-access': None,
                'enable-external-links': None,
                'enable-internal-links': None,
                'no-outline': None,
                'quiet': ''
            }
            
            pdf_bytes = pdfkit.from_string(
                html_content, 
                False, 
                options=options,
                configuration=config
            )
            return pdf_bytes
            
        except Exception as e:
            st.warning(f"pdfkit falhou: {str(e)[:100]}")
    
    # Opção 3: WeasyPrint (pode ter problemas no Windows)
    if WEASYPRINT_AVAILABLE:
        try:
            # CSS adicional para otimização do PDF
            pdf_css = """
            @page {
                size: A4;
                margin: 1cm;
            }
            
            a {
                color: #007bff !important;
                text-decoration: underline !important;
            }
            
            .section, .metric-card, .stride-category, .threat-row {
                page-break-inside: avoid;
            }
            
            body {
                font-size: 10pt;
            }
            """ if css_for_pdf else ""
            
            # Criar PDF com WeasyPrint
            pdf_bytes = HTML(string=html_content).write_pdf(
                stylesheets=[CSS(string=pdf_css)] if css_for_pdf else None
            )
            
            return pdf_bytes
            
        except Exception as e:
            st.warning(f"WeasyPrint falhou: {str(e)[:100]}")
    
    # Se nenhuma biblioteca funcionar, retornar None
    return None


# FUNÇÃO ALTERNATIVA: Gerar PDF básico com ReportLab (sempre funciona no Windows)
def generate_simple_pdf_report(analysis_result: Dict) -> bytes:
    """
    Gera um PDF simples mas funcional usando ReportLab
    Esta é uma alternativa que sempre funciona no Windows
    """
    if not REPORTLAB_AVAILABLE:
        return None
    
    try:
        # Criar buffer para o PDF
        pdf_buffer = io.BytesIO()
        
        # Criar documento
        doc = SimpleDocTemplate(
            pdf_buffer,
            pagesize=A4,
            rightMargin=72,
            leftMargin=72,
            topMargin=72,
            bottomMargin=18,
        )
        
        # Container para elementos
        elements = []
        
        # Estilos
        styles = getSampleStyleSheet()
        styles.add(ParagraphStyle(
            name='CustomTitle',
            parent=styles['Heading1'],
            fontSize=24,
            textColor=colors.HexColor('#2c3e50'),
            spaceAfter=30,
            alignment=TA_CENTER
        ))
        
        # Título
        elements.append(Paragraph("Archer - AI STRIDE Security Analysis Report", styles['CustomTitle']))
        elements.append(Spacer(1, 20))
        
        # Informações básicas
        info_style = ParagraphStyle(
            name='Info',
            parent=styles['Normal'],
            fontSize=10,
            leading=14
        )
        
        timestamp = analysis_result.get('timestamp', datetime.now().isoformat())
        filename = analysis_result.get('image_info', {}).get('filename', 'N/A')
        
        elements.append(Paragraph(f"<b>Data da Análise:</b> {timestamp}", info_style))
        elements.append(Paragraph(f"<b>Arquivo Analisado:</b> {filename}", info_style))
        elements.append(Spacer(1, 20))
        
        # Métricas principais
        elements.append(Paragraph("Resumo Executivo", styles['Heading2']))
        
        components = analysis_result.get('detected_components', [])
        threats = analysis_result.get('threats', [])
        risk_score = analysis_result.get('risk_score', 0)
        
        summary_data = [
            ['Métrica', 'Valor'],
            ['Componentes Detectados', str(len(components))],
            ['Ameaças Identificadas', str(len(threats))],
            ['Risk Score', f"{risk_score}/10"],
            ['Compliance Score', f"{analysis_result.get('compliance_score', 0)}/10"]
        ]
        
        summary_table = Table(summary_data, colWidths=[200, 200])
        summary_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 12),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
            ('GRID', (0, 0), (-1, -1), 1, colors.black)
        ]))
        
        elements.append(summary_table)
        elements.append(PageBreak())
        
        # Componentes detectados
        elements.append(Paragraph("Componentes Detectados", styles['Heading2']))
        elements.append(Spacer(1, 12))
        
        for comp in components[:10]:  # Limitar a 10 componentes
            comp_text = f"• <b>{comp.get('name', 'Unknown')}</b> - {comp.get('type', 'unknown')} ({comp.get('provider', 'generic')}) - Confiança: {comp.get('confidence', 0):.0%}"
            elements.append(Paragraph(comp_text, styles['Normal']))
        
        elements.append(PageBreak())
        
        # Ameaças principais
        elements.append(Paragraph("Principais Ameaças Identificadas", styles['Heading2']))
        elements.append(Spacer(1, 12))
        
        # Tabela de ameaças
        threat_data = [['Categoria', 'Componente', 'Severidade', 'Risk Score']]
        
        for threat in threats[:15]:  # Limitar a 15 ameaças
            threat_data.append([
                threat.get('category', 'Unknown'),
                threat.get('component', 'Unknown')[:30],  # Limitar tamanho
                threat.get('severity', 'medium'),
                str(threat.get('risk_score', 0))
            ])
        
        threat_table = Table(threat_data, colWidths=[120, 180, 80, 80])
        threat_table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
            ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), colors.white),
            ('GRID', (0, 0), (-1, -1), 1, colors.black),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
        ]))
        
        elements.append(threat_table)
        
        # Adicionar nota sobre links
        elements.append(Spacer(1, 30))
        note_style = ParagraphStyle(
            name='Note',
            parent=styles['Normal'],
            fontSize=9,
            textColor=colors.grey,
            alignment=TA_CENTER
        )
        elements.append(Paragraph(
            "Para versão completa com links clicáveis, use o relatório HTML",
            note_style
        ))
        
        # Construir PDF
        doc.build(elements)
        
        # Retornar bytes do PDF
        pdf_buffer.seek(0)
        return pdf_buffer.read()
        
    except Exception as e:
        st.error(f"Erro ao gerar PDF com ReportLab: {str(e)}")
        return None



# Funções das Abas Principais
def create_home_tab():
    """Aba principal com indicadores de AI Providers"""
    st.markdown("""
    <div class="main-header">
        <h1>🔐 Archer AI - STRIDE Security Analyzer Enhanced - Computer Vision</h1>
        <p>Sistema avançado com análise visual de imagens de arquitetura</p>
    </div>
    """, unsafe_allow_html=True)
    
    col1, col2, col3 = st.columns(3)
    
    with col1:
        st.markdown("""
        <div class="metric-card">
            <h3>🎯 Análise</h3>
            <div class="metric-value">100%</div>
            <div class="metric-description">Detecção visual</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col2:
        st.markdown("""
        <div class="metric-card">
            <h3>⚡ Multi-Modal</h3>
            <div class="metric-value">4</div>
            <div class="metric-description">Métodos de análise</div>
        </div>
        """, unsafe_allow_html=True)
    
    with col3:
        st.markdown("""
        <div class="metric-card">
            <h3>🧠 IA Vision</h3>
            <div class="metric-value">Smart</div>
            <div class="metric-description">OpenAI + OpenCV</div>
        </div>
        """, unsafe_allow_html=True)
    
    st.markdown("### 🚀 Funcionalidades de Análise")
    
    col1, col2 = st.columns(2)
    
    with col1:
        st.markdown("""
        **✅ Análise Visual Implementada:**
        - 🔍 **OpenCV**: Detecção de formas e contornos
        - 📝 **OCR**: Extração de texto para identificar tecnologias
        - 🎨 **Análise de Cores**: Identificação de cloud providers
        - 🤖 **OpenAI Vision**: Análise semântica avançada
        - 📊 **Detecção Dinâmica**: Componentes reais da imagem
        - ⚡ **Ameaças Proporcionais**: Baseadas nos componentes detectados
        """)
    
    with col2:
        st.markdown("""
        **🔧 Melhorias Técnicas:**
        - ❌ **Removido**: Hardcoding de 3 componentes sempre
        - ❌ **Removido**: 7 ameaças fixas independente da imagem
        - ✅ **Novo**: Detecção baseada no conteúdo visual
        - ✅ **Novo**: Análise multi-modal (4 métodos combinados)
        - ✅ **Novo**: Risk score ponderado por confiança
        - ✅ **Novo**: Interface mostra detalhes técnicos da detecção
        """)

    # ADICIONAR: Status dos AI Providers
    st.markdown("### 🤖 Status dos AI Providers")
    
    manager = get_ai_provider_manager()
    status = manager.get_status()
    
    col1, col2, col3, col4 = st.columns(4)
    
    with col1:
        openai_status = "🟢 Disponível" if status['openai_available'] else "🔴 Indisponível"
        st.info(f"**OpenAI:** {openai_status}")
    
    with col2:
        anthropic_status = "🟢 Disponível" if status['anthropic_available'] else "🔴 Indisponível"
        st.info(f"**Anthropic:** {anthropic_status}")
    
    with col3:
        mode_text = status['mode'].replace('_', ' ').title()
        st.info(f"**Modo:** {mode_text}")
    
    with col4:
        total_providers = sum([status['openai_available'], status['anthropic_available']])
        st.info(f"**Providers Ativos:** {total_providers}")    
    # Status do sistema
    st.markdown("### 📊 Status das Dependências")
    
    status_col1, status_col2, status_col3, status_col4 = st.columns(4)
    
    with status_col1:
        cv2_status = "🟢 Disponível" if CV2_AVAILABLE else "🔴 Instalar opencv-python"
        st.info(f"**OpenCV:** {cv2_status}")
    
    with status_col2:
        ocr_status = "🟢 Disponível" if OCR_AVAILABLE else "🔴 Instalar pytesseract"
        st.info(f"**OCR:** {ocr_status}")
    
    with status_col3:
        openai_status = "🟢 Conectado" if OPENAI_AVAILABLE and os.getenv('OPENAI_API_KEY') else "🟡 Configurar API"
        st.info(f"**OpenAI:** {openai_status}")
    
    with status_col4:
        plotly_status = "🟢 Disponível" if PLOTLY_AVAILABLE else "🟡 Instalar plotly"
        st.info(f"**Plotly:** {plotly_status}")


def create_analysis_tab():
    """Aba de análise com detecção real e YOLO integrado"""
    st.header("🔍 Análise STRIDE - Detecção Visual com YOLO")
    
    # Mostrar status do YOLO
    col_status1, col_status2, col_status3 = st.columns(3)
    
    with col_status1:
        # Verificar se modelo YOLO está disponível
        yolo_model_path = Path("./cloud_icons_training/best.pt")
        print(yolo_model_path)
        if yolo_model_path.exists():
            st.success("✅ Modelo YOLO carregado")
            st.caption(f"Arquivo: {yolo_model_path.name}")
        else:
            st.warning("⚠️ Modelo YOLO não encontrado")
            st.caption("Coloque best_cloud_icons.pt na pasta cloud_icons_training/")
    
    with col_status2:
        # Status do PyTorch
        try:
            import torch
            device = "GPU" if torch.cuda.is_available() else "CPU"
            st.info(f"🔧 PyTorch: {device}")
        except:
            st.error("❌ PyTorch não instalado")
    
    with col_status3:
        # Outros métodos
        methods_available = []
        if CV2_AVAILABLE:
            methods_available.append("OpenCV")
        if OCR_AVAILABLE:
            methods_available.append("OCR")
        if OPENAI_AVAILABLE:
            methods_available.append("GPT-4")
        
        st.info(f"📊 Métodos: {len(methods_available) + 1}")
        st.caption("YOLO + " + ", ".join(methods_available))
    
    # Key dinâmica para permitir limpeza
    file_key = f"uploaded_file_{st.session_state.get('uploaded_file_key', 0)}"
    
    # Upload de imagem
    uploaded_file = st.file_uploader(
        "📤 Carregue a imagem da arquitetura",
        type=['png', 'jpg', 'jpeg', 'bmp', 'tiff'],
        help="O sistema usará YOLO treinado + outros métodos para detectar componentes de cloud",
        key=file_key
    )
    
    if uploaded_file:
        col1, col2 = st.columns([2, 1])
        
        with col1:
            st.image(uploaded_file, caption="Imagem carregada", use_container_width=True)
        
        with col2:
            st.markdown(f"""
            **📋 Informações da Imagem:**
            - **Nome:** {uploaded_file.name}
            - **Tamanho:** {len(uploaded_file.getvalue()) / 1024:.1f} KB
            - **Tipo:** {uploaded_file.type}
            
            **🔬 Métodos de Detecção:**
            - ✅ YOLO (ícones treinados)
            - ✅ OpenCV (formas)  
            - ✅ OCR (texto)
            - ✅ Cores (providers)
            - ✅ GPT-4 Vision (contexto)
            """)
            
            # Opções de análise
            st.markdown("**⚙️ Opções de Análise:**")
            use_yolo = st.checkbox("🎯 Usar YOLO treinado", value=True, help="Detecta ícones específicos de cloud")
            use_vision = st.checkbox("👁️ Usar OpenAI Vision", value=True, help="Requer API key")
            
            # Botão de análise
            if st.button("🚀 Iniciar Análise com YOLO", type="primary", use_container_width=True):
                with st.spinner("🔄 Analisando com YOLO + multi-modal..."):
                    try:
                        # Importar o analisador com YOLO
                        from enhanced_image_analyzer_yolo_integration import RealImageAnalyzerWithYOLO
                        
                        # Criar analisador STRIDE que usa o analyzer com YOLO
                        class RealSTRIDEAnalyzerWithYOLO(RealSTRIDEAnalyzer):
                            def __init__(self):
                                super().__init__()
                                # Substituir o image_analyzer pela versão com YOLO
                                self.image_analyzer = RealImageAnalyzerWithYOLO()
                        
                        # Executar análise
                        analyzer = RealSTRIDEAnalyzerWithYOLO()
                        result = analyzer.analyze_image(uploaded_file, use_yolo=use_yolo, use_vision=use_vision)
                        
                        if result.get('success'):
                            st.session_state['analysis_result'] = result
                            st.session_state['analysis_timestamp'] = datetime.now()
                            
                            # Configurar contexto do RAG
                            stride_rag = get_stride_rag()
                            stride_rag.set_analysis_context(result)
                            
                            st.success("✅ Análise concluída com YOLO + métodos complementares!")
                            
                            # Mostrar estatísticas específicas do YOLO
                            if result.get('detection_details', {}).get('yolo_analysis', {}).get('stats'):
                                stats = result['detection_details']['yolo_analysis']['stats']
                                
                                with st.expander("🎯 Estatísticas YOLO", expanded=True):
                                    col1, col2, col3 = st.columns(3)
                                    
                                    with col1:
                                        providers = stats.get('providers', {})
                                        st.metric("Providers Detectados", len(providers))
                                        for provider, count in providers.items():
                                            st.caption(f"{provider.upper()}: {count} ícones")
                                    
                                    with col2:
                                        confidence = stats.get('confidence', {})
                                        mean_conf = confidence.get('mean', 0)
                                        st.metric("Confiança Média", f"{mean_conf:.1%}")
                                        st.caption(f"Alta confiança: {confidence.get('high_confidence_count', 0)}")
                                    
                                    with col3:
                                        if stats.get('is_multi_cloud'):
                                            st.warning("⚠️ Multi-cloud detectado!")
                                        else:
                                            dominant = stats.get('dominant_provider', 'unknown')
                                            st.info(f"Provider: {dominant.upper()}")
                        else:
                            st.error(f"❌ Erro na análise: {result.get('error', 'Erro desconhecido')}")
                    
                    except ImportError as e:
                        st.error(f"❌ Erro ao importar módulo YOLO: {str(e)}")
                        st.info("Verifique se o arquivo enhanced_image_analyzer_yolo_integration.py está presente")
                    except Exception as e:
                        st.error(f"❌ Erro na análise: {str(e)}")
    
    # Mostrar resultados se disponível (resto do código permanece o mesmo)
    if st.session_state.get('analysis_result'):
        result = st.session_state['analysis_result']
        
        st.markdown("---")
        st.markdown("### 📊 Resultados da Análise Visual")
        
        # Métricas principais
        metric_col1, metric_col2, metric_col3, metric_col4 = st.columns(4)
        
        with metric_col1:
            component_count = len(result.get('detected_components', []))
            st.metric("🎯 Componentes Detectados", component_count, 
                     delta=f"Real: {component_count} (não mais fixo em 3)")
        
        with metric_col2:
            threat_count = len(result.get('threats', []))
            st.metric("⚠️ Ameaças Geradas", threat_count,
                     delta=f"Proporcional aos componentes")
        
        with metric_col3:
            risk_score = result.get('risk_score', 0)
            risk_delta = "Alto" if risk_score >= 7 else "Médio" if risk_score >= 4 else "Baixo"
            st.metric("📊 Risk Score", f"{risk_score}/10", delta=f"Ponderado: {risk_delta}")
        
        with metric_col4:
            st.metric("⏱️ Tempo", f"{result.get('analysis_time', 0):.2f}s")
        
        # Componentes detectados com detalhes técnicos
        if result.get('detected_components'):
            st.markdown("#### 🔍 Componentes Detectados por Análise Visual")
            
            for i, comp in enumerate(result['detected_components']):
                with st.expander(f"📦 {comp['name']} (Confiança: {comp.get('confidence', 0):.0%})"):
                    col1, col2, col3 = st.columns(3)
                    
                    with col1:
                        st.write(f"**Tipo:** {comp.get('type', 'Unknown')}")
                        st.write(f"**Provedor:** {comp.get('provider', 'Unknown')}")
                    
                    with col2:
                        st.write(f"**Método:** {comp.get('detection_method', 'unknown')}")
                        st.write(f"**Confiança:** {comp.get('confidence', 0):.1%}")
                    
                    with col3:
                        if 'position' in comp:
                            pos = comp['position']
                            st.write(f"**Posição:** x={pos.get('x', 0)}, y={pos.get('y', 0)}")
                            st.write(f"**Tamanho:** {pos.get('w', 0)}x{pos.get('h', 0)}")
        
        # Detalhes técnicos da detecção
        if st.checkbox("🔬 Mostrar detalhes técnicos da detecção visual"):
            st.markdown("### 🔧 Análise Técnica dos Métodos de Detecção")
            
            details = result.get('detection_details', {})
            
            tab1, tab2, tab3, tab4, tab5 = st.tabs(["OpenCV", "OCR", "Cores", "OpenAI", "Anthropic"])
            
            with tab1:
                if details.get('cv_analysis'):
                    cv_data = details['cv_analysis']
                    st.write("**Análise OpenCV:**")
                    st.write(f"- Contornos significativos detectados: {cv_data.get('total_contours', 0)}")
                    st.write(f"- Formas identificadas: {len(cv_data.get('shapes', []))}")
                    
                    if cv_data.get('shapes'):
                        st.write("**Formas detectadas:**")
                        for shape in cv_data['shapes'][:5]:  # Mostrar top 5
                            st.write(f"  • {shape['type']}: área {shape['area']}, {shape['vertices']} vértices")
                else:
                    st.info("OpenCV não disponível - instale opencv-python")
            
            with tab2:
                if details.get('ocr_analysis'):
                    ocr_data = details['ocr_analysis']
                    st.write("**Análise OCR:**")
                    st.write(f"- Regiões de texto detectadas: {ocr_data.get('total_text_regions', 0)}")
                    st.write(f"- Tecnologias identificadas: {len(ocr_data.get('identified_technologies', []))}")
                    
                    if ocr_data.get('identified_technologies'):
                        st.write("**Tecnologias encontradas:**")
                        for tech in ocr_data['identified_technologies'][:10]:
                            st.write(f"  • {tech['text']} ({tech['provider']}) - {tech['confidence']}%")
                else:
                    st.info("OCR não disponível - instale pytesseract")
            
            with tab3:
                if details.get('color_analysis'):
                    color_data = details['color_analysis']
                    st.write("**Análise de Cores:**")
                    st.write(f"- Provider dominante: **{color_data.get('dominant_provider', 'unknown').upper()}**")
                    st.write(f"- Confiança na detecção: {color_data.get('confidence', 0):.1%}")
                    
                    if 'color_matches' in color_data:
                        st.write("**Correspondências por provider:**")
                        for provider, matches in color_data['color_matches'].items():
                            st.write(f"  • {provider.upper()}: {matches} pixels correspondentes")
                else:
                    st.info("Análise de cores requer OpenCV")
            
            with tab4:
                if details.get('openai_analysis'):
                    openai_data = details['openai_analysis']
                    if 'error' not in openai_data:
                        st.write("**Análise OpenAI Vision:**")
                        if 'component_count' in openai_data:
                            st.write(f"- Componentes identificados: {openai_data['component_count']}")
                        if 'provider' in openai_data:
                            st.write(f"- Provider identificado: {openai_data['provider']}")
                        if 'components' in openai_data:
                            st.write("**Componentes identificados:**")
                            for comp in openai_data['components']:
                                st.write(f"  • {comp}")
                        
                        # Mostrar resposta bruta se disponível
                        if 'raw_response' in openai_data:
                            with st.expander("📄 Resposta completa do GPT-4o"):
                                st.text(openai_data['raw_response'])
                    else:
                        st.error(f"Erro na análise OpenAI: {openai_data['error']}")
                        st.info("Possíveis causas: API key inválida, limite de créditos atingido, ou problema de conectividade")
                else:
                    openai_configured = OPENAI_AVAILABLE and os.getenv('OPENAI_API_KEY')
                    if not OPENAI_AVAILABLE:
                        st.warning("📦 OpenAI não instalado")
                        st.code("pip install openai")
                    elif not os.getenv('OPENAI_API_KEY'):
                        st.warning("🔑 OpenAI API Key não configurada")
                        st.code("export OPENAI_API_KEY='sua_chave_aqui'")
                    else:
                        st.info("OpenAI configurado mas não executou análise visual")
            with tab5:
                # Verificar se há dados do Anthropic na análise
                if details.get('openai_analysis') and 'ai_provider' in details['openai_analysis']:
                    ai_data = details['openai_analysis']
                    
                    # Verificar se foi Anthropic ou consolidação
                    if ai_data.get('ai_provider') == 'anthropic':
                        st.write("**Análise Anthropic Claude:**")
                        st.write(f"- Modelo usado: {ai_data.get('ai_model', 'Claude')}")
                        
                        if 'component_count' in ai_data:
                            st.write(f"- Componentes identificados: {ai_data['component_count']}")
                        if 'provider' in ai_data:
                            st.write(f"- Provider identificado: {ai_data['provider']}")
                        if 'components' in ai_data:
                            st.write("**Componentes identificados:**")
                            for comp in ai_data['components']:
                                st.write(f"  • {comp}")
                        if 'confidence' in ai_data:
                            st.write(f"- Confiança: {ai_data['confidence']}")
                        
                        # Mostrar resposta bruta se disponível
                        if 'raw_response' in ai_data:
                            with st.expander("📄 Resposta completa do Claude"):
                                st.text(ai_data['raw_response'])
                                
                    elif ai_data.get('ai_provider') == 'consolidated':
                        st.write("**Análise Consolidada (OpenAI + Anthropic):**")
                        st.write(f"- Tipo de análise: {ai_data.get('analysis_type', 'Redundante')}")
                        st.write(f"- Número de sources: {ai_data.get('sources', 2)}")
                        
                        if 'provider_insights' in ai_data:
                            st.write("**Insights consolidados dos providers:**")
                            for provider, insights in ai_data['provider_insights'].items():
                                with st.expander(f"📊 Insights do {provider.title()}"):
                                    st.json(insights)
                        
                        if 'component_count' in ai_data:
                            st.write(f"- Componentes identificados (consolidado): {ai_data['component_count']}")
                        if 'components' in ai_data:
                            st.write("**Componentes identificados (consolidado):**")
                            for comp in ai_data['components']:
                                st.write(f"  • {comp}")
                    else:
                        st.info("Análise feita apenas com OpenAI nesta execução")
                else:
                    # Verificar status do Anthropic
                    manager = get_ai_provider_manager()
                    status = manager.get_status()
                    
                    if status['anthropic_available']:
                        st.info("🟣 Anthropic configurado mas não foi usado nesta análise")
                        
                        # Mostrar modo atual
                        mode_text = status['mode'].replace('_', ' ').title()
                        st.write(f"**Modo atual:** {mode_text}")
                        
                        if status['mode'] == 'openai_only':
                            st.warning("⚠️ Sistema configurado para usar apenas OpenAI")
                            st.caption("Para usar Anthropic, mude o modo na aba Config > AI Providers")
                        elif status['mode'] in ['fallback', 'redundant']:
                            st.info(f"Modo {mode_text} ativo - Anthropic pode ser usado automaticamente")
                    else:
                        st.warning("📦 Anthropic não configurado")
                        st.code("export ANTHROPIC_API_KEY='sua_chave_aqui'")
                        
                        with st.expander("Como obter API Key do Anthropic"):
                            st.markdown("""
                            1. Acesse https://console.anthropic.com/
                            2. Faça login ou crie uma conta
                            3. Vá em Settings > API Keys
                            4. Crie uma nova API key
                            5. Configure a variável de ambiente:
                               export ANTHROPIC_API_KEY='sua-chave-aqui'
                        6. Reinicie o aplicativo
                        """)
    
# CONTINUAÇÃO DO CÓDIGO - PARTE 2
# Cole este código logo após a linha: st.info("OpenAI configurado mas não executou análise visual")

def create_chat_tab():
    """Aba de chat RAG híbrido com busca vetorial semântica"""
    st.header("💬 Chat RAG Híbrido - Busca Vetorial + GPT-4")
    
    # Obter instância do RAG
    stride_rag = get_stride_rag()
    
    # Verificar análise disponível e configurar contexto
    analysis_available = st.session_state.get('analysis_result') is not None
    
    # Status do sistema RAG
    col1, col2, col3 = st.columns(3)
    
    with col1:
        if analysis_available:
            result = st.session_state['analysis_result']
            stride_rag.set_analysis_context(result)
            filename = result.get('image_info', {}).get('filename', 'N/A')
            component_count = len(result.get('detected_components', []))
            st.success(f"✅ Arquitetura: {filename} ({component_count} componentes)")
        else:
            st.info("ℹ️ Arquitetura não analisada")
    
    with col2:
        frameworks_count = len(stride_rag.compliance_frameworks)
        if frameworks_count > 0:
            st.success(f"✅ Frameworks: {frameworks_count} carregados")
        else:
            st.warning("⚠️ Nenhum framework carregado")
    
    with col3:
        if stride_rag.embeddings_ready:
            embedding_type = "OpenAI Ada-002" if stride_rag.vector_rag.openai_client else "TF-IDF"
            st.success(f"✅ Embeddings: {embedding_type}")
        else:
            st.warning("⚠️ Embeddings não criados")
    
    # Informações sobre capacidades do sistema
    with st.expander("🧠 Capacidades do RAG Híbrido"):
        st.markdown("**Sistema Híbrido Implementado:**")
        
        st.markdown("**1. Busca Vetorial Semântica:**")
        st.write("• Embeddings dos frameworks de compliance (.md)")
        st.write("• Busca por similaridade cosine")  
        st.write("• Retrieval de conteúdo mais relevante")
        
        st.markdown("**2. Análise Contextual:**")
        st.write("• GPT-4 com contexto da arquitetura")
        st.write("• Correlação automática com normas")
        st.write("• Respostas naturais e específicas")
        
        st.markdown("**3. Frameworks Suportados:**")
        st.write("• NIST Cybersecurity Framework")
        st.write("• OWASP Top 10 2021")
        st.write("• ISO 27001:2022")
        st.write("• Qualquer framework em formato .md")
    
    # Inicializar histórico do chat se não existir
    if "chat_messages" not in st.session_state:
        st.session_state.chat_messages = []
        
        if analysis_available and stride_rag.embeddings_ready:
            welcome_msg = f"Olá! Sistema RAG híbrido ativo. Analisei sua arquitetura '{result.get('image_info', {}).get('filename', 'N/A')}' e criei embeddings de {len(stride_rag.compliance_frameworks)} frameworks de compliance. Posso responder com busca semântica + GPT-4!"
        elif analysis_available:
            welcome_msg = f"Olá! Analisei sua arquitetura, mas embeddings não estão disponíveis. Posso usar GPT-4 com contexto da sua análise."
        else:
            welcome_msg = "Olá! Execute uma análise STRIDE primeiro para ativar o RAG contextual completo."
            
        st.session_state.chat_messages.append({"role": "assistant", "content": welcome_msg})
    
    # Verificar se há mensagem do usuário não processada (para botões)
    if len(st.session_state.chat_messages) > 0:
        last_message = st.session_state.chat_messages[-1]
        if last_message["role"] == "user":
            # Há uma mensagem do usuário não processada, processar automaticamente
            user_input = last_message["content"]
            
            with st.chat_message("assistant"):
                if stride_rag.embeddings_ready:
                    with st.spinner("🔍 Busca semântica + GPT-4..."):
                        # Mostrar processo de busca vetorial
                        with st.expander("🔬 Processo de RAG Híbrido", expanded=False):
                            # Busca semântica independente para mostrar processo
                            relevant_chunks = stride_rag.vector_rag.semantic_search(user_input, top_k=5)
                            
                            if relevant_chunks:
                                st.write("**Top controles encontrados por busca vetorial:**")
                                for i, chunk in enumerate(relevant_chunks):
                                    similarity = chunk.get('similarity_score', 0)
                                    framework = chunk.get('framework', 'Unknown').upper()
                                    control = chunk.get('control', 'Unknown')
                                    st.write(f"{i+1}. {framework} - {control} (similaridade: {similarity:.3f})")
                            else:
                                st.write("Nenhum controle específico encontrado na busca vetorial")
                        
                        # Resposta do RAG híbrido
                        response = stride_rag.process_query(user_input)
                        st.write(response)
                else:
                    with st.spinner("🧠 Processando com GPT-4..."):
                        response = stride_rag.process_query(user_input)
                        st.write(response)
            
            # Adicionar resposta do assistente
            st.session_state.chat_messages.append({"role": "assistant", "content": response})
            st.rerun()
    
    # Mostrar histórico de mensagens
    for message in st.session_state.chat_messages:
        with st.chat_message(message["role"]):
            st.write(message["content"])
    
    # Input do usuário - linguagem natural
    user_input = st.chat_input("Pergunte sobre sua arquitetura, ameaças STRIDE, ou normas de compliance (ex: 'Quais controles NIST aplicam ao meu spoofing?')")
    
    if user_input:
        # Adicionar mensagem do usuário
        st.session_state.chat_messages.append({"role": "user", "content": user_input})
        st.rerun()  # Recarregar para processar a nova mensagem
    
    # Exemplos de perguntas para RAG híbrido
    if analysis_available and stride_rag.embeddings_ready:
        st.markdown("---")
        st.markdown("#### 💡 Exemplos de Perguntas para RAG Híbrido:")
        
        # Gerar exemplos baseados na análise atual
        result = st.session_state['analysis_result']
        components = result.get('detected_components', [])
        threats = result.get('threats', [])
        providers = list(result.get('cloud_providers', {}).keys())
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Correlação Arquitetura + Normas:**")
            if st.button("Quais controles NIST aplicam às minhas ameaças?", key="nist_controls"):
                st.session_state.chat_messages.append({"role": "user", "content": "Quais controles NIST aplicam às minhas ameaças?"})
                st.rerun()
            
            if st.button("Como OWASP Top 10 relaciona com minha arquitetura?", key="owasp_relation"):
                st.session_state.chat_messages.append({"role": "user", "content": "Como OWASP Top 10 relaciona com minha arquitetura?"})
                st.rerun()
        
        with col2:
            st.markdown("**Perguntas Específicas da Análise:**")
            
            # Botão contextual baseado nos componentes detectados
            if components:
                main_component = components[0]['name']
                if st.button(f"Como proteger {main_component}?", key="protect_component"):
                    st.session_state.chat_messages.append({"role": "user", "content": f"Como proteger {main_component} da minha arquitetura?"})
                    st.rerun()
            else:
                if st.button("Como melhorar a segurança desta arquitetura?", key="improve_security"):
                    st.session_state.chat_messages.append({"role": "user", "content": "Como melhorar a segurança desta arquitetura?"})
                    st.rerun()
            
            # Botão contextual baseado nas principais ameaças
            if threats:
                main_threat = threats[0]['category']
                if st.button(f"Controles para {main_threat.lower()}", key="threat_controls"):
                    st.session_state.chat_messages.append({"role": "user", "content": f"Que controles de compliance aplicam para {main_threat.lower()} na minha arquitetura?"})
                    st.rerun()
            else:
                if st.button("Controles de compliance recomendados", key="compliance_controls"):
                    st.session_state.chat_messages.append({"role": "user", "content": "Quais controles de compliance são recomendados para esta arquitetura?"})
                    st.rerun()
    else:
        st.markdown("---")
        st.markdown("#### 💡 Exemplos Gerais:")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("Como funciona análise STRIDE?", key="stride_explanation"):
                st.session_state.chat_messages.append({"role": "user", "content": "Como funciona análise STRIDE?"})
                st.rerun()
        
        with col2:
            if st.button("Principais frameworks de segurança", key="security_frameworks"):
                st.session_state.chat_messages.append({"role": "user", "content": "Quais são os principais frameworks de segurança?"})
                st.rerun()
    
    # Estatísticas do RAG
    if st.checkbox("📊 Estatísticas do Sistema RAG"):
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**Base de Conhecimento:**")
            st.write(f"• Frameworks: {len(stride_rag.compliance_frameworks)}")
            if stride_rag.vector_rag.document_chunks:
                st.write(f"• Chunks indexados: {len(stride_rag.vector_rag.document_chunks)}")
            if stride_rag.vector_rag.embedding_matrix is not None:
                st.write(f"• Dimensões dos embeddings: {stride_rag.vector_rag.embedding_matrix.shape}")
        
        with col2:
            st.markdown("**Capacidades Ativas:**")
            st.write(f"• OpenAI disponível: {OPENAI_AVAILABLE and os.getenv('OPENAI_API_KEY') is not None}")
            st.write(f"• Scikit-learn: {SKLEARN_AVAILABLE}")
            st.write(f"• Embeddings prontos: {stride_rag.embeddings_ready}")
            st.write(f"• RAG híbrido: {stride_rag.embeddings_ready and OPENAI_AVAILABLE}")
    
    # Botão para recriar embeddings
    if st.button("🔄 Recriar Embeddings"):
        with st.spinner("Recriando embeddings..."):
            stride_rag.embeddings_ready = stride_rag.vector_rag.create_embeddings_from_frameworks(stride_rag.compliance_frameworks)
            if stride_rag.embeddings_ready:
                st.success("Embeddings recriados com sucesso!")
            else:
                st.error("Falha ao recriar embeddings")
        st.rerun()
    
    # Botão para limpar chat
    if st.button("🗑️ Limpar Chat"):
        st.session_state.chat_messages = []
        st.rerun()

# Agora, substitua a função create_reports_tab() pela versão com sub-abas:

def create_reports_tab():
    """Aba de relatórios com duas sub-abas para diferentes visualizações"""
    st.header("📄 Relatórios - Análise Visual")
    
    if st.session_state.get('analysis_result'):
        analysis_result = st.session_state['analysis_result']
        
        # Criar sub-abas
                # Criar 4 sub-abas
        report_tabs = st.tabs([
            "📊 Visão 1 - Análise", 
            "🎯 Visão 2 - Threat Style",
            "⚡ Visão 3 - Risk Matrix",
            "🔐 Visão 4 - Threat vs Assets"
        ])
        
        # SUB-ABA 1: Template Original
        with report_tabs[0]:
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.subheader("🌐 Preview do Relatório HTML - Análise Original")
                
                # Gerar HTML dinâmico original
                html_content = generate_enhanced_html_report(analysis_result)
                
                # Preview HTML
                st.components.v1.html(html_content, height=600, scrolling=True)
            
            with col2:
                st.subheader("📥 Downloads V1")
                
                # Informações da análise real
                threats = analysis_result.get('threats', [])
                components = analysis_result.get('detected_components', [])
                
                st.markdown(f"""
                **📋 Análise Visual:**
                - **Imagem:** {analysis_result.get('image_info', {}).get('filename', 'N/A')}
                - **Componentes:** {len(components)} (detecção)
                - **Ameaças:** {len(threats)} (proporcionais)  
                - **Risk Score:** {analysis_result.get('risk_score', 0)}/10 (ponderado)
                - **Análise ID:** {analysis_result.get('analysis_id', 'N/A')}
                - **Tempo:** {analysis_result.get('analysis_time', 0):.2f}s
                """)
                
                st.markdown("---")
                
                # Preparar nomes de arquivo
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                image_name = analysis_result.get('image_info', {}).get('filename', 'unknown').split('.')[0]
                
                # Download HTML V1
                html_filename = f"stride_real_analysis_{image_name}_{timestamp}.html"
                
                st.download_button(
                    label="💾 Download Relatório HTML",
                    data=html_content,
                    file_name=html_filename,
                    mime="text/html",
                    use_container_width=True,
                    help="Relatório completo com links clicáveis"
                )
                
                # Download PDF - Versão compatível com Windows
                pdf_filename = f"stride_real_analysis_{image_name}_{timestamp}.pdf"
                
                # Verificar bibliotecas disponíveis
                pdf_libs_available = XHTML2PDF_AVAILABLE or PDFKIT_AVAILABLE or WEASYPRINT_AVAILABLE or REPORTLAB_AVAILABLE
                
                if pdf_libs_available:
                    col_pdf1, col_pdf2 = st.columns(2)
                    
                    with col_pdf1:
                        # PDF completo (tenta manter links)
                        if st.button("📑 PDF Completo", use_container_width=True, type="primary", key="pdf_complete_v1"):
                            with st.spinner("Gerando PDF..."):
                                pdf_bytes = generate_pdf_from_html(html_content)
                                
                                if pdf_bytes:
                                    st.download_button(
                                        label="📥 Baixar PDF",
                                        data=pdf_bytes,
                                        file_name=pdf_filename,
                                        mime="application/pdf",
                                        use_container_width=True,
                                        key="download_pdf_v1"
                                    )
                                    st.success("✅ PDF gerado!")
                                else:
                                    st.error("❌ Erro ao gerar PDF completo")
                    
                    with col_pdf2:
                        # PDF simples (sempre funciona)
                        if REPORTLAB_AVAILABLE:
                            if st.button("📄 PDF Simples", use_container_width=True, key="pdf_simple_v1"):
                                with st.spinner("Gerando PDF simples..."):
                                    pdf_bytes = generate_simple_pdf_report(analysis_result)
                                    
                                    if pdf_bytes:
                                        simple_filename = f"stride_simple_{image_name}_{timestamp}.pdf"
                                        st.download_button(
                                            label="📥 Baixar",
                                            data=pdf_bytes,
                                            file_name=simple_filename,
                                            mime="application/pdf",
                                            use_container_width=True,
                                            key="download_simple_v1"
                                        )
                                        st.success("✅ PDF simples gerado!")
                else:
                    st.warning("⚠️ Nenhuma biblioteca PDF instalada")
                    
                    with st.expander("📦 Como instalar (Windows)"):
                        st.markdown("""
                        **Opção 1 - xhtml2pdf (Mais simples):**

                        pip install xhtml2pdf
                    **Opção 2 - ReportLab (Sempre funciona):**
                        pip install reportlab
                    **Opção 3 - PDFKit (Precisa wkhtmltopdf):**
                        # Baixe wkhtmltopdf de:
                        # https://wkhtmltopdf.org/downloads.html
                        # Instale no Windows
                        
                        pip install pdfkit
                    **Alternativa:** Use Ctrl+P no navegador
                    """)
            
            # Download JSON
            json_data = json.dumps(convert_numpy_types(analysis_result), indent=2, ensure_ascii=False)
            json_filename = f"stride_real_data_{image_name}_{timestamp}.json"
            
            st.download_button(
                label="📊 Download Dados JSON",
                data=json_data,
                file_name=json_filename,
                mime="application/json", 
                use_container_width=True,
                help="Dados completos da análise",
                key="json_v1"
            )
            
            st.markdown("---")
            
            # Status das bibliotecas PDF
            st.markdown("#### 📑 Status PDF")
            
            status_list = []
            if XHTML2PDF_AVAILABLE:
                status_list.append("✅ xhtml2pdf")
            if REPORTLAB_AVAILABLE:
                status_list.append("✅ ReportLab")
            if PDFKIT_AVAILABLE:
                status_list.append("✅ PDFKit")
            if WEASYPRINT_AVAILABLE:
                status_list.append("⚠️ WeasyPrint")
            
            if status_list:
                for status in status_list:
                    st.write(status)
            else:
                st.warning("⚠️ Instale uma biblioteca PDF")        
        # SUB-ABA 2: AWS Threat Composer Style
        with report_tabs[1]:
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.subheader("🎯 Preview do Dashboard AWS Threat Composer Style")
                
                # Gerar HTML no estilo AWS
                html_content_v2 = generate_enhanced_html_report2(analysis_result)
                
                # Preview HTML
                st.components.v1.html(html_content_v2, height=600, scrolling=True)
            
        with col2:
            st.subheader("📥 Downloads V2")
            
            # Informações da análise
            threats = analysis_result.get('threats', [])
            components = analysis_result.get('detected_components', [])
            
            st.markdown(f"""
            **🎯 Template AWS Style:**
            - **Estilo:** Clean/Professional
            - **Layout:** Dashboard Metrics
            - **Visual:** AWS Design System
            - **Foco:** Progress Tracking
            """)
            
            st.markdown("---")
            
            # Métricas do dashboard
            severity_counts = {'critical': 0, 'high': 0, 'medium': 0, 'low': 0}
            for threat in threats:
                severity = threat.get('severity', 'medium')
                if severity in severity_counts:
                    severity_counts[severity] += 1
            
            col_m1, col_m2 = st.columns(2)
            with col_m1:
                st.metric("Total Threats", len(threats))
                st.metric("High Priority", severity_counts['high'] + severity_counts['critical'])
            with col_m2:
                st.metric("Med Priority", severity_counts['medium'])
                st.metric("Low Priority", severity_counts['low'])
            
            st.markdown("---")
            
            # Preparar nomes de arquivo
            timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
            image_name = analysis_result.get('image_info', {}).get('filename', 'unknown').split('.')[0]
            
            # Download HTML V2
            html_filename_v2 = f"threat_composer_{image_name}_{timestamp}.html"
            
            st.download_button(
                label="💾 Download HTML AWS Style",
                data=html_content_v2,
                file_name=html_filename_v2,
                mime="text/html",
                use_container_width=True,
                help="Dashboard estilo AWS",
                key="html_v2"
            )
            
            # Download PDF V2 - Versão compatível com Windows
            pdf_filename_v2 = f"threat_composer_{image_name}_{timestamp}.pdf"
            
            # Verificar bibliotecas disponíveis
            pdf_libs_available = XHTML2PDF_AVAILABLE or PDFKIT_AVAILABLE or WEASYPRINT_AVAILABLE or REPORTLAB_AVAILABLE
            
            if pdf_libs_available:
                col_pdf1, col_pdf2 = st.columns(2)
                
                with col_pdf1:
                    # PDF completo V2
                    if st.button("📑 PDF Completo", use_container_width=True, type="primary", key="pdf_complete_v2"):
                        with st.spinner("Gerando PDF AWS Style..."):
                            pdf_bytes = generate_pdf_from_html(html_content_v2)
                            
                            if pdf_bytes:
                                st.download_button(
                                    label="📥 Baixar PDF",
                                    data=pdf_bytes,
                                    file_name=pdf_filename_v2,
                                    mime="application/pdf",
                                    use_container_width=True,
                                    key="download_pdf_v2"
                                )
                                st.success("✅ PDF gerado!")
                            else:
                                st.error("❌ Erro ao gerar PDF completo")
                
                with col_pdf2:
                    # PDF simples (sempre funciona)
                    if REPORTLAB_AVAILABLE:
                        if st.button("📄 PDF Simples", use_container_width=True, key="pdf_simple_v2"):
                            with st.spinner("Gerando PDF simples..."):
                                pdf_bytes = generate_simple_pdf_report(analysis_result)
                                
                                if pdf_bytes:
                                    simple_filename_v2 = f"threat_simple_{image_name}_{timestamp}.pdf"
                                    st.download_button(
                                        label="📥 Baixar",
                                        data=pdf_bytes,
                                        file_name=simple_filename_v2,
                                        mime="application/pdf",
                                        use_container_width=True,
                                        key="download_simple_v2"
                                    )
                                    st.success("✅ PDF simples gerado!")

            else:
                st.warning("⚠️ Nenhuma biblioteca PDF instalada")
                
                with st.expander("📦 Como instalar (Windows)"):
                    st.markdown("""
                    **Opção 1 - xhtml2pdf (Mais simples):**
                        pip install xhtml2pdf
                    **Opção 2 - ReportLab (Sempre funciona):**
                        pip install reportlab
                    **Alternativa:** Use Ctrl+P no navegador
                    """)
            
            # Download JSON (mesmos dados para ambas visões)
            json_data = json.dumps(convert_numpy_types(analysis_result), indent=2, ensure_ascii=False)
            json_filename = f"threat_data_{image_name}_{timestamp}.json"
            
            st.download_button(
                label="📊 Download Dados JSON",
                data=json_data,
                file_name=json_filename,
                mime="application/json",
                use_container_width=True,
                help="Dados completos da análise",
                key="json_v2"
            )
            
            st.markdown("---")
            
            # Status das bibliotecas PDF
            st.markdown("#### 📑 Status PDF")
            
            status_list = []
            if XHTML2PDF_AVAILABLE:
                status_list.append("✅ xhtml2pdf")
            if REPORTLAB_AVAILABLE:
                status_list.append("✅ ReportLab")
            if PDFKIT_AVAILABLE:
                status_list.append("✅ PDFKit")
            if WEASYPRINT_AVAILABLE:
                status_list.append("⚠️ WeasyPrint")
            
            if status_list:
                for status in status_list:
                    st.write(status)
            else:
                st.warning("⚠️ Instale uma biblioteca PDF")
        # SUB-ABA 3: Risk Matrix (Attack Feasibility)
        with report_tabs[2]:
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.subheader("⚡ Attack Feasibility Risk Matrix")
                html_content_v3 = generate_enhanced_html_report3(analysis_result)
                st.components.v1.html(html_content_v3, height=600, scrolling=True)
            
            with col2:
                st.subheader("📥 Downloads V3")
                
                # Obter RAG status
                stride_rag = get_stride_rag()
                rag_status = "✅ Ativo" if stride_rag.embeddings_ready else "❌ Inativo"
                
                st.markdown(f"""
                **⚡ Risk Matrix:**
                - Impact vs Likelihood
                - 5x5 Risk Grid
                - RAG Integration: {rag_status}
                - Compliance Controls
                """)
                
                st.markdown("---")
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                image_name = analysis_result.get('image_info', {}).get('filename', 'unknown').split('.')[0]
                
                html_filename_v3 = f"risk_matrix_{image_name}_{timestamp}.html"
                st.download_button(
                    label="💾 Download HTML V3",
                    data=html_content_v3,
                    file_name=html_filename_v3,
                    mime="text/html",
                    use_container_width=True,
                    key="html_v3"
                )
                
                # Info sobre knowledge base
                if stride_rag.compliance_frameworks:
                    st.success(f"📚 {len(stride_rag.compliance_frameworks)} frameworks carregados")
                else:
                    st.warning("📚 Nenhum framework na knowledge_base")
        
        # SUB-ABA 4: Threat vs Assets Matrix
        with report_tabs[3]:
            col1, col2 = st.columns([3, 1])
            
            with col1:
                st.subheader("🔐 Threat Events vs Assets Matrix")
                html_content_v4 = generate_enhanced_html_report4(analysis_result)
                st.components.v1.html(html_content_v4, height=600, scrolling=True)
            
            with col2:
                st.subheader("📥 Downloads V4")
                
                # Estatísticas da matriz
                threats = analysis_result.get('threats', [])
                components = analysis_result.get('detected_components', [])
                
                st.markdown(f"""
                **🔐 Threat Matrix:**
                - STRIDE vs Assets
                - 6 Threat Events
                - 6 Asset Categories
                - Cross-correlation
                """)
                
                st.markdown("---")
                
                # Métricas
                st.metric("Threats", len(threats))
                st.metric("Assets", len(components))
                
                st.markdown("---")
                
                timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
                image_name = analysis_result.get('image_info', {}).get('filename', 'unknown').split('.')[0]
                
                html_filename_v4 = f"threat_assets_{image_name}_{timestamp}.html"
                st.download_button(
                    label="💾 Download HTML V4",
                    data=html_content_v4,
                    file_name=html_filename_v4,
                    mime="text/html",
                    use_container_width=True,
                    key="html_v4"
                )
        
        # Seção comum de downloads JSON (aparece em todas as abas)
        st.markdown("---")
        st.markdown("### 📊 Dados Brutos (JSON)")
        
        json_data = json.dumps(convert_numpy_types(analysis_result), indent=2, ensure_ascii=False)
        json_filename = f"stride_data_{datetime.now().strftime('%Y%m%d_%H%M%S')}.json"
        
        st.download_button(
            label="📊 Download JSON Completo",
            data=json_data,
            file_name=json_filename,
            mime="application/json",
            use_container_width=True,
            help="Dados completos da análise em formato JSON"
        )
    
    else:
        st.warning("⚠️ Execute uma análise primeiro para ver os relatórios.")
        
        # Mostrar preview dos templates disponíveis
        st.markdown("---")
        st.markdown("### 📋 Templates Disponíveis:")
        
        col1, col2, col3, col4 = st.columns(4)
        
        with col1:
            st.info("""
            **Visão 1 - Template Original:**
            - Design colorido com gradientes
            - Cards interativos
            - Gráficos dinâmicos
            - Links para OWASP/NIST
            - PDF com links clicáveis
            """)
        
        with col2:
            st.info("""
            **Visão 2 - AWS Threat Composer:**
            - Design limpo e profissional
            - Dashboard com métricas
            - Progress tracking
            - Estilo AWS Console
        - PDF estilo enterprise
            """)
        with col3:
            st.info("""
            **Visão 3 - Risk Matrix:**
            - Matriz 5x5
            - Impact vs Likelihood
            - Integração RAG
             """)
        with col4:
             st.info("""    
            **Visão 4 - Threat Matrix:**
            - STRIDE vs Assets
            - Cross-correlation
            - Compliance controls
            """)

def create_config_tab():
    """Aba de configurações incluindo cadastro de reconhecimento facial"""
    st.header("⚙️ Configurações")
    
    # Tabs dentro da aba Config - ADICIONAR nova tab
    config_tabs = st.tabs(["👤 Perfil", "📸 Reconhecimento Facial", "🔐 Segurança", "🤖 AI Providers"])
        
    # Tab Perfil
    with config_tabs[0]:
        st.subheader("👤 Informações do Perfil")
        
        col1, col2 = st.columns([1, 2])
        
        with col1:
            st.markdown(f"""
            **Usuário:** {st.session_state['username']}
            
            **ID:** {st.session_state['user_id']}
            
            **Método de Login:** {st.session_state.get('auth_method', 'credentials').title()}
            """)
            
            # Estatísticas de login
            stats = auth_system.get_login_stats(st.session_state['user_id'])
            
            st.markdown("---")
            st.markdown("**📊 Estatísticas de Login:**")
            st.metric("Total de logins", stats['total'])
            
            if stats['by_method']:
                st.markdown("**Por método:**")
                for method, count in stats['by_method'].items():
                    st.write(f"- {method.title()}: {count}")
        
        with col2:
            st.markdown("### 🔑 Alterar Senha")
            
            with st.form("change_password_config"):
                current_password = st.text_input("Senha Atual", type="password")
                new_password = st.text_input("Nova Senha", type="password")
                confirm_password = st.text_input("Confirmar Nova Senha", type="password")
                
                if st.form_submit_button("Alterar Senha", type="primary"):
                    if current_password and new_password and confirm_password:
                        # Verificar senha atual
                        result = auth_system.authenticate(st.session_state['username'], current_password)
                        
                        if result['success']:
                            if new_password == confirm_password:
                                if len(new_password) >= 6:
                                    auth_system.change_password(st.session_state['user_id'], new_password)
                                    st.success("✅ Senha alterada com sucesso!")
                                else:
                                    st.error("A senha deve ter pelo menos 6 caracteres")
                            else:
                                st.error("As senhas não coincidem")
                        else:
                            st.error("Senha atual incorreta")
                    else:
                        st.error("Preencha todos os campos")
    
    # Tab Reconhecimento Facial
    with config_tabs[1]:
        st.subheader("📸 Configuração de Reconhecimento Facial")
        
        # Verificar se o reconhecimento facial está disponível
        if not FACE_RECOGNITION_AVAILABLE:
            st.error("""
            ❌ **Reconhecimento facial não disponível**
            
            Para habilitar esta funcionalidade, instale as dependências necessárias:
            ```bash
            pip install cmake
            pip install dlib
            pip install face-recognition
            ```
            
            **Nota:** Requer compilador C++ e pode demorar para instalar.
            """)
            return
        
        col1, col2 = st.columns([2, 1])
        
        with col1:
            # Verificar se já tem face cadastrada
            has_face = auth_system.has_facial_auth(st.session_state['username'])
            
            if has_face:
                st.success("✅ Você já tem reconhecimento facial configurado!")
                st.markdown("""
                **Status do Reconhecimento Facial:**
                - ✅ Face cadastrada
                - ✅ Login facial habilitado
                - ✅ Pode fazer login com sua face
                """)
                
                # Mostrar última autenticação facial se houver
                stats = auth_system.get_login_stats(st.session_state['user_id'])
                if stats['last_facial']:
                    confidence, timestamp = stats['last_facial']
                    st.info(f"**Último login facial:** {timestamp} (Confiança: {confidence:.1f}%)")
                
                st.markdown("---")
                st.markdown("### 🔄 Atualizar Foto de Referência")
                st.info("Atualize sua foto de referência se desejar melhorar a precisão do reconhecimento.")
                action = "update"
            else:
                st.warning("⚠️ Você ainda não configurou o reconhecimento facial")
                st.markdown("""
                **Configure o reconhecimento facial para:**
                - 🚀 Login mais rápido
                - 🔐 Segurança adicional
                - 📸 Autenticação sem senha
                """)
                
                st.markdown("---")
                st.markdown("### 📸 Cadastrar Face para Autenticação")
                action = "register"
            
            # Opções de captura
            capture_method = st.radio(
                "Método de captura",
                ["Upload de Foto", "Captura por Webcam"],
                horizontal=True,
                key="face_capture_method"
            )
            
            if capture_method == "Upload de Foto":
                uploaded_photo = st.file_uploader(
                    "Selecione sua foto de referência" if action == "register" else "Selecione a nova foto de referência",
                    type=['jpg', 'jpeg', 'png'],
                    help="Esta foto será usada para reconhecimento facial nos próximos logins",
                    key="face_upload"
                )
                
                if uploaded_photo:
                    # Preview
                    st.image(uploaded_photo, caption="Foto de referência", use_container_width=True)
                    
                    button_text = "💾 Cadastrar Face" if action == "register" else "🔄 Atualizar Face"
                    
                    if st.button(button_text, use_container_width=True, type="primary"):
                        with st.spinner("🔍 Processando face..."):
                            result = auth_system.register_face(
                                st.session_state['user_id'],
                                uploaded_photo.getvalue()
                            )
                            
                            if result['success']:
                                st.success(result['message'])
                                st.snow()
                                time.sleep(2)
                                st.rerun()
                            else:
                                st.error(result['message'])
            else:
                # Captura por webcam
                try:
                    picture = st.camera_input(
                        "Tire uma foto para cadastro" if action == "register" else "Tire uma nova foto",
                        key="face_camera"
                    )
                    
                    if picture:
                        button_text = "💾 Cadastrar Face" if action == "register" else "🔄 Atualizar Face"
                        
                        if st.button(button_text, use_container_width=True, type="primary"):
                            with st.spinner("🔍 Processando face..."):
                                result = auth_system.register_face(
                                    st.session_state['user_id'],
                                    picture.getvalue()
                                )
                                
                                if result['success']:
                                    st.success(result['message'])
                                    st.snow()
                                    time.sleep(2)
                                    st.rerun()
                                else:
                                    st.error(result['message'])
                except:
                    st.warning("Captura por webcam requer Streamlit >= 1.28.0")
                    st.info("Use o método de upload de foto como alternativa.")
        
        with col2:
            st.markdown("""
            ### 🔐 Segurança Facial
            
            **Como funciona:**
            - Sua foto é processada localmente
            - Apenas características matemáticas são salvas
            - Impossível reconstruir a foto original
            - Dados criptografados no banco
            
            **Privacidade:**
            - Foto salva apenas localmente
            - Não enviada para servidores externos
            - Pode ser deletada a qualquer momento
            
            **Tecnologia:**
            - Biblioteca face_recognition
            - Algoritmo HOG + SVM
            - Tolerância configurável
            - Alta precisão (~99.38%)
            
            **Requisitos da foto:**
            - Rosto claramente visível
            - Boa iluminação
            - Apenas uma pessoa na foto
            - Olhando para a câmera
            """)
    
    # Tab Segurança
    with config_tabs[2]:
        st.subheader("🔐 Configurações de Segurança")
        
        st.markdown("### 🗂️ Dados e Privacidade")
        
        col1, col2 = st.columns(2)
        
        with col1:
            st.markdown("**📊 Dados Armazenados:**")
            
            # Contar conversas
            conversations = auth_system.load_conversations(st.session_state['user_id'])
            st.metric("Conversas salvas", len(conversations))
            
            # Informações sobre face
            has_face = auth_system.has_facial_auth(st.session_state['username'])
            face_status = "Configurado" if has_face else "Não configurado"
            st.metric("Reconhecimento Facial", face_status)
            
        with col2:
            st.markdown("**🔧 Ações:**")
            
            if has_face:
                if st.button("🗑️ Remover Reconhecimento Facial", use_container_width=True):
                    # Remover face do banco
                    conn = sqlite3.connect(auth_system.db_path)
                    cursor = conn.cursor()
                    cursor.execute('''
                        UPDATE users 
                        SET face_encoding = NULL, face_image_path = NULL, facial_auth_enabled = FALSE
                        WHERE id = ?
                    ''', (st.session_state['user_id'],))
                    conn.commit()
                    conn.close()
                    
                    st.success("Reconhecimento facial removido!")
                    st.rerun()
            
            if len(conversations) > 0:
                if st.button("🗑️ Apagar Todas as Conversas", use_container_width=True):
                    # Apagar conversas
                    conn = sqlite3.connect(auth_system.db_path)
                    cursor = conn.cursor()
                    cursor.execute("DELETE FROM conversations WHERE user_id = ?", (st.session_state['user_id'],))
                    conn.commit()
                    conn.close()
                    
                    st.success("Todas as conversas foram apagadas!")
                    st.rerun()
        
        st.markdown("---")
        
        st.markdown("### 🔒 Política de Segurança")
        
        with st.expander("Ver Política de Segurança"):
            st.markdown("""
            **Criptografia:**
            - Senhas são hasheadas com bcrypt
            - Salt único para cada senha
            - Impossível recuperar senha original
            
            **Reconhecimento Facial:**
            - Encodings matemáticos apenas
            - Comparação por distância euclidiana
            - Tolerância ajustável (padrão 0.6)
            
            **Armazenamento:**
            - Banco SQLite local
            - Sem envio para nuvem
            - Controle total dos dados
            
            **Sessões:**
            - Timeout automático após inatividade
            - Logout limpa todos os dados da sessão
            - Histórico de login registrado
            """)
    # NOVA TAB: AI Providers
    with config_tabs[3]:
        st.subheader("🤖 Configuração de AI Providers")
        
        # Mostrar status dos providers
        show_ai_provider_status()
        
        st.markdown("---")
        
        # Configurar modo de operação
        manager = configure_ai_provider_mode()
        
        st.markdown("---")
        
        # Informações sobre os modos
        st.markdown("### 📚 Sobre os Modos de Operação")
        
        with st.expander("ℹ️ Entenda cada modo"):
            st.markdown("""
            **🤖 Auto (Recomendado):**
            - Detecta automaticamente os providers disponíveis
            - Configura o melhor modo baseado nas API keys configuradas
            - Ideal para a maioria dos casos
            
            **🔵 OpenAI Apenas:**
            - Usa exclusivamente OpenAI (GPT-4 e GPT-4 Vision)
            - Modo original do sistema
            - Requer OPENAI_API_KEY
            
            **🟣 Anthropic Apenas:**
            - Usa exclusivamente Anthropic (Claude 3)
            - Alternativa completa ao OpenAI
            - Requer ANTHROPIC_API_KEY
            
            **🔄 Fallback (OpenAI → Anthropic):**
            - Tenta OpenAI primeiro
            - Se falhar, usa Anthropic automaticamente
            - Ideal para alta disponibilidade
            - Requer ambas API keys
            
            **🔀 Redundante (Ambos + Consolidação):**
            - Executa análise em AMBOS providers
            - Consolida resultados para insights mais ricos
            - Maior custo mas maior qualidade
            - Requer ambas API keys
            """)
        st.markdown("---")
        
        # Teste rápido dos providers
        st.markdown("### 🧪 Teste Rápido")
        
        col1, col2 = st.columns(2)
        
        with col1:
            if st.button("🔵 Testar OpenAI", use_container_width=True):
                with st.spinner("Testando OpenAI..."):
                    test_response = manager._chat_openai(
                        [{"role": "user", "content": "Hello, respond with 'OK' if working"}],
                        0.1, 10
                    )
                    if test_response.success:
                        st.success(f"✅ OpenAI funcionando! Resposta: {test_response.content}")
                    else:
                        st.error(f"❌ OpenAI erro: {test_response.error}")
        
        with col2:
            if st.button("🟣 Testar Anthropic", use_container_width=True):
                with st.spinner("Testando Anthropic..."):
                    test_response = manager._chat_anthropic(
                        [{"role": "user", "content": "Hello, respond with 'OK' if working"}],
                        0.1, 10
                    )
                    if test_response.success:
                        st.success(f"✅ Anthropic funcionando! Resposta: {test_response.content}")
                    else:
                        st.error(f"❌ Anthropic erro: {test_response.error}")
        
        # Limpar cache e estatísticas
        st.markdown("---")
        st.markdown("### 🗑️ Manutenção")
        
        if st.button("🔄 Resetar Estatísticas", use_container_width=True):
            manager.stats = {
                'openai_calls': 0,
                'anthropic_calls': 0,
                'openai_failures': 0,
                'anthropic_failures': 0,
                'fallback_used': 0,
                'consolidations': 0
            }
            st.success("Estatísticas resetadas!")
            st.rerun()

# Funções auxiliares para gestão de conversas
def save_current_conversation_to_db():
    """Salva a conversa atual no banco de dados"""
    if len(st.session_state.get('chat_messages', [])) > 1:  # Mais que apenas welcome
        # Criar dados da conversa
        conversation_data = {
            'id': f"conv_{st.session_state.get('conversation_counter', 1)}",
            'timestamp': datetime.now().strftime('%d/%m/%Y %H:%M'),
            'messages': st.session_state['chat_messages'].copy(),
            'analysis_context': st.session_state.get('analysis_result', {}).get('image_info', {}).get('filename', 'N/A'),
            'message_count': len(st.session_state['chat_messages']) - 1  # Excluir welcome message
        }
        
        # Salvar no banco de dados
        auth_system.save_conversation(st.session_state['user_id'], conversation_data)
        
        # Incrementar contador
        st.session_state['conversation_counter'] = st.session_state.get('conversation_counter', 1) + 1
        
        return True
    return False


def clear_analysis_states():
    """Limpa todos os estados relacionados à análise atual"""
    # Limpar resultado da análise
    st.session_state['analysis_result'] = None
    
    # Limpar timestamp da análise
    if 'analysis_timestamp' in st.session_state:
        del st.session_state['analysis_timestamp']
    
    # Limpar mensagens do chat atual
    if 'chat_messages' in st.session_state:
        del st.session_state['chat_messages']
    
    # Incrementar key do file_uploader para forçar reset
    if 'uploaded_file_key' not in st.session_state:
        st.session_state['uploaded_file_key'] = 0
    st.session_state['uploaded_file_key'] += 1


def create_conversation_manager_db():
    """Gerenciador de conversas salvas no banco de dados com interface moderna"""
    st.markdown("### 💾 Conversas Persistentes")
    
    # Carregar conversas do banco
    saved_conversations = auth_system.load_conversations(st.session_state['user_id'])
    
    if not saved_conversations:
        st.info("Nenhuma conversa salva no banco ainda")
    else:
        st.markdown(f"**{len(saved_conversations)} conversa(s) salva(s) permanentemente**")
        
        # Listar conversas salvas com interface moderna
        for i, conv in enumerate(saved_conversations):
            # Criar key única
            unique_key_base = f"{st.session_state['user_id']}_{i}_{conv['id'].replace('conv_', '')}"
            
            # Container para cada conversa
            conv_container = st.container()
            
            with conv_container:
                # Criar colunas para layout
                col_main, col_menu = st.columns([10, 1])
                
                with col_main:
                    # Botão principal para carregar conversa (ocupa toda a área)
                    if st.button(
                        f"💬 {conv['timestamp']}\n📄 {conv['analysis_context']}\n💭 {conv['message_count']} mensagens",
                        key=f"load_conv_{unique_key_base}",
                        use_container_width=True,
                        help="Clique para carregar esta conversa"
                    ):
                        load_conversation_from_db(conv)
                
                with col_menu:
                    # Menu de 3 pontinhos
                    menu_key = f"menu_{unique_key_base}"
                    if st.button("⋮", key=menu_key, help="Opções da conversa"):
                        # Toggle do estado do menu
                        menu_state_key = f"show_menu_{unique_key_base}"
                        st.session_state[menu_state_key] = not st.session_state.get(menu_state_key, False)
                        st.rerun()
                
                # Mostrar menu dropdown se ativo
                menu_state_key = f"show_menu_{unique_key_base}"
                if st.session_state.get(menu_state_key, False):
                    with st.container():
                        col_delete, col_close = st.columns([3, 1])
                        
                        with col_delete:
                            if st.button("🗑️ Deletar conversa", 
                                        key=f"delete_conv_{unique_key_base}", 
                                        use_container_width=True,
                                        type="secondary"):
                                # Confirmar deleção
                                st.session_state[f"confirm_delete_{unique_key_base}"] = True
                                st.session_state[menu_state_key] = False
                                st.rerun()
                        
                        with col_close:
                            if st.button("✕", key=f"close_menu_{unique_key_base}", help="Fechar menu"):
                                st.session_state[menu_state_key] = False
                                st.rerun()
                
                # Modal de confirmação de deleção
                confirm_key = f"confirm_delete_{unique_key_base}"
                if st.session_state.get(confirm_key, False):
                    st.warning(f"⚠️ Confirmar deleção da conversa de {conv['timestamp']}?")
                    col_yes, col_no = st.columns(2)
                    
                    with col_yes:
                        if st.button("✅ Sim, deletar", key=f"confirm_yes_{unique_key_base}", type="primary"):
                            delete_conversation_from_db(conv['id'])
                            st.session_state[confirm_key] = False
                            st.success(f"Conversa de {conv['timestamp']} deletada!")
                            st.rerun()
                    
                    with col_no:
                        if st.button("❌ Cancelar", key=f"confirm_no_{unique_key_base}"):
                            st.session_state[confirm_key] = False
                            st.rerun()
        
        # Botão para limpar todas (com confirmação)
        if len(saved_conversations) > 1:
            st.markdown("---")
            
            if not st.session_state.get('confirm_delete_all', False):
                if st.button("🗑️ Apagar Todas as Conversas", 
                            key=f"delete_all_btn_{st.session_state['user_id']}", 
                            use_container_width=True,
                            type="secondary"):
                    st.session_state['confirm_delete_all'] = True
                    st.rerun()
            else:
                st.warning("⚠️ Confirmar deleção de TODAS as conversas?")
                col_yes, col_no = st.columns(2)
                
                with col_yes:
                    if st.button("✅ Sim, deletar todas", 
                                key=f"confirm_delete_all_yes_{st.session_state['user_id']}", 
                                type="primary"):
                        # Apagar todas as conversas do usuário
                        conn = sqlite3.connect(auth_system.db_path)
                        cursor = conn.cursor()
                        cursor.execute("DELETE FROM conversations WHERE user_id = ?", (st.session_state['user_id'],))
                        conn.commit()
                        conn.close()
                        
                        st.session_state['confirm_delete_all'] = False
                        st.success("Todas as conversas foram apagadas do banco de dados!")
                        st.rerun()
                
                with col_no:
                    if st.button("❌ Cancelar", key=f"confirm_delete_all_no_{st.session_state['user_id']}"):
                        st.session_state['confirm_delete_all'] = False
                        st.rerun()


def load_conversation_from_db(conv_data):
    """Carrega uma conversa salva do banco de dados"""
    # Carregar mensagens
    st.session_state['chat_messages'] = conv_data['messages'].copy()
    
    st.success(f"💾 Conversa de {conv_data['timestamp']} carregada do banco! Vá para aba 'Chat'.")
    st.rerun()


def delete_conversation_from_db(conversation_id: str):
    """Apaga uma conversa específica do banco de dados"""
    auth_system.delete_conversation(st.session_state['user_id'], conversation_id)
    st.success(f"🗑️ Conversa {conversation_id} apagada do banco!")
    st.rerun()


def create_enhanced_sidebar():
    """Sidebar melhorada sem botões de face (movidos para aba Config)"""
    with st.sidebar:
        # Header com usuário logado
        st.markdown(f"### 👤 Logado como: **{st.session_state['username']}**")
        
        # Mostrar método de autenticação usado
        auth_method = st.session_state.get('auth_method', 'credentials')
        auth_emoji = "🔑" if auth_method == 'credentials' else "📸"
        st.caption(f"{auth_emoji} Via: {auth_method.title()}")
        
        # Botão de logout
        if st.button("🚪 Logout", use_container_width=True):
            # Limpar dados de sessão
            for key in list(st.session_state.keys()):
                del st.session_state[key]
            st.rerun()
        
        st.markdown("---")
        st.markdown("### ⚙️ Configurações - Análise")
        
        # ADICIONAR: Status do AI Provider
        st.markdown("**🤖 AI Provider:**")
        manager = get_ai_provider_manager()
        status = manager.get_status()
        
        if status['mode'] == 'redundant':
            st.info("🔀 Modo Redundante")
        elif status['mode'] == 'fallback':
            st.info("🔄 Modo Fallback")
        elif status['mode'] == 'openai_only':
            st.info("🔵 OpenAI")
        elif status['mode'] == 'anthropic_only':
            st.info("🟣 Anthropic")
        else:
            st.info("🤖 Auto")
        
        # Mostrar pequenas estatísticas
        if status['stats']['openai_calls'] > 0 or status['stats']['anthropic_calls'] > 0:
            with st.expander("📊 Uso de AI", expanded=False):
                st.caption(f"OpenAI: {status['stats']['openai_calls']} calls")
                st.caption(f"Anthropic: {status['stats']['anthropic_calls']} calls")
                if status['stats']['fallback_used'] > 0:
                    st.caption(f"Fallbacks: {status['stats']['fallback_used']}")
                if status['stats']['consolidations'] > 0:
                    st.caption(f"Consolidações: {status['stats']['consolidations']}")
        
        # Status das dependências
        st.markdown("**📊 Status das Dependências:**")
        
        deps_status = []
        deps_status.append(("OpenCV", CV2_AVAILABLE))
        deps_status.append(("OCR", OCR_AVAILABLE))  
        deps_status.append(("OpenAI", OPENAI_AVAILABLE and os.getenv('OPENAI_API_KEY')))
        deps_status.append(("Plotly", PLOTLY_AVAILABLE))
        deps_status.append(("Face Recognition", FACE_RECOGNITION_AVAILABLE))
        
        for dep, available in deps_status:
            status_emoji = "🟢" if available else "🔴"
            st.write(f"{status_emoji} {dep}")
        
        if not all(status for _, status in deps_status[:2]):  # OpenCV e OCR são essenciais
            st.warning("⚠️ Instale dependências para análise completa")
            with st.expander("Ver comandos de instalação"):
                st.code("""
# Análise de imagem
pip install opencv-python
pip install pytesseract
pip install pillow

# Autenticação
pip install bcrypt

# Reconhecimento facial
pip install cmake
pip install dlib
pip install face-recognition
""")
        
        st.markdown("---")
        
        # Informações da sessão atual
        if st.session_state.get('analysis_result'):
            result = st.session_state['analysis_result']
            filename = result.get('image_info', {}).get('filename', 'N/A')
            components_count = len(result.get('detected_components', []))
            threats_count = len(result.get('threats', []))
            
            st.success("✅ Análise Ativa")
            st.markdown(f"""
            **📊 Análise Atual:**
            - **Imagem:** {filename}
            - **Componentes:** {components_count} (real)
            - **Ameaças:** {threats_count} (proporcional)
            - **Risk Score:** {result.get('risk_score', 0)}/10
            - **Métodos:** Multi-modal
            """)
            
            # Botão Nova Análise
            if st.button("🔄 Nova Análise", use_container_width=True, type="primary"):
                # Salvar conversa atual se houver
                saved = save_current_conversation_to_db()
                
                # Limpar estados para nova análise
                clear_analysis_states()
                
                # Forçar redirecionamento para aba de análise
                st.session_state['redirect_to_analysis'] = True
                
                # Mostrar feedback
                if saved:
                    st.success("💾 Conversa salva no banco de dados!")
                else:
                    st.info("🔄 Campos limpos para nova análise!")
                
                st.rerun()
        else:
            st.info("ℹ️ Nenhuma análise ativa")
            
        st.markdown("---")
        
        # Gestão de Conversas Salvas no Banco
        create_conversation_manager_db()
        
        st.markdown("---")
        
        # Melhorias implementadas
        st.markdown("### ✨ Sistema Atualizado")
        st.markdown("""
        **🔐 Login Implementado:**
        - ✅ SQLite para persistência
        - ✅ Senhas criptografadas (bcrypt)
        - ✅ Conversas salvas permanentemente
        - 📸 Reconhecimento Facial
        
        **⚙️ Nova Aba Config:**
        - ✅ Gerenciamento de perfil
        - ✅ Cadastro/atualização de face
        - ✅ Configurações de segurança
        - ✅ Estatísticas de login
        """)


def main():
    """Função principal com sistema de autenticação e nova aba Config"""
    # Verificar autenticação
    if not check_authentication():
        return
    
    # Injetar CSS
    inject_custom_css()
    
    # Inicializar estados da sessão autenticada
    if 'analysis_result' not in st.session_state:
        st.session_state['analysis_result'] = None
    if 'conversation_counter' not in st.session_state:
        st.session_state['conversation_counter'] = 1
    if 'uploaded_file_key' not in st.session_state:
        st.session_state['uploaded_file_key'] = 0
    
    # Tabs principais - Agora com aba Config
    tabs = st.tabs(["🏠 Home", "🔍 Análise", "💬 Chat with Architecture", "📄 Relatórios", "⚙️ Config"])
    
    # Verificar se deve redirecionar para análise
    if st.session_state.get('redirect_to_analysis', False):
        st.session_state['redirect_to_analysis'] = False
    
    with tabs[0]:
        create_home_tab()
    
    with tabs[1]:
        create_analysis_tab()
    
    with tabs[2]:
        create_chat_tab()
    
    with tabs[3]:
        create_reports_tab()
    
    with tabs[4]:
        create_config_tab()  # Nova aba Config
    
    # Sidebar melhorada sem botões de face
    create_enhanced_sidebar()


if __name__ == "__main__":
    main()