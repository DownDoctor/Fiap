# api_bridge.py
from stride_analyzer_enhanced import RealSTRIDEAnalyzer

def analyze_for_api(image_bytes, filename):
    """Bridge entre API e Streamlit analyzer"""
    
    class FakeFile:
        def __init__(self, data, name):
            self.name = name
            self.data = data
        def getvalue(self):
            return self.data
    
    analyzer = RealSTRIDEAnalyzer()
    fake = FakeFile(image_bytes, filename)
    
    return analyzer.analyze_image(fake, use_yolo=False, use_vision=False)