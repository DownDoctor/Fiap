# vector_database_enhanced.py
"""
Sistema de banco vetorial com RAG aprimorado para Chat with Architecture
Suporta múltiplos modelos de embedding e estratégias de busca
"""

import chromadb
from chromadb.config import Settings
from sentence_transformers import SentenceTransformer
import numpy as np
from typing import List, Dict, Optional, Tuple, Any
import json
from pathlib import Path
import hashlib
from datetime import datetime
import pickle
import faiss
from sklearn.preprocessing import normalize
import torch

class EnhancedVectorDB:
    """Banco vetorial com funcionalidades avançadas de RAG"""
    
    def __init__(self, persist_path: str = "./chroma_db_enhanced"):
        self.persist_path = Path(persist_path)
        self.persist_path.mkdir(exist_ok=True)
        
        # Cliente ChromaDB com configurações otimizadas
        self.client = chromadb.PersistentClient(
            path=str(self.persist_path),
            settings=Settings(
                anonymized_telemetry=False,
                allow_reset=True
            )
        )
        
        # Múltiplos modelos de embedding para diferentes contextos
        self.encoders = {
            'general': SentenceTransformer('all-mpnet-base-v2'),
            'technical': SentenceTransformer('sentence-transformers/all-MiniLM-L12-v2'),
            'multilingual': SentenceTransformer('sentence-transformers/paraphrase-multilingual-MiniLM-L12-v2')
        }
        
        # Encoder principal
        self.encoder = self.encoders['general']
        
        # Criar coleções especializadas
        self.collections = self._initialize_collections()
        
        # Cache de embeddings
        self.embedding_cache = {}
        
        # Índice FAISS para busca rápida
        self.faiss_indices = {}
        
        # Carregar knowledge base
        self._load_knowledge_base()
    
    def _initialize_collections(self) -> Dict:
        """Inicializa coleções especializadas"""
        collections = {
            'architecture': {
                'name': 'architecture_components',
                'description': 'Componentes e padrões de arquitetura'
            },
            'threats': {
                'name': 'stride_threats',
                'description': 'Ameaças STRIDE e vulnerabilidades'
            },
            'mitigations': {
                'name': 'security_mitigations',
                'description': 'Mitigações e controles de segurança'
            },
            'compliance': {
                'name': 'compliance_requirements',
                'description': 'Requisitos de compliance (SOC2, GDPR, etc)'
            },
            'best_practices': {
                'name': 'cloud_best_practices',
                'description': 'Best practices para AWS, Azure, GCP'
            },
            'patterns': {
                'name': 'architecture_patterns',
                'description': 'Padrões arquiteturais e anti-patterns'
            },
            'analysis_history': {
                'name': 'analysis_history',
                'description': 'Histórico de análises realizadas'
            }
        }
        
        initialized = {}
        for key, config in collections.items():
            initialized[key] = self._get_or_create_collection(
                config['name'],
                config['description']
            )
        
        return initialized
    
    def _get_or_create_collection(self, name: str, description: str):
        """Cria ou obtém coleção com configuração otimizada"""
        try:
            collection = self.client.get_collection(name=name)
            print(f"✓ Coleção '{name}' carregada")
        except:
            collection = self.client.create_collection(
                name=name,
                metadata={
                    "hnsw:space": "cosine",
                    "hnsw:construction_ef": 200,
                    "hnsw:M": 16,
                    "description": description
                }
            )
            print(f"✓ Coleção '{name}' criada")
        
        return collection
    
    def _load_knowledge_base(self):
        """Carrega knowledge base pré-definida"""
        kb_path = self.persist_path / "knowledge_base"
        kb_path.mkdir(exist_ok=True)
        
        # Carregar dados STRIDE
        self._load_stride_knowledge()
        
        # Carregar best practices
        self._load_cloud_best_practices()
        
        # Carregar padrões de compliance
        self._load_compliance_patterns()
        
        print("✓ Knowledge base carregada")
    
    def _load_stride_knowledge(self):
        """Carrega conhecimento sobre STRIDE"""
        stride_threats = [
            {
                "category": "Spoofing",
                "description": "Falsificação de identidade ou autenticação",
                "common_vectors": ["Token theft", "Session hijacking", "Credential stuffing"],
                "mitigations": ["MFA", "Strong authentication", "Certificate pinning"],
                "cloud_specific": {
                    "aws": ["IAM roles", "Cognito", "STS tokens"],
                    "azure": ["Azure AD", "Managed Identity", "Key Vault"],
                    "gcp": ["Cloud IAM", "Service accounts", "Workload Identity"]
                }
            },
            {
                "category": "Tampering",
                "description": "Modificação não autorizada de dados",
                "common_vectors": ["Man-in-the-middle", "Data injection", "Code injection"],
                "mitigations": ["Input validation", "Integrity checks", "Code signing"],
                "cloud_specific": {
                    "aws": ["CloudTrail", "Config Rules", "GuardDuty"],
                    "azure": ["Azure Policy", "Azure Monitor", "Sentinel"],
                    "gcp": ["Cloud Audit Logs", "Binary Authorization", "Cloud Security Scanner"]
                }
            },
            {
                "category": "Repudiation",
                "description": "Negação de ações realizadas",
                "common_vectors": ["Log tampering", "Audit trail deletion"],
                "mitigations": ["Immutable logs", "Centralized logging", "Digital signatures"],
                "cloud_specific": {
                    "aws": ["CloudWatch Logs", "CloudTrail with S3 MFA delete"],
                    "azure": ["Azure Log Analytics", "Immutable storage"],
                    "gcp": ["Cloud Logging", "Access Transparency"]
                }
            },
            {
                "category": "Information Disclosure",
                "description": "Exposição não autorizada de informações",
                "common_vectors": ["Data leaks", "Misconfigured storage", "Verbose errors"],
                "mitigations": ["Encryption at rest/transit", "Access controls", "Data classification"],
                "cloud_specific": {
                    "aws": ["KMS", "Secrets Manager", "S3 encryption"],
                    "azure": ["Azure Key Vault", "Storage encryption", "Information Protection"],
                    "gcp": ["Cloud KMS", "Secret Manager", "DLP API"]
                }
            },
            {
                "category": "Denial of Service",
                "description": "Indisponibilidade do serviço",
                "common_vectors": ["Resource exhaustion", "DDoS attacks", "API abuse"],
                "mitigations": ["Rate limiting", "Auto-scaling", "DDoS protection"],
                "cloud_specific": {
                    "aws": ["AWS Shield", "WAF", "Auto Scaling", "API Gateway throttling"],
                    "azure": ["Azure DDoS Protection", "Front Door", "Traffic Manager"],
                    "gcp": ["Cloud Armor", "Load Balancing", "Cloud CDN"]
                }
            },
            {
                "category": "Elevation of Privilege",
                "description": "Obtenção de privilégios não autorizados",
                "common_vectors": ["Privilege escalation", "Role assumption", "Container escape"],
                "mitigations": ["Least privilege", "Role separation", "Regular audits"],
                "cloud_specific": {
                    "aws": ["IAM policies", "SCPs", "Permission boundaries"],
                    "azure": ["RBAC", "PIM", "Azure Policy"],
                    "gcp": ["IAM conditions", "Organization policies", "Binary Authorization"]
                }
            }
        ]
        
        # Adicionar ao banco vetorial
        for threat in stride_threats:
            self.add_document(
                collection='threats',
                document=json.dumps(threat),
                metadata={
                    'category': threat['category'],
                    'type': 'stride_threat',
                    'timestamp': datetime.now().isoformat()
                },
                document_id=f"stride_{threat['category'].lower()}"
            )
    
    def _load_cloud_best_practices(self):
        """Carrega best practices para clouds"""
        best_practices = [
            {
                "provider": "AWS",
                "category": "Security",
                "practices": [
                    "Enable MFA for root account",
                    "Use IAM roles instead of access keys",
                    "Enable CloudTrail in all regions",
                    "Implement SCPs for organization-wide policies",
                    "Use AWS Config for compliance monitoring",
                    "Enable GuardDuty for threat detection",
                    "Implement VPC flow logs",
                    "Use Systems Manager for patch management"
                ]
            },
            {
                "provider": "Azure",
                "category": "Security",
                "practices": [
                    "Enable Azure Security Center",
                    "Use Managed Identities",
                    "Implement Azure Policy",
                    "Enable Azure Sentinel",
                    "Use Key Vault for secrets",
                    "Implement Just-In-Time VM access",
                    "Enable Azure Defender",
                    "Use Private Endpoints"
                ]
            },
            {
                "provider": "GCP",
                "category": "Security",
                "practices": [
                    "Enable Security Command Center",
                    "Use Workload Identity",
                    "Implement Organization Policies",
                    "Enable Cloud Asset Inventory",
                    "Use VPC Service Controls",
                    "Implement Binary Authorization",
                    "Enable Cloud Armor",
                    "Use Private Google Access"
                ]
            }
        ]
        
        for practice in best_practices:
            self.add_document(
                collection='best_practices',
                document=json.dumps(practice),
                metadata={
                    'provider': practice['provider'],
                    'category': practice['category'],
                    'type': 'best_practice'
                },
                document_id=f"bp_{practice['provider'].lower()}_{practice['category'].lower()}"
            )
    
    def _load_compliance_patterns(self):
        """Carrega padrões de compliance"""
        compliance_frameworks = [
            {
                "framework": "SOC2",
                "controls": {
                    "CC6.1": "Logical and Physical Access Controls",
                    "CC6.2": "Prior to Issuing System Credentials",
                    "CC6.3": "Role-Based Access Control",
                    "CC6.6": "Encryption of Data",
                    "CC6.7": "Transmission of Sensitive Data",
                    "CC7.1": "Configuration and Monitoring",
                    "CC7.2": "System Monitoring"
                },
                "cloud_mappings": {
                    "aws": ["IAM", "CloudTrail", "KMS", "VPC", "Security Groups"],
                    "azure": ["Azure AD", "Key Vault", "NSG", "Azure Monitor"],
                    "gcp": ["Cloud IAM", "Cloud KMS", "VPC", "Cloud Monitoring"]
                }
            },
            {
                "framework": "GDPR",
                "requirements": [
                    "Data minimization",
                    "Purpose limitation",
                    "Consent management",
                    "Right to erasure",
                    "Data portability",
                    "Privacy by design",
                    "Breach notification (72 hours)"
                ],
                "technical_controls": [
                    "Encryption",
                    "Pseudonymization",
                    "Access controls",
                    "Audit logging",
                    "Data classification"
                ]
            }
        ]
        
        for framework in compliance_frameworks:
            self.add_document(
                collection='compliance',
                document=json.dumps(framework),
                metadata={
                    'framework': framework['framework'],
                    'type': 'compliance_framework'
                },
                document_id=f"compliance_{framework['framework'].lower()}"
            )
    
    def add_document(self, collection: str, document: str, 
                    metadata: Dict = None, document_id: str = None) -> str:
        """Adiciona documento ao banco vetorial"""
        if collection not in self.collections:
            raise ValueError(f"Collection '{collection}' não existe")
        
        # Gerar ID se não fornecido
        if document_id is None:
            document_id = hashlib.md5(document.encode()).hexdigest()
        
        # Gerar embedding
        embedding = self._get_embedding(document)
        
        # Adicionar ao ChromaDB
        self.collections[collection].add(
            embeddings=[embedding.tolist()],
            documents=[document],
            metadatas=[metadata or {}],
            ids=[document_id]
        )
        
        # Invalidar cache FAISS
        if collection in self.faiss_indices:
            del self.faiss_indices[collection]
        
        return document_id
    
    def _get_embedding(self, text: str, encoder_type: str = 'general') -> np.ndarray:
        """Gera embedding com cache"""
        cache_key = hashlib.md5(f"{text}_{encoder_type}".encode()).hexdigest()
        
        if cache_key in self.embedding_cache:
            return self.embedding_cache[cache_key]
        
        encoder = self.encoders.get(encoder_type, self.encoder)
        embedding = encoder.encode(text, convert_to_numpy=True)
        
        # Normalizar para cosine similarity
        embedding = normalize(embedding.reshape(1, -1))[0]
        
        self.embedding_cache[cache_key] = embedding
        return embedding
    
    def search(self, query: str, collection: str = None, 
              k: int = 5, filters: Dict = None,
              use_reranking: bool = True) -> List[Dict]:
        """Busca semântica com reranking opcional"""
        
        # Se collection não especificada, buscar em todas
        if collection is None:
            all_results = []
            for coll_name in self.collections.keys():
                results = self.search(query, coll_name, k, filters, False)
                all_results.extend(results)
            
            # Reranking global
            if use_reranking and all_results:
                all_results = self._rerank_results(query, all_results, k)
            
            return all_results[:k]
        
        if collection not in self.collections:
            raise ValueError(f"Collection '{collection}' não existe")
        
        # Gerar embedding da query
        query_embedding = self._get_embedding(query)
        
        # Buscar no ChromaDB
        results = self.collections[collection].query(
            query_embeddings=[query_embedding.tolist()],
            n_results=k * 2 if use_reranking else k,
            where=filters
        )
        
        # Processar resultados
        processed_results = []
        if results['documents'] and results['documents'][0]:
            for i, doc in enumerate(results['documents'][0]):
                processed_results.append({
                    'document': doc,
                    'metadata': results['metadatas'][0][i] if results['metadatas'] else {},
                    'distance': results['distances'][0][i] if results['distances'] else 0,
                    'collection': collection
                })
        
        # Reranking se solicitado
        if use_reranking and processed_results:
            processed_results = self._rerank_results(query, processed_results, k)
        
        return processed_results[:k]
    
    def _rerank_results(self, query: str, results: List[Dict], k: int) -> List[Dict]:
        """Reranking usando cross-encoder ou modelo mais sofisticado"""
        try:
            from sentence_transformers import CrossEncoder
            
            # Usar cross-encoder para reranking
            reranker = CrossEncoder('cross-encoder/ms-marco-MiniLM-L-6-v2')
            
            # Preparar pares query-documento
            pairs = [[query, r['document']] for r in results]
            
            # Calcular scores
            scores = reranker.predict(pairs)
            
            # Reordenar por score
            for i, result in enumerate(results):
                result['rerank_score'] = float(scores[i])
            
            results.sort(key=lambda x: x.get('rerank_score', 0), reverse=True)
            
        except ImportError:
            # Fallback: usar similarity original
            results.sort(key=lambda x: x.get('distance', float('inf')))
        
        return results
    
    def hybrid_search(self, query: str, collection: str = None,
                     k: int = 5, alpha: float = 0.5) -> List[Dict]:
        """Busca híbrida: semântica + keyword"""
        # Busca semântica
        semantic_results = self.search(query, collection, k * 2, use_reranking=False)
        
        # Busca por keywords (BM25-like)
        keyword_results = self._keyword_search(query, collection, k * 2)
        
        # Combinar resultados com peso alpha
        combined = {}
        
        for i, result in enumerate(semantic_results):
            doc_id = hashlib.md5(result['document'].encode()).hexdigest()
            if doc_id not in combined:
                combined[doc_id] = {
                    'result': result,
                    'semantic_rank': i,
                    'keyword_rank': float('inf'),
                    'score': 0
                }
            combined[doc_id]['semantic_rank'] = i
        
        for i, result in enumerate(keyword_results):
            doc_id = hashlib.md5(result['document'].encode()).hexdigest()
            if doc_id not in combined:
                combined[doc_id] = {
                    'result': result,
                    'semantic_rank': float('inf'),
                    'keyword_rank': i,
                    'score': 0
                }
            combined[doc_id]['keyword_rank'] = i
        
        # Calcular score híbrido
        for doc_id, data in combined.items():
            semantic_score = 1 / (1 + data['semantic_rank'])
            keyword_score = 1 / (1 + data['keyword_rank'])
            data['score'] = alpha * semantic_score + (1 - alpha) * keyword_score
        
        # Ordenar por score
        sorted_results = sorted(combined.values(), key=lambda x: x['score'], reverse=True)
        
        return [r['result'] for r in sorted_results[:k]]
    
    def _keyword_search(self, query: str, collection: str = None, k: int = 5) -> List[Dict]:
        """Busca por palavras-chave (implementação simplificada)"""
        results = []
        query_terms = set(query.lower().split())
        
        collections_to_search = [collection] if collection else self.collections.keys()
        
        for coll_name in collections_to_search:
            coll = self.collections[coll_name]
            
            # Buscar todos os documentos (limitado para performance)
            all_docs = coll.get(limit=1000)
            
            if all_docs['documents']:
                for i, doc in enumerate(all_docs['documents']):
                    doc_terms = set(doc.lower().split())
                    
                    # Calcular overlap
                    overlap = len(query_terms & doc_terms)
                    
                    if overlap > 0:
                        results.append({
                            'document': doc,
                            'metadata': all_docs['metadatas'][i] if all_docs['metadatas'] else {},
                            'collection': coll_name,
                            'keyword_score': overlap / len(query_terms)
                        })
        
        # Ordenar por score
        results.sort(key=lambda x: x['keyword_score'], reverse=True)
        
        return results[:k]
    
    def add_analysis_to_history(self, analysis_result: Dict) -> str:
        """Adiciona resultado de análise ao histórico para futuras consultas"""
        # Processar resultado para extração de informações relevantes
        processed = self._process_analysis_result(analysis_result)
        
        # Criar documento consolidado
        document = json.dumps({
            'timestamp': datetime.now().isoformat(),
            'architecture_type': processed.get('architecture_type'),
            'components': processed.get('components'),
            'threats': processed.get('threats'),
            'recommendations': processed.get('recommendations'),
            'risk_score': processed.get('risk_score')
        })
        
        # Adicionar ao histórico
        doc_id = self.add_document(
            collection='analysis_history',
            document=document,
            metadata={
                'timestamp': datetime.now().isoformat(),
                'architecture_type': processed.get('architecture_type', 'unknown'),
                'risk_score': processed.get('risk_score', 0),
                'total_threats': len(processed.get('threats', []))
            }
        )
        
        # Indexar componentes individuais
        for component in processed.get('components', []):
            self.add_document(
                collection='architecture',
                document=json.dumps(component),
                metadata={
                    'analysis_id': doc_id,
                    'component_type': component.get('type'),
                    'provider': component.get('provider')
                }
            )
        
        # Indexar threats individuais
        for threat in processed.get('threats', []):
            self.add_document(
                collection='threats',
                document=json.dumps(threat),
                metadata={
                    'analysis_id': doc_id,
                    'severity': threat.get('severity'),
                    'stride_category': threat.get('category')
                }
            )
        
        return doc_id
    
    def _process_analysis_result(self, result: Dict) -> Dict:
        """Processa resultado de análise para extração de informações"""
        processed = {
            'architecture_type': result.get('architecture_analysis', {}).get('type'),
            'components': [],
            'threats': [],
            'recommendations': [],
            'risk_score': 0
        }
        
        # Extrair componentes
        if 'components_detected' in result:
            processed['components'] = result['components_detected']
        
        # Extrair threats
        stride_analysis = result.get('stride_analysis', {})
        if 'top_threats' in stride_analysis:
            processed['threats'] = stride_analysis['top_threats']
        
        # Extrair recommendations
        if 'recommendations' in result:
            processed['recommendations'] = result['recommendations']
        
        # Extrair risk score
        if 'risk_assessment' in result:
            processed['risk_score'] = result['risk_assessment'].get('overall_risk_score', 0)
        
        return processed
    
    def get_relevant_context(self, query: str, analysis_result: Dict = None,
                            k: int = 5, use_hybrid: bool = True) -> List[Dict]:
        """Obtém contexto relevante para responder queries sobre análise"""
        contexts = []
        
        # Se há resultado de análise, adicionar ao contexto
        if analysis_result:
            # Extrair informações relevantes da análise
            analysis_context = {
                'document': json.dumps(self._process_analysis_result(analysis_result)),
                'metadata': {'type': 'current_analysis'},
                'distance': 0,
                'collection': 'current'
            }
            contexts.append(analysis_context)
        
        # Buscar informações relevantes
        if use_hybrid:
            search_results = self.hybrid_search(query, k=k)
        else:
            search_results = self.search(query, k=k)
        
        contexts.extend(search_results)
        
        # Enriquecer com conhecimento específico
        enriched_contexts = self._enrich_contexts(contexts, query)
        
        return enriched_contexts
    
    def _enrich_contexts(self, contexts: List[Dict], query: str) -> List[Dict]:
        """Enriquece contextos com informações adicionais relevantes"""
        enriched = []
        
        for context in contexts:
            enriched_context = context.copy()
            
            # Adicionar informações relacionadas baseadas no tipo
            metadata = context.get('metadata', {})
            
            if metadata.get('type') == 'stride_threat':
                # Buscar mitigações relacionadas
                category = metadata.get('category')
                mitigations = self.search(
                    f"mitigation for {category}",
                    collection='mitigations',
                    k=2
                )
                enriched_context['related_mitigations'] = mitigations
            
            elif metadata.get('type') == 'best_practice':
                # Buscar compliance relacionado
                provider = metadata.get('provider')
                compliance = self.search(
                    f"compliance for {provider}",
                    collection='compliance',
                    k=2
                )
                enriched_context['related_compliance'] = compliance
            
            enriched.append(enriched_context)
        
        return enriched
    
    def build_faiss_index(self, collection: str):
        """Constrói índice FAISS para busca ultra-rápida"""
        if collection not in self.collections:
            raise ValueError(f"Collection '{collection}' não existe")
        
        # Obter todos os embeddings
        coll = self.collections[collection]
        data = coll.get(include=['embeddings', 'documents', 'metadatas'])
        
        if not data['embeddings']:
            return
        
        embeddings = np.array(data['embeddings'], dtype=np.float32)
        
        # Criar índice FAISS
        dimension = embeddings.shape[1]
        index = faiss.IndexFlatIP(dimension)  # Inner product (para cosine similarity com vetores normalizados)
        
        # Normalizar e adicionar ao índice
        faiss.normalize_L2(embeddings)
        index.add(embeddings)
        
        # Armazenar índice e metadados
        self.faiss_indices[collection] = {
            'index': index,
            'documents': data['documents'],
            'metadatas': data['metadatas']
        }
        
        print(f"✓ Índice FAISS criado para '{collection}' com {len(data['documents'])} documentos")
    
    def export_collection(self, collection: str, output_path: str):
        """Exporta coleção para arquivo"""
        if collection not in self.collections:
            raise ValueError(f"Collection '{collection}' não existe")
        
        data = self.collections[collection].get(
            include=['embeddings', 'documents', 'metadatas']
        )
        
        output_path = Path(output_path)
        output_path.parent.mkdir(parents=True, exist_ok=True)
        
        with open(output_path, 'wb') as f:
            pickle.dump(data, f)
        
        print(f"✓ Collection '{collection}' exportada para {output_path}")
    
    def import_collection(self, collection: str, input_path: str):
        """Importa coleção de arquivo"""
        input_path = Path(input_path)
        
        if not input_path.exists():
            raise FileNotFoundError(f"Arquivo não encontrado: {input_path}")
        
        with open(input_path, 'rb') as f:
            data = pickle.load(f)
        
        # Adicionar dados à coleção
        if data['documents']:
            self.collections[collection].add(
                embeddings=data['embeddings'],
                documents=data['documents'],
                metadatas=data['metadatas'],
                ids=[f"imported_{i}" for i in range(len(data['documents']))]
            )
        
        print(f"✓ Collection '{collection}' importada de {input_path}")
    
    def get_statistics(self) -> Dict:
        """Retorna estatísticas do banco vetorial"""
        stats = {
            'total_documents': 0,
            'collections': {}
        }
        
        for name, collection in self.collections.items():
            count = collection.count()
            stats['collections'][name] = count
            stats['total_documents'] += count
        
        stats['cache_size'] = len(self.embedding_cache)
        stats['faiss_indices'] = list(self.faiss_indices.keys())
        
        return stats


class RAGChatEngine:
    """Motor de chat com RAG para análises STRIDE"""
    
    def __init__(self, vector_db: EnhancedVectorDB):
        self.vector_db = vector_db
        self.conversation_history = []
        self.max_history = 10
    
    def chat(self, query: str, analysis_result: Dict = None,
            use_openai: bool = True, model: str = "gpt-4o-mini") -> str:
        """Processa query do usuário com contexto RAG"""
        
        # Obter contexto relevante
        contexts = self.vector_db.get_relevant_context(
            query=query,
            analysis_result=analysis_result,
            k=5,
            use_hybrid=True
        )
        
        # Preparar prompt
        prompt = self._build_prompt(query, contexts)
        
        # Gerar resposta
        if use_openai:
            response = self._generate_openai_response(prompt, model)
        else:
            response = self._generate_local_response(prompt, contexts)
        
        # Adicionar ao histórico
        self.conversation_history.append({
            'query': query,
            'response': response,
            'timestamp': datetime.now().isoformat()
        })
        
        # Manter histórico limitado
        if len(self.conversation_history) > self.max_history:
            self.conversation_history.pop(0)
        
        return response
    
    def _build_prompt(self, query: str, contexts: List[Dict]) -> str:
        """Constrói prompt com contexto"""
        prompt = "Você é um especialista em segurança cloud e análise STRIDE.\n\n"
        
        # Adicionar contextos relevantes
        prompt += "CONTEXTO RELEVANTE:\n"
        for i, context in enumerate(contexts[:5], 1):
            doc = context.get('document', '')
            metadata = context.get('metadata', {})
            
            # Parse JSON se necessário
            try:
                if doc.startswith('{'):
                    doc_data = json.loads(doc)
                    doc = json.dumps(doc_data, indent=2, ensure_ascii=False)
            except:
                pass
            
            prompt += f"\n[Contexto {i} - {metadata.get('type', 'info')}]:\n{doc[:1000]}\n"
        
        # Adicionar histórico recente
        if self.conversation_history:
            prompt += "\n\nHISTÓRICO RECENTE:\n"
            for hist in self.conversation_history[-3:]:
                prompt += f"Q: {hist['query'][:200]}\n"
                prompt += f"R: {hist['response'][:200]}...\n\n"
        
        prompt += f"\n\nPERGUNTA DO USUÁRIO: {query}\n\n"
        prompt += "Responda de forma clara e específica, citando as fontes do contexto quando relevante."
        
        return prompt
    
    def _generate_openai_response(self, prompt: str, model: str) -> str:
        """Gera resposta usando OpenAI"""
        try:
            from openai import OpenAI
            client = OpenAI()
            
            response = client.chat.completions.create(
                model=model,
                messages=[
                    {"role": "system", "content": "Você é um especialista em segurança cloud e STRIDE."},
                    {"role": "user", "content": prompt}
                ],
                temperature=0.7,
                max_tokens=1000
            )
            
            return response.choices[0].message.content
            
        except Exception as e:
            return f"Erro ao gerar resposta: {str(e)}"
    
    def _generate_local_response(self, prompt: str, contexts: List[Dict]) -> str:
        """Gera resposta localmente (fallback)"""
        # Implementação simplificada para fallback
        response = "Baseado no contexto disponível:\n\n"
        
        # Extrair informações relevantes dos contextos
        for context in contexts[:3]:
            metadata = context.get('metadata', {})
            doc = context.get('document', '')
            
            if metadata.get('type') == 'stride_threat':
                response += f"• Ameaça STRIDE identificada: {metadata.get('category')}\n"
            elif metadata.get('type') == 'best_practice':
                response += f"• Best practice para {metadata.get('provider')}\n"
            elif metadata.get('type') == 'compliance_framework':
                response += f"• Requisito de compliance: {metadata.get('framework')}\n"
        
        return response