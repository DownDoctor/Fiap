# utils.py
"""
Utilitários compartilhados para STRIDE Analyzer Enhanced
"""

import hashlib
import json
import time
from pathlib import Path
from typing import Dict, Any, Optional, List
from datetime import datetime, timedelta
import tempfile
import shutil

def generate_analysis_id(image_path: str, timestamp: Optional[float] = None) -> str:
    """
    Gera ID único para análise baseado em imagem e timestamp
    
    Args:
        image_path: Caminho da imagem
        timestamp: Timestamp opcional (usa atual se não fornecido)
    
    Returns:
        ID único da análise (8 caracteres)
    """
    timestamp = timestamp or time.time()
    content = f"{Path(image_path).name}{timestamp}"
    return hashlib.md5(content.encode()).hexdigest()[:8]

def validate_image_file(file_path: str, max_size_mb: Optional[int] = None) -> Dict[str, Any]:
    """
    Valida arquivo de imagem
    
    Args:
        file_path: Caminho do arquivo
        max_size_mb: Tamanho máximo em MB (usa config se não especificado)
    
    Returns:
        Dicionário com resultado da validação
    """
    from config import config
    
    result = {
        'valid': False,
        'error': None,
        'file_info': {}
    }
    
    try:
        file_path = Path(file_path)
        
        # Verificar se arquivo existe
        if not file_path.exists():
            result['error'] = f"File not found: {file_path}"
            return result
        
        # Verificar extensão
        valid_extensions = {'.png', '.jpg', '.jpeg', '.bmp', '.tiff', '.webp'}
        if file_path.suffix.lower() not in valid_extensions:
            result['error'] = f"Invalid file extension: {file_path.suffix}"
            return result
        
        # Verificar tamanho
        size_mb = file_path.stat().st_size / (1024 * 1024)
        max_size = max_size_mb or config.MAX_IMAGE_SIZE_MB
        
        if size_mb > max_size:
            result['error'] = f"File too large: {size_mb:.1f}MB > {max_size}MB"
            return result
        
        # Informações do arquivo
        result['file_info'] = {
            'path': str(file_path),
            'name': file_path.name,
            'size_mb': round(size_mb, 2),
            'extension': file_path.suffix.lower(),
            'modified': datetime.fromtimestamp(file_path.stat().st_mtime).isoformat()
        }
        
        result['valid'] = True
        
    except Exception as e:
        result['error'] = f"Validation error: {str(e)}"
    
    return result

def save_analysis_result(result: Dict[str, Any], output_dir: str = "reports") -> Dict[str, str]:
    """
    Salva resultado da análise em arquivos JSON e HTML
    
    Args:
        result: Resultado da análise
        output_dir: Diretório de saída
    
    Returns:
        Caminhos dos arquivos salvos
    """
    
    output_path = Path(output_dir)
    output_path.mkdir(exist_ok=True)
    
    analysis_id = result.get('analysis_id', 'unknown')
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    
    # Salvar JSON
    json_file = output_path / f"stride_analysis_{analysis_id}_{timestamp}.json"
    with open(json_file, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2, ensure_ascii=False, default=str)
    
    # Gerar e salvar HTML (se função disponível)
    html_file = None
    try:
        from stride_integration_llm_fixed import EnhancedSTRIDEAnalyzerCore
        analyzer = EnhancedSTRIDEAnalyzerCore()
        html_content = analyzer.generate_enhanced_html_report(result)
        
        html_file = output_path / f"stride_report_{analysis_id}_{timestamp}.html"
        with open(html_file, 'w', encoding='utf-8') as f:
            f.write(html_content)
    
    except Exception as e:
        print(f"Warning: Could not generate HTML report: {e}")
    
    return {
        'json_report': str(json_file),
        'html_report': str(html_file) if html_file else None
    }

def format_duration(seconds: float) -> str:
    """
    Formata duração em formato legível
    
    Args:
        seconds: Duração em segundos
    
    Returns:
        Duração formatada (ex: "1m 30s", "45s")
    """
    if seconds < 1:
        return f"{seconds*1000:.0f}ms"
    elif seconds < 60:
        return f"{seconds:.1f}s"
    else:
        minutes = int(seconds // 60)
        remaining_seconds = int(seconds % 60)
        return f"{minutes}m {remaining_seconds}s"

def format_file_size(size_bytes: int) -> str:
    """
    Formata tamanho de arquivo em formato legível
    
    Args:
        size_bytes: Tamanho em bytes
    
    Returns:
        Tamanho formatado (ex: "1.5 MB", "2.3 KB")
    """
    for unit in ['B', 'KB', 'MB', 'GB']:
        if size_bytes < 1024.0:
            return f"{size_bytes:.1f} {unit}"
        size_bytes /= 1024.0
    return f"{size_bytes:.1f} TB"

def clean_old_files(directory: str, max_age_hours: int = 168) -> int:
    """
    Remove arquivos antigos de um diretório
    
    Args:
        directory: Diretório para limpeza
        max_age_hours: Idade máxima em horas (padrão: 7 dias)
    
    Returns:
        Número de arquivos removidos
    """
    
    directory_path = Path(directory)
    if not directory_path.exists():
        return 0
    
    cutoff_time = datetime.now() - timedelta(hours=max_age_hours)
    removed_count = 0
    
    try:
        for file_path in directory_path.iterdir():
            if file_path.is_file():
                file_time = datetime.fromtimestamp(file_path.stat().st_mtime)
                if file_time < cutoff_time:
                    file_path.unlink()
                    removed_count += 1
    
    except Exception as e:
        print(f"Warning: Error cleaning directory {directory}: {e}")
    
    return removed_count

def create_temporary_copy(file_path: str) -> str:
    """
    Cria cópia temporária de arquivo
    
    Args:
        file_path: Caminho do arquivo original
    
    Returns:
        Caminho do arquivo temporário
    """
    
    source_path = Path(file_path)
    
    # Criar arquivo temporário com mesmo sufixo
    with tempfile.NamedTemporaryFile(suffix=source_path.suffix, delete=False) as temp_file:
        temp_path = temp_file.name
    
    # Copiar arquivo
    shutil.copy2(source_path, temp_path)
    
    return temp_path

def extract_text_from_contexts(contexts: List[Dict]) -> str:
    """
    Extrai texto útil de contextos de RAG
    
    Args:
        contexts: Lista de contextos do RAG
    
    Returns:
        Texto consolidado
    """
    
    if not contexts:
        return "No context available."
    
    text_parts = []
    
    for i, context in enumerate(contexts[:3], 1):  # Top 3 contextos
        document = context.get('document', '')
        metadata = context.get('metadata', {})
        score = context.get('score', 0)
        
        # Extrair título se disponível
        title = metadata.get('title', f'Context {i}')
        
        text_parts.append(f"[{title} - Score: {score:.2f}]")
        
        # Limitar texto do documento
        if len(document) > 300:
            text_parts.append(document[:300] + "...")
        else:
            text_parts.append(document)
        
        text_parts.append("")  # Linha em branco entre contextos
    
    return '\n'.join(text_parts)

def sanitize_filename(filename: str) -> str:
    """
    Sanitiza nome de arquivo removendo caracteres inválidos
    
    Args:
        filename: Nome original do arquivo
    
    Returns:
        Nome sanitizado
    """
    
    # Caracteres inválidos para nomes de arquivo
    invalid_chars = '<>:"/\\|?*'
    
    # Substituir caracteres inválidos por underscore
    sanitized = filename
    for char in invalid_chars:
        sanitized = sanitized.replace(char, '_')
    
    # Remover múltiplos underscores consecutivos
    while '__' in sanitized:
        sanitized = sanitized.replace('__', '_')
    
    # Remover underscore no início e fim
    sanitized = sanitized.strip('_')
    
    # Garantir que não está vazio
    if not sanitized:
        sanitized = 'unnamed_file'
    
    # Limitar tamanho
    if len(sanitized) > 100:
        name_part, ext = sanitized.rsplit('.', 1) if '.' in sanitized else (sanitized, '')
        name_part = name_part[:95]
        sanitized = f"{name_part}.{ext}" if ext else name_part
    
    return sanitized

def check_system_resources() -> Dict[str, Any]:
    """
    Verifica recursos disponíveis do sistema
    
    Returns:
        Informações sobre recursos do sistema
    """
    
    import psutil
    
    # Memória
    memory = psutil.virtual_memory()
    
    # Disco
    disk = psutil.disk_usage('.')
    
    # CPU
    cpu_percent = psutil.cpu_percent(interval=1)
    
    return {
        'memory': {
            'total_gb': round(memory.total / (1024**3), 1),
            'available_gb': round(memory.available / (1024**3), 1),
            'usage_percent': memory.percent
        },
        'disk': {
            'total_gb': round(disk.total / (1024**3), 1),
            'free_gb': round(disk.free / (1024**3), 1),
            'usage_percent': round((disk.used / disk.total) * 100, 1)
        },
        'cpu': {
            'usage_percent': cpu_percent,
            'core_count': psutil.cpu_count()
        }
    }

def get_system_info() -> Dict[str, Any]:
    """
    Coleta informações completas do sistema
    
    Returns:
        Informações detalhadas do sistema
    """
    
    import platform
    import sys
    from config import config
    
    info = {
        'platform': {
            'system': platform.system(),
            'release': platform.release(),
            'machine': platform.machine(),
            'processor': platform.processor()
        },
        'python': {
            'version': sys.version,
            'executable': sys.executable
        },
        'stride_config': config.get_config_summary()
    }
    
    # Adicionar recursos se psutil disponível
    try:
        import psutil
        info['resources'] = check_system_resources()
    except ImportError:
        info['resources'] = {'note': 'psutil not available'}
    
    return info