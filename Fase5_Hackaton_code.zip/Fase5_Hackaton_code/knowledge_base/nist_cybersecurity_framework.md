# NIST Cybersecurity Framework 2.0

## Introdução ao Framework

O NIST Cybersecurity Framework fornece uma abordagem estruturada para gerenciar riscos de cibersegurança. Foi desenvolvido pelo National Institute of Standards and Technology (NIST) dos EUA e é amplamente adotado globalmente.

## Estrutura do Framework

O Framework consiste em três componentes principais:
- **Core (Núcleo)** - Conjunto de atividades de cibersegurança e resultados
- **Tiers (Níveis)** - Medida da maturidade dos processos de cibersegurança
- **Profiles (Perfis)** - Alinhamento das atividades com necessidades de negócio

---

## Core Functions (Funções Centrais)

### **1. IDENTIFY (Identificar)**

Desenvolver compreensão organizacional para gerenciar riscos de cibersegurança para sistemas, pessoas, ativos, dados e capacidades.

#### **Asset Management (AM)**
- **AM.AM-01:** Inventário de hardware físico e sistemas é mantido
- **AM.AM-02:** Inventário de software e aplicações é mantido  
- **AM.AM-03:** Fluxos de comunicação organizacionais e dados são catalogados
- **AM.AM-04:** Recursos externos são inventariados e monitorados
- **AM.AM-05:** Priorização de recursos baseada em classificação e criticidade

**Implementações Cloud:**
- **AWS:** Config, Systems Manager, Asset Inventory, Resource Groups
- **Azure:** Resource Graph, Inventory, Asset Management, Tags
- **GCP:** Cloud Asset Inventory, Resource Manager, Labels

#### **Business Environment (BE)**
- **BE.BE-01:** Papel da organização na cadeia de suprimentos é identificado
- **BE.BE-02:** Lugar da organização no setor e mercado é compreendido
- **BE.BE-03:** Prioridades organizacionais são estabelecidas
- **BE.BE-04:** Dependências críticas são estabelecidas
- **BE.BE-05:** Funções de missão crítica e apoio são identificadas

#### **Governance (GV)**
- **GV.GV-01:** Política organizacional de cibersegurança é estabelecida
- **GV.GV-02:** Funções e responsabilidades de cibersegurança são coordenadas
- **GV.GV-03:** Requisitos legais e regulatórios são compreendidos
- **GV.GV-04:** Processos de governança abordam riscos de cibersegurança

#### **Risk Assessment (RA)**
- **RA.RA-01:** Vulnerabilidades de ativos são identificadas
- **RA.RA-02:** Inteligência de ameaças cibernéticas é recebida
- **RA.RA-03:** Ameaças internas e externas são identificadas
- **RA.RA-04:** Impactos potenciais e probabilidades são identificados
- **RA.RA-05:** Ameaças, vulnerabilidades e impactos são usados para determinar risco
- **RA.RA-06:** Respostas a risco são identificadas e priorizadas

**Ferramentas de Avaliação:**
- **AWS:** Inspector, GuardDuty, Security Hub, Trusted Advisor
- **Azure:** Security Center, Advisor, Sentinel, Defender
- **GCP:** Security Command Center, Cloud Security Scanner

#### **Risk Management Strategy (RM)**
- **RM.RM-01:** Estratégia de gerenciamento de risco é estabelecida
- **RM.RM-02:** Tolerância a risco organizacional é determinada
- **RM.RM-03:** Determinação de risco organizacional inclui impacto nas partes interessadas

#### **Supply Chain Risk Management (SC)**
- **SC.SC-01:** Estratégia de gerenciamento de risco da cadeia de suprimentos é estabelecida
- **SC.SC-02:** Fornecedores são identificados, priorizados e avaliados
- **SC.SC-03:** Contratos com fornecedores incluem provisões para abordar riscos

---

### **2. PROTECT (Proteger)**

Desenvolver e implementar salvaguardas apropriadas para assegurar entrega de serviços de infraestrutura crítica.

#### **Identity Management and Access Control (PR.AC)**
- **PR.AC-01:** Identidades e credenciais são emitidas, gerenciadas e revogadas
- **PR.AC-02:** Identidades são comprovadas e correlacionadas para usuários
- **PR.AC-03:** Acesso remoto é gerenciado
- **PR.AC-04:** Permissões de acesso e autorizações são gerenciadas
- **PR.AC-05:** Integridade da rede é protegida
- **PR.AC-06:** Identidades são comprovadas e correlacionadas para dispositivos
- **PR.AC-07:** Usuários, dispositivos e outros ativos são autenticados

**Implementações Cloud:**
- **AWS:** IAM, SSO, Organizations, Directory Service, Cognito
- **Azure:** Azure AD, MFA, Conditional Access, B2B, B2C
- **GCP:** Cloud Identity, IAM, Identity-Aware Proxy, Cloud Directory Sync

#### **Awareness and Training (PR.AT)**
- **PR.AT-01:** Todos os usuários são informados e treinados
- **PR.AT-02:** Usuários privilegiados compreendem funções e responsabilidades
- **PR.AT-03:** Terceiros compreendem funções e responsabilidades
- **PR.AT-04:** Executivos seniores compreendem funções e responsabilidades
- **PR.AT-05:** Desenvolvedores seguem práticas de desenvolvimento seguro

#### **Data Security (PR.DS)**
- **PR.DS-01:** Dados em repouso são protegidos
- **PR.DS-02:** Dados em trânsito são protegidos
- **PR.DS-03:** Sistemas/ativos são formalmente gerenciados durante remoção
- **PR.DS-04:** Capacidade adequada para assegurar disponibilidade é mantida
- **PR.DS-05:** Proteções contra vazamento de dados são implementadas
- **PR.DS-06:** Mecanismos de verificação de integridade são usados
- **PR.DS-07:** Desenvolvimento e ambiente de teste são separados do ambiente de produção
- **PR.DS-08:** Mecanismos de verificação de integridade são usados

**Implementações Cloud:**
- **AWS:** KMS, S3 encryption, EBS encryption, RDS encryption, CloudHSM
- **Azure:** Key Vault, Storage encryption, Disk encryption, SQL TDE
- **GCP:** Cloud KMS, encryption at rest, Cloud HSM, Secret Manager

#### **Information Protection Processes and Procedures (PR.IP)**
- **PR.IP-01:** Baseline de configuração é criada e mantida
- **PR.IP-02:** Ciclo de vida de desenvolvimento de sistema de segurança é implementado
- **PR.IP-03:** Políticas de configuração change control são implementadas
- **PR.IP-04:** Backups de informações são conduzidos e testados
- **PR.IP-05:** Política para destruição segura de dados é implementada
- **PR.IP-06:** Dados são destruídos de acordo com política
- **PR.IP-07:** Processos de melhoria contínua são incorporados
- **PR.IP-08:** Eficácia de tecnologias de proteção é compartilhada
- **PR.IP-09:** Planos de resposta e recuperação são em vigor e gerenciados
- **PR.IP-10:** Planos de resposta e recuperação são testados
- **PR.IP-11:** Políticas de cibersegurança são incorporadas em recursos humanos
- **PR.IP-12:** Plano de gerenciamento de vulnerabilidade é desenvolvido

#### **Maintenance (PR.MA)**
- **PR.MA-01:** Manutenção é realizada e registrada
- **PR.MA-02:** Manutenção remota é aprovada, registrada e realizada

#### **Protective Technology (PR.PT)**
- **PR.PT-01:** Logs de auditoria/registro são determinados, documentados, implementados
- **PR.PT-02:** Mídia removível é protegida e seu uso restrito
- **PR.PT-03:** Princípio de funcionalidade mínima é incorporado
- **PR.PT-04:** Redes de comunicação e controle são protegidas
- **PR.PT-05:** Mecanismos são implementados para alcançar resilência

---

### **3. DETECT (Detectar)**

Desenvolver e implementar atividades apropriadas para identificar ocorrência de evento de cibersegurança.

#### **Anomalies and Events (DE.AE)**
- **DE.AE-01:** Baseline de atividade de rede e expected data flows é estabelecida
- **DE.AE-02:** Eventos detectados são analisados para compreender alvos
- **DE.AE-03:** Dados de evento são coletados e correlacionados de múltiplas fontes
- **DE.AE-04:** Impacto de eventos é determinado
- **DE.AE-05:** Limiares de alerta de incidente são estabelecidos

**Ferramentas de Detecção:**
- **AWS:** GuardDuty, Security Hub, CloudWatch, VPC Flow Logs
- **Azure:** Security Center, Sentinel, Monitor, Network Watcher
- **GCP:** Security Command Center, Cloud Logging, VPC Flow Logs

#### **Security Continuous Monitoring (DE.CM)**
- **DE.CM-01:** Rede é monitorada para detectar potenciais eventos de cibersegurança
- **DE.CM-02:** Ambiente físico é monitorado para detectar potenciais eventos
- **DE.CM-03:** Atividade de pessoal é monitorada para detectar potenciais eventos
- **DE.CM-04:** Código malicioso é detectado
- **DE.CM-05:** Atividade externa de serviço provider é monitorada
- **DE.CM-06:** Atividade externa de serviço provider é monitorada
- **DE.CM-07:** Monitoramento para acesso não autorizado é realizado
- **DE.CM-08:** Scans de vulnerabilidade são realizados

#### **Detection Processes (DE.DP)**
- **DE.DP-01:** Funções e responsabilidades para detecção são bem definidas
- **DE.DP-02:** Atividades de detecção estão em conformidade com requisitos
- **DE.DP-03:** Processos de detecção são testados
- **DE.DP-04:** Informações de evento de detecção são comunicadas
- **DE.DP-05:** Processos de detecção são continuamente melhorados

---

### **4. RESPOND (Responder)**

Desenvolver e implementar atividades apropriadas para tomar ação sobre evento de cibersegurança detectado.

#### **Response Planning (RS.RP)**
- **RS.RP-01:** Plano de resposta é executado durante ou após evento
- **RS.RP-02:** Plano de resposta é atualizado

#### **Communications (RS.CO)**
- **RS.CO-01:** Pessoal conhece funções e ordem de operações durante resposta
- **RS.CO-02:** Eventos são reportados consistente com critérios estabelecidos
- **RS.CO-03:** Informações são compartilhadas consistente com planos de resposta
- **RS.CO-04:** Coordenação com partes interessadas ocorre durante resposta
- **RS.CO-05:** Informações de resposta voluntária são compartilhadas

#### **Analysis (RS.AN)**
- **RS.AN-01:** Notificações de sistemas de detecção são investigadas
- **RS.AN-02:** Impacto do incidente é compreendido
- **RS.AN-03:** Forensics é realizada
- **RS.AN-04:** Incidentes são categorizados consistente com planos de resposta
- **RS.AN-05:** Processos são estabelecidos para receber análise de vulnerabilidades

#### **Mitigation (RS.MI)**
- **RS.MI-01:** Incidentes são contidos
- **RS.MI-02:** Incidentes são mitigados
- **RS.MI-03:** Novos artefatos são identificados e removidos
- **RS.MI-04:** Sistemas comprometidos são isolados

#### **Improvements (RS.IM)**
- **RS.IM-01:** Planos de resposta incorporam lições aprendidas
- **RS.IM-02:** Estratégias de resposta são atualizadas

---

### **5. RECOVER (Recuperar)**

Desenvolver e implementar atividades apropriadas para manter planos de resilência e restaurar capacidades ou serviços prejudicados por evento de cibersegurança.

#### **Recovery Planning (RC.RP)**
- **RC.RP-01:** Plano de recuperação é executado durante ou após evento
- **RC.RP-02:** Plano de recuperação é atualizado

#### **Improvements (RC.IM)**
- **RC.IM-01:** Planos de recuperação incorporam lições aprendidas
- **RC.IM-02:** Estratégias de recuperação são atualizadas

#### **Communications (RC.CO)**
- **RC.CO-01:** Relações públicas são gerenciadas
- **RC.CO-02:** Planos de recuperação são comunicados às partes interessadas internas
- **RC.CO-03:** Informações de recuperação são comunicadas às partes interessadas

---

## Implementation Tiers (Níveis de Implementação)

### **Tier 1: Partial (Parcial)**
- Processos de gerenciamento de risco de cibersegurança são Ad Hoc
- Consciência limitada de risco de cibersegurança
- Não há processo organizacional para compartilhar informações

### **Tier 2: Risk Informed (Informado por Risco)**
- Processos de gerenciamento de risco são aprovados pela administração
- Há consciência de risco de cibersegurança mas processo organizacional não estabelecido
- Informações de cibersegurança são compartilhadas informalmente

### **Tier 3: Repeatable (Repetível)**
- Políticas organizacionais de gerenciamento de risco são formalmente aprovadas
- Práticas de cibersegurança são regularmente atualizadas
- Organização compreende sua função no ecossistema maior

### **Tier 4: Adaptive (Adaptativo)**
- Organização adapta suas práticas de cibersegurança baseada em indicadores
- Análises avançadas e sofisticadas são realizadas
- Organização gerencia ativamente risco de cibersegurança

---

## Framework Profiles (Perfis)

Um Profile representa outcomes que uma organização selecionou dos Framework Categories e Subcategories com base em suas necessidades de negócio e tolerância a risco.

### **Current Profile**
- Estado atual de implementação das subcategorias do Framework
- Indica quais resultados estão sendo alcançados atualmente

### **Target Profile**  
- Estado desejado de implementação das subcategorias do Framework
- Alinha com objetivos organizacionais e tolerância a risco

### **Gap Analysis**
- Comparação entre Current Profile e Target Profile
- Identifica áreas prioritárias para investimento e melhorias

---

## Integração com Padrões Internacionais

### **ISO 27001/27002**
- Mapeamento direto entre controles ISO e subcategorias NIST
- Compatibilidade com sistemas de gestão de segurança

### **COBIT**
- Alinhamento com processos de governança de TI
- Integração com frameworks de auditoria

### **ITIL**
- Incorporação em processos de service management
- Alinhamento com práticas de operational excellence

---

## Recursos e Ferramentas

### **NIST Resources**
- [NIST Cybersecurity Framework 2.0](https://www.nist.gov/cyberframework)
- [Framework Implementation Guidance](https://csrc.nist.gov/publications/detail/sp/800-53/rev-5/final)
- [Small Business Quick-Start Guide](https://www.nist.gov/cyberframework/small-business-resources)

### **Assessment Tools**
- NIST Privacy Framework
- Cybersecurity Supply Chain Risk Management
- Critical Infrastructure Cybersecurity Performance Goals

### **Cloud Provider Resources**
- [AWS NIST Compliance](https://aws.amazon.com/compliance/nist/)
- [Azure NIST Framework](https://docs.microsoft.com/en-us/azure/governance/policy/samples/nist-sp-800-53-r4)
- [GCP NIST Resources](https://cloud.google.com/security/compliance/nist-sp-800-53)