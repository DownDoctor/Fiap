# NIST Cybersecurity Framework

## Access Control (AC)
### AC-1: Access Control Policy and Procedures
- **Description**: Establish formal access control policies
- **Implementation**: Document access control procedures
- **STRIDE Relevance**: Mitigates Spoofing and Elevation of Privilege
- **Risk Level**: High if not implemented

### AC-2: Account Management  
- **Description**: Manage user accounts systematically
- **Implementation**: Regular account reviews and provisioning
- **STRIDE Relevance**: Prevents unauthorized access (Spoofing)
- **Risk Level**: Critical for multi-user systems

## Identification and Authentication (IA)
### IA-1: Identification and Authentication Policy
- **Description**: Establish identity verification procedures
- **Implementation**: Multi-factor authentication required
- **STRIDE Relevance**: Primary defense against Spoofing attacks
- **Risk Level**: Critical

### IA-2: User Identification and Authentication
- **Description**: Uniquely identify and authenticate users
- **Implementation**: Strong password policies + MFA
- **STRIDE Relevance**: Spoofing prevention
- **Risk Level**: High

## System and Information Integrity (SI)
### SI-1: System and Information Integrity Policy
- **Description**: Maintain data and system integrity
- **Implementation**: Integrity monitoring tools
- **STRIDE Relevance**: Detects and prevents Tampering
- **Risk Level**: High

### SI-7: Software and Information Integrity
- **Description**: Detect unauthorized changes
- **Implementation**: Digital signatures, checksums
- **STRIDE Relevance**: Anti-tampering controls
- **Risk Level**: Medium to High
