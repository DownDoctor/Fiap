---

## 📋 **Compliance Frameworks**

### **SOC 2 (Service Organization Control 2)**

**Trust Service Criteria:**

**Security:**
- Access controls are implemented
- Logical and physical access is restricted
- Access is removed timely upon termination

**Availability:**
- System availability commitments are met
- System capacity is monitored and managed
- Backup and recovery procedures are implemented

**Processing Integrity:**
- System processing is complete, valid, accurate, timely, and authorized
- Data processing errors are identified and corrected

**Confidentiality:**
- Information designated as confidential is protected
- Confidentiality commitments are met

**Privacy:**
- Personal information is collected, used, retained, and disposed of in conformity with commitments

---

### **ISO 27001 Information Security Management**

**Key Control Areas:**

**Information Security Policies (A.5)**
- Management direction and support for information security

**Organization of Information Security (A.6)**
- Internal organization and mobile devices/teleworking

**Human Resource Security (A.7)**
- Prior to employment, during employment, termination or change of employment

**Asset Management (A.8)**
- Responsibility for assets, information classification, media handling

**Access Control (A.9)**
- Business requirements, user access management, system and application access control

**Cryptography (A.10)**
- Cryptographic controls

**Physical and Environmental Security (A.11)**
- Secure areas, equipment

**Operations Security (A.12)**
- Operational procedures, protection from malware, backup, logging and monitoring

**Communications Security (A.13)**
- Network security management, information transfer

**System Acquisition, Development and Maintenance (A.14)**
- Security requirements, security in development and support processes

**Supplier Relationships (A.15)**
- Information security in supplier relationships, supplier service delivery management

**Information Security Incident Management (A.16)**
- Management of information security incidents and improvements

**Information Security Aspects of Business Continuity Management (A.17)**
- Information security continuity, redundancies

**Compliance (A.18)**
- Compliance with legal and contractual requirements, information security reviews