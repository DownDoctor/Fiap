# Microsoft STRIDE Threat Modeling Framework

## Introdução ao STRIDE

STRIDE é um framework de modelagem de ameaças desenvolvido pela Microsoft que categoriza ameaças de segurança em seis tipos principais. Cada letra representa uma categoria específica de ameaça que pode afetar sistemas de software.

## As 6 Categorias STRIDE

### **S - Spoofing Identity**

**Definição:** Ameaças de falsificação de identidade onde atacantes se fazem passar por usuários legítimos ou sistemas confiáveis.

**Exemplos de Ataques:**
- IP address spoofing
- Email spoofing (falsificação de remetente)
- User credential theft e reutilização
- Man-in-the-middle attacks
- DNS spoofing
- ARP spoofing em redes locais
- Certificate spoofing

**Técnicas de Mitigação:**
- **Strong authentication mechanisms** (autenticação multifator - MFA)
- **Digital certificates e PKI** (Public Key Infrastructure)
- **Mutual authentication** entre cliente e servidor
- **Kerberos authentication** em ambientes corporativos
- **SSL/TLS com certificate pinning**
- **DNSSEC** para validação de DNS
- **Network segmentation** para isolar recursos críticos

**Implementações Cloud:**
- **AWS:** IAM com MFA, AWS SSO, Cognito, Certificate Manager
- **Azure:** Azure Active Directory, Managed Identity, Conditional Access
- **GCP:** Cloud Identity, Identity-Aware Proxy, Cloud IAM

**Indicadores de Detecção:**
- Logins de localizações geograficamente impossíveis
- Múltiplos logins simultâneos da mesma conta
- Falhas de validação de certificado
- Tráfego de rede suspeito

---

### **T - Tampering with Data**

**Definição:** Modificação maliciosa de dados persistentes ou em trânsito sem autorização adequada.

**Exemplos de Ataques:**
- Modificação de dados em banco de dados
- Alteração de arquivos de configuração
- Manipulação de parâmetros HTTP
- SQL Injection para modificar dados
- Buffer overflow para corromper memória
- Modificação de logs de auditoria
- Alteração de dados em transit (network tampering)

**Técnicas de Mitigação:**
- **Data integrity checks** usando HMAC ou checksums
- **Digital signatures** para validação de integridade
- **File integrity monitoring** (FIM)
- **Code signing** para executáveis
- **Database transaction logging**
- **Write-once storage** para logs críticos
- **Network-level integrity** usando IPSec ou TLS

**Implementações Cloud:**
- **AWS:** CloudTrail, Config, S3 Object Lock, KMS para assinaturas
- **Azure:** Activity Log, Immutable Blob Storage, Key Vault
- **GCP:** Cloud Audit Logs, Retention policies, Cloud KMS

**Controles de Prevenção:**
- Validação de entrada em todas as camadas
- Principle of least privilege para modificação de dados
- Segregation of duties para operações críticas
- Regular integrity verification procedures

---

### **R - Repudiation**

**Definição:** Negação de ações realizadas, falta de auditoria adequada que permita provar que determinada ação foi executada por usuário específico.

**Exemplos de Ataques:**
- Usuário nega ter executado uma transação financeira
- Administrador nega ter alterado configurações críticas
- Falta de logs para provar atividade maliciosa
- Manipulação ou exclusão de logs de auditoria
- Uso de contas compartilhadas sem rastreabilidade
- Ações executadas sem timestamps adequados

**Técnicas de Mitigação:**
- **Comprehensive audit logging** de todas as ações críticas
- **Digital signatures** em transações importantes
- **Time stamping** com servidor de tempo confiável
- **Non-repudiation protocols** usando PKI
- **Log forwarding** para sistemas centralizados
- **Log integrity protection** contra manipulação
- **Legal evidence collection** procedures

**Implementações Cloud:**
- **AWS:** CloudTrail, S3 Access Logging, VPC Flow Logs
- **Azure:** Activity Log, Storage Analytics, Network Watcher
- **GCP:** Cloud Audit Logs, VPC Flow Logs, Activity Tracker

**Elementos Essenciais de Logs:**
- User identity (who)
- Action performed (what)
- Resource affected (where)
- Timestamp (when)
- Source location (from where)
- Success/failure status

---

### **I - Information Disclosure**

**Definição:** Exposição não autorizada de informações sensíveis a indivíduos que não deveriam ter acesso a elas.

**Exemplos de Ataques:**
- SQL injection para extrair dados do banco
- Directory traversal para acessar arquivos
- Memory dumps contendo dados sensíveis
- Error messages revelando informações do sistema
- Eavesdropping em comunicações não criptografadas
- Cache attacks para extrair chaves criptográficas
- Side-channel attacks

**Técnicas de Mitigação:**
- **Data encryption at rest** usando algoritmos fortes
- **Data encryption in transit** com TLS/SSL
- **Access controls** baseados em necessidade (need-to-know)
- **Data loss prevention (DLP)** systems
- **Secure data classification** e handling procedures
- **Network segmentation** para isolar dados sensíveis
- **Secrets management** para credenciais e chaves

**Implementações Cloud:**
- **AWS:** KMS, S3 encryption, VPC, IAM policies
- **Azure:** Key Vault, Storage encryption, Virtual Networks
- **GCP:** Cloud KMS, encryption by default, VPC Service Controls

**Categorias de Informação Sensível:**
- Personally Identifiable Information (PII)
- Payment Card Information (PCI)
- Healthcare information (PHI/HIPAA)
- Intellectual property e trade secrets
- System architecture e configuration details

---

### **D - Denial of Service**

**Definição:** Negação ou degradação de serviços para usuários legítimos, tornando recursos indisponíveis quando necessários.

**Exemplos de Ataques:**
- **Volumetric attacks** (UDP floods, ICMP floods)
- **Protocol attacks** (SYN floods, Ping of Death)
- **Application layer attacks** (HTTP floods, Slowloris)
- **Distributed DoS (DDoS)** usando botnets
- **Resource exhaustion** attacks (CPU, memory, disk)
- **Algorithmic complexity attacks** (HashDoS, ReDoS)
- **Physical layer attacks** (cable cutting, power outage)

**Técnicas de Mitigação:**
- **Rate limiting e throttling** por usuário/IP
- **Load balancing** para distribuir carga
- **Auto-scaling** para lidar com picos de demanda
- **DDoS protection services** e traffic filtering
- **Resource quotas** para evitar esgotamento
- **Circuit breakers** para falhas em cascata
- **Geographic distribution** de recursos

**Implementações Cloud:**
- **AWS:** Shield, CloudFront, Auto Scaling, ELB
- **Azure:** DDoS Protection, Traffic Manager, Load Balancer
- **GCP:** Cloud Armor, Cloud CDN, Auto Scaling

**Tipos de Proteção:**
- **Network layer** protection (L3/L4)
- **Application layer** protection (L7)
- **DNS layer** protection
- **Infrastructure** redundancy

---

### **E - Elevation of Privilege**

**Definição:** Obtenção não autorizada de privilégios elevados no sistema, permitindo acesso a recursos normalmente restritos.

**Exemplos de Ataques:**
- **Buffer overflow** para executar código privilegiado
- **SQL injection** para acessar dados administrativos
- **Local privilege escalation** em sistemas operacionais
- **Container escape** para acessar host
- **Privilege inheritance** attacks
- **Token manipulation** para elevar permissões
- **Kernel exploits** para root/administrator access

**Técnicas de Mitigação:**
- **Principle of least privilege** em todas as camadas
- **Role-based access control (RBAC)** granular
- **Regular privilege reviews** e access recertification
- **Privileged Access Management (PAM)** solutions
- **Just-in-time access** para operações administrativas
- **System hardening** e regular patching
- **Application sandboxing** e containerization

**Implementações Cloud:**
- **AWS:** IAM roles, AssumeRole, Organizations SCPs
- **Azure:** RBAC, Privileged Identity Management (PIM)
- **GCP:** IAM roles, Service accounts, Organizational policies

**Controles de Prevenção:**
- Regular security assessments
- Penetration testing
- Vulnerability management
- Security awareness training
- Incident response planning

---

## Aplicação Prática do STRIDE

### **Processo de Threat Modeling com STRIDE**

1. **Identify Assets** - Identifique dados, sistemas e processos críticos
2. **Create Architecture Overview** - Documente fluxos de dados e componentes
3. **Decompose Application** - Quebre em componentes menores
4. **Identify Threats** - Use STRIDE para cada componente
5. **Document Threats** - Registre ameaças identificadas
6. **Rate Threats** - Use frameworks como DREAD ou CVSS
7. **Mitigate Threats** - Implemente controles apropriados

### **STRIDE vs. Elementos de Sistema**

| Elemento | S | T | R | I | D | E |
|----------|---|---|---|---|---|---|
| Data Flow | ✓ | ✓ | - | ✓ | ✓ | - |
| Data Store | - | ✓ | ✓ | ✓ | ✓ | - |
| Process | ✓ | ✓ | ✓ | ✓ | ✓ | ✓ |
| External Entity | ✓ | - | ✓ | - | - | - |
| Trust Boundary | ✓ | ✓ | - | ✓ | ✓ | ✓ |

### **Integração com Frameworks de Segurança**

**STRIDE + OWASP Top 10:**
- Broken Access Control ➜ Spoofing, Elevation of Privilege
- Cryptographic Failures ➜ Information Disclosure, Tampering
- Injection ➜ Tampering, Information Disclosure, Elevation of Privilege
- Insecure Design ➜ All STRIDE categories
- Security Misconfiguration ➜ All STRIDE categories

**STRIDE + NIST Framework:**
- **Identify** ➜ Asset discovery para STRIDE analysis
- **Protect** ➜ Implement STRIDE mitigations
- **Detect** ➜ Monitor for STRIDE attack indicators  
- **Respond** ➜ Incident response para STRIDE threats
- **Recover** ➜ Recovery procedures pós-incident

### **STRIDE em Arquiteturas Cloud**

**Microservices Architecture:**
- **Service-to-service** communication vulnerabilities
- **API Gateway** as critical attack surface
- **Container** security considerations
- **Service mesh** security implications

**Serverless Architecture:**
- **Function** privilege escalation
- **Event-driven** attack vectors
- **Shared responsibility** model implications
- **Cold start** security considerations

**Multi-Cloud Architecture:**
- **Cross-cloud** data flows security
- **Identity federation** challenges  
- **Compliance** across multiple providers
- **Network connectivity** security

---

## Ferramentas e Recursos

### **Ferramentas de Threat Modeling**
- Microsoft Threat Modeling Tool
- OWASP Threat Dragon
- ThreatSpec
- securiCAD
- IriusRisk

### **Referências Essenciais**
- [Microsoft STRIDE Documentation](https://docs.microsoft.com/en-us/azure/security/develop/threat-modeling-tool-threats)
- [OWASP Threat Modeling](https://owasp.org/www-community/Threat_Modeling)
- [NIST SP 800-154 - Guide to Data-Centric System Threat Modeling](https://csrc.nist.gov/publications/detail/sp/800-154/draft)
- [Threat Modeling: Designing for Security (Adam Shostack)](https://threatmodelingbook.com/)

### **Templates e Checklists**
- STRIDE threat assessment templates
- Security control mapping sheets
- Risk assessment matrices
- Mitigation planning worksheets