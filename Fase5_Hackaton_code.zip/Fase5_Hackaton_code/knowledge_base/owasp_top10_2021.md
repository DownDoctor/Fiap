# OWASP Top 10 2021 - Security Knowledge Base

## A01:2021 – Broken Access Control

**Descrição:** Falhas no controle de acesso permitem que atacantes acessem funcionalidades ou dados não autorizados.

**Exemplos Comuns:**
- Violation of the principle of least privilege or deny by default
- Bypassing access control checks by modifying the URL (parameter tampering, force browsing)  
- Permitting viewing or editing someone else's account
- Accessing API with missing access controls for POST, PUT and DELETE
- Elevation of privilege (acting as a user without being logged in or acting as an admin when logged in as a user)
- Metadata manipulation, such as replaying or tampering with a JSON Web Token (JWT)

**Como Prevenir:**
- Except for public resources, deny by default
- Implement access control mechanisms once and re-use them throughout the application
- Model access controls should enforce record ownership rather than accepting that the user can create, read, update, or delete any record
- Unique application business limit requirements should be enforced by domain models
- Disable web server directory listing and ensure file metadata and backup files are not present within web roots
- Log access control failures, alert admins when appropriate
- Rate limit API and controller access to minimize the harm from automated attack tooling
- Stateful session identifiers should be invalidated on the server after logout

**STRIDE Mapping:** Spoofing, Elevation of Privilege

**Cloud Security Controls:**
- **AWS:** IAM Policies, Resource-based policies, AWS Organizations SCPs
- **Azure:** RBAC, Azure AD Conditional Access, Resource locks
- **GCP:** Cloud IAM, Resource Manager constraints, VPC Service Controls

**Referências:**
- [OWASP A01:2021](https://owasp.org/Top10/A01_2021-Broken_Access_Control/)
- [NIST SP 800-53 AC Controls](https://csrc.nist.gov/publications/detail/sp/800-53/rev-5/final)

---

## A02:2021 – Cryptographic Failures

**Descrição:** Falhas relacionadas à criptografia que podem levar à exposição de dados sensíveis.

**Exemplos Comuns:**
- Data transmitted in clear text (HTTP, SMTP, FTP)
- Old or weak cryptographic algorithms or protocols used by default
- Default crypto keys in use, weak crypto keys generated or re-used
- Encryption not enforced (e.g., any user agent security directives or headers missing)
- Does the received server certificate and the trust chain properly validate?
- Are passwords used as cryptographic keys in absence of a password base key derivation function?

**Como Prevenir:**
- Classify data processed, stored, or transmitted by an application
- Don't store sensitive data unnecessarily
- Ensure up-to-date and strong standard algorithms, protocols, and keys are in place
- Encrypt all data in transit with secure protocols such as TLS
- Encrypt all sensitive data at rest
- Store passwords using strong adaptive and salted hashing functions
- Initialization vectors must be chosen appropriately for the mode of operation
- Always use authenticated encryption instead of just encryption
- Keys should be generated cryptographically randomly and stored in memory as byte arrays

**STRIDE Mapping:** Information Disclosure, Tampering

**Cloud Security Controls:**
- **AWS:** KMS, CloudHSM, Certificate Manager, S3 encryption
- **Azure:** Key Vault, HSM, Certificate management, Storage encryption  
- **GCP:** Cloud KMS, Cloud HSM, Certificate Authority Service, encryption at rest

**Referências:**
- [OWASP A02:2021](https://owasp.org/Top10/A02_2021-Cryptographic_Failures/)
- [NIST Cryptographic Standards](https://csrc.nist.gov/projects/cryptographic-standards-and-guidelines)

---

## A03:2021 – Injection

**Descrição:** Falhas de injeção como SQL, NoSQL, OS, e LDAP injection.

**Exemplos Comuns:**
- User-supplied data is not validated, filtered, or sanitized by the application
- Dynamic queries or non-parameterized calls without context-aware escaping are used directly in the interpreter
- Hostile data is used within object-relational mapping (ORM) search parameters to extract additional, sensitive records
- Hostile data is directly used or concatenated. The SQL or command contains the structure and malicious data in dynamic queries, commands, or stored procedures

**Como Prevenir:**
- Use a safe API, which avoids using the interpreter entirely, provides a parameterized interface, or migrates to Object Relational Mapping Tools (ORMs)
- Use positive server-side input validation
- For any residual dynamic queries, escape special characters using the specific escape syntax for that interpreter
- Use LIMIT and other SQL controls within queries to prevent mass disclosure of records in case of SQL injection

**STRIDE Mapping:** Tampering, Information Disclosure, Elevation of Privilege

**Cloud Security Controls:**
- **AWS:** Parameter Store, WAF, Lambda input validation, RDS parameter groups
- **Azure:** Application Gateway WAF, SQL Database threat detection, Key Vault
- **GCP:** Cloud Armor, Cloud SQL parameter validation, Secret Manager

**Referências:**
- [OWASP A03:2021](https://owasp.org/Top10/A03_2021-Injection/)
- [OWASP SQL Injection Prevention Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html)

---

## A04:2021 – Insecure Design

**Descrição:** Categoria ampla que representa diferentes fraquezas, expressas como "design inseguro ausente ou ineficaz".

**Exemplos Comuns:**
- A credential recovery workflow might include "questions and answers," which cannot assure the identity of the user
- A cinema chain allows group booking discounts and has a maximum of fifteen attendees before requiring a deposit
- A retail chain's e-commerce website does not have protection against bots run by scalpers buying high-end video cards to resell auction websites

**Como Prevenir:**
- Establish and use a secure development lifecycle with AppSec professionals to help evaluate and design security and privacy-related controls
- Establish and use a library of secure design patterns or paved road ready to use components
- Use threat modeling for critical authentication, access control, business logic, and key flows
- Integrate security language and controls into user stories
- Integrate plausibility checks at each tier of your application (from frontend to backend)
- Write unit and integration tests to validate that all critical flows are resistant to the threat model

**STRIDE Mapping:** All categories (design-level threat)

**Cloud Security Controls:**
- **AWS:** Well-Architected Framework, Security Pillar, AWS Config Rules
- **Azure:** Azure Architecture Center, Security best practices, Azure Blueprints
- **GCP:** Architecture Framework, Security best practices, Cloud Security Command Center

**Referências:**
- [OWASP A04:2021](https://owasp.org/Top10/A04_2021-Insecure_Design/)
- [OWASP Threat Modeling](https://owasp.org/www-community/Threat_Modeling)

---

## A05:2021 – Security Misconfiguration

**Descrição:** Falhas de configuração de segurança, incluindo configurações padrão inseguras, configurações incompletas ou ad hoc, armazenamento em nuvem aberto, cabeçalhos HTTP mal configurados e mensagens de erro detalhadas contendo informações sensíveis.

**Como Prevenir:**
- A repeatable hardening process makes it fast and easy to deploy another environment that is appropriately locked down
- A minimal platform without any unnecessary features, components, documentation, and samples
- A task to review and update the configurations appropriate to all security notes, updates, and patches as part of the patch management process
- A segmented application architecture provides effective and secure separation between components or tenants
- Sending security directives to clients, e.g., Security Headers
- An automated process to verify the effectiveness of the configurations and settings in all environments

**STRIDE Mapping:** All categories

**Cloud Security Controls:**
- **AWS:** Config, Systems Manager, Security Hub, Trusted Advisor
- **Azure:** Security Center, Policy, Advisor, Azure Blueprints
- **GCP:** Security Command Center, Policy Intelligence, Cloud Asset Inventory

**Referências:**
- [OWASP A05:2021](https://owasp.org/Top10/A05_2021-Security_Misconfiguration/)
- [CIS Benchmarks](https://www.cisecurity.org/cis-benchmarks/)

---

## A06:2021 – Vulnerable and Outdated Components

**Descrição:** Uso de componentes com vulnerabilidades conhecidas.

**Como Prevenir:**
- Remove unused dependencies, unnecessary features, components, files, and documentation
- Continuously inventory the versions of both client-side and server-side components and their dependencies
- Only obtain components from official sources over secure links
- Monitor for libraries and components that are unmaintained or do not create security patches for older versions
- Every organization must ensure an ongoing plan for monitoring, triaging, and applying updates or configuration changes for the lifetime of the application or portfolio

**STRIDE Mapping:** All categories

**Cloud Security Controls:**
- **AWS:** Inspector, Systems Manager Patch Manager, Trusted Advisor
- **Azure:** Security Center, Update Management, Advisor
- **GCP:** Container Analysis, OS Patch Management, Security Command Center

**Referências:**
- [OWASP A06:2021](https://owasp.org/Top10/A06_2021-Vulnerable_and_Outdated_Components/)
- [NIST Cybersecurity Framework - Identify](https://www.nist.gov/cyberframework)

---

## A07:2021 – Identification and Authentication Failures

**Descrição:** Falhas relacionadas à confirmação da identidade, autenticação e gerenciamento de sessão do usuário.

**Como Prevenir:**
- Where possible, implement multi-factor authentication to prevent automated credential stuffing, brute force, and stolen credential reuse attacks
- Do not ship or deploy with any default credentials, particularly for admin users
- Implement weak password checks, such as testing new or changed passwords against the top 10,000 worst passwords list
- Align password length, complexity, and rotation policies with National Institute of Standards and Technology (NIST) 800-63b's guidelines in section 5.1.1 for Memorized Secrets or other modern, evidence-based password policies
- Ensure registration, credential recovery, and API pathways are hardened against account enumeration attacks by using the same messages for all outcomes
- Limit or increasingly delay failed login attempts, but be careful not to create a denial of service scenario. Log all failures and alert administrators when credential stuffing, brute force, or other attacks are detected
- Use a server-side, secure, built-in session manager that generates a new random session ID with high entropy after login

**STRIDE Mapping:** Spoofing, Elevation of Privilege

**Cloud Security Controls:**
- **AWS:** Cognito, IAM, STS, MFA enforcement
- **Azure:** Azure AD, B2C, MFA, Conditional Access
- **GCP:** Cloud Identity, Firebase Auth, 2SV enforcement

**Referências:**
- [OWASP A07:2021](https://owasp.org/Top10/A07_2021-Identification_and_Authentication_Failures/)
- [NIST SP 800-63B](https://pages.nist.gov/800-63-3/sp800-63b.html)

---

## A08:2021 – Software and Data Integrity Failures

**Descrição:** Falhas relacionadas a código e infraestrutura que não protegem contra violações de integridade.

**Como Prevenir:**
- Use digital signatures or similar mechanisms to verify the software or data is from the expected source and has not been altered
- Ensure libraries and dependencies, such as npm or Maven, are consuming trusted repositories
- Ensure that a software supply chain security tool, such as OWASP Dependency Check or OWASP CycloneDX, is used to verify that components do not contain known vulnerabilities
- Ensure that there is a review process for code and configuration changes to minimize the chance that malicious code or configuration could be introduced into your software pipeline
- Ensure that your CI/CD pipeline has proper segregation, configuration, and access control to ensure the integrity of the code flowing through the build and deploy processes
- Ensure that unsigned or unencrypted serialized data is not sent to untrusted clients without some form of integrity check or digital signature to detect tampering or replay of the serialized data

**STRIDE Mapping:** Tampering, Repudiation

**Cloud Security Controls:**
- **AWS:** Code Signing, CloudTrail, Config, GuardDuty
- **Azure:** Code Signing, Activity Log, Policy, Security Center
- **GCP:** Binary Authorization, Cloud Audit Logs, Policy Intelligence

**Referências:**
- [OWASP A08:2021](https://owasp.org/Top10/A08_2021-Software_and_Data_Integrity_Failures/)
- [NIST SSDF](https://csrc.nist.gov/publications/detail/sp/800-218/final)

---

## A09:2021 – Security Logging and Monitoring Failures

**Descrição:** Falhas de logging e monitoramento, juntamente com integração ausente ou ineficaz com resposta a incidentes, permitem que atacantes ataquem sistemas adicionais, mantenham persistência e pivô para mais sistemas para adulterar, extrair ou destruir dados.

**Como Prevenir:**
- Ensure all login, access control, and server-side input validation failures can be logged with sufficient user context to identify suspicious or malicious accounts and held for enough time to allow delayed forensic analysis
- Ensure that logs are generated in a format that log management solutions can easily consume
- Ensure log data is encoded correctly to prevent injections or attacks on the logging or monitoring systems
- Ensure high-value transactions have an audit trail with integrity controls to prevent tampering or deletion, such as append-only database tables or similar
- DevSecOps teams should establish effective monitoring and alerting such that suspicious activities are detected and responded to quickly
- Establish or adopt an incident response and recovery plan, such as National Institute of Standards and Technology (NIST) 800-61r2 or later

**STRIDE Mapping:** Repudiation, Information Disclosure

**Cloud Security Controls:**
- **AWS:** CloudTrail, CloudWatch, GuardDuty, Security Hub
- **Azure:** Activity Log, Monitor, Sentinel, Security Center
- **GCP:** Cloud Audit Logs, Cloud Logging, Security Command Center

**Referências:**
- [OWASP A09:2021](https://owasp.org/Top10/A09_2021-Security_Logging_and_Monitoring_Failures/)
- [NIST SP 800-61r2](https://csrc.nist.gov/publications/detail/sp/800-61/rev-2/final)

---

## A10:2021 – Server-Side Request Forgery (SSRF)

**Descrição:** Falhas de SSRF ocorrem sempre que uma aplicação web busca um recurso remoto sem validar a URL fornecida pelo usuário.

**Como Prevenir:**
- Segregate remote resource access functionality in separate networks to reduce the impact of SSRF
- Enforce "deny by default" firewall policies or network access control rules to block all but essential intranet traffic
- Sanitize and validate all client-supplied input data
- Enforce the URL schema, port, and destination with a positive allow list
- Do not send raw responses to clients
- Disable HTTP redirections
- Be aware of the URL consistency to avoid attacks such as DNS rebinding and "time of check, time of use" (TOCTOU) race conditions

**STRIDE Mapping:** Spoofing, Tampering, Information Disclosure

**Cloud Security Controls:**
- **AWS:** VPC, Security Groups, WAF, Lambda@Edge
- **Azure:** Virtual Network, NSGs, Application Gateway WAF
- **GCP:** VPC, Firewall rules, Cloud Armor, Cloud Functions

**Referências:**
- [OWASP A10:2021](https://owasp.org/Top10/A10_2021-Server-Side_Request_Forgery_%28SSRF%29/)
- [OWASP SSRF Prevention Cheat Sheet](https://cheatsheetseries.owasp.org/cheatsheets/Server_Side_Request_Forgery_Prevention_Cheat_Sheet.html)