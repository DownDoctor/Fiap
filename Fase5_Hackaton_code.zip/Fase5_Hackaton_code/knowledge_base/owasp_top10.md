# OWASP Top 10 2021

## A01 - Broken Access Control
- **Description**: Restrictions on authenticated users not properly enforced
- **Common Weaknesses**: Bypassing access control checks
- **STRIDE Relevance**: Elevation of Privilege, Spoofing
- **Mitigation**: Implement proper authorization checks
- **Testing**: Verify access controls in all user flows

## A02 - Cryptographic Failures
- **Description**: Failures related to cryptography leading to data exposure
- **Common Weaknesses**: Weak encryption, plain text storage
- **STRIDE Relevance**: Information Disclosure
- **Mitigation**: Use strong encryption standards (AES-256)
- **Testing**: Scan for weak cryptographic implementations

## A03 - Injection
- **Description**: Hostile data sent to interpreter as part of command/query
- **Common Weaknesses**: SQL, NoSQL, OS command injection
- **STRIDE Relevance**: Tampering, Elevation of Privilege
- **Mitigation**: Input validation, parameterized queries
- **Testing**: Automated and manual injection testing

## A08 - Software and Data Integrity Failures
- **Description**: Code and infrastructure without integrity protection
- **Common Weaknesses**: Unsigned updates, CI/CD vulnerabilities
- **STRIDE Relevance**: Tampering
- **Mitigation**: Digital signatures, secure CI/CD pipelines
- **Testing**: Verify software update mechanisms

## A09 - Security Logging and Monitoring Failures
- **Description**: Insufficient logging, detection, monitoring
- **Common Weaknesses**: Logs not monitored, inadequate incident response
- **STRIDE Relevance**: Repudiation
- **Mitigation**: Comprehensive logging strategy
- **Testing**: Verify log coverage and alerting
