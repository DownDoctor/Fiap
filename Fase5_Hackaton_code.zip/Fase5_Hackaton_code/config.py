# config.py
"""
Sistema de configuração centralizada para STRIDE Analyzer Enhanced
Carrega configurações de variáveis de ambiente com fallbacks seguros
"""

import os
from pathlib import Path
from typing import Dict, Any, Optional
from dotenv import load_dotenv

# Carregar variáveis de ambiente
load_dotenv()

class Config:
    """Classe de configuração centralizada"""
    
    def __init__(self):
        self.base_dir = Path(__file__).parent
        self._validate_environment()
    
    # ===== OpenAI Configuration =====
    OPENAI_API_KEY: str = os.getenv('OPENAI_API_KEY', '')
    OPENAI_MODEL: str = os.getenv('OPENAI_MODEL', 'gpt-4o-mini')
    OPENAI_MAX_TOKENS: int = int(os.getenv('OPENAI_MAX_TOKENS', '4096'))
    OPENAI_TEMPERATURE: float = float(os.getenv('OPENAI_TEMPERATURE', '0.1'))
    
    @property
    def openai_available(self) -> bool:
        return bool(self.OPENAI_API_KEY and self.OPENAI_API_KEY.startswith('sk-'))
    
    # ===== YOLO Configuration =====
    YOLO_MODEL_PATH: str = os.getenv('YOLO_MODEL_PATH', './models/cloud_icons_detector.pt')
    YOLO_CONFIDENCE_THRESHOLD: float = float(os.getenv('YOLO_CONFIDENCE_THRESHOLD', '0.5'))
    YOLO_IOU_THRESHOLD: float = float(os.getenv('YOLO_IOU_THRESHOLD', '0.4'))
    YOLO_MAX_DETECTIONS: int = int(os.getenv('YOLO_MAX_DETECTIONS', '100'))
    
    @property
    def yolo_available(self) -> bool:
        return Path(self.YOLO_MODEL_PATH).exists()
    
    # ===== RAG Configuration =====
    RAG_CACHE_DIR: str = os.getenv('RAG_CACHE_DIR', './rag_cache')
    VECTOR_DB_PATH: str = os.getenv('VECTOR_DB_PATH', './chroma_db_enhanced')  
    EMBEDDING_MODEL: str = os.getenv('EMBEDDING_MODEL', 'all-MiniLM-L6-v2')
    RAG_TOP_K: int = int(os.getenv('RAG_TOP_K', '5'))
    RAG_SCORE_THRESHOLD: float = float(os.getenv('RAG_SCORE_THRESHOLD', '0.7'))
    
    # ===== Security KB Configuration =====
    SECURITY_KB_DIR: str = os.getenv('SECURITY_KB_DIR', './knowledge_base')
    ENABLE_KB_AUTO_UPDATE: bool = os.getenv('ENABLE_KB_AUTO_UPDATE', 'true').lower() == 'true'
    KB_UPDATE_INTERVAL_HOURS: int = int(os.getenv('KB_UPDATE_INTERVAL_HOURS', '24'))
    
    # ===== Streamlit Configuration =====
    STREAMLIT_SERVER_PORT: int = int(os.getenv('STREAMLIT_SERVER_PORT', '8501'))
    STREAMLIT_SERVER_ADDRESS: str = os.getenv('STREAMLIT_SERVER_ADDRESS', '0.0.0.0')
    STREAMLIT_THEME_BASE: str = os.getenv('STREAMLIT_THEME_BASE', 'light')
    STREAMLIT_THEME_PRIMARY_COLOR: str = os.getenv('STREAMLIT_THEME_PRIMARY_COLOR', '#667eea')
    
    # ===== Analysis Configuration =====
    MAX_IMAGE_SIZE_MB: int = int(os.getenv('MAX_IMAGE_SIZE_MB', '10'))
    MAX_CONCURRENT_ANALYSES: int = int(os.getenv('MAX_CONCURRENT_ANALYSES', '3'))
    ANALYSIS_CACHE_EXPIRY_HOURS: int = int(os.getenv('ANALYSIS_CACHE_EXPIRY_HOURS', '24'))
    DEFAULT_REPORT_FORMAT: str = os.getenv('DEFAULT_REPORT_FORMAT', 'html')
    
    # ===== Logging Configuration =====
    LOG_LEVEL: str = os.getenv('LOG_LEVEL', 'INFO')
    LOG_FILE: str = os.getenv('LOG_FILE', './logs/stride_analyzer.log')
    LOG_MAX_SIZE_MB: int = int(os.getenv('LOG_MAX_SIZE_MB', '100'))
    LOG_BACKUP_COUNT: int = int(os.getenv('LOG_BACKUP_COUNT', '5'))
    ENABLE_CONSOLE_LOGGING: bool = os.getenv('ENABLE_CONSOLE_LOGGING', 'true').lower() == 'true'
    
    # ===== Performance Configuration =====
    ENABLE_CACHING: bool = os.getenv('ENABLE_CACHING', 'true').lower() == 'true'
    CACHE_TTL_SECONDS: int = int(os.getenv('CACHE_TTL_SECONDS', '3600'))
    MAX_MEMORY_USAGE_GB: int = int(os.getenv('MAX_MEMORY_USAGE_GB', '4'))
    THREAD_POOL_SIZE: int = int(os.getenv('THREAD_POOL_SIZE', '4'))
    
    # ===== Security Configuration =====
    ENABLE_RATE_LIMITING: bool = os.getenv('ENABLE_RATE_LIMITING', 'true').lower() == 'true'
    MAX_REQUESTS_PER_MINUTE: int = int(os.getenv('MAX_REQUESTS_PER_MINUTE', '60'))
    ENABLE_INPUT_VALIDATION: bool = os.getenv('ENABLE_INPUT_VALIDATION', 'true').lower() == 'true'
    MAX_FILE_SIZE_MB: int = int(os.getenv('MAX_FILE_SIZE_MB', '50'))
    
    def _validate_environment(self):
        """Valida configuração do ambiente"""
        
        # Criar diretórios necessários
        required_dirs = [
            self.RAG_CACHE_DIR,
            self.VECTOR_DB_PATH, 
            self.SECURITY_KB_DIR,
            Path(self.LOG_FILE).parent,
            './models',
            './reports'
        ]
        
        for dir_path in required_dirs:
            Path(dir_path).mkdir(parents=True, exist_ok=True)
        
        # Validar configurações críticas
        if self.openai_available and not self.OPENAI_API_KEY.startswith('sk-'):
            print("⚠️ Warning: OPENAI_API_KEY format invalid")
        
        if self.YOLO_CONFIDENCE_THRESHOLD < 0.1 or self.YOLO_CONFIDENCE_THRESHOLD > 1.0:
            print("⚠️ Warning: YOLO_CONFIDENCE_THRESHOLD should be between 0.1 and 1.0")
        
        if self.MAX_IMAGE_SIZE_MB > 100:
            print("⚠️ Warning: MAX_IMAGE_SIZE_MB is very high (>100MB)")
    
    def get_config_summary(self) -> Dict[str, Any]:
        """Retorna resumo da configuração atual"""
        return {
            'openai_configured': self.openai_available,
            'yolo_available': self.yolo_available,
            'vector_db_path': self.VECTOR_DB_PATH,
            'kb_directory': self.SECURITY_KB_DIR,
            'log_level': self.LOG_LEVEL,
            'max_image_size_mb': self.MAX_IMAGE_SIZE_MB,
            'streamlit_port': self.STREAMLIT_SERVER_PORT,
            'caching_enabled': self.ENABLE_CACHING
        }
    
    def validate_openai_key(self, api_key: str) -> bool:
        """Valida formato da chave OpenAI"""
        return api_key.startswith('sk-') and len(api_key) > 20
    
    def get_streamlit_config(self) -> Dict[str, Any]:
        """Retorna configuração específica do Streamlit"""
        return {
            'server.port': self.STREAMLIT_SERVER_PORT,
            'server.address': self.STREAMLIT_SERVER_ADDRESS,
            'theme.base': self.STREAMLIT_THEME_BASE,
            'theme.primaryColor': self.STREAMLIT_THEME_PRIMARY_COLOR,
            'theme.backgroundColor': os.getenv('STREAMLIT_THEME_BACKGROUND_COLOR', '#FFFFFF'),
            'theme.secondaryBackgroundColor': os.getenv('STREAMLIT_THEME_SECONDARY_BACKGROUND_COLOR', '#f8f9fa'),
            'client.toolbarMode': 'minimal',
            'client.showErrorDetails': False
        }

# Instância global de configuração
config = Config()