# unified_stride_system.py
"""
Sistema STRIDE Unificado - Integração completa de todas as melhorias
Combina YOLO, Vision API, ML, RAG e análise avançada
"""

import streamlit as st
import asyncio
from pathlib import Path
import json
import time
from typing import Dict, List, Optional, Any
import numpy as np
from datetime import datetime
import logging

# Importar todos os módulos melhorados
from vector_database_enhanced import EnhancedVectorDB, RAGChatEngine
from yolo_icon_training_system import IconDetectionEngine, CloudIconDatasetBuilder
from openai_vision_integration import EnhancedVisionAnalyzer, VisionAnalysisRequest, AnalysisDepth
from ml_threat_pattern_detection import IntegratedThreatDetectionSystem
from enhanced_ocr_engine import MultiEngineOCR

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


class UnifiedSTRIDEAnalyzer:
    """Sistema unificado de análise STRIDE com todas as melhorias"""
    
    def __init__(self, config: Optional[Dict] = None):
        self.config = config or self._get_default_config()
        
        # Inicializar componentes
        self._initialize_components()
        
        # Cache e histórico
        self.analysis_cache = {}
        self.analysis_history = []
        
        logger.info("✓ Sistema STRIDE Unificado inicializado")
    
    def _get_default_config(self) -> Dict:
        """Configuração padrão do sistema"""
        return {
            'vector_db': {
                'persist_path': './chroma_db_enhanced',
                'embedding_model': 'all-mpnet-base-v2'
            },
            'yolo': {
                'model_path': './models/cloud_icons_best.pt',
                'confidence_threshold': 0.5
            },
            'vision': {
                'default_depth': AnalysisDepth.COMPREHENSIVE,
                'max_tokens': 4096,
                'temperature': 0.1
            },
            'ml': {
                'model_type': 'xgboost',
                'models_path': './models/threat_models'
            },
            'ocr': {
                'enable_all_engines': True
            },
            'cache': {
                'enabled': True,
                'ttl_seconds': 3600
            }
        }
    
    def _initialize_components(self):
        """Inicializa todos os componentes do sistema"""
        
        # 1. Banco Vetorial e RAG
        self.vector_db = EnhancedVectorDB(
            persist_path=self.config['vector_db']['persist_path']
        )
        self.rag_engine = RAGChatEngine(self.vector_db)
        
        # 2. YOLO para detecção de ícones
        yolo_path = Path(self.config['yolo']['model_path'])
        if yolo_path.exists():
            self.icon_detector = IconDetectionEngine(
                str(yolo_path),
                self.config['yolo']['confidence_threshold']
            )
        else:
            logger.warning("Modelo YOLO não encontrado - detecção de ícones desabilitada")
            self.icon_detector = None
        
        # 3. Vision Analyzer
        self.vision_analyzer = EnhancedVisionAnalyzer()
        
        # 4. Sistema ML de detecção de ameaças
        self.threat_detector = IntegratedThreatDetectionSystem()
        
        # Carregar modelos ML se existirem
        models_path = Path(self.config['ml']['models_path'])
        if models_path.exists():
            try:
                self.threat_detector.ml_classifier.load_models(str(models_path))
                logger.info("✓ Modelos ML carregados")
            except:
                logger.warning("Não foi possível carregar modelos ML")
        
        # 5. OCR Multi-engine
        self.ocr_engine = MultiEngineOCR()
    
    async def analyze_comprehensive(self, 
                                   image_path: str,
                                   analysis_options: Optional[Dict] = None) -> Dict:
        """
        Análise completa usando todos os sistemas
        
        Args:
            image_path: Caminho para a imagem do diagrama
            analysis_options: Opções específicas de análise
        
        Returns:
            Relatório completo consolidado
        """
        
        start_time = time.time()
        
        # Verificar cache
        cache_key = self._get_cache_key(image_path, analysis_options)
        if self.config['cache']['enabled'] and cache_key in self.analysis_cache:
            cached = self.analysis_cache[cache_key]
            if time.time() - cached['timestamp'] < self.config['cache']['ttl_seconds']:
                logger.info("Retornando resultado do cache")
                return cached['result']
        
        # Opções padrão
        options = {
            'use_yolo': True,
            'use_ocr': True,
            'use_vision': True,
            'use_ml': True,
            'vision_depth': AnalysisDepth.COMPREHENSIVE,
            'extract_text': True,
            'detect_patterns': True,
            'generate_recommendations': True
        }
        if analysis_options:
            options.update(analysis_options)
        
        logger.info(f"Iniciando análise completa de: {image_path}")
        
        # Executar análises em paralelo
        tasks = []
        
        # 1. Detecção de ícones com YOLO
        if options['use_yolo'] and self.icon_detector:
            tasks.append(self._yolo_detection(image_path))
        
        # 2. OCR para extração de texto
        if options['use_ocr']:
            tasks.append(self._ocr_extraction(image_path))
        
        # 3. Vision API para análise principal
        if options['use_vision']:
            tasks.append(self._vision_analysis(image_path, options['vision_depth']))
        
        # Executar tarefas em paralelo
        results = await asyncio.gather(*tasks, return_exceptions=True)
        
        # Processar resultados
        yolo_result = results[0] if len(results) > 0 and options['use_yolo'] else {}
        ocr_result = results[1] if len(results) > 1 and options['use_ocr'] else {}
        vision_result = results[2] if len(results) > 2 and options['use_vision'] else {}
        
        # Consolidar informações
        consolidated = self._consolidate_results(yolo_result, ocr_result, vision_result)
        
        # 4. Detecção de padrões de ameaças com ML
        if options['use_ml']:
            ml_threats = await self._ml_threat_detection(consolidated)
            consolidated['ml_threats'] = ml_threats
        
        # 5. Gerar recomendações avançadas
        if options['generate_recommendations']:
            recommendations = self._generate_advanced_recommendations(consolidated)
            consolidated['advanced_recommendations'] = recommendations
        
        # 6. Adicionar ao banco vetorial para RAG
        self._update_vector_db(consolidated)
        
        # Calcular métricas finais
        consolidated['analysis_metrics'] = {
            'execution_time': time.time() - start_time,
            'components_detected': len(consolidated.get('components', [])),
            'threats_identified': len(consolidated.get('all_threats', [])),
            'risk_score': consolidated.get('risk_score', 0),
            'confidence_level': self._calculate_confidence(consolidated)
        }
        
        # Adicionar ao histórico
        self.analysis_history.append({
            'timestamp': datetime.now().isoformat(),
            'image_path': image_path,
            'summary': self._create_summary(consolidated)
        })
        
        # Cachear resultado
        if self.config['cache']['enabled']:
            self.analysis_cache[cache_key] = {
                'timestamp': time.time(),
                'result': consolidated
            }
        
        logger.info(f"✓ Análise completa em {consolidated['analysis_metrics']['execution_time']:.2f}s")
        
        return consolidated
    
    async def _yolo_detection(self, image_path: str) -> Dict:
        """Detecção de ícones com YOLO"""
        try:
            logger.info("Executando detecção YOLO...")
            
            # Detectar ícones
            detections = await asyncio.to_thread(
                self.icon_detector.detect_icons,
                image_path
            )
            
            # Analisar composição
            composition = await asyncio.to_thread(
                self.icon_detector.analyze_architecture_composition,
                detections
            )
            
            return {
                'icon_detections': detections,
                'composition_analysis': composition,
                'total_icons': len(detections)
            }
            
        except Exception as e:
            logger.error(f"Erro na detecção YOLO: {str(e)}")
            return {}
    
    async def _ocr_extraction(self, image_path: str) -> Dict:
        """Extração de texto com OCR multi-engine"""
        try:
            logger.info("Executando OCR multi-engine...")
            
            ocr_results = await asyncio.to_thread(
                self.ocr_engine.extract_comprehensive_text,
                image_path
            )
            
            # Processar e consolidar textos
            all_texts = []
            for engine, results in ocr_results.items():
                if isinstance(results, list):
                    all_texts.extend([r.get('text', '') for r in results if r.get('text')])
            
            # Remover duplicatas
            unique_texts = list(set(all_texts))
            
            return {
                'extracted_texts': unique_texts,
                'raw_results': ocr_results,
                'text_count': len(unique_texts)
            }
            
        except Exception as e:
            logger.error(f"Erro no OCR: {str(e)}")
            return {}
    
    async def _vision_analysis(self, image_path: str, depth: AnalysisDepth) -> Dict:
        """Análise com Vision API"""
        try:
            logger.info(f"Executando Vision API (depth: {depth.value})...")
            
            request = VisionAnalysisRequest(
                image_path=image_path,
                analysis_depth=depth,
                focus_areas=['security', 'architecture', 'compliance', 'performance'],
                include_ocr=False,  # Já fazemos OCR separadamente
                include_icons=False,  # Já temos YOLO
                include_flows=True,
                include_security=True,
                include_cost=True,
                max_tokens=self.config['vision']['max_tokens'],
                temperature=self.config['vision']['temperature']
            )
            
            result = await asyncio.to_thread(
                self.vision_analyzer.analyze,
                request
            )
            
            return result
            
        except Exception as e:
            logger.error(f"Erro na Vision API: {str(e)}")
            return {}
    
    async def _ml_threat_detection(self, consolidated_data: Dict) -> Dict:
        """Detecção de ameaças com ML"""
        try:
            logger.info("Executando detecção ML de ameaças...")
            
            # Preparar dados para ML
            architecture_data = {
                'components': consolidated_data.get('components', []),
                'connections': consolidated_data.get('connections', []),
                'architecture_analysis': consolidated_data.get('architecture_overview', {})
            }
            
            # Detectar ameaças
            threat_report = await asyncio.to_thread(
                self.threat_detector.analyze_threats,
                architecture_data,
                use_ml=True,
                use_patterns=True,
                use_deep=False
            )
            
            return threat_report
            
        except Exception as e:
            logger.error(f"Erro na detecção ML: {str(e)}")
            return {}
    
    def _consolidate_results(self, yolo: Dict, ocr: Dict, vision: Dict) -> Dict:
        """Consolida resultados de todas as análises"""
        consolidated = {
            'timestamp': datetime.now().isoformat(),
            'analysis_version': '3.0'
        }
        
        # Componentes detectados
        components = []
        
        # Componentes do Vision
        if 'components' in vision:
            components.extend(vision['components'])
        
        # Componentes do YOLO
        if 'icon_detections' in yolo:
            for detection in yolo['icon_detections']:
                # Verificar se não é duplicata
                comp_name = detection['class']
                if not any(c.get('name') == comp_name for c in components):
                    components.append({
                        'name': comp_name,
                        'type': detection['category'],
                        'provider': detection['provider'],
                        'position': {'x': detection['center'][0], 'y': detection['center'][1]},
                        'confidence': detection['confidence'],
                        'source': 'yolo'
                    })
        
        # Enriquecer com informações do OCR
        if 'extracted_texts' in ocr:
            for text in ocr['extracted_texts'][:20]:  # Limitar para performance
                # Tentar identificar configurações ou labels
                for comp in components:
                    if comp['name'].lower() in text.lower():
                        if 'labels' not in comp:
                            comp['labels'] = []
                        comp['labels'].append(text)
        
        consolidated['components'] = components
        
        # Conexões e fluxos
        consolidated['connections'] = vision.get('connections', [])
        
        # Análise de segurança
        all_threats = []
        
        # Threats do Vision
        if 'security_analysis' in vision:
            stride_threats = vision['security_analysis'].get('stride_threats', [])
            all_threats.extend(stride_threats)
        
        consolidated['all_threats'] = all_threats
        
        # Arquitetura overview
        consolidated['architecture_overview'] = vision.get('architecture_overview', {})
        
        # Estatísticas do YOLO
        if 'composition_analysis' in yolo:
            consolidated['icon_statistics'] = yolo['composition_analysis']
        
        # Textos extraídos
        if 'extracted_texts' in ocr:
            consolidated['extracted_texts'] = ocr['extracted_texts']
        
        # Risk score
        if 'risk_score' in vision:
            consolidated['risk_score'] = vision['risk_score']
        else:
            consolidated['risk_score'] = self._calculate_risk_score(all_threats)
        
        # Recomendações
        consolidated['recommendations'] = vision.get('recommendations', {})
        
        return consolidated
    
    def _generate_advanced_recommendations(self, data: Dict) -> Dict:
        """Gera recomendações avançadas baseadas em toda a análise"""
        recommendations = {
            'security': [],
            'architecture': [],
            'compliance': [],
            'performance': [],
            'cost': []
        }
        
        # Análise de componentes
        components = data.get('components', [])
        threats = data.get('all_threats', [])
        ml_report = data.get('ml_threats', {})
        
        # Recomendações de segurança baseadas em threats
        critical_threats = [t for t in threats if t.get('severity') == 'critical']
        if critical_threats:
            recommendations['security'].append({
                'priority': 'IMMEDIATE',
                'title': 'Address Critical Security Threats',
                'description': f'Found {len(critical_threats)} critical threats requiring immediate attention',
                'actions': [t.get('mitigation', '') for t in critical_threats[:3] if t.get('mitigation')]
            })
        
        # Recomendações de arquitetura baseadas em padrões
        if 'icon_statistics' in data:
            stats = data['icon_statistics']
            if stats.get('providers', {}):
                if len(stats['providers']) > 2:
                    recommendations['architecture'].append({
                        'priority': 'MEDIUM',
                        'title': 'Multi-Cloud Complexity',
                        'description': 'Architecture spans multiple cloud providers',
                        'actions': [
                            'Implement unified monitoring across clouds',
                            'Standardize security policies',
                            'Consider cloud-agnostic tools'
                        ]
                    })
        
        # Recomendações de compliance baseadas em ML
        if 'compliance_impact' in ml_report:
            impact = ml_report['compliance_impact']
            if impact.get('compliance_risk') == 'HIGH':
                recommendations['compliance'].append({
                    'priority': 'HIGH',
                    'title': 'Compliance Risk Detected',
                    'description': f"Affected frameworks: {', '.join(impact.get('affected_frameworks', []))}",
                    'actions': [
                        'Review affected controls',
                        'Implement missing compliance requirements',
                        'Schedule compliance audit'
                    ]
                })
        
        # Recomendações de performance
        connections = data.get('connections', [])
        unencrypted = [c for c in connections if c.get('encryption') in ['None', None]]
        if unencrypted:
            recommendations['performance'].append({
                'priority': 'MEDIUM',
                'title': 'Unencrypted Connections',
                'description': f'Found {len(unencrypted)} unencrypted connections',
                'actions': [
                    'Implement TLS/mTLS for all connections',
                    'Consider service mesh for automatic encryption',
                    'Review data classification requirements'
                ]
            })
        
        # Recomendações de custo
        if 'cost_analysis' in data:
            cost = data['cost_analysis']
            if cost.get('potential_savings', '0%').replace('%', '') != '0':
                recommendations['cost'].append({
                    'priority': 'LOW',
                    'title': 'Cost Optimization Opportunity',
                    'description': f"Potential savings: {cost.get('potential_savings', 'N/A')}",
                    'actions': cost.get('optimization_opportunities', [])
                })
        
        return recommendations
    
    def _update_vector_db(self, analysis_result: Dict):
        """Atualiza banco vetorial com resultado da análise"""
        try:
            # Adicionar análise ao histórico do banco
            doc_id = self.vector_db.add_analysis_to_history(analysis_result)
            logger.info(f"✓ Análise adicionada ao banco vetorial: {doc_id}")
            
        except Exception as e:
            logger.error(f"Erro ao atualizar banco vetorial: {str(e)}")
    
    def _calculate_risk_score(self, threats: List[Dict]) -> float:
        """Calcula risk score baseado nas ameaças"""
        if not threats:
            return 0.0
        
        severity_weights = {
            'critical': 10,
            'high': 7,
            'medium': 4,
            'low': 1
        }
        
        total_score = sum(
            severity_weights.get(t.get('severity', 'medium'), 4)
            for t in threats
        )
        
        # Normalizar para escala 0-10
        max_possible = len(threats) * 10
        normalized = min(10, (total_score / max_possible) * 10) if max_possible > 0 else 0
        
        return round(normalized, 1)
    
    def _calculate_confidence(self, data: Dict) -> float:
        """Calcula nível de confiança da análise"""
        confidence_factors = []
        
        # Fator 1: Componentes detectados
        components = data.get('components', [])
        if components:
            avg_confidence = np.mean([c.get('confidence', 0.5) for c in components])
            confidence_factors.append(avg_confidence)
        
        # Fator 2: Múltiplas fontes de detecção
        sources = set()
        for comp in components:
            source = comp.get('source', 'unknown')
            sources.add(source)
        
        multi_source_factor = min(1.0, len(sources) / 3)  # Max 3 fontes
        confidence_factors.append(multi_source_factor)
        
        # Fator 3: Completude da análise
        has_vision = 'architecture_overview' in data
        has_ml = 'ml_threats' in data
        has_icons = 'icon_statistics' in data
        
        completeness = sum([has_vision, has_ml, has_icons]) / 3
        confidence_factors.append(completeness)
        
        # Calcular média
        if confidence_factors:
            return round(np.mean(confidence_factors), 2)
        return 0.5
    
    def _create_summary(self, data: Dict) -> Dict:
        """Cria resumo executivo da análise"""
        return {
            'components': len(data.get('components', [])),
            'threats': len(data.get('all_threats', [])),
            'risk_score': data.get('risk_score', 0),
            'architecture_type': data.get('architecture_overview', {}).get('type', 'unknown'),
            'confidence': data.get('analysis_metrics', {}).get('confidence_level', 0)
        }
    
    def _get_cache_key(self, image_path: str, options: Optional[Dict]) -> str:
        """Gera chave de cache"""
        import hashlib
        
        # Ler primeiros bytes da imagem
        with open(image_path, 'rb') as f:
            image_hash = hashlib.md5(f.read(1024)).hexdigest()
        
        # Incluir opções na chave
        options_str = json.dumps(options or {}, sort_keys=True)
        
        key_data = f"{image_hash}_{options_str}"
        return hashlib.md5(key_data.encode()).hexdigest()
    
    async def chat_with_analysis(self, query: str, 
                                analysis_result: Optional[Dict] = None) -> str:
        """
        Chat interativo sobre a análise usando RAG
        
        Args:
            query: Pergunta do usuário
            analysis_result: Resultado da análise para contexto
        
        Returns:
            Resposta do chat
        """
        try:
            response = await asyncio.to_thread(
                self.rag_engine.chat,
                query=query,
                analysis_result=analysis_result,
                use_openai=True,
                model="gpt-4o-mini"
            )
            
            return response
            
        except Exception as e:
            logger.error(f"Erro no chat: {str(e)}")
            return f"Desculpe, ocorreu um erro ao processar sua pergunta: {str(e)}"
    
    def export_report(self, analysis_result: Dict, 
                     format: str = 'html',
                     output_path: Optional[str] = None) -> str:
        """
        Exporta relatório em diferentes formatos
        
        Args:
            analysis_result: Resultado da análise
            format: Formato de exportação (html, json, markdown, pdf)
            output_path: Caminho de saída (opcional)
        
        Returns:
            Caminho do arquivo exportado
        """
        if not output_path:
            timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
            output_path = f"stride_report_{timestamp}.{format}"
        
        output_path = Path(output_path)
        
        if format == 'json':
            with open(output_path, 'w') as f:
                json.dump(analysis_result, f, indent=2, default=str)
        
        elif format == 'html':
            html_content = self._generate_html_report(analysis_result)
            with open(output_path, 'w') as f:
                f.write(html_content)
        
        elif format == 'markdown':
            md_content = self._generate_markdown_report(analysis_result)
            with open(output_path, 'w') as f:
                f.write(md_content)
        
        elif format == 'pdf':
            # Gerar HTML primeiro, depois converter para PDF
            html_content = self._generate_html_report(analysis_result)
            self._html_to_pdf(html_content, output_path)
        
        else:
            raise ValueError(f"Formato não suportado: {format}")
        
        logger.info(f"✓ Relatório exportado: {output_path}")
        return str(output_path)
    
    def _generate_html_report(self, data: Dict) -> str:
        """Gera relatório HTML completo"""
        risk_score = data.get('risk_score', 0)
        risk_color = '#28a745' if risk_score < 4 else '#ffc107' if risk_score < 7 else '#dc3545'
        
        html = f"""<!DOCTYPE html>
<html>
<head>
    <title>STRIDE Analysis Report - Enhanced</title>
    <meta charset="UTF-8">
    <style>
        body {{ 
            font-family: 'Segoe UI', system-ui, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
            min-height: 100vh;
        }}
        .container {{ 
            max-width: 1400px; 
            margin: 0 auto; 
            background: white; 
            padding: 40px; 
            border-radius: 20px; 
            box-shadow: 0 20px 60px rgba(0,0,0,0.3);
        }}
        .header {{ 
            background: linear-gradient(135deg, #1e3c72 0%, #2a5298 100%); 
            color: white; 
            padding: 40px; 
            border-radius: 15px; 
            margin-bottom: 40px; 
            text-align: center;
        }}
        .header h1 {{ margin: 0; font-size: 2.5em; }}
        .header p {{ margin: 10px 0 0 0; opacity: 0.9; font-size: 1.2em; }}
        
        .metrics-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
            gap: 20px;
            margin-bottom: 40px;
        }}
        
        .metric-card {{
            background: white;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            text-align: center;
            border-top: 4px solid #007bff;
            transition: transform 0.3s ease;
        }}
        
        .metric-card:hover {{ transform: translateY(-5px); }}
        
        .metric-card h3 {{
            color: #6c757d;
            font-size: 0.9em;
            text-transform: uppercase;
            letter-spacing: 1px;
            margin: 0 0 15px 0;
        }}
        
        .metric-value {{
            font-size: 2.5em;
            font-weight: bold;
            color: #2c3e50;
        }}
        
        .risk-score {{
            color: {risk_color};
        }}
        
        .section {{
            background: #f8f9fa;
            padding: 30px;
            border-radius: 12px;
            margin-bottom: 30px;
            border-left: 5px solid #007bff;
        }}
        
        .section h2 {{
            color: #2c3e50;
            margin: 0 0 20px 0;
        }}
        
        .threat-item {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 4px solid #dc3545;
        }}
        
        .component-grid {{
            display: grid;
            grid-template-columns: repeat(auto-fill, minmax(200px, 1fr));
            gap: 15px;
        }}
        
        .component-card {{
            background: white;
            padding: 15px;
            border-radius: 8px;
            border: 1px solid #dee2e6;
            text-align: center;
        }}
        
        .recommendation {{
            background: white;
            padding: 20px;
            border-radius: 8px;
            margin-bottom: 15px;
            border-left: 4px solid #28a745;
        }}
        
        .confidence-bar {{
            width: 100%;
            height: 20px;
            background: #e9ecef;
            border-radius: 10px;
            overflow: hidden;
        }}
        
        .confidence-fill {{
            height: 100%;
            background: linear-gradient(90deg, #28a745, #20c997);
            transition: width 0.5s ease;
        }}
        
        .footer {{
            text-align: center;
            padding: 30px;
            margin-top: 50px;
            border-top: 2px solid #dee2e6;
            color: #6c757d;
        }}
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>🔒 STRIDE Security Analysis Report</h1>
            <p>Enhanced Multi-Cloud Architecture Analysis with AI</p>
            <p style="font-size: 0.9em; margin-top: 15px;">
                {data.get('timestamp', 'N/A')} | Version {data.get('analysis_version', '3.0')}
            </p>
        </div>
        
        <div class="metrics-grid">
            <div class="metric-card">
                <h3>Risk Score</h3>
                <div class="metric-value risk-score">{risk_score}/10</div>
            </div>
            <div class="metric-card">
                <h3>Components</h3>
                <div class="metric-value">{len(data.get('all_threats', []))}</div>
            </div>
            <div class="metric-card">
                <h3>Confidence</h3>
                <div class="metric-value">{data.get('analysis_metrics', {}).get('confidence_level', 0)*100:.0f}%</div>
                <div class="confidence-bar">
                    <div class="confidence-fill" style="width: {data.get('analysis_metrics', {}).get('confidence_level', 0)*100}%"></div>
                </div>
            </div>
        </div>
        
        <div class="section">
            <h2>🏗️ Architecture Overview</h2>
            <p><strong>Type:</strong> {data.get('architecture_overview', {}).get('type', 'Unknown')}</p>
            <p><strong>Cloud Providers:</strong> {', '.join(data.get('architecture_overview', {}).get('cloud_providers', {}).get('primary', ['N/A']))}</p>
            <p><strong>Analysis Time:</strong> {data.get('analysis_metrics', {}).get('execution_time', 0):.2f} seconds</p>
        </div>
        
        <div class="section">
            <h2>📦 Components Detected</h2>
            <div class="component-grid">
                {self._generate_components_html(data.get('components', [])[:12])}
            </div>
        </div>
        
        <div class="section">
            <h2>🎯 Top Security Threats</h2>
            {self._generate_threats_html(data.get('all_threats', [])[:5])}
        </div>
        
        <div class="section">
            <h2>💡 Recommendations</h2>
            {self._generate_recommendations_html(data.get('advanced_recommendations', {}))}
        </div>
        
        <div class="footer">
            <p><strong>🔒 STRIDE Analysis System v3.0</strong></p>
            <p>Powered by YOLO Icon Detection | OpenAI Vision API | Machine Learning | RAG</p>
            <p style="font-size: 0.9em; margin-top: 10px;">
                Components: {len(data.get('components', []))} | 
                Threats: {len(data.get('all_threats', []))} | 
                Risk Score: {risk_score}/10 | 
                Confidence: {data.get('analysis_metrics', {}).get('confidence_level', 0)*100:.0f}%
            </p>
        </div>
    </div>
</body>
</html>"""
        
        return html
    
    def _generate_components_html(self, components: List[Dict]) -> str:
        """Gera HTML para componentes"""
        html = ""
        for comp in components:
            provider_colors = {
                'AWS': '#FF9900',
                'Azure': '#0078D4',
                'GCP': '#4285F4',
                'Kubernetes': '#326CE5'
            }
            color = provider_colors.get(comp.get('provider', ''), '#6c757d')
            
            html += f"""
            <div class="component-card" style="border-top: 3px solid {color}">
                <strong>{comp.get('name', 'Unknown')}</strong><br>
                <small>{comp.get('provider', 'N/A')} - {comp.get('type', 'N/A')}</small><br>
                <small>Confidence: {comp.get('confidence', 0)*100:.0f}%</small>
            </div>
            """
        
        return html
    
    def _generate_threats_html(self, threats: List[Dict]) -> str:
        """Gera HTML para threats"""
        if not threats:
            return "<p>No threats detected</p>"
        
        html = ""
        for threat in threats:
            severity_colors = {
                'critical': '#dc3545',
                'high': '#fd7e14',
                'medium': '#ffc107',
                'low': '#28a745'
            }
            color = severity_colors.get(threat.get('severity', 'medium'), '#6c757d')
            
            html += f"""
            <div class="threat-item" style="border-left-color: {color}">
                <strong>{threat.get('category', 'Unknown')} - {threat.get('severity', 'N/A').upper()}</strong><br>
                <p>{threat.get('description', 'No description available')}</p>
                <p><strong>Mitigation:</strong> {threat.get('mitigation', 'Review security controls')}</p>
            </div>
            """
        
        return html
    
    def _generate_recommendations_html(self, recommendations: Dict) -> str:
        """Gera HTML para recomendações"""
        html = ""
        
        priority_order = ['security', 'compliance', 'architecture', 'performance', 'cost']
        
        for category in priority_order:
            if category in recommendations and recommendations[category]:
                html += f"<h3>{category.title()} Recommendations</h3>"
                
                for rec in recommendations[category][:3]:
                    priority_colors = {
                        'IMMEDIATE': '#dc3545',
                        'HIGH': '#fd7e14',
                        'MEDIUM': '#ffc107',
                        'LOW': '#28a745'
                    }
                    color = priority_colors.get(rec.get('priority', 'MEDIUM'), '#6c757d')
                    
                    html += f"""
                    <div class="recommendation" style="border-left-color: {color}">
                        <strong>[{rec.get('priority', 'N/A')}] {rec.get('title', 'Recommendation')}</strong><br>
                        <p>{rec.get('description', '')}</p>
                        <ul>
                            {"".join([f"<li>{action}</li>" for action in rec.get('actions', [])[:3]])}
                        </ul>
                    </div>
                    """
        
        return html or "<p>No specific recommendations available</p>"
    
    def _generate_markdown_report(self, data: Dict) -> str:
        """Gera relatório em Markdown"""
        risk_score = data.get('risk_score', 0)
        
        md = f"""# STRIDE Security Analysis Report

**Generated:** {data.get('timestamp', 'N/A')}  
**Version:** {data.get('analysis_version', '3.0')}

## Executive Summary

- **Risk Score:** {risk_score}/10
- **Components Detected:** {len(data.get('components', []))}
- **Threats Identified:** {len(data.get('all_threats', []))}
- **Confidence Level:** {data.get('analysis_metrics', {}).get('confidence_level', 0)*100:.0f}%
- **Analysis Time:** {data.get('analysis_metrics', {}).get('execution_time', 0):.2f} seconds

## Architecture Overview

- **Type:** {data.get('architecture_overview', {}).get('type', 'Unknown')}
- **Primary Cloud:** {data.get('architecture_overview', {}).get('cloud_providers', {}).get('primary', 'N/A')}
- **Multi-Cloud:** {data.get('architecture_overview', {}).get('cloud_providers', {}).get('multi_cloud', False)}

## Components Detected

"""
        
        for comp in data.get('components', [])[:10]:
            md += f"- **{comp.get('name', 'Unknown')}** ({comp.get('provider', 'N/A')}): {comp.get('type', 'N/A')} - Confidence: {comp.get('confidence', 0)*100:.0f}%\n"
        
        md += "\n## Top Security Threats\n\n"
        
        for i, threat in enumerate(data.get('all_threats', [])[:5], 1):
            md += f"""### {i}. {threat.get('category', 'Unknown')} - {threat.get('severity', 'N/A').upper()}

**Description:** {threat.get('description', 'N/A')}

**Mitigation:** {threat.get('mitigation', 'Review security controls')}

"""
        
        md += "## Recommendations\n\n"
        
        recs = data.get('advanced_recommendations', {})
        for category, items in recs.items():
            if items:
                md += f"### {category.title()}\n\n"
                for rec in items[:2]:
                    md += f"**[{rec.get('priority', 'N/A')}] {rec.get('title', 'Recommendation')}**\n\n"
                    md += f"{rec.get('description', '')}\n\n"
                    for action in rec.get('actions', [])[:3]:
                        md += f"- {action}\n"
                    md += "\n"
        
        return md
    
    def _html_to_pdf(self, html_content: str, output_path: Path):
        """Converte HTML para PDF"""
        try:
            # Tentar diferentes métodos de conversão
            
            # Método 1: pdfkit (requer wkhtmltopdf)
            try:
                import pdfkit
                pdfkit.from_string(html_content, str(output_path))
                return
            except:
                pass
            
            # Método 2: weasyprint
            try:
                from weasyprint import HTML
                HTML(string=html_content).write_pdf(str(output_path))
                return
            except:
                pass
            
            # Método 3: xhtml2pdf
            try:
                from xhtml2pdf import pisa
                with open(output_path, "wb") as f:
                    pisa.CreatePDF(html_content, dest=f)
                return
            except:
                pass
            
            # Se nenhum método funcionar, salvar como HTML
            logger.warning("PDF conversion failed, saving as HTML")
            output_path = output_path.with_suffix('.html')
            with open(output_path, 'w') as f:
                f.write(html_content)
                
        except Exception as e:
            logger.error(f"Erro na conversão para PDF: {str(e)}")
            raise


# Interface Streamlit
def create_streamlit_app():
    """Cria interface Streamlit para o sistema unificado"""
    
    st.set_page_config(
        page_title="STRIDE Analyzer - Unified System",
        page_icon="🔒",
        layout="wide"
    )
    
    st.title("🔒 STRIDE Security Analyzer - Unified System v3.0")
    st.markdown("""
    **Sistema completo de análise de segurança com:**
    - 🎯 YOLO para detecção de ícones cloud
    - 👁️ OpenAI Vision API para análise profunda
    - 🤖 Machine Learning para detecção de padrões
    - 💬 Chat RAG com conhecimento de segurança
    - 📊 OCR multi-engine para extração de texto
    """)
    
    # Inicializar sistema
    if 'analyzer' not in st.session_state:
        with st.spinner("Inicializando sistema..."):
            st.session_state.analyzer = UnifiedSTRIDEAnalyzer()
    
    # Tabs principais
    tab1, tab2, tab3, tab4 = st.tabs(["📤 Upload & Análise", "📊 Resultados", "💬 Chat", "⚙️ Configurações"])
    
    with tab1:
        st.header("Upload e Análise")
        
        uploaded_file = st.file_uploader(
            "Selecione o diagrama de arquitetura",
            type=['png', 'jpg', 'jpeg', 'bmp'],
            help="Formatos suportados: PNG, JPG, JPEG, BMP"
        )
        
        if uploaded_file:
            # Salvar arquivo temporário
            temp_path = Path(f"temp_{uploaded_file.name}")
            with open(temp_path, 'wb') as f:
                f.write(uploaded_file.getbuffer())
            
            st.image(str(temp_path), caption="Diagrama carregado", use_column_width=True)
            
            # Opções de análise
            col1, col2 = st.columns(2)
            
            with col1:
                st.subheader("Opções de Análise")
                use_yolo = st.checkbox("🎯 Detecção de Ícones (YOLO)", value=True)
                use_ocr = st.checkbox("📝 Extração de Texto (OCR)", value=True)
                use_vision = st.checkbox("👁️ Vision API", value=True)
                use_ml = st.checkbox("🤖 Machine Learning", value=True)
            
            with col2:
                st.subheader("Profundidade")
                depth = st.select_slider(
                    "Nível de análise",
                    options=['basic', 'standard', 'detailed', 'comprehensive'],
                    value='comprehensive'
                )
                
                generate_recommendations = st.checkbox("💡 Gerar Recomendações", value=True)
            
            if st.button("🚀 Iniciar Análise", type="primary"):
                with st.spinner("Analisando arquitetura... Isso pode levar alguns minutos."):
                    
                    # Preparar opções
                    analysis_options = {
                        'use_yolo': use_yolo,
                        'use_ocr': use_ocr,
                        'use_vision': use_vision,
                        'use_ml': use_ml,
                        'vision_depth': AnalysisDepth[depth.upper()],
                        'generate_recommendations': generate_recommendations
                    }
                    
                    # Executar análise
                    result = asyncio.run(
                        st.session_state.analyzer.analyze_comprehensive(
                            str(temp_path),
                            analysis_options
                        )
                    )
                    
                    # Salvar resultado
                    st.session_state.analysis_result = result
                    
                    # Métricas principais
                    col1, col2, col3, col4 = st.columns(4)
                    
                    with col1:
                        st.metric(
                            "Risk Score",
                            f"{result.get('risk_score', 0)}/10"
                        )
                    
                    with col2:
                        st.metric(
                            "Components",
                            len(result.get('components', []))
                        )
                    
                    with col3:
                        st.metric(
                            "Threats",
                            len(result.get('all_threats', []))
                        )
                    
                    with col4:
                        confidence = result.get('analysis_metrics', {}).get('confidence_level', 0)
                        st.metric(
                            "Confidence",
                            f"{confidence*100:.0f}%"
                        )
                    
                    st.success("✅ Análise concluída com sucesso!")
                
                # Limpar arquivo temporário
                temp_path.unlink()
    
    with tab2:
        st.header("Resultados da Análise")
        
        if 'analysis_result' in st.session_state:
            result = st.session_state.analysis_result
            
            # Visão geral
            st.subheader("📊 Visão Geral")
            col1, col2 = st.columns(2)
            
            with col1:
                st.info(f"""
                **Tipo de Arquitetura:** {result.get('architecture_overview', {}).get('type', 'Unknown')}  
                **Providers:** {', '.join(str(p) for p in result.get('architecture_overview', {}).get('cloud_providers', {}).get('primary', ['N/A']))}  
                **Multi-Cloud:** {result.get('architecture_overview', {}).get('cloud_providers', {}).get('multi_cloud', False)}
                """)
            
            with col2:
                st.info(f"""
                **Tempo de Análise:** {result.get('analysis_metrics', {}).get('execution_time', 0):.2f}s  
                **Confiança:** {result.get('analysis_metrics', {}).get('confidence_level', 0)*100:.0f}%  
                **Risk Score:** {result.get('risk_score', 0)}/10
                """)
            
            # Componentes
            st.subheader("📦 Componentes Detectados")
            components_df = []
            for comp in result.get('components', [])[:20]:
                components_df.append({
                    'Nome': comp.get('name', 'Unknown'),
                    'Provider': comp.get('provider', 'N/A'),
                    'Tipo': comp.get('type', 'N/A'),
                    'Confiança': f"{comp.get('confidence', 0)*100:.0f}%",
                    'Fonte': comp.get('source', 'vision')
                })
            
            if components_df:
                st.dataframe(components_df)
            
            # Threats
            st.subheader("🎯 Ameaças Identificadas")
            for threat in result.get('all_threats', [])[:10]:
                severity = threat.get('severity', 'medium')
                severity_colors = {
                    'critical': '🔴',
                    'high': '🟠',
                    'medium': '🟡',
                    'low': '🟢'
                }
                
                with st.expander(f"{severity_colors.get(severity, '⚪')} {threat.get('category', 'Unknown')} - {severity.upper()}"):
                    st.write(f"**Descrição:** {threat.get('description', 'N/A')}")
                    st.write(f"**Mitigação:** {threat.get('mitigation', 'Review security controls')}")
                    if threat.get('references'):
                        st.write(f"**Referências:** {', '.join(threat['references'])}")
            
            # Recomendações
            st.subheader("💡 Recomendações")
            recs = result.get('advanced_recommendations', {})
            
            for category, items in recs.items():
                if items:
                    st.write(f"**{category.title()}:**")
                    for rec in items[:3]:
                        priority = rec.get('priority', 'MEDIUM')
                        st.write(f"- [{priority}] {rec.get('title', 'Recommendation')}")
                        st.write(f"  {rec.get('description', '')}")
            
            # Export
            st.subheader("📤 Exportar Relatório")
            col1, col2, col3, col4 = st.columns(4)
            
            with col1:
                if st.button("📄 JSON"):
                    path = st.session_state.analyzer.export_report(result, 'json')
                    st.success(f"Exportado: {path}")
            
            with col2:
                if st.button("🌐 HTML"):
                    path = st.session_state.analyzer.export_report(result, 'html')
                    st.success(f"Exportado: {path}")
            
            with col3:
                if st.button("📝 Markdown"):
                    path = st.session_state.analyzer.export_report(result, 'markdown')
                    st.success(f"Exportado: {path}")
            
            with col4:
                if st.button("📑 PDF"):
                    path = st.session_state.analyzer.export_report(result, 'pdf')
                    st.success(f"Exportado: {path}")
        
        else:
            st.info("Execute uma análise primeiro na aba 'Upload & Análise'")
    
    with tab3:
        st.header("Chat sobre a Análise")
        
        if 'analysis_result' in st.session_state:
            st.info("💬 Faça perguntas sobre a arquitetura analisada usando nosso sistema RAG com conhecimento de segurança")
            
            # Histórico do chat
            if 'chat_history' not in st.session_state:
                st.session_state.chat_history = []
            
            # Exibir histórico
            for message in st.session_state.chat_history:
                with st.chat_message(message["role"]):
                    st.write(message["content"])
            
            # Input do usuário
            if prompt := st.chat_input("Digite sua pergunta..."):
                # Adicionar pergunta ao histórico
                st.session_state.chat_history.append({"role": "user", "content": prompt})
                
                with st.chat_message("user"):
                    st.write(prompt)
                
                # Gerar resposta
                with st.chat_message("assistant"):
                    with st.spinner("Pensando..."):
                        response = asyncio.run(
                            st.session_state.analyzer.chat_with_analysis(
                                prompt,
                                st.session_state.analysis_result
                            )
                        )
                    st.write(response)
                
                # Adicionar resposta ao histórico
                st.session_state.chat_history.append({"role": "assistant", "content": response})
        
        else:
            st.info("Execute uma análise primeiro para habilitar o chat")
    
    with tab4:
        st.header("Configurações")
        
        st.subheader("🎯 YOLO")
        yolo_confidence = st.slider("Confidence Threshold", 0.1, 1.0, 0.5, 0.05)
        
        st.subheader("👁️ Vision API")
        vision_temp = st.slider("Temperature", 0.0, 1.0, 0.1, 0.05)
        max_tokens = st.number_input("Max Tokens", 1000, 8000, 4096, 100)
        
        st.subheader("🤖 Machine Learning")
        ml_model = st.selectbox("Modelo ML", ["xgboost", "random_forest", "gradient_boosting"])
        
        st.subheader("💾 Cache")
        enable_cache = st.checkbox("Habilitar Cache", value=True)
        cache_ttl = st.number_input("TTL (segundos)", 60, 7200, 3600, 60)
        
        if st.button("💾 Salvar Configurações"):
            # Atualizar configurações
            st.session_state.analyzer.config.update({
                'yolo': {'confidence_threshold': yolo_confidence},
                'vision': {'temperature': vision_temp, 'max_tokens': max_tokens},
                'ml': {'model_type': ml_model},
                'cache': {'enabled': enable_cache, 'ttl_seconds': cache_ttl}
            })
            st.success("✅ Configurações salvas!")


# Executar aplicação
if __name__ == "__main__":
    create_streamlit_app()