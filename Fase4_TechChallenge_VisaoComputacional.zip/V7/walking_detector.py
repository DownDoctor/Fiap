"""
Enhanced Walking Detector Module with Configurable Body Visibility Thresholds
Improved assessment of walking movement with adaptive landmark analysis
"""
import cv2
import mediapipe as mp
import numpy as np
from collections import deque
from scipy.fft import fft, fftfreq
from scipy.signal import savgol_filter
from dataclasses import dataclass
from typing import Optional, Tuple, Dict, List

@dataclass
class VisibilityConfig:
    """Configuration for body visibility thresholds and analysis modes"""
    high_visibility_threshold: float = 0.9
    medium_visibility_threshold: float = 0.7
    low_visibility_threshold: float = 0.5
    
    # Analysis modes based on visibility
    use_ankles_high_vis: bool = True
    use_arm_swing_medium_vis: bool = True
    use_balance_analysis: bool = True

@dataclass
class WalkingMetrics:
    """Metrics for walking detection analysis"""
    visibility_score: float
    analysis_mode: str
    hip_movement_score: float
    knee_alternation_score: float
    ankle_movement_score: float
    arm_swing_score: float
    balance_score: float
    overall_walking_score: float
    confidence_level: str

class WalkingDetector:
    def __init__(self, buffer_size=30, fps=30, visibility_config=None):
        """
        Enhanced walking detector with configurable visibility thresholds.
        
        Args:
            buffer_size (int): Buffer size for movement analysis
            fps (int): Frames per second
            visibility_config (VisibilityConfig): Configuration for visibility thresholds
        """
        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose(
            static_image_mode=False,
            model_complexity=1,
            smooth_landmarks=True,
            min_detection_confidence=0.5,
            min_tracking_confidence=0.5
        )
        self.mp_drawing = mp.solutions.drawing_utils
        
        # Configuration
        self.buffer_size = buffer_size
        self.fps = fps
        self.visibility_config = visibility_config or VisibilityConfig()
        
        # Movement buffers - organized by body part
        self.hip_positions = deque(maxlen=buffer_size)
        self.knee_angles = {
            'left': deque(maxlen=buffer_size),
            'right': deque(maxlen=buffer_size)
        }
        self.ankle_positions = {
            'left': deque(maxlen=buffer_size),
            'right': deque(maxlen=buffer_size)
        }
        self.shoulder_positions = {
            'left': deque(maxlen=buffer_size),
            'right': deque(maxlen=buffer_size)
        }
        self.wrist_positions = {
            'left': deque(maxlen=buffer_size),
            'right': deque(maxlen=buffer_size)
        }
        
        # Analysis buffers
        self.body_tilt_angles = deque(maxlen=buffer_size)
        self.step_rhythm_buffer = deque(maxlen=buffer_size)
        self.stability_scores = deque(maxlen=buffer_size)
        self.detection_history = deque(maxlen=10)
        
        # Landmark indices for easy reference
        self.LANDMARKS = {
            'left_shoulder': 11, 'right_shoulder': 12,
            'left_hip': 23, 'right_hip': 24,
            'left_knee': 25, 'right_knee': 26,
            'left_ankle': 27, 'right_ankle': 28,
            'left_wrist': 15, 'right_wrist': 16,
            'left_foot': 31, 'right_foot': 32
        }
        
        # Adaptive thresholds based on visibility
        self.walking_thresholds = {
            'high_vis': {'score': 7.0, 'confidence': 'high'},
            'medium_vis': {'score': 5.5, 'confidence': 'medium'},
            'low_vis': {'score': 4.0, 'confidence': 'low'}
        }
    
    def get_landmark_with_visibility(self, landmarks, index: int) -> Tuple[Optional[np.ndarray], float]:
        """
        Get landmark position with visibility score.
        
        Returns:
            Tuple of (position_array, visibility_score) or (None, 0.0)
        """
        if index >= len(landmarks):
            return None, 0.0
            
        landmark = landmarks[index]
        if landmark.visibility < self.visibility_config.low_visibility_threshold:
            return None, 0.0
            
        position = np.array([landmark.x, landmark.y, landmark.z])
        return position, landmark.visibility
    
    def calculate_body_visibility_score(self, landmarks) -> Tuple[float, str]:
        """
        Calculate overall body visibility and determine analysis mode.
        
        Returns:
            Tuple of (visibility_score, analysis_mode)
        """
        key_landmarks = ['left_hip', 'right_hip', 'left_knee', 'right_knee', 
                        'left_shoulder', 'right_shoulder']
        
        visibility_scores = []
        for landmark_name in key_landmarks:
            idx = self.LANDMARKS[landmark_name]
            _, vis_score = self.get_landmark_with_visibility(landmarks, idx)
            visibility_scores.append(vis_score)
        
        avg_visibility = np.mean(visibility_scores) if visibility_scores else 0.0
        
        # Determine analysis mode based on visibility
        if avg_visibility >= self.visibility_config.high_visibility_threshold:
            return avg_visibility, "high_visibility"
        elif avg_visibility >= self.visibility_config.medium_visibility_threshold:
            return avg_visibility, "medium_visibility"
        else:
            return avg_visibility, "low_visibility"
    
    def analyze_hip_movement(self, landmarks) -> float:
        """Analyze hip movement patterns for walking detection."""
        left_hip, left_vis = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['left_hip'])
        right_hip, right_vis = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['right_hip'])
        
        if left_hip is None or right_hip is None:
            return 0.0
        
        # Calculate hip center
        hip_center = (left_hip + right_hip) / 2
        self.hip_positions.append(hip_center)
        
        if len(self.hip_positions) < 10:
            return 0.0
        
        # Analyze hip displacement and rhythm
        positions = np.array(list(self.hip_positions))
        
        # Calculate displacement variance in x and y directions
        x_variance = np.var(positions[:, 0])
        y_variance = np.var(positions[:, 1])
        
        # Calculate forward movement (consistent x displacement)
        x_trend = np.polyfit(range(len(positions)), positions[:, 0], 1)[0]
        
        # Score based on movement characteristics
        movement_score = 0.0
        
        # Rhythmic side-to-side movement (walking sway)
        if x_variance > 0.0001:  # Some lateral movement
            movement_score += 1.0
            
        # Consistent forward movement
        if abs(x_trend) > 0.0005:  # Forward/backward progression
            movement_score += 1.5
            
        # Appropriate vertical movement (not too much bouncing)
        if 0.00005 < y_variance < 0.001:  # Controlled vertical movement
            movement_score += 1.0
        
        return min(movement_score, 3.0)  # Max score of 3
    
    def analyze_knee_alternation(self, landmarks) -> float:
        """Analyze knee movement alternation pattern."""
        # Get knee positions and calculate angles
        left_hip, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['left_hip'])
        left_knee, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['left_knee'])
        left_ankle, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['left_ankle'])
        
        right_hip, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['right_hip'])
        right_knee, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['right_knee'])
        right_ankle, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['right_ankle'])
        
        score = 0.0
        
        # Calculate knee angles if all points are available
        if all(p is not None for p in [left_hip, left_knee, left_ankle]):
            left_angle = self._calculate_angle(left_hip, left_knee, left_ankle)
            if left_angle is not None:
                self.knee_angles['left'].append(left_angle)
        
        if all(p is not None for p in [right_hip, right_knee, right_ankle]):
            right_angle = self._calculate_angle(right_hip, right_knee, right_ankle)
            if right_angle is not None:
                self.knee_angles['right'].append(right_angle)
        
        # Analyze alternation if we have enough data
        if len(self.knee_angles['left']) >= 15 and len(self.knee_angles['right']) >= 15:
            left_angles = list(self.knee_angles['left'])
            right_angles = list(self.knee_angles['right'])
            
            # Check for rhythmic movement in each knee
            left_rhythm = self._detect_rhythmic_pattern(left_angles)
            right_rhythm = self._detect_rhythmic_pattern(right_angles)
            
            if left_rhythm or right_rhythm:
                score += 1.0
            
            # Check for alternation between knees
            if len(left_angles) == len(right_angles):
                correlation = np.corrcoef(left_angles, right_angles)[0, 1]
                if not np.isnan(correlation) and correlation < -0.1:  # Negative correlation indicates alternation
                    score += 1.5
        
        return min(score, 2.5)  # Max score of 2.5
    
    def analyze_ankle_movement(self, landmarks, analysis_mode: str) -> float:
        """Analyze ankle movement - used primarily in high visibility mode."""
        if analysis_mode != "high_visibility" or not self.visibility_config.use_ankles_high_vis:
            return 0.0
        
        left_ankle, left_vis = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['left_ankle'])
        right_ankle, right_vis = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['right_ankle'])
        
        if left_ankle is None or right_ankle is None:
            return 0.0
        
        # Store ankle positions
        self.ankle_positions['left'].append(left_ankle)
        self.ankle_positions['right'].append(right_ankle)
        
        if len(self.ankle_positions['left']) < 10:
            return 0.0
        
        score = 0.0
        
        # Analyze ankle elevation alternation
        left_positions = np.array(list(self.ankle_positions['left']))
        right_positions = np.array(list(self.ankle_positions['right']))
        
        # Check for alternating elevation (y-coordinate)
        left_y_var = np.var(left_positions[:, 1])
        right_y_var = np.var(right_positions[:, 1])
        
        if left_y_var > 0.0001 or right_y_var > 0.0001:  # Some elevation change
            score += 1.0
        
        # Check for step rhythm in ankle movement
        if len(left_positions) >= 15:
            left_rhythm = self._detect_rhythmic_pattern(left_positions[:, 1])
            right_rhythm = self._detect_rhythmic_pattern(right_positions[:, 1])
            
            if left_rhythm or right_rhythm:
                score += 1.0
        
        return min(score, 2.0)  # Max score of 2
    
    def analyze_arm_swing(self, landmarks, analysis_mode: str) -> float:
        """Analyze arm swing patterns - more important in medium visibility."""
        if analysis_mode == "low_visibility":
            return 0.0
        
        left_shoulder, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['left_shoulder'])
        left_wrist, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['left_wrist'])
        right_shoulder, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['right_shoulder'])
        right_wrist, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['right_wrist'])
        
        score = 0.0
        
        # Calculate arm swing for each arm
        if left_shoulder is not None and left_wrist is not None:
            left_arm_vector = left_wrist - left_shoulder
            self.wrist_positions['left'].append(left_wrist)
        
        if right_shoulder is not None and right_wrist is not None:
            right_arm_vector = right_wrist - right_shoulder
            self.wrist_positions['right'].append(right_wrist)
        
        # Analyze wrist movement patterns
        for side in ['left', 'right']:
            if len(self.wrist_positions[side]) >= 10:
                positions = np.array(list(self.wrist_positions[side]))
                
                # Check for rhythmic forward-backward movement
                x_movement = positions[:, 0]
                if self._detect_rhythmic_pattern(x_movement):
                    score += 0.75
                
                # Check for appropriate range of motion
                x_range = np.max(x_movement) - np.min(x_movement)
                if 0.05 < x_range < 0.3:  # Reasonable arm swing range
                    score += 0.5
        
        return min(score, 2.0)  # Max score of 2
    
    def analyze_body_balance(self, landmarks) -> float:
        """Analyze body balance and stability during movement."""
        left_shoulder, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['left_shoulder'])
        right_shoulder, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['right_shoulder'])
        left_hip, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['left_hip'])
        right_hip, _ = self.get_landmark_with_visibility(landmarks, self.LANDMARKS['right_hip'])
        
        if any(p is None for p in [left_shoulder, right_shoulder, left_hip, right_hip]):
            return 0.0
        
        # Calculate body centerline and tilt
        shoulder_center = (left_shoulder + right_shoulder) / 2
        hip_center = (left_hip + right_hip) / 2
        
        # Body tilt angle (should be relatively stable during walking)
        body_vector = shoulder_center - hip_center
        vertical_vector = np.array([0, -1, 0])
        
        # Calculate angle with vertical
        cos_angle = np.dot(body_vector, vertical_vector) / (
            np.linalg.norm(body_vector) * np.linalg.norm(vertical_vector)
        )
        tilt_angle = np.degrees(np.arccos(np.clip(cos_angle, -1.0, 1.0)))
        
        self.body_tilt_angles.append(tilt_angle)
        
        if len(self.body_tilt_angles) < 10:
            return 0.0
        
        # Analyze balance stability
        tilt_angles = list(self.body_tilt_angles)
        tilt_std = np.std(tilt_angles)
        avg_tilt = np.mean(tilt_angles)
        
        score = 0.0
        
        # Good balance: reasonable average tilt and low variation
        if avg_tilt < 30:  # Not too tilted
            score += 1.0
        
        if tilt_std < 15:  # Stable posture
            score += 1.0
        
        return min(score, 2.0)  # Max score of 2
    
    def _calculate_angle(self, a: np.ndarray, b: np.ndarray, c: np.ndarray) -> Optional[float]:
        """Calculate angle between three points."""
        try:
            ab = a - b
            cb = c - b
            
            norm_ab = np.linalg.norm(ab)
            norm_cb = np.linalg.norm(cb)
            
            if norm_ab == 0 or norm_cb == 0:
                return None
                
            cos_angle = np.dot(ab, cb) / (norm_ab * norm_cb)
            return np.degrees(np.arccos(np.clip(cos_angle, -1.0, 1.0)))
        except Exception:
            return None
    
    def _detect_rhythmic_pattern(self, data: List[float], min_freq=0.5, max_freq=3.0) -> bool:
        """Detect rhythmic patterns in movement data using FFT."""
        if len(data) < 10:
            return False
        
        try:
            # Smooth the signal
            if len(data) >= 5:
                window_length = min(5, len(data))
                if window_length % 2 == 0:
                    window_length -= 1
                if window_length >= 3:
                    data_smooth = savgol_filter(data, window_length, 2)
                else:
                    data_smooth = data
            else:
                data_smooth = data
            
            # Prepare for FFT
            y = np.array(data_smooth) - np.mean(data_smooth)
            if np.std(y) < 1e-6:
                return False
            
            # Apply window and FFT
            window = np.hanning(len(y))
            y_windowed = y * window
            
            fft_vals = np.abs(fft(y_windowed))
            freqs = fftfreq(len(y_windowed), 1 / self.fps)
            
            # Analyze frequency range
            idx = (freqs >= min_freq) & (freqs <= max_freq)
            if not np.any(idx):
                return False
            
            power = fft_vals[idx]
            
            if len(power) == 0:
                return False
            
            # Check for dominant frequency
            max_power = np.max(power)
            mean_power = np.mean(power)
            
            return max_power > 2.0 * mean_power and max_power > 1.0
            
        except Exception:
            return False
    
    def detect_walking(self, frame) -> Tuple[bool, np.ndarray, str, Dict]:
        """
        Enhanced walking detection with adaptive analysis based on body visibility.
        
        Returns:
            Tuple of (is_walking, processed_frame, status, detailed_metrics)
        """
        # Convert frame for MediaPipe
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.pose.process(image)
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        
        # Initialize default values
        is_walking = False
        status = "No pose detected"
        metrics = WalkingMetrics(
            visibility_score=0.0,
            analysis_mode="none",
            hip_movement_score=0.0,
            knee_alternation_score=0.0,
            ankle_movement_score=0.0,
            arm_swing_score=0.0,
            balance_score=0.0,
            overall_walking_score=0.0,
            confidence_level="none"
        )
        
        if results.pose_landmarks:
            landmarks = results.pose_landmarks.landmark
            
            # Determine visibility and analysis mode
            visibility_score, analysis_mode = self.calculate_body_visibility_score(landmarks)
            
            # Perform analysis based on visibility level
            hip_score = self.analyze_hip_movement(landmarks)
            knee_score = self.analyze_knee_alternation(landmarks)
            ankle_score = self.analyze_ankle_movement(landmarks, analysis_mode)
            arm_score = self.analyze_arm_swing(landmarks, analysis_mode)
            balance_score = self.analyze_body_balance(landmarks)
            
            # Calculate weighted overall score based on analysis mode
            if analysis_mode == "high_visibility":
                # Use all available metrics with full weighting
                overall_score = (
                    hip_score * 1.5 +      # Hip movement is crucial
                    knee_score * 1.5 +     # Knee alternation is crucial
                    ankle_score * 1.0 +    # Ankle movement adds confidence
                    arm_score * 0.8 +      # Arm swing supports detection
                    balance_score * 1.0    # Balance confirms walking
                )
                threshold_info = self.walking_thresholds['high_vis']
                
            elif analysis_mode == "medium_visibility":
                # Focus on hip, knee, and arm movement
                overall_score = (
                    hip_score * 1.8 +      # Higher weight on hip movement
                    knee_score * 1.8 +     # Higher weight on knee alternation
                    arm_score * 1.2 +      # More emphasis on arm swing
                    balance_score * 1.0    # Balance still important
                )
                threshold_info = self.walking_thresholds['medium_vis']
                
            else:  # low_visibility
                # Rely primarily on hip and knee movement
                overall_score = (
                    hip_score * 2.0 +      # Maximum weight on hip movement
                    knee_score * 2.0 +     # Maximum weight on knee alternation
                    balance_score * 1.5    # Higher weight on balance
                )
                threshold_info = self.walking_thresholds['low_vis']
            
            # Determine if walking based on threshold
            is_walking_current = overall_score >= threshold_info['score']
            
            # Add to detection history for stability
            self.detection_history.append(is_walking_current)
            
            # Final decision based on recent history
            if len(self.detection_history) >= 5:
                recent_detections = list(self.detection_history)
                walking_votes = sum(recent_detections)
                is_walking = walking_votes >= len(recent_detections) // 2
            else:
                is_walking = is_walking_current
            
            # Create metrics object
            metrics = WalkingMetrics(
                visibility_score=visibility_score,
                analysis_mode=analysis_mode,
                hip_movement_score=hip_score,
                knee_alternation_score=knee_score,
                ankle_movement_score=ankle_score,
                arm_swing_score=arm_score,
                balance_score=balance_score,
                overall_walking_score=overall_score,
                confidence_level=threshold_info['confidence']
            )
            
            # Set status
            status = f"Walking ({threshold_info['confidence']} confidence)" if is_walking else f"Not walking ({analysis_mode})"
            
            # Draw pose landmarks
            self.mp_drawing.draw_landmarks(
                image, results.pose_landmarks, self.mp_pose.POSE_CONNECTIONS
            )
            
            # Draw analysis info on frame
            self._draw_analysis_overlay(image, metrics, is_walking)
        
        debug_info = {
            'metrics': metrics,
            'raw_scores': {
                'hip': metrics.hip_movement_score,
                'knee': metrics.knee_alternation_score,
                'ankle': metrics.ankle_movement_score,
                'arm': metrics.arm_swing_score,
                'balance': metrics.balance_score
            },
            'visibility': metrics.visibility_score,
            'mode': metrics.analysis_mode
        }
        
        return is_walking, image, status, debug_info
    
    def _draw_analysis_overlay(self, frame: np.ndarray, metrics: WalkingMetrics, is_walking: bool):
        """Draw analysis information overlay on the frame."""
        # Background for overlay
        overlay = frame.copy()
        #cv2.rectangle(overlay, (10, 10), (400, 200), (0, 0, 0), -1)
        cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
        
        # Color based on walking detection
        color = (0, 255, 0) if is_walking else (0, 0, 255)
        
        # Main status
        #cv2.putText(frame, f"Walking: {'YES' if is_walking else 'NO'}", (20, 35),
        #           cv2.FONT_HERSHEY_SIMPLEX, 0.8, color, 2)
        
        # Visibility and mode
        #cv2.putText(frame, f"Visibility: {metrics.visibility_score:.2f} ({metrics.analysis_mode})", 
        #           (20, 60), cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
        
        # Individual scores
        y_offset = 80
        scores = [
            ("Hip Movement", metrics.hip_movement_score),
            ("Knee Pattern", metrics.knee_alternation_score),
            ("Ankle Move", metrics.ankle_movement_score),
            ("Arm Swing", metrics.arm_swing_score),
            ("Balance", metrics.balance_score)
        ]
        
       # for label, score in scores:
        #    cv2.putText(frame, f"{label}: {score:.1f}", (20, y_offset),
        #               cv2.FONT_HERSHEY_SIMPLEX, 0.4, (200, 200, 200), 1)
        y_offset += 20
        
        # Overall score
        #cv2.putText(frame, f"Overall: {metrics.overall_walking_score:.1f}", (20, y_offset),
        #           cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 255), 2)
    
    def configure_visibility_thresholds(self, high_vis: float = 0.9, medium_vis: float = 0.7, low_vis: float = 0.5):
        """Configure body visibility thresholds."""
        self.visibility_config.high_visibility_threshold = high_vis
        self.visibility_config.medium_visibility_threshold = medium_vis
        self.visibility_config.low_visibility_threshold = low_vis
    
    def reset_buffers(self):
        """Reset all movement analysis buffers."""
        self.hip_positions.clear()
        for side in ['left', 'right']:
            self.knee_angles[side].clear()
            self.ankle_positions[side].clear()
            self.shoulder_positions[side].clear()
            self.wrist_positions[side].clear()
        
        self.body_tilt_angles.clear()
        self.step_rhythm_buffer.clear()
        self.stability_scores.clear()
        self.detection_history.clear()
    
    def cleanup(self):
        """Clean up MediaPipe resources."""
        if hasattr(self, 'pose'):
            self.pose.close()

# Example usage and testing
def main():
    """Test the enhanced walking detector."""
    # Create detector with custom visibility configuration
    visibility_config = VisibilityConfig(
        high_visibility_threshold=0.85,
        medium_visibility_threshold=0.65,
        low_visibility_threshold=0.45
    )
    
    detector = EnhancedWalkingDetector(
        buffer_size=30,
        fps=30,
        visibility_config=visibility_config
    )
    
    # Test with video
    cap = cv2.VideoCapture(0)  # Use webcam or replace with video path
    
    if not cap.isOpened():
        print("Error: Could not open video source")
        return
    
    try:
        frame_count = 0
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            
            is_walking, processed_frame, status, debug_info = detector.detect_walking(frame)
            
            print(f"Frame {frame_count}: {status}")
            if frame_count % 30 == 0:  # Print detailed info every 30 frames
                metrics = debug_info['metrics']
                print(f"  Visibility: {metrics.visibility_score:.2f} ({metrics.analysis_mode})")
                print(f"  Scores - Hip: {metrics.hip_movement_score:.1f}, "
                      f"Knee: {metrics.knee_alternation_score:.1f}, "
                      f"Balance: {metrics.balance_score:.1f}")
            
            cv2.imshow("Enhanced Walking Detector", processed_frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == 27:  # ESC
                break
            elif key == ord('r'):  # Reset
                detector.reset_buffers()
                print("Buffers reset")
            
            frame_count += 1
            
    finally:
        cap.release()
        cv2.destroyAllWindows()
        detector.cleanup()

if __name__ == "__main__":
    main()