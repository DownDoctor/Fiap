"""
Módulo para reconhecimento facial e detecção de emoções usando face_recognition e DeepFace
"""
import cv2
import face_recognition
import os
import numpy as np
from deepface import DeepFace

class FaceEmotionDetector:
    def __init__(self, images_folder='images'):
        """
        Inicializa o detector de faces e emoções.
        
        Args:
            images_folder (str): Pasta contendo imagens de referência para reconhecimento
        """
        self.known_face_encodings = []
        self.known_face_names = []
        self.images_folder = images_folder
        
        # Carrega as imagens de referência
        self.load_known_faces()
    
    def load_known_faces(self):
        """Carrega imagens de faces conhecidas da pasta especificada"""
        if not os.path.exists(self.images_folder):
            print(f"Pasta '{self.images_folder}' não encontrada. Criando pasta...")
            os.makedirs(self.images_folder)
            print(f"Adicione imagens de referência na pasta '{self.images_folder}'")
            return
        
        # Percorrer todos os arquivos na pasta fornecida
        for filename in os.listdir(self.images_folder):
            # Verificar se o arquivo é uma imagem
            if filename.lower().endswith((".jpg", ".jpeg", ".png", ".bmp")):
                try:
                    # Carregar a imagem
                    image_path = os.path.join(self.images_folder, filename)
                    image = face_recognition.load_image_file(image_path)
                    
                    # Obter as codificações faciais (assumindo uma face por imagem)
                    face_encodings = face_recognition.face_encodings(image)
                    
                    if face_encodings:
                        face_encoding = face_encodings[0]
                        # Extrair o nome do arquivo, removendo o sufixo numérico e a extensão
                        name = os.path.splitext(filename)[0]
                        # Remove sufixo numérico se existir (como no código original)
                        if name and name[-1].isdigit():
                            name = name[:-1]
                        
                        # Adicionar a codificação e o nome às listas
                        self.known_face_encodings.append(face_encoding)
                        self.known_face_names.append(name)
                        
                        print(f"Face carregada: {name} ({filename})")
                    else:
                        print(f"Nenhuma face encontrada em: {filename}")
                        
                except Exception as e:
                    print(f"Erro ao carregar {filename}: {str(e)}")
        
        print(f"Total de faces conhecidas carregadas: {len(self.known_face_names)}")
    
    def detect_faces_and_emotions(self, frame):
        """
        Detecta faces e emoções em um frame.
        
        Args:
            frame: Frame de vídeo (BGR)
            
        Returns:
            tuple: (processed_frame, detection_info)
                processed_frame: Frame com anotações
                detection_info: Lista de dicionários com informações das detecções
        """
        processed_frame = frame.copy()
        detection_info = []
        
        try:
            # Analisar o frame para detectar faces e expressões usando DeepFace
            result = DeepFace.analyze(frame, actions=['emotion'], enforce_detection=False)
            
            # Garantir que result é uma lista
            if not isinstance(result, list):
                result = [result]
            
            # Obter as localizações e codificações das faces conhecidas no frame
            rgb_frame = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
            face_locations = face_recognition.face_locations(rgb_frame)
            face_encodings = face_recognition.face_encodings(rgb_frame, face_locations)
            
            # Reconhecer faces conhecidas
            face_names = []
            for face_encoding in face_encodings:
                matches = face_recognition.compare_faces(self.known_face_encodings, face_encoding)
                name = "Desconhecido"
                
                if self.known_face_encodings:  # Verificar se há faces conhecidas
                    face_distances = face_recognition.face_distance(self.known_face_encodings, face_encoding)
                    best_match_index = np.argmin(face_distances)
                    if matches[best_match_index]:
                        name = self.known_face_names[best_match_index]
                
                face_names.append(name)
            
            # Processar cada face detectada pelo DeepFace
            for i, face in enumerate(result):
                try:
                    # Obter a caixa delimitadora da face
                    region = face.get('region', {})
                    x = region.get('x', 0)
                    y = region.get('y', 0)
                    w = region.get('w', 50)
                    h = region.get('h', 50)
                    
                    # Obter a emoção dominante
                    dominant_emotion = face.get('dominant_emotion', 'unknown')
                    emotion_scores = face.get('emotion', {})
                    
                    # Desenhar um retângulo ao redor da face
                    cv2.rectangle(processed_frame, (x, y), (x+w, y+h), (0, 255, 0), 2)
                    
                    # Escrever a emoção dominante acima da face
                    cv2.putText(processed_frame, dominant_emotion, (x, y-10), 
                               cv2.FONT_HERSHEY_SIMPLEX, 0.7, (36, 255, 12), 2)
                    
                    # Encontrar nome correspondente
                    recognized_name = "Desconhecido"
                    for (top, right, bottom, left), name in zip(face_locations, face_names):
                        # Verificar se a face do DeepFace corresponde à face do face_recognition
                        if (x <= left <= x + w and y <= top <= y + h) or \
                           (left <= x <= right and top <= y <= bottom):
                            recognized_name = name
                            # Escrever o nome abaixo da face
                            cv2.putText(processed_frame, name, (x + 6, y + h - 6), 
                                       cv2.FONT_HERSHEY_SIMPLEX, 0.7, (176, 224, 230), 2)
                            break
                    
                    # Adicionar informações de detecção
                    detection_info.append({
                        'face_id': i,
                        'name': recognized_name,
                        'emotion': dominant_emotion,
                        'emotion_scores': emotion_scores,
                        'bbox': (x, y, w, h)
                    })
                    
                except Exception as e:
                    print(f"Erro ao processar face {i}: {str(e)}")
                    continue
                    
        except Exception as e:
            print(f"Erro na detecção de faces/emoções: {str(e)}")
        
        return processed_frame, detection_info
    
    def get_summary_stats(self, detection_info):
        """
        Gera estatísticas resumidas das detecções.
        
        Args:
            detection_info: Lista de informações de detecção
            
        Returns:
            dict: Estatísticas resumidas
        """
        if not detection_info:
            return {'total_faces': 0, 'emotions': {}, 'recognized_faces': []}
        
        stats = {
            'total_faces': len(detection_info),
            'emotions': {},
            'recognized_faces': []
        }
        
        for info in detection_info:
            # Contar emoções
            emotion = info['emotion']
            stats['emotions'][emotion] = stats['emotions'].get(emotion, 0) + 1
            
            # Listar faces reconhecidas
            if info['name'] != "Desconhecido":
                stats['recognized_faces'].append(info['name'])
        
        return stats

def main():
    """Função principal para teste do módulo"""
    detector = FaceEmotionDetector()
    
    # Testa com vídeo
    video_path = 'TechChallengeVideo.mp4'  # Substitua pelo caminho do seu vídeo
    cap = cv2.VideoCapture(video_path)
    
    if not cap.isOpened():
        print(f"Erro ao abrir vídeo: {video_path}")
        print("Tentando usar webcam...")
        cap = cv2.VideoCapture(0)
        if not cap.isOpened():
            print("Erro ao abrir webcam também")
            return
    
    try:
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            
            processed_frame, detection_info = detector.detect_faces_and_emotions(frame)
            
            # Mostrar estatísticas no console (opcional)
            if detection_info:
                stats = detector.get_summary_stats(detection_info)
                print(f"Faces: {stats['total_faces']}, Emoções: {stats['emotions']}")
            
            cv2.imshow("Face & Emotion Detector", processed_frame)
            
            if cv2.waitKey(1) & 0xFF == 27:  # ESC
                break
                
    finally:
        cap.release()
        cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
