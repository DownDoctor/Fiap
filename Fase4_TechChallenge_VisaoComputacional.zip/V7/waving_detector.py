"""
Módulo para detecção de aceno (waving) usando MediaPipe
"""
import cv2
import mediapipe as mp
import numpy as np
from collections import deque

class WavingDetector:
    def __init__(self, buffer_size=20, std_threshold=0.015):
        """
        Inicializa o detector de aceno.
        
        Args:
            buffer_size (int): Tamanho do buffer para análise de movimento
            std_threshold (float): Limiar de desvio padrão para detecção de movimento lateral
        """
        self.mp_pose = mp.solutions.pose
        self.pose = self.mp_pose.Pose(static_image_mode=False)
        self.mp_drawing = mp.solutions.drawing_utils
        
        # Configurações
        self.buffer_size = buffer_size
        self.std_threshold = std_threshold
        
        # Buffers para movimento lateral das mãos
        self.wrist_x_dir = deque(maxlen=buffer_size)  # Mão direita
        self.wrist_x_esq = deque(maxlen=buffer_size)  # Mão esquerda
    
    def get_x(self, landmarks, index):
        """Obtém coordenada X de um landmark"""
        return landmarks[index].x
    
    def get_y(self, landmarks, index):
        """Obtém coordenada Y de um landmark"""
        return landmarks[index].y
    
    def detect_waving(self, frame):
        """
        Detecta se há movimento de aceno no frame.
        
        Args:
            frame: Frame de vídeo (BGR)
            
        Returns:
            tuple: (is_waving, processed_frame, status_text)
        """
        # Converte para RGB para o MediaPipe
        image = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        results = self.pose.process(image)
        image = cv2.cvtColor(image, cv2.COLOR_RGB2BGR)
        
        is_waving = False
        status = "Unknown"
        
        if results.pose_landmarks:
            lm = results.pose_landmarks.landmark
            
            try:
                # Análise da mão direita
                self.wrist_x_dir.append(self.get_x(lm, 16))
                std_wrist_dir = np.std(self.wrist_x_dir) if len(self.wrist_x_dir) > 1 else 0
                above_eye_dir = self.get_y(lm, 16) < self.get_y(lm, 5)
                
                # Análise da mão esquerda
                self.wrist_x_esq.append(self.get_x(lm, 15))
                std_wrist_esq = np.std(self.wrist_x_esq) if len(self.wrist_x_esq) > 1 else 0
                above_eye_esq = self.get_y(lm, 15) < self.get_y(lm, 2)
                
                # Critério de aceno (movimento lateral + mão erguida)
                aceno_dir = above_eye_dir and std_wrist_dir > self.std_threshold
                aceno_esq = above_eye_esq and std_wrist_esq > self.std_threshold
                
                is_waving = aceno_dir or aceno_esq
                status = "Waving..." if is_waving else "Not Waving"
                
            except Exception as e:
                status = f"Error: {str(e)}"
            
            # Desenha os landmarks da pose
            self.mp_drawing.draw_landmarks(
                image, results.pose_landmarks, self.mp_pose.POSE_CONNECTIONS
            )
        
        return is_waving, image, status
    
    def reset_buffers(self):
        """Reseta os buffers de movimento"""
        self.wrist_x_dir.clear()
        self.wrist_x_esq.clear()
    
    def cleanup(self):
        """Limpa recursos do MediaPipe"""
        if hasattr(self, 'pose'):
            self.pose.close()

def main():
    """Função principal para teste do módulo"""
    detector = WavingDetector()
    
    # Testa com vídeo
    video_path = 'media/frames/F2.mp4'  # Substitua pelo caminho do seu vídeo
    cap = cv2.VideoCapture(video_path)
    
    if not cap.isOpened():
        print(f"Erro ao abrir vídeo: {video_path}")
        return
    
    try:
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            
            is_waving, processed_frame, status = detector.detect_waving(frame)
            
            # HUD simples
            #cv2.rectangle(processed_frame, (10, 10), (300, 60), (0, 0, 0), -1)
            #cv2.putText(processed_frame, f"Status: {status}", (20, 45),
            #           cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
            
            cv2.imshow("Detector de Aceno", processed_frame)
            
            if cv2.waitKey(1) & 0xFF == 27:  # ESC
                break
                
    finally:
        cap.release()
        cv2.destroyAllWindows()
        detector.cleanup()

if __name__ == "__main__":
    main()