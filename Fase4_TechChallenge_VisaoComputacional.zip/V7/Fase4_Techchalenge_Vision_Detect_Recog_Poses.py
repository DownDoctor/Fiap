"""
Programa principal que utiliza os detectores de aceno, caminhada melhorada, faces e emoções
Com contador de frames e resumo automático - VERSÃO MELHORADA COM NOVO WALKING DETECTOR
"""
import cv2
import argparse
import sys
import os
import json
from collections import defaultdict, Counter
from waving_detector import WavingDetector
from walking_detector import WalkingDetector, VisibilityConfig, WalkingMetrics
from face_emotion_detector import FaceEmotionDetector

class MultiActionDetector:
    def __init__(self, enable_face_detection=True, images_folder='images', visibility_config=None):
        """
        Inicializa os detectores de aceno, caminhada melhorada e faces/emoções
        
        Args:
            enable_face_detection (bool): Se deve habilitar detecção de faces/emoções
            images_folder (str): Pasta com imagens de referência para reconhecimento facial
            visibility_config (VisibilityConfig): Configuração de limites de visibilidade
        """
        self.waving_detector = WavingDetector()
        
        # Configuração de visibilidade personalizada ou padrão
        if visibility_config is None:
            visibility_config = VisibilityConfig(
                high_visibility_threshold=0.85,
                medium_visibility_threshold=0.70,
                low_visibility_threshold=0.50,
                use_ankles_high_vis=True,
                use_arm_swing_medium_vis=True,
                use_balance_analysis=True
            )
        
        # Inicializa o detector melhorado com configurações otimizadas
        self.walking_detector = WalkingDetector(
            buffer_size=30, 
            fps=30, 
            visibility_config=visibility_config
        )
        
        self.enable_face_detection = enable_face_detection
        
        if enable_face_detection:
            self.face_emotion_detector = FaceEmotionDetector(images_folder)
        else:
            self.face_emotion_detector = None
            
        # Inicializa estatísticas para o resumo
        self.reset_statistics()
    
    def reset_statistics(self):
        """Reset das estatísticas para novo processamento"""
        self.statistics = {
            'total_frames': 0,
            'waving_frames': 0,
            'walking_frames': 0,
            'dancing_frames': 0,
            'idle_frames': 0,
            'faces_detected': 0,
            'emotions_detected': defaultdict(int),
            'people_recognized': defaultdict(int),
            'max_faces_per_frame': 0,
            'frames_with_faces': 0,
            # Estatísticas melhoradas do novo detector
            'walking_analysis': {
                'high_visibility_frames': 0,
                'medium_visibility_frames': 0,
                'low_visibility_frames': 0,
                'avg_visibility_score': 0.0,
                'avg_hip_score': 0.0,
                'avg_knee_score': 0.0,
                'avg_ankle_score': 0.0,
                'avg_arm_score': 0.0,
                'avg_balance_score': 0.0,
                'confidence_distribution': defaultdict(int),
                'walking_scores': [],
                'analysis_modes': defaultdict(int)
            }
        }
    
    def update_statistics(self, is_waving, is_walking, face_info, walking_debug=None):
        """Atualiza estatísticas do frame atual com dados melhorados"""
        self.statistics['total_frames'] += 1
        
        # Atualiza contadores de ações
        if is_waving and is_walking:
            self.statistics['dancing_frames'] += 1
        elif is_waving:
            self.statistics['waving_frames'] += 1
        elif is_walking:
            self.statistics['walking_frames'] += 1
        else:
            self.statistics['idle_frames'] += 1
        
        # Armazena informações detalhadas do walking detector melhorado
        if walking_debug and 'metrics' in walking_debug:
            metrics = walking_debug['metrics']
            walking_stats = self.statistics['walking_analysis']
            
            # Atualiza contadores de modo de análise
            walking_stats['analysis_modes'][metrics.analysis_mode] += 1
            
            # Atualiza contadores de visibilidade
            if metrics.analysis_mode == 'high_visibility':
                walking_stats['high_visibility_frames'] += 1
            elif metrics.analysis_mode == 'medium_visibility':
                walking_stats['medium_visibility_frames'] += 1
            elif metrics.analysis_mode == 'low_visibility':
                walking_stats['low_visibility_frames'] += 1
            
            # Distribui confiança
            walking_stats['confidence_distribution'][metrics.confidence_level] += 1
            
            # Acumula scores para médias
            walking_stats['walking_scores'].append(metrics.overall_walking_score)
            
            # Calcula médias incrementais
            total_frames = self.statistics['total_frames']
            walking_stats['avg_visibility_score'] = (
                (walking_stats['avg_visibility_score'] * (total_frames - 1) + 
                 metrics.visibility_score) / total_frames
            )
            walking_stats['avg_hip_score'] = (
                (walking_stats['avg_hip_score'] * (total_frames - 1) + 
                 metrics.hip_movement_score) / total_frames
            )
            walking_stats['avg_knee_score'] = (
                (walking_stats['avg_knee_score'] * (total_frames - 1) + 
                 metrics.knee_alternation_score) / total_frames
            )
            walking_stats['avg_ankle_score'] = (
                (walking_stats['avg_ankle_score'] * (total_frames - 1) + 
                 metrics.ankle_movement_score) / total_frames
            )
            walking_stats['avg_arm_score'] = (
                (walking_stats['avg_arm_score'] * (total_frames - 1) + 
                 metrics.arm_swing_score) / total_frames
            )
            walking_stats['avg_balance_score'] = (
                (walking_stats['avg_balance_score'] * (total_frames - 1) + 
                 metrics.balance_score) / total_frames
            )
        
        # Atualiza estatísticas de faces
        if face_info:
            num_faces = len(face_info)
            self.statistics['faces_detected'] += num_faces
            self.statistics['frames_with_faces'] += 1
            self.statistics['max_faces_per_frame'] = max(
                self.statistics['max_faces_per_frame'], 
                num_faces
            )
            
            # Conta emoções e pessoas
            for face in face_info:
                if 'emotion' in face:
                    self.statistics['emotions_detected'][face['emotion']] += 1
                if 'name' in face:
                    self.statistics['people_recognized'][face['name']] += 1
    
    def detect_actions(self, frame):
        """
        Detecta aceno, caminhada melhorada e faces/emoções em um frame.
        ATUALIZADO para usar o detector melhorado com análise adaptativa
        
        Args:
            frame: Frame de vídeo (BGR)
            
        Returns:
            tuple: (is_waving, is_walking, processed_frame, status_dict, face_info)
        """
        # Detecta aceno
        is_waving, frame_waving, waving_status = self.waving_detector.detect_waving(frame.copy())
        
        # Detecta caminhada usando o detector melhorado
        is_walking, frame_walking, walking_status, walking_debug = self.walking_detector.detect_walking(frame.copy())
        
        # Detecta faces e emoções se habilitado
        face_info = []
        if self.enable_face_detection and self.face_emotion_detector:
            processed_frame, face_info = self.face_emotion_detector.detect_faces_and_emotions(frame_walking)
        else:
            processed_frame = frame_waving
        
        # Atualiza estatísticas incluindo dados melhorados de debug
        self.update_statistics(is_waving, is_walking, face_info, walking_debug)
        
        # Extrai métricas detalhadas do walking detector
        walking_metrics = walking_debug.get('metrics', None) if walking_debug else None
        
        status_dict = {
            'waving': waving_status,
            'walking': walking_status,
            'combined': self._get_combined_status(is_waving, is_walking),
            'face_count': len(face_info) if face_info else 0,
            'total_frames': self.statistics['total_frames'],
            # Informações melhoradas do walking detector
            'walking_visibility': walking_metrics.visibility_score if walking_metrics else 0,
            'walking_analysis_mode': walking_metrics.analysis_mode if walking_metrics else 'none',
            'walking_confidence': walking_metrics.confidence_level if walking_metrics else 'none',
            'walking_overall_score': walking_metrics.overall_walking_score if walking_metrics else 0,
            'walking_hip_score': walking_metrics.hip_movement_score if walking_metrics else 0,
            'walking_knee_score': walking_metrics.knee_alternation_score if walking_metrics else 0,
            'walking_balance_score': walking_metrics.balance_score if walking_metrics else 0
        }
        
        return is_waving, is_walking, processed_frame, status_dict, face_info
    
    def _get_combined_status(self, is_waving, is_walking):
        """Determina status combinado das ações"""
        if is_waving and is_walking:
            return "Combined moves..."
        elif is_waving:
            return "Waving"
        elif is_walking:
            return "Walking"
        else:
            return "Idle"
    
    def generate_summary(self):
        """Gera resumo automático das atividades detectadas - VERSÃO MELHORADA COM ANÁLISE AVANÇADA"""
        stats = self.statistics
        total_frames = stats['total_frames']
        
        if total_frames == 0:
            return {"error": "Nenhum frame processado"}
        
        # Calcula percentuais
        summary = {
            "frames_analysis": {
                "total_frames": total_frames,
                "waving_frames": stats['waving_frames'],
                "walking_frames": stats['walking_frames'],
                "dancing_frames": stats['dancing_frames'],
                "idle_frames": stats['idle_frames'],
                "waving_percentage": round((stats['waving_frames'] / total_frames) * 100, 2),
                "walking_percentage": round((stats['walking_frames'] / total_frames) * 100, 2),
                "dancing_percentage": round((stats['dancing_frames'] / total_frames) * 100, 2),
                "idle_percentage": round((stats['idle_frames'] / total_frames) * 100, 2)
            },
            "face_analysis": {
                "total_faces_detected": stats['faces_detected'],
                "frames_with_faces": stats['frames_with_faces'],
                "max_faces_per_frame": stats['max_faces_per_frame'],
                "average_faces_per_frame": round(stats['faces_detected'] / total_frames, 2) if total_frames > 0 else 0,
                "face_presence_percentage": round((stats['frames_with_faces'] / total_frames) * 100, 2) if total_frames > 0 else 0
            },
            "emotion_analysis": {
                "emotions_detected": dict(stats['emotions_detected']),
                "most_common_emotion": max(stats['emotions_detected'].items(), key=lambda x: x[1])[0] if stats['emotions_detected'] else "None",
                "emotion_diversity": len(stats['emotions_detected'])
            },
            "people_recognition": {
                "people_recognized": dict(stats['people_recognized']),
                "unique_people_count": len(stats['people_recognized']),
                "most_frequent_person": max(stats['people_recognized'].items(), key=lambda x: x[1])[0] if stats['people_recognized'] else "None"
            },
            # Nova seção com análise avançada do detector melhorado
            "enhanced_walking_analysis": {
                "visibility_analysis": {
                    "average_visibility_score": round(stats['walking_analysis']['avg_visibility_score'], 3),
                    "high_visibility_frames": stats['walking_analysis']['high_visibility_frames'],
                    "medium_visibility_frames": stats['walking_analysis']['medium_visibility_frames'],
                    "low_visibility_frames": stats['walking_analysis']['low_visibility_frames'],
                    "high_vis_percentage": round((stats['walking_analysis']['high_visibility_frames'] / total_frames) * 100, 2),
                    "medium_vis_percentage": round((stats['walking_analysis']['medium_visibility_frames'] / total_frames) * 100, 2),
                    "low_vis_percentage": round((stats['walking_analysis']['low_visibility_frames'] / total_frames) * 100, 2)
                },
                "movement_scores": {
                    "average_hip_movement": round(stats['walking_analysis']['avg_hip_score'], 2),
                    "average_knee_alternation": round(stats['walking_analysis']['avg_knee_score'], 2),
                    "average_ankle_movement": round(stats['walking_analysis']['avg_ankle_score'], 2),
                    "average_arm_swing": round(stats['walking_analysis']['avg_arm_score'], 2),
                    "average_balance": round(stats['walking_analysis']['avg_balance_score'], 2)
                },
                "confidence_distribution": dict(stats['walking_analysis']['confidence_distribution']),
                "analysis_mode_distribution": dict(stats['walking_analysis']['analysis_modes']),
                "walking_score_statistics": {
                    "max_score": max(stats['walking_analysis']['walking_scores']) if stats['walking_analysis']['walking_scores'] else 0,
                    "min_score": min(stats['walking_analysis']['walking_scores']) if stats['walking_analysis']['walking_scores'] else 0,
                    "average_score": round(sum(stats['walking_analysis']['walking_scores']) / len(stats['walking_analysis']['walking_scores']), 2) if stats['walking_analysis']['walking_scores'] else 0,
                    "score_variability": round(
                        (max(stats['walking_analysis']['walking_scores']) - min(stats['walking_analysis']['walking_scores'])), 2
                    ) if stats['walking_analysis']['walking_scores'] else 0
                }
            }
        }
        
        # Adiciona interpretações melhoradas
        summary["interpretation"] = self._generate_enhanced_interpretation(summary)
        
        return summary
    
    def _generate_enhanced_interpretation(self, summary):
        """Gera interpretação textual aprimorada do resumo"""
        interpretations = []
        
        frames_data = summary["frames_analysis"]
        face_data = summary["face_analysis"]
        emotion_data = summary["emotion_analysis"]
        walking_data = summary["enhanced_walking_analysis"]
        
        # Atividade predominante
        activities = [
            ("idle", frames_data["idle_percentage"]),
            ("walking", frames_data["walking_percentage"]),
            ("waving", frames_data["waving_percentage"]),
            ("dancing", frames_data["dancing_percentage"])
        ]
        main_activity = max(activities, key=lambda x: x[1])
        interpretations.append(f"Atividade predominante: {main_activity[0]} ({main_activity[1]}% do tempo)")
        
        # Análise de qualidade da detecção baseada na visibilidade
        vis_data = walking_data["visibility_analysis"]
        if vis_data["high_vis_percentage"] > 50:
            interpretations.append(f"Excelente qualidade de pose detectada ({vis_data['high_vis_percentage']}% alta visibilidade)")
        elif vis_data["medium_vis_percentage"] > 50:
            interpretations.append(f"Boa qualidade de pose detectada ({vis_data['medium_vis_percentage']}% média visibilidade)")
        else:
            interpretations.append(f"Qualidade de pose limitada (visibilidade reduzida em {vis_data['low_vis_percentage']}% dos frames)")
        
        # Análise de movimento específica
        movement_scores = walking_data["movement_scores"]
        dominant_movement = max(movement_scores.items(), key=lambda x: x[1])
        interpretations.append(f"Padrão de movimento dominante: {dominant_movement[0]} (score: {dominant_movement[1]})")
        
        # Qualidade da detecção de caminhada
        score_stats = walking_data["walking_score_statistics"]
        if score_stats["average_score"] > 6:
            interpretations.append(f"Alta qualidade na detecção de caminhada (score médio: {score_stats['average_score']})")
        elif score_stats["average_score"] > 4:
            interpretations.append(f"Qualidade moderada na detecção de caminhada (score médio: {score_stats['average_score']})")
        else:
            interpretations.append(f"Detecção de caminhada com baixa confiança (score médio: {score_stats['average_score']})")
        
        # Estabilidade da detecção
        if score_stats["score_variability"] < 2:
            interpretations.append("Detecção muito estável e consistente")
        elif score_stats["score_variability"] < 4:
            interpretations.append("Detecção moderadamente estável")
        else:
            interpretations.append("Detecção com alta variabilidade")
        
        # Presença de faces
        if face_data["face_presence_percentage"] > 50:
            interpretations.append(f"Alta presença de faces no vídeo ({face_data['face_presence_percentage']}% dos frames)")
        elif face_data["face_presence_percentage"] > 20:
            interpretations.append(f"Presença moderada de faces no vídeo ({face_data['face_presence_percentage']}% dos frames)")
        else:
            interpretations.append(f"Baixa presença de faces no vídeo ({face_data['face_presence_percentage']}% dos frames)")
        
        # Emoção predominante
        if emotion_data["most_common_emotion"] != "None":
            interpretations.append(f"Emoção mais detectada: {emotion_data['most_common_emotion']}")
        
        # Diversidade emocional
        if emotion_data["emotion_diversity"] > 3:
            interpretations.append("Alta diversidade emocional detectada")
        elif emotion_data["emotion_diversity"] > 1:
            interpretations.append("Diversidade emocional moderada")
        
        return interpretations
    
    def save_summary_to_file(self, filename="enhanced_video_summary.json"):
        """Salva o resumo melhorado em arquivo JSON"""
        summary = self.generate_summary()
        try:
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(summary, f, indent=2, ensure_ascii=False)
            print(f"Resumo melhorado salvo em: {filename}")
        except Exception as e:
            print(f"Erro ao salvar resumo: {e}")
    
    def print_summary(self):
        """Imprime resumo formatado no console - VERSÃO MELHORADA COM ANÁLISE AVANÇADA"""
        summary = self.generate_summary()
        
        print("\n" + "="*70)
        print("RESUMO AUTOMÁTICO DO VÍDEO - VERSÃO MELHORADA COM WALKING DETECTOR AVANÇADO")
        print("="*70)
        
        # Análise de frames
        frames = summary["frames_analysis"]
        print(f"\n📊 ANÁLISE DE FRAMES:")
        print(f"  Total de frames processados: {frames['total_frames']}")
        print(f"  Frames com aceno: {frames['waving_frames']} ({frames['waving_percentage']}%)")
        print(f"  Frames com caminhada: {frames['walking_frames']} ({frames['walking_percentage']}%)")
        print(f"  Frames dançando: {frames['dancing_frames']} ({frames['dancing_percentage']}%)")
        print(f"  Frames em repouso: {frames['idle_frames']} ({frames['idle_percentage']}%)")
        
        # Nova seção: Análise avançada de caminhada
        walking_enhanced = summary["enhanced_walking_analysis"]
        print(f"\n🚶 ANÁLISE AVANÇADA DE CAMINHADA:")
        
        # Análise de visibilidade
        vis_data = walking_enhanced["visibility_analysis"]
        print(f"  📈 QUALIDADE DA POSE:")
        print(f"    Score médio de visibilidade: {vis_data['average_visibility_score']}")
        print(f"    Alta visibilidade: {vis_data['high_visibility_frames']} frames ({vis_data['high_vis_percentage']}%)")
        print(f"    Média visibilidade: {vis_data['medium_visibility_frames']} frames ({vis_data['medium_vis_percentage']}%)")
        print(f"    Baixa visibilidade: {vis_data['low_visibility_frames']} frames ({vis_data['low_vis_percentage']}%)")
        
        # Scores de movimento
        movement_scores = walking_enhanced["movement_scores"]
        print(f"  🎯 SCORES DE MOVIMENTO:")
        print(f"    Movimento do quadril: {movement_scores['average_hip_movement']}")
        print(f"    Alternância dos joelhos: {movement_scores['average_knee_alternation']}")
        print(f"    Movimento dos tornozelos: {movement_scores['average_ankle_movement']}")
        print(f"    Balanço dos braços: {movement_scores['average_arm_swing']}")
        print(f"    Equilíbrio corporal: {movement_scores['average_balance']}")
        
        # Estatísticas de score
        score_stats = walking_enhanced["walking_score_statistics"]
        print(f"  📊 ESTATÍSTICAS DE DETECÇÃO:")
        print(f"    Score médio geral: {score_stats['average_score']}")
        print(f"    Score máximo: {score_stats['max_score']}")
        print(f"    Score mínimo: {score_stats['min_score']}")
        print(f"    Variabilidade: {score_stats['score_variability']}")
        
        # Distribuição de confiança
        confidence_dist = walking_enhanced["confidence_distribution"]
        print(f"  🎖️ DISTRIBUIÇÃO DE CONFIANÇA:")
        for conf_level, count in confidence_dist.items():
            print(f"    {conf_level}: {count} frames")
        
        # Modos de análise
        mode_dist = walking_enhanced["analysis_mode_distribution"]
        print(f"  🔍 MODOS DE ANÁLISE UTILIZADOS:")
        for mode, count in mode_dist.items():
            print(f"    {mode}: {count} frames")
        
        # Análise de faces
        faces = summary["face_analysis"]
        print(f"\n👥 ANÁLISE DE FACES:")
        print(f"  Total de faces detectadas: {faces['total_faces_detected']}")
        print(f"  Frames com faces: {faces['frames_with_faces']} ({faces['face_presence_percentage']}%)")
        print(f"  Máximo de faces por frame: {faces['max_faces_per_frame']}")
        print(f"  Média de faces por frame: {faces['average_faces_per_frame']}")
        
        # Análise de emoções
        emotions = summary["emotion_analysis"]
        print(f"\n😊 ANÁLISE DE EMOÇÕES:")
        print(f"  Emoção mais comum: {emotions['most_common_emotion']}")
        print(f"  Diversidade emocional: {emotions['emotion_diversity']} emoções diferentes")
        if emotions['emotions_detected']:
            print("  Distribuição de emoções:")
            for emotion, count in emotions['emotions_detected'].items():
                print(f"    {emotion}: {count} detecções")
        
        # Reconhecimento de pessoas
        people = summary["people_recognition"]
        print(f"\n🔍 RECONHECIMENTO DE PESSOAS:")
        print(f"  Pessoas únicas reconhecidas: {people['unique_people_count']}")
        print(f"  Pessoa mais frequente: {people['most_frequent_person']}")
        if people['people_recognized']:
            print("  Frequência de reconhecimento:")
            for person, count in people['people_recognized'].items():
                print(f"    {person}: {count} detecções")
        
        # Interpretações melhoradas
        print(f"\n💡 INTERPRETAÇÕES AVANÇADAS:")
        for interpretation in summary["interpretation"]:
            print(f"  • {interpretation}")
        
        print("\n" + "="*70)
    
    def configure_walking_sensitivity(self, high_vis_threshold=0.85, medium_vis_threshold=0.70, low_vis_threshold=0.50):
        """Configura a sensibilidade do detector de caminhada"""
        self.walking_detector.configure_visibility_thresholds(
            high_vis=high_vis_threshold,
            medium_vis=medium_vis_threshold,
            low_vis=low_vis_threshold
        )
        print(f"Limites de visibilidade configurados: Alta={high_vis_threshold}, Média={medium_vis_threshold}, Baixa={low_vis_threshold}")
    
    def cleanup(self):
        """Limpa recursos dos detectores"""
        self.waving_detector.cleanup()
        self.walking_detector.cleanup()
        # Face detector não precisa de cleanup específico

def draw_enhanced_hud(frame, status_dict, face_info=None):
    """
    Desenha interface de usuário com informações de status melhoradas
    
    Args:
        frame: Frame para desenhar
        status_dict: Dicionário com status das detecções
        face_info: Lista com informações de faces detectadas
    """
    # Calcula altura do HUD baseado no conteúdo
    base_height = 280  # Aumentado para incluir mais informações
    face_height = max(30 * len(face_info), 0) if face_info else 0
    hud_height = base_height + face_height
    
    # Fundo semi-transparente
    overlay = frame.copy()
    cv2.rectangle(overlay, (10, 10), (550, hud_height), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
    
    # Textos de status principais
    y_offset = 35
    cv2.putText(frame, f"Movements/Poses: {status_dict['combined']}", (20, y_offset),
                cv2.FONT_HERSHEY_SIMPLEX, 0.8, (0, 255, 255), 2)
    
    y_offset += 25
    cv2.putText(frame, f"Waving: {status_dict['waving']}", (20, y_offset),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 0), 1)
    
    y_offset += 25
    cv2.putText(frame, f"Walking: {status_dict['walking']}", (20, y_offset),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (0, 255, 0), 1)
    
    # Informações melhoradas do walking detector
    y_offset += 20
    cv2.putText(frame, "=== WALKING ANALYSIS ===", (20, y_offset),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)
    
    y_offset += 20
    visibility = status_dict.get('walking_visibility', 0)
    analysis_mode = status_dict.get('walking_analysis_mode', 'none')
    cv2.putText(frame, f"Visibility: {visibility:.2f} ({analysis_mode})", (20, y_offset),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 200, 200), 1)
    
    y_offset += 20
    confidence = status_dict.get('walking_confidence', 'none')
    overall_score = status_dict.get('walking_overall_score', 0)
    cv2.putText(frame, f"Confidence: {confidence} (Score: {overall_score:.1f})", (20, y_offset),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (0, 200, 200), 1)
    
    y_offset += 20
    hip_score = status_dict.get('walking_hip_score', 0)
    knee_score = status_dict.get('walking_knee_score', 0)
    cv2.putText(frame, f"Hip: {hip_score:.1f} | Knee: {knee_score:.1f}", (20, y_offset),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (150, 200, 255), 1)
    
    y_offset += 20
    balance_score = status_dict.get('walking_balance_score', 0)
    cv2.putText(frame, f"Balance: {balance_score:.1f}", (20, y_offset),
                cv2.FONT_HERSHEY_SIMPLEX, 0.45, (150, 200, 255), 1)
    
    y_offset += 25
    cv2.putText(frame, f"Faces: {status_dict.get('face_count', 0)}", (20, y_offset),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 0, 255), 1)
    
    # Contador de frames total
    y_offset += 25
    cv2.putText(frame, f"Total Frames: {status_dict.get('total_frames', 0)}", (20, y_offset),
                cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 128, 0), 1)
    
    # Informações das faces detectadas
    if face_info:
        y_offset += 17
        cv2.putText(frame, "Face Details:", (20, y_offset),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.5, (200, 200, 200), 1)
        
        for i, face in enumerate(face_info[:3]):  # Mostra no máximo 3 faces
            y_offset += 25
            name = face.get('name', 'Unknown')
            emotion = face.get('emotion', 'unknown')
            cv2.putText(frame, f"  {name}: {emotion}", (20, y_offset),
                       cv2.FONT_HERSHEY_SIMPLEX, 0.5, (150, 200, 255), 1)
    
    # Instruções
    cv2.putText(frame, "Press ESC to exit, 'r' to reset, 'c' to configure", 
                (20, frame.shape[0] - 20),
                cv2.FONT_HERSHEY_SIMPLEX, 0.5, (255, 255, 255), 1)

def draw_enhanced_summary_overlay(frame, summary_data):
    """
    Desenha o resumo automático melhorado do vídeo no frame
    VERSÃO MELHORADA com informações do detector avançado
    
    Args:
        frame: Frame para desenhar o resumo
        summary_data: Dicionário com dados do resumo gerado por generate_summary()
    """
    if not summary_data or "error" in summary_data:
        return
    
    start_x = 650
    start_y = 30
    line_height = 22
    font = cv2.FONT_HERSHEY_SIMPLEX
    font_scale = 0.55
    thickness = 1
    
    # Calcula altura total necessária para o overlay
    total_lines = 40  # Aumentado para incluir análise avançada
    overlay_height = start_y + (total_lines * line_height) + 50
    overlay_width = 600  # Largura aumentada
    
    # Cria fundo semi-transparente
    overlay = frame.copy()
    cv2.rectangle(overlay, (start_x - 10, 10), 
                 (start_x + overlay_width, overlay_height), (0, 0, 0), -1)
    cv2.addWeighted(overlay, 0.7, frame, 0.3, 0, frame)
    
    # Título do resumo
    y_pos = start_y
    cv2.putText(frame, "VIDEO ANALYSIS REPORT", (start_x, y_pos),
                font, 0.8, (0, 255, 255), 2)
    
    y_pos += line_height + 10
    
    # Análise de Frames
    frames_data = summary_data["frames_analysis"]
    cv2.putText(frame, "FRAME ANALYSIS:", (start_x, y_pos),
                font, 0.7, (255, 255, 0), thickness)
    
    y_pos += line_height
    cv2.putText(frame, f"Total: {frames_data['total_frames']} frames", (start_x + 10, y_pos),
                font, font_scale, (255, 255, 255), thickness)
    
    y_pos += line_height
    cv2.putText(frame, f"Walking: {frames_data['walking_frames']} ({frames_data['walking_percentage']}%)", 
                (start_x + 10, y_pos), font, font_scale, (0, 255, 0), thickness)
    
    y_pos += line_height
    cv2.putText(frame, f"Waving: {frames_data['waving_frames']} ({frames_data['waving_percentage']}%)", 
                (start_x + 10, y_pos), font, font_scale, (255, 255, 0), thickness)
    
    y_pos += line_height
    cv2.putText(frame, f"Dancing: {frames_data['dancing_frames']} ({frames_data['dancing_percentage']}%)", 
                (start_x + 10, y_pos), font, font_scale, (0, 255, 255), thickness)
    
    y_pos += line_height + 5
    
    # Análise avançada de caminhada
    walking_enhanced = summary_data.get("enhanced_walking_analysis", {})
    if walking_enhanced:
        cv2.putText(frame, "ADVANCED WALKING ANALYSIS:", (start_x, y_pos),
                    font, 0.7, (0, 255, 128), thickness)
        
        # Análise de visibilidade
        vis_data = walking_enhanced.get("visibility_analysis", {})
        y_pos += line_height
        cv2.putText(frame, f"Avg visibility: {vis_data.get('average_visibility_score', 0):.2f}", 
                    (start_x + 10, y_pos), font, font_scale, (255, 255, 255), thickness)
        
        y_pos += line_height
        cv2.putText(frame, f"High quality: {vis_data.get('high_vis_percentage', 0)}%", 
                    (start_x + 10, y_pos), font, font_scale, (0, 255, 128), thickness)
        
        # Scores de movimento
        movement_scores = walking_enhanced.get("movement_scores", {})
        y_pos += line_height
        cv2.putText(frame, f"Hip: {movement_scores.get('average_hip_movement', 0):.1f} | Knee: {movement_scores.get('average_knee_alternation', 0):.1f}", 
                    (start_x + 10, y_pos), font, 0.5, (200, 200, 255), thickness)
        
        y_pos += line_height
        cv2.putText(frame, f"Balance: {movement_scores.get('average_balance', 0):.1f} | Arm: {movement_scores.get('average_arm_swing', 0):.1f}", 
                    (start_x + 10, y_pos), font, 0.5, (200, 200, 255), thickness)
        
        # Estatísticas de score
        score_stats = walking_enhanced.get("walking_score_statistics", {})
        y_pos += line_height
        cv2.putText(frame, f"Avg score: {score_stats.get('average_score', 0):.1f} (range: {score_stats.get('min_score', 0):.1f}-{score_stats.get('max_score', 0):.1f})", 
                    (start_x + 10, y_pos), font, 0.5, (100, 255, 200), thickness)
        
        y_pos += line_height + 5
    
    # Análise de Faces
    face_data = summary_data["face_analysis"]
    cv2.putText(frame, "FACE ANALYSIS:", (start_x, y_pos),
                font, 0.7, (255, 0, 255), thickness)
    
    y_pos += line_height
    cv2.putText(frame, f"Faces detected: {face_data['total_faces_detected']}", 
                (start_x + 10, y_pos), font, font_scale, (255, 255, 255), thickness)
    
    y_pos += line_height
    cv2.putText(frame, f"Face presence: {face_data['face_presence_percentage']}%", 
                (start_x + 10, y_pos), font, font_scale, (255, 0, 255), thickness)
    
    y_pos += line_height + 5
    
    # Análise de Emoções
    emotion_data = summary_data["emotion_analysis"]
    cv2.putText(frame, "EMOTION ANALYSIS:", (start_x, y_pos),
                font, 0.7, (0, 255, 0), thickness)
    
    y_pos += line_height
    cv2.putText(frame, f"Most common: {emotion_data['most_common_emotion']}", 
                (start_x + 10, y_pos), font, font_scale, (255, 255, 255), thickness)
    
    y_pos += line_height
    cv2.putText(frame, f"Diversity: {emotion_data['emotion_diversity']} types", 
                (start_x + 10, y_pos), font, font_scale, (0, 255, 0), thickness)
    
    y_pos += line_height + 5
    
    # Interpretações principais (máximo 4 linhas)
    cv2.putText(frame, "KEY INSIGHTS:", (start_x, y_pos),
                font, 0.7, (255, 255, 255), thickness)
    
    interpretations = summary_data.get("interpretation", [])[:4]
    for interpretation in interpretations:
        y_pos += line_height
        # Quebra texto longo se necessário
        if len(interpretation) > 60:
            interpretation = interpretation[:57] + "..."
        cv2.putText(frame, f"• {interpretation}", 
                   (start_x + 10, y_pos), font, 0.45, (200, 200, 200), thickness)


def process_enhanced_video(video_path, detector_type='all', enable_face_detection=True, images_folder='images', visibility_config=None):
    """
    Versão melhorada da função process_video com detector de caminhada avançado
    
    Args:
        video_path: Caminho do vídeo
        detector_type: Tipo de detector ('waving', 'walking', 'face', 'all')
        enable_face_detection: Se deve habilitar detecção facial
        images_folder: Pasta com imagens de referência
        visibility_config: Configuração de visibilidade customizada
    """
    cap = cv2.VideoCapture(video_path)
    script_dir = os.path.dirname(os.path.abspath(__file__))
    output_path = os.path.join(script_dir, 'TechChallenge_Enhanced_Processed.mp4')
    
    # Obter propriedades do vídeo
    width = int(cap.get(cv2.CAP_PROP_FRAME_WIDTH))
    height = int(cap.get(cv2.CAP_PROP_FRAME_HEIGHT))
    fps = int(cap.get(cv2.CAP_PROP_FPS))
    total_frames = int(cap.get(cv2.CAP_PROP_FRAME_COUNT))

    # Definir o codec e criar o objeto VideoWriter
    fourcc = cv2.VideoWriter_fourcc(*'mp4v')
    out = cv2.VideoWriter(output_path, fourcc, fps, (width, height))

    if not cap.isOpened():
        print(f"Erro ao abrir vídeo: {video_path}")
        return
    
    print(f"Vídeo carregado: {total_frames} frames totais, {fps} FPS")
    
    # Configuração de visibilidade customizada
    if visibility_config is None:
        visibility_config = VisibilityConfig(
            high_visibility_threshold=0.85,
            medium_visibility_threshold=0.70,
            low_visibility_threshold=0.50,
            use_ankles_high_vis=True,
            use_arm_swing_medium_vis=True,
            use_balance_analysis=True
        )
    
    # Inicializa detectores baseado no tipo
    if detector_type == 'all':
        detector = MultiActionDetector(enable_face_detection, images_folder, visibility_config)
        window_name = "Multi-Action Detector"
    elif detector_type == 'waving':
        detector = WavingDetector()
        window_name = "Waving Detector"
    elif detector_type == 'walking':
        detector = WalkingDetector(visibility_config=visibility_config)
        window_name = "Walking Detector"
    elif detector_type == 'face':
        detector = FaceEmotionDetector(images_folder)
        window_name = "Face & Emotion Detector"
    else:
        print("Tipo de detector inválido. Use 'waving', 'walking', 'face' ou 'all'")
        return
    
    try:
        frame_count = 0
        last_processed_frame = None
        
        while cap.isOpened():
            ret, frame = cap.read()
            if not ret:
                break
            
            frame_count += 1
            print(f"Processando frame {frame_count}/{total_frames}", end='\r')
            
            if detector_type == 'all':
                is_waving, is_walking, processed_frame, status_dict, face_info = detector.detect_actions(frame)
                draw_enhanced_hud(processed_frame, status_dict, face_info)
            elif detector_type == 'waving':
                is_waving, processed_frame, status = detector.detect_waving(frame)
                cv2.rectangle(processed_frame, (10, 10), (300, 60), (0, 0, 0), -1)
                cv2.putText(processed_frame, f"Status: {status}", (20, 45),
                           cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
            elif detector_type == 'walking':
                is_walking, processed_frame, status, debug_info = detector.detect_walking(frame)
                cv2.putText(processed_frame, f"Status: {status}", (20, 40),
                           cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
                # Adiciona informações de debug para walking detector
                if debug_info and 'metrics' in debug_info:
                    metrics = debug_info['metrics']
                    cv2.putText(processed_frame, f"Mode: {metrics.analysis_mode}", (20, 70),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
                    cv2.putText(processed_frame, f"Score: {metrics.overall_walking_score:.1f}", (20, 100),
                               cv2.FONT_HERSHEY_SIMPLEX, 0.6, (255, 255, 255), 1)
            elif detector_type == 'face':
                processed_frame, face_info = detector.detect_faces_and_emotions(frame)
            
            # Se é o último frame e temos detector completo, adiciona o resumo melhorado
            if frame_count == total_frames and detector_type == 'all' and hasattr(detector, 'generate_summary'):
                summary_data = detector.generate_summary()
                draw_enhanced_summary_overlay(processed_frame, summary_data)
                print(f"\nResumo melhorado adicionado ao último frame!")
            
            # Escrever o frame processado no vídeo de saída
            out.write(processed_frame)
            last_processed_frame = processed_frame.copy()
            cv2.imshow(window_name, processed_frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == 27:  # ESC
                break
            elif key == ord('r') and detector_type == 'all':  # Reset buffers
                detector.waving_detector.reset_buffers()
                detector.walking_detector.reset_buffers()
                print("\nBuffers resetados!")
            elif key == ord('c') and detector_type == 'all':  # Configure thresholds
                print("\nConfigurando limites de visibilidade...")
                detector.configure_walking_sensitivity(0.80, 0.65, 0.45)
                
    finally:
        print(f"\nProcessamento concluído! {frame_count} frames processados.")
        cap.release()
        out.release()
        cv2.destroyAllWindows()
        
        # Gera e exibe resumo melhorado apenas para detector completo
        if detector_type == 'all' and hasattr(detector, 'print_summary'):
            detector.print_summary()
            detector.save_summary_to_file(f"enhanced_resumo_{os.path.basename(video_path)}.json")
        
        detector.cleanup()

def process_enhanced_webcam(detector_type='all', enable_face_detection=True, images_folder='images', visibility_config=None):
    """
    Processa feed da webcam com detecção de ações melhorada.
    
    Args:
        detector_type: Tipo de detector ('waving', 'walking', 'face', 'all')
        enable_face_detection: Se deve habilitar detecção facial
        images_folder: Pasta com imagens de referência
        visibility_config: Configuração de visibilidade customizada
    """
    cap = cv2.VideoCapture(0)
    
    if not cap.isOpened():
        print("Erro ao abrir webcam")
        return
    
    # Configuração de visibilidade customizada
    if visibility_config is None:
        visibility_config = VisibilityConfig(
            high_visibility_threshold=0.85,
            medium_visibility_threshold=0.70,
            low_visibility_threshold=0.50
        )
    
    # Inicializa detectores baseado no tipo
    if detector_type == 'all':
        detector = MultiActionDetector(enable_face_detection, images_folder, visibility_config)
        window_name = "Multi-Action Detector - Webcam"
    elif detector_type == 'waving':
        detector = WavingDetector()
        window_name = "Waving Detector - Webcam"
    elif detector_type == 'walking':
        detector = WalkingDetector(visibility_config=visibility_config)
        window_name = "Walking Detector - Webcam"
    elif detector_type == 'face':
        detector = FaceEmotionDetector(images_folder)
        window_name = "Face & Emotion Detector - Webcam"
    else:
        print("Tipo de detector inválido. Use 'waving', 'walking', 'face' ou 'all'")
        return
    
    print(f"Iniciando webcam com detector melhorado: {detector_type}")
    print("Teclas: ESC=sair, 'r'=reset, 'c'=configurar sensibilidade")
    
    try:
        frame_count = 0
        while True:
            ret, frame = cap.read()
            if not ret:
                break
            
            # Espelha a imagem da webcam para ficar mais natural
            frame = cv2.flip(frame, 1)
            frame_count += 1
            
            if detector_type == 'all':
                is_waving, is_walking, processed_frame, status_dict, face_info = detector.detect_actions(frame)
                draw_enhanced_hud(processed_frame, status_dict, face_info)
                
                # Mostra informações de debug periodicamente
                if frame_count % 60 == 0:  # A cada 2 segundos (30fps)
                    print(f"Frame {frame_count}: Walking={is_walking}, Mode={status_dict.get('walking_analysis_mode', 'none')}, Score={status_dict.get('walking_overall_score', 0):.1f}")
                    
            elif detector_type == 'waving':
                is_waving, processed_frame, status = detector.detect_waving(frame)
                cv2.rectangle(processed_frame, (10, 10), (300, 60), (0, 0, 0), -1)
                cv2.putText(processed_frame, f"Status: {status}", (20, 45),
                           cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 255), 2)
            elif detector_type == 'walking':
                is_walking, processed_frame, status, debug_info = detector.detect_walking(frame)
                cv2.putText(processed_frame, f"Status: {status}", (20, 40),
                           cv2.FONT_HERSHEY_SIMPLEX, 1, (0, 255, 0), 2)
            elif detector_type == 'face':
                processed_frame, face_info = detector.detect_faces_and_emotions(frame)
            
            cv2.imshow(window_name, processed_frame)
            
            key = cv2.waitKey(1) & 0xFF
            if key == 27:  # ESC
                break
            elif key == ord('r') and detector_type in ['all', 'walking']:  # Reset buffers
                if detector_type == 'all':
                    detector.waving_detector.reset_buffers()
                    detector.walking_detector.reset_buffers()
                else:
                    detector.reset_buffers()
                print("Buffers resetados!")
            elif key == ord('c') and detector_type in ['all', 'walking']:  # Configure thresholds
                print("Configurando limites de visibilidade para detecção mais sensível...")
                if detector_type == 'all':
                    detector.configure_walking_sensitivity(0.80, 0.60, 0.40)
                else:
                    detector.configure_visibility_thresholds(0.80, 0.60, 0.40)
                
    finally:
        cap.release()
        cv2.destroyAllWindows()
        
        # Exibe resumo da sessão webcam se for detector completo
        if detector_type == 'all' and hasattr(detector, 'print_summary'):
            print("\nResumo da sessão webcam melhorada:")
            detector.print_summary()
        
        detector.cleanup()

def main():
    """Função principal do programa melhorado"""
    parser = argparse.ArgumentParser(description='Detector de Ações Humanas Melhorado')
    parser.add_argument('--video', '-v', type=str, help='Caminho do vídeo')
    parser.add_argument('--webcam', '-w', action='store_true', help='Usar webcam')
    parser.add_argument('--detector', '-d', type=str, default='all',
                       choices=['waving', 'walking', 'all'],
                       help='Tipo de detector a usar')
    parser.add_argument('--high-vis', type=float, default=0.85,
                       help='Limiar de alta visibilidade (padrão: 0.85)')
    parser.add_argument('--medium-vis', type=float, default=0.70,
                       help='Limiar de média visibilidade (padrão: 0.70)')
    parser.add_argument('--low-vis', type=float, default=0.50,
                       help='Limiar de baixa visibilidade (padrão: 0.50)')
    
    args = parser.parse_args()
    
    # Criar configuração de visibilidade customizada
    visibility_config = VisibilityConfig(
        high_visibility_threshold=args.high_vis,
        medium_visibility_threshold=args.medium_vis,
        low_visibility_threshold=args.low_vis,
        use_ankles_high_vis=True,
        use_arm_swing_medium_vis=True,
        use_balance_analysis=True
    )
    
    print(f"Configuração de visibilidade: Alta={args.high_vis}, Média={args.medium_vis}, Baixa={args.low_vis}")
    
    if args.webcam:
        print(f"Iniciando detecção melhorada na webcam com detector: {args.detector}")
        process_enhanced_webcam(args.detector, visibility_config=visibility_config)
    elif args.video:
        print(f"Processando vídeo: {args.video} com detector melhorado: {args.detector}")
        process_enhanced_video(args.video, args.detector, visibility_config=visibility_config)
    else:
        print("Uso do Detector Melhorado:")
        print("  python enhanced_main_detector.py --webcam --detector all")
        print("  python enhanced_main_detector.py --video path/to/video.mp4 --detector walking")
        print("  python enhanced_main_detector.py --video path/to/video.mp4 --detector all --high-vis 0.90 --medium-vis 0.75")
        print("\nParâmetros de visibilidade:")
        print("  --high-vis: Limiar para alta qualidade de pose (padrão: 0.85)")
        print("  --medium-vis: Limiar para média qualidade de pose (padrão: 0.70)")
        print("  --low-vis: Limiar para baixa qualidade de pose (padrão: 0.50)")

if __name__ == "__main__":
    main()